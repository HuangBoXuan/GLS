# MiniGame 核心 SDK 0.2.0

稳定接入层包含账号认证、认证网络、广告调度、账号/游戏隔离存档、通用游戏请求，以及模块清单和生命周期契约。它不依赖 Unity 宿主、xLua、Garden DTO 或构建工具。账号与广告属于 SDK 的共用服务；原生广告商驱动由产品注入。

运行 Lua/AssetBundle 小游戏应安装配套 com.minigame.platform-host；开发导出再安装 com.minigame.platform-authoring。核心 SDK 自身不提供 Unity 播放器。

小游戏玩法、进度格式、奖励、排行榜字段由游戏与服务端负责。Requests 仅访问宿主绑定的 /v1/games/<gameId>/ 范围，取消只移除回调，不撤销服务器已执行的操作。共用资产与排行榜仍由在线有效结算驱动。

0.1.0 到 0.2.0 涉及包和程序集拆分。旧 host.Platform 游戏专属入口已移除，需迁移到 host.Services 和游戏自己的业务适配。

2026-09-30 工作区扩展（尚未生成新的发行快照）：PlatformSession 支持 BindAccount / LoginAccount / GetAccountBinding / ResumeSession。账号采用邮箱格式＋密码，不验证邮箱；绑定沿用同一 userId，不保存密码。新服务端端点必须单独实现后才能上线使用，详见工程 docs/architecture/password-account-binding-2026-09-30.md。
