using System;
using MiniGamePlatform.SDK.Network;
using UnityEngine;
using UnityEngine.Scripting;

namespace MiniGamePlatform.SDK.Auth
{
    [Serializable, Preserve]
    public sealed class AccountBinding
    {
        public string userId;
        public string accountName;
        public bool isBound;
    }

    public sealed partial class PlatformSession
    {
        private long _bindingRevision;
        [Serializable, Preserve] private sealed class BindAccountBody
        { public string accountName; public string password; public string productId; }
        [Serializable, Preserve] private sealed class LoginAccountBody
        { public string accountName; public string password; public string productId; public string deviceId; }

        /// <summary>Cached hint only. GetAccountBinding reads the authoritative binding.</summary>
        public string AccountName => _state.AccountName;

        public void BindAccount(string accountName, string password, Action<ApiResult<AccountBinding>> callback)
        {
            if (callback == null) throw new ArgumentNullException(nameof(callback));
            string name = NormalizeAccountName(accountName);
            ValidatePassword(password);
            if (string.IsNullOrEmpty(UserId)) { callback(ApiResult<AccountBinding>.NetworkFailure("NO_SESSION", false)); return; }
            string json = JsonUtility.ToJson(new BindAccountBody { accountName = name, password = password, productId = _productId });
            ReadBinding(new ApiRequest("POST", "/v1/platform/auth/account/bind", json, productId: _productId), name, callback);
        }

        public void GetAccountBinding(Action<ApiResult<AccountBinding>> callback)
        {
            if (callback == null) throw new ArgumentNullException(nameof(callback));
            if (string.IsNullOrEmpty(UserId)) { callback(ApiResult<AccountBinding>.NetworkFailure("NO_SESSION", false)); return; }
            ReadBinding(new ApiRequest("GET", "/v1/platform/auth/account", productId: _productId), null, callback);
        }

        private void ReadBinding(ApiRequest request, string requiredName, Action<ApiResult<AccountBinding>> callback)
        {
            string user = UserId;
            long version = IdentityVersion;
            long bindingRevision = _bindingRevision;
            SendAuthorized<AccountBinding>(request, result =>
            {
                if (version != IdentityVersion || user != UserId)
                { callback(result.WithError("ACCOUNT_CHANGED", "Binding belongs to the previous account.", false)); return; }
                if (requiredName == null && bindingRevision != _bindingRevision)
                { callback(result.WithError("BINDING_CHANGED", "Binding changed while this query was in flight; query again.", true)); return; }
                if (!result.IsSuccess) { callback(result); return; }
                AccountBinding binding = result.Data;
                if (binding == null || binding.userId != user ||
                    (binding.isBound ? !IsCanonicalAccountName(binding.accountName) : !string.IsNullOrEmpty(binding.accountName)) ||
                    (requiredName != null && (!binding.isBound || binding.accountName != requiredName)))
                { callback(result.WithError("INVALID_RESPONSE", "Invalid account binding response.", false)); return; }
                // Preserve any refresh rotation that completed while this request was in flight.
                CredentialState next = _state.Copy();
                next.AccountName = binding.isBound ? binding.accountName : null;
                try { _store.Save(next); }
                catch (Exception)
                { callback(result.WithError("CREDENTIAL_STORAGE_FAILED", "Could not save account binding; query its status before retrying.", true)); return; }
                // Metadata is not an identity change. Keep the state reference used
                // by in-flight refresh/guest recovery, updating it only after Save.
                _state.AccountName = next.AccountName;
                if (requiredName != null) _bindingRevision++;
                callback(result);
            }, user);
        }

        public void LoginAccount(string accountName, string password, Action<ApiResult<SessionIdentity>> callback)
        {
            if (callback == null) throw new ArgumentNullException(nameof(callback));
            string name = NormalizeAccountName(accountName);
            ValidatePassword(password);
            long version = IdentityVersion;
            string json = JsonUtility.ToJson(new LoginAccountBody
            { accountName = name, password = password, productId = _productId, deviceId = _state.DeviceId });
            // Never attach the previous guest's bearer token to password authentication.
            _transport.Send<SessionIdentity>(new ApiRequest("POST", "/v1/platform/auth/account/login", json, productId: _productId), result =>
            {
                if (version != IdentityVersion)
                { callback(result.WithError("ACCOUNT_CHANGED", "Obsolete password login response.", false)); return; }
                if (!result.IsSuccess) { callback(result); return; }
                SessionIdentity identity = result.Data;
                if (identity == null || identity.accountName != name || string.IsNullOrWhiteSpace(identity.userId) ||
                    string.IsNullOrWhiteSpace(identity.guestCredential) || string.IsNullOrWhiteSpace(identity.accessToken) ||
                    string.IsNullOrWhiteSpace(identity.refreshToken) || identity.expiresInSeconds <= 0 || identity.refreshExpiresInSeconds <= 0)
                { callback(result.WithError("INVALID_RESPONSE", "Incomplete password login identity.", false)); return; }
                try { PersistIdentity(identity, true); }
                catch (Exception)
                { callback(result.WithError("CREDENTIAL_STORAGE_FAILED", "Could not save login credentials.", true)); return; }
                callback(result);
            });
        }

        /// <summary>Bound accounts reuse tokens; passwords are never stored by the SDK.</summary>
        public void ResumeSession(Action<ApiResult<SessionIdentity>> callback)
        {
            if (callback == null) throw new ArgumentNullException(nameof(callback));
            if (string.IsNullOrEmpty(AccountName)) { ResumeGuest(callback); return; }
            if (string.IsNullOrEmpty(_state.RefreshToken)) { ResumeGuest(callback); return; }
            long version = IdentityVersion;
            WithAccessToken(token =>
            {
                if (version != IdentityVersion)
                { callback(ApiResult<SessionIdentity>.NetworkFailure("ACCOUNT_CHANGED", false)); return; }
                callback(ApiResult<SessionIdentity>.FromData(new SessionIdentity
                {
                    userId = UserId, accountName = AccountName, guestCredential = _state.GuestCredential,
                    accessToken = token, refreshToken = _state.RefreshToken,
                    expiresInSeconds = Math.Max(1, (int)(_accessExpiresAt - DateTime.UtcNow).TotalSeconds)
                }));
            }, error => callback(ApiResult<SessionIdentity>.NetworkFailure(error, _refreshRetryable)));
        }

        private static string NormalizeAccountName(string value)
        {
            if (value == null) throw new ArgumentNullException(nameof(value));
            string name = value.Trim().ToLowerInvariant();
            int at = name.IndexOf('@');
            if (name.Length > 254 || at <= 0 || at != name.LastIndexOf('@') || at == name.Length - 1)
                throw new ArgumentException("Account must have email format.", nameof(value));
            foreach (char c in name)
                if (c <= 32 || c > 126) throw new ArgumentException("Account must contain printable ASCII without spaces.", nameof(value));
            return name;
        }

        private static bool IsCanonicalAccountName(string value)
        {
            try { return value == NormalizeAccountName(value); }
            catch (ArgumentException) { return false; }
        }

        private static void ValidatePassword(string password)
        {
            if (password == null) throw new ArgumentNullException(nameof(password));
            if (password.Length < 8 || password.Length > 128 || string.IsNullOrWhiteSpace(password))
                throw new ArgumentException("Password must contain 8 to 128 printable ASCII characters.", nameof(password));
            foreach (char c in password)
                if (c < 32 || c > 126) throw new ArgumentException("Password must contain printable ASCII characters.", nameof(password));
        }
    }
}
