using System;

namespace MiniGamePlatform.SDK.Auth
{
    [Serializable]
    public sealed class CredentialState
    {
        public string DeviceId;
        public string UserId;
        public string AccountName;
        public string GuestCredential;
        public string RefreshToken;
        public string PendingRefreshKey;
        public long PendingRefreshStartedAtUnixSeconds;

        public CredentialState Copy()
        {
            return new CredentialState
            {
                DeviceId = DeviceId,
                UserId = UserId,
                AccountName = AccountName,
                GuestCredential = GuestCredential,
                RefreshToken = RefreshToken,
                PendingRefreshKey = PendingRefreshKey,
                PendingRefreshStartedAtUnixSeconds = PendingRefreshStartedAtUnixSeconds
            };
        }
    }

    public interface ICredentialStore
    {
        void Save(CredentialState state);
        bool TryLoad(out CredentialState state);
        void Clear();
    }
}
