using System;
using System.Collections.Generic;
using MiniGamePlatform.SDK.Network;
using UnityEngine;

namespace MiniGamePlatform.SDK.Auth
{
    [Serializable]
    public sealed class SessionIdentity
    {
        public string userId;
        public string accountName;
        public string guestCredential;
        public string accessToken;
        public string refreshToken;
        public int expiresInSeconds;
        public int refreshExpiresInSeconds;
    }

    [Serializable]
    public sealed class LinkCode
    {
        public string code;
        public int expiresInSeconds;
    }

    public sealed partial class PlatformSession
    {
        [Serializable] private sealed class GuestCreateBody { public string deviceId; public string productId; }
        [Serializable] private sealed class GuestResumeBody { public string deviceId; public string productId; public string guestCredential; }
        [Serializable] private sealed class RefreshBody { public string refreshToken; public string deviceId; }
        [Serializable] private sealed class RedeemBody { public string code; public string productId; }
        [Serializable] private sealed class LogoutBody { public string refreshToken; }

        private readonly IPlatformTransport _transport;
        private readonly ICredentialStore _store;
        private readonly string _productId;
        private CredentialState _state;
        private string _accessToken;
        private DateTime _accessExpiresAt;
        private string _userId;
        private bool _refreshInFlight;
        private readonly List<Action<bool>> _refreshWaiters = new List<Action<bool>>();
        private string _refreshErrorCode;
        private bool _refreshRetryable;

        public string UserId { get { return _userId; } }
        public long IdentityVersion { get; private set; }
        public event Action IdentityChanged;

        public PlatformSession(IPlatformTransport transport, ICredentialStore store, string productId)
        {
            _transport = transport ?? throw new ArgumentNullException(nameof(transport));
            _store = store ?? throw new ArgumentNullException(nameof(store));
            if (string.IsNullOrWhiteSpace(productId)) throw new ArgumentException("Product ID is required.", nameof(productId));
            _productId = productId;
            if (!_store.TryLoad(out _state)) _state = new CredentialState { DeviceId = Guid.NewGuid().ToString("N") };
            if (string.IsNullOrWhiteSpace(_state.DeviceId)) throw new InvalidOperationException("Stored device ID is missing.");
            _userId = _state.UserId;
        }

        public void LoginGuest(Action<ApiResult<SessionIdentity>> callback)
        {
            if (callback == null) throw new ArgumentNullException(nameof(callback));
            string json = JsonUtility.ToJson(new GuestCreateBody { deviceId = _state.DeviceId, productId = _productId });
            long version = IdentityVersion;
            _transport.Send<SessionIdentity>(new ApiRequest("POST", "/v1/platform/auth/guest", json), result =>
            {
                if (version != IdentityVersion) { callback(result.WithError("ACCOUNT_CHANGED", "Obsolete login response.", true)); return; }
                CompleteGuestLogin(result, callback);
            });
        }

        public void ResumeGuest(Action<ApiResult<SessionIdentity>> callback)
        { ResumeGuest(callback, false); }

        private void ResumeGuest(Action<ApiResult<SessionIdentity>> callback, bool preserveIdentity)
        {
            if (callback == null) throw new ArgumentNullException(nameof(callback));
            if (string.IsNullOrEmpty(_state.GuestCredential))
            {
                if (!string.IsNullOrEmpty(_state.UserId)) callback(ApiResult<SessionIdentity>.NetworkFailure("LOGIN_REQUIRED", false));
                else LoginGuest(callback);
                return;
            }
            string json = JsonUtility.ToJson(new GuestResumeBody { deviceId = _state.DeviceId, productId = _productId, guestCredential = _state.GuestCredential });
            CredentialState resumeState = _state;
            _transport.Send<SessionIdentity>(new ApiRequest("POST", "/v1/platform/auth/guest", json), result =>
            {
                if (!ReferenceEquals(_state, resumeState))
                {
                    callback(result.WithError("ACCOUNT_CHANGED", "Guest recovery belongs to an obsolete session.", true));
                    return;
                }
                if (result.IsSuccess && !string.IsNullOrEmpty(resumeState.UserId) && result.Data?.userId != resumeState.UserId)
                {
                    callback(result.WithError("INVALID_IDENTITY", "Guest credential returned another user.", false));
                    return;
                }
                CompleteGuestLogin(result, callback, preserveIdentity);
            });
        }

        public void SendAuthorized<T>(ApiRequest request, Action<ApiResult<T>> callback)
        {
            SendAuthorized(request, callback, null);
        }

        public void SendAuthorized<T>(ApiRequest request, Action<ApiResult<T>> callback, string expectedUserId)
        {
            if (request == null) throw new ArgumentNullException(nameof(request));
            if (callback == null) throw new ArgumentNullException(nameof(callback));
            long version = IdentityVersion;
            if (expectedUserId != null && _userId != expectedUserId)
            {
                callback(ApiResult<T>.NetworkFailure("ACCOUNT_CHANGED", true));
                return;
            }
            if (_accessToken == null || DateTime.UtcNow >= _accessExpiresAt)
            {
                RefreshThen(ok =>
                {
                    if (ok) SendProtected(request, callback, false, expectedUserId, version);
                    else callback(ApiResult<T>.NetworkFailure(_refreshErrorCode, _refreshRetryable));
                });
                return;
            }
            SendProtected(request, callback, false, expectedUserId, version);
        }

        public void WithAccessToken(Action<string> onReady, Action<string> onError)
        {
            if (onReady == null) throw new ArgumentNullException(nameof(onReady));
            if (_accessToken != null && DateTime.UtcNow < _accessExpiresAt) { onReady(_accessToken); return; }
            RefreshThen(ok => { if (ok) onReady(_accessToken); else onError?.Invoke(_refreshErrorCode); });
        }

        public void CreateLinkCode(Action<ApiResult<LinkCode>> callback)
        {
            SendAuthorized<LinkCode>(new ApiRequest("POST", "/v1/platform/auth/link-code", "{}"), callback);
        }

        public void RedeemLinkCode(string code, Action<ApiResult<SessionIdentity>> callback)
        {
            if (string.IsNullOrWhiteSpace(code)) throw new ArgumentException("Link code is required.", nameof(code));
            if (callback == null) throw new ArgumentNullException(nameof(callback));
            string json = JsonUtility.ToJson(new RedeemBody { code = code, productId = _productId });
            long version = IdentityVersion;
            SendAuthorized<SessionIdentity>(new ApiRequest("POST", "/v1/platform/auth/redeem-link-code", json), result =>
            {
                if (version != IdentityVersion) { callback(result.WithError("ACCOUNT_CHANGED", "Obsolete binding response.", true)); return; }
                if (result.IsSuccess) PersistIdentity(result.Data, true);
                callback(result);
            });
        }

        public void Logout(Action<ApiResult<object>> callback)
        {
            if (callback == null) throw new ArgumentNullException(nameof(callback));
            if (string.IsNullOrEmpty(_state.RefreshToken))
            {
                ClearLocal();
                callback(ApiResult<object>.FromJson("{\"data\":{},\"meta\":{}}", 200));
                return;
            }
            SendLogout(callback, false);
        }

        private void SendLogout(Action<ApiResult<object>> callback, bool alreadyRetried)
        {
            long version = IdentityVersion;
            WithAccessToken(token =>
            {
                if (version != IdentityVersion) { callback(ApiResult<object>.NetworkFailure("ACCOUNT_CHANGED", true)); return; }
                string json = JsonUtility.ToJson(new LogoutBody { refreshToken = _state.RefreshToken });
                _transport.Send<object>(new ApiRequest("POST", "/v1/platform/auth/logout", json, accessToken: token), result =>
                {
                    if (version != IdentityVersion) { callback(result.WithError("ACCOUNT_CHANGED", "Obsolete logout response.", true)); return; }
                    if (result.HttpStatus == 401 && !alreadyRetried)
                    {
                        _accessToken = null;
                        RefreshThen(ok =>
                        {
                            if (version != IdentityVersion) callback(ApiResult<object>.NetworkFailure("ACCOUNT_CHANGED", true));
                            else if (ok) SendLogout(callback, true);
                            else callback(ApiResult<object>.NetworkFailure(_refreshErrorCode, _refreshRetryable));
                        });
                        return;
                    }
                    if (result.IsSuccess) ClearLocal();
                    callback(result);
                });
            }, error => callback(ApiResult<object>.NetworkFailure(error, _refreshRetryable)));
        }

        private void CompleteGuestLogin(ApiResult<SessionIdentity> result, Action<ApiResult<SessionIdentity>> callback, bool preserveIdentity = false)
        {
            if (result.IsSuccess)
            {
                if (!IsCompleteIdentity(result.Data, false, true))
                { callback(result.WithError("INVALID_RESPONSE", "Incomplete guest identity.", false)); return; }
                try { PersistIdentity(result.Data, false, true, preserveIdentity); }
                catch (Exception)
                { callback(result.WithError("CREDENTIAL_STORAGE_FAILED", "Could not save login credentials.", true)); return; }
            }
            callback(result);
        }

        private static bool IsCompleteIdentity(SessionIdentity identity, bool requireNewGuestCredential, bool requireUserId)
        {
            return identity != null && (!requireUserId || !string.IsNullOrEmpty(identity.userId)) &&
                !string.IsNullOrEmpty(identity.accessToken) && !string.IsNullOrEmpty(identity.refreshToken) &&
                (!requireNewGuestCredential || !string.IsNullOrEmpty(identity.guestCredential));
        }

        private void PersistIdentity(SessionIdentity identity, bool requireNewGuestCredential, bool requireUserId = true, bool preserveIdentity = false)
        {
            if (!IsCompleteIdentity(identity, requireNewGuestCredential, requireUserId))
                throw new InvalidOperationException("Auth response is incomplete.");
            CredentialState next = _state.Copy();
            if (requireNewGuestCredential || (!string.IsNullOrEmpty(identity.userId) && identity.userId != next.UserId))
                next.AccountName = identity.accountName;
            else if (identity.accountName != null) next.AccountName = identity.accountName;
            if (!string.IsNullOrEmpty(identity.userId)) next.UserId = identity.userId;
            if (!string.IsNullOrEmpty(identity.guestCredential)) next.GuestCredential = identity.guestCredential;
            next.RefreshToken = identity.refreshToken;
            next.PendingRefreshKey = null;
            next.PendingRefreshStartedAtUnixSeconds = 0;
            _store.Save(next);
            bool identityChanged = (requireUserId && !preserveIdentity) || _userId != next.UserId;
            _state = next;
            _userId = next.UserId;
            _accessToken = identity.accessToken;
            _accessExpiresAt = DateTime.UtcNow.AddSeconds(Math.Max(1, identity.expiresInSeconds - 30));
            if (identityChanged) AdvanceIdentity();
        }

        private void SendProtected<T>(ApiRequest request, Action<ApiResult<T>> callback, bool alreadyRetried, string expectedUserId, long expectedVersion)
        {
            if (IdentityVersion != expectedVersion || (expectedUserId != null && _userId != expectedUserId))
            {
                callback(ApiResult<T>.NetworkFailure("ACCOUNT_CHANGED", true));
                return;
            }
            string tokenUsed = _accessToken;
            var signed = new ApiRequest(request.Method, request.Path, request.BodyJson, request.IdempotencyKey, tokenUsed, request.Query, request.ProductId);
            _transport.Send<T>(signed, result =>
            {
                if (IdentityVersion != expectedVersion || (expectedUserId != null && _userId != expectedUserId))
                {
                    callback(result.WithError("ACCOUNT_CHANGED", "Request belongs to the previous account.", true));
                    return;
                }
                if (result.HttpStatus != 401 || alreadyRetried) { callback(result); return; }
                if (_accessToken != tokenUsed) { SendProtected(request, callback, true, expectedUserId, expectedVersion); return; }
                _accessToken = null;
                RefreshThen(ok =>
                {
                    if (ok) SendProtected(request, callback, true, expectedUserId, expectedVersion);
                    else callback(ApiResult<T>.NetworkFailure(_refreshErrorCode, _refreshRetryable));
                });
            });
        }

        private void RefreshThen(Action<bool> continuation)
        {
            _refreshWaiters.Add(continuation);
            if (_refreshInFlight) return;
            if (string.IsNullOrEmpty(_state.RefreshToken))
            {
                CompleteRefreshWaiters(false, "NO_SESSION", false);
                return;
            }
            long now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            if (!string.IsNullOrEmpty(_state.PendingRefreshKey) &&
                (_state.PendingRefreshStartedAtUnixSeconds <= 0 || now - _state.PendingRefreshStartedAtUnixSeconds >= 50))
            {
                if (string.IsNullOrEmpty(_state.GuestCredential))
                {
                    CompleteRefreshWaiters(false, "REFRESH_RECOVERY_EXPIRED", false);
                    return;
                }
                _refreshInFlight = true;
                ResumeGuest(result => CompleteRefreshWaiters(result.IsSuccess, result.ErrorCode, result.Retryable), true);
                return;
            }
            _refreshInFlight = true;
            CredentialState next = _state.Copy();
            if (string.IsNullOrEmpty(next.PendingRefreshKey))
            {
                next.PendingRefreshKey = Guid.NewGuid().ToString("N");
                next.PendingRefreshStartedAtUnixSeconds = now;
            }
            try { _store.Save(next); }
            catch (Exception)
            { CompleteRefreshWaiters(false, "CREDENTIAL_STORAGE_FAILED", true); return; }
            _state = next;
            string json = JsonUtility.ToJson(new RefreshBody { refreshToken = next.RefreshToken, deviceId = next.DeviceId });
            _transport.Send<SessionIdentity>(new ApiRequest("POST", "/v1/platform/auth/refresh", json, next.PendingRefreshKey), (ApiResult<SessionIdentity> result) =>
            {
                if (!ReferenceEquals(_state, next))
                {
                    CompleteRefreshWaiters(false, "ACCOUNT_CHANGED", true);
                    return;
                }
                if (result.IsSuccess)
                {
                    if (!IsCompleteIdentity(result.Data, false, false))
                    { CompleteRefreshWaiters(false, "INVALID_RESPONSE", true); return; }
                    try { PersistIdentity(result.Data, false, false); }
                    catch (Exception)
                    { CompleteRefreshWaiters(false, "CREDENTIAL_STORAGE_FAILED", true); return; }
                    CompleteRefreshWaiters(true, null, false);
                }
                else
                {
                    // Uncertain responses retain both the old token and the exact request key.
                    if (!result.Retryable)
                    {
                        CredentialState definitive = _state.Copy();
                        definitive.PendingRefreshKey = null;
                        definitive.PendingRefreshStartedAtUnixSeconds = 0;
                        try { _store.Save(definitive); }
                        catch (Exception)
                        { CompleteRefreshWaiters(false, "CREDENTIAL_STORAGE_FAILED", true); return; }
                        _state = definitive;
                    }
                    CompleteRefreshWaiters(false, result.ErrorCode, result.Retryable);
                }
            });
        }

        private void CompleteRefreshWaiters(bool success, string errorCode, bool retryable)
        {
            _refreshInFlight = false;
            _refreshErrorCode = errorCode;
            _refreshRetryable = retryable;
            Action<bool>[] waiters = _refreshWaiters.ToArray();
            _refreshWaiters.Clear();
            foreach (Action<bool> waiter in waiters) waiter(success);
        }

        private void ClearLocal()
        {
            _store.Clear();
            _state = new CredentialState { DeviceId = Guid.NewGuid().ToString("N") };
            _accessToken = null;
            _userId = null;
            AdvanceIdentity();
        }

        private void AdvanceIdentity()
        {
            IdentityVersion++;
            var listeners = IdentityChanged;
            if (listeners == null) return;
            foreach (Action listener in listeners.GetInvocationList())
                try { listener(); } catch (Exception e) { Debug.LogException(e); }
        }
    }
}
