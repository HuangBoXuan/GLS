using System;
using System.Text.RegularExpressions;

namespace MiniGamePlatform.SDK.GameData
{
    public sealed class GameContext
    {
        private static readonly Regex ProductIdPattern = new Regex("^[A-Za-z0-9._-]{1,64}$", RegexOptions.CultureInvariant);
        // New registrations use [a-z][a-z0-9_]{0,63}. Keep legacy hyphenated
        // server game IDs (for example game-a) readable during migration.
        private static readonly Regex GameIdPattern = new Regex("^[a-z0-9][a-z0-9_-]{0,63}$", RegexOptions.CultureInvariant);

        public string ProductId { get; }
        public string GameId { get; }

        public GameContext(string productId, string gameId)
        {
            if (string.IsNullOrEmpty(productId) || !ProductIdPattern.IsMatch(productId)) throw new ArgumentException("Invalid product ID.", nameof(productId));
            if (string.IsNullOrEmpty(gameId) || !GameIdPattern.IsMatch(gameId)) throw new ArgumentException("Invalid game ID.", nameof(gameId));
            ProductId = productId;
            GameId = gameId;
        }
    }
}
