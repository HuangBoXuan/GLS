using System;
using MiniGamePlatform.HotUpdate;
using MiniGamePlatform.SDK.Auth;

namespace MiniGamePlatform.SDK.Contracts
{
    public interface IModuleAccount
    {
        bool IsAvailable { get; }
        string UserId { get; }
        event Action Invalidated;
    }
    public interface IModuleLocalStorage
    {
        bool IsAvailable { get; }
        string Read(string key);
        void Write(string key, string value);
        void Delete(string key);
    }
    public interface IModuleAds
    {
        bool IsAvailable { get; }
        // format: rewarded / interstitial. Callback JSON: requestId, status, isTest, error.
        // A completed client callback is not proof of a server reward.
        string Show(string placement, string format, Action<string> callback);
    }
    // Optional API 7 extension. Older independent shells may only implement IModuleAds.
    public interface IModuleAdReadiness
    {
        // Read-only; the same host gate is checked again when Show is called.
        bool IsReady(string placement, string format);
    }
    // Optional native conveniences. The module owns only this activation's lease;
    // SDK methods forward to the product shell and never contain game rules.
    public interface IModuleNativeFeatures : IDisposable
    {
        float BannerTopPixels { get; }
        string GetBannerContext();
        void SetHomeBanner(bool visible);
        int BeginGameplayBanner(bool eligible);
        bool ShowGameplayBanner(int runId);
        bool IsGameplayBannerViable(int runId);
        void SetGameplayBannerOverlay(int runId, bool obscured);
        void SuppressGameplayBanner(int runId);
        void EndGameplayBanner(int runId);
        bool IsFullscreenShowing();
        bool OpenLegalDocument(string document);
        bool ShowPrivacyOptions(Action<bool> completion);
        bool PlayHaptic(int cue);
        bool CancelHaptic();
        bool RequestExit();
    }
    public interface IModuleRequests
    {
        bool IsAvailable { get; }
        // JSON: method, path relative to this game's API root, bodyJson, idempotencyKey, query[{key,value}].
        // Callback receives the server JSON envelope. No game DTO, credentials, or absolute URL is exposed.
        string Send(string requestJson, Action<string> callback);
        void Cancel(string requestId);
    }
    public interface IModuleHostServices : IDisposable
    {
        IModuleAccount Account { get; }
        IModuleLocalStorage Storage { get; }
        IModuleAds Ads { get; }
        IModuleRequests Requests { get; }
    }
    // Host frame hook, kept separate from the interfaces games consume.
    public interface IModuleServicePump
    {
        void Pump();
    }
}
