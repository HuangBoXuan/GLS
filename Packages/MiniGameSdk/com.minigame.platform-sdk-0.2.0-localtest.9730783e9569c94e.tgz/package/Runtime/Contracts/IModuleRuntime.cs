using System;
namespace MiniGamePlatform.HotUpdate
{
    public enum GameRunState { Empty, Running, Paused }
    public interface IModuleRuntime : IDisposable
    {
        GameRunState State { get; }
        bool HasPendingExit { get; }
        ModuleRunException LastError { get; }
        void Tick();
        void LateTick();
        void Pause();
        void Resume();
        void Exit();
    }
}
