using System;
using System.Text;
using UnityEngine.Networking;

namespace MiniGamePlatform.SDK.Network
{
    public interface IPlatformTransport
    {
        void Send<T>(ApiRequest request, Action<ApiResult<T>> callback);
    }

    public sealed class UnityApiTransport : IPlatformTransport
    {
        private readonly Uri _origin;
        private readonly string _platform;
        private readonly string _clientVersion;

        public UnityApiTransport(string apiBaseUrl, string platform = "android", string clientVersion = "1.0.0")
        {
            if (!Uri.TryCreate(apiBaseUrl, UriKind.Absolute, out Uri uri) || uri.UserInfo.Length > 0 || uri.Query.Length > 0 || uri.Fragment.Length > 0 || uri.AbsolutePath != "/")
                throw new ArgumentException("API base must be an origin URL.", nameof(apiBaseUrl));
            bool localDevelopment = false;
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            localDevelopment = uri.Scheme == Uri.UriSchemeHttp && uri.Host == "127.0.0.1";
#endif
            if (uri.Scheme != Uri.UriSchemeHttps && !localDevelopment)
                throw new ArgumentException("API base must use HTTPS.", nameof(apiBaseUrl));
            _origin = uri;
            _platform = platform;
            _clientVersion = clientVersion;
        }

        public void Send<T>(ApiRequest request, Action<ApiResult<T>> callback)
        {
            if (request == null) throw new ArgumentNullException(nameof(request));
            if (callback == null) throw new ArgumentNullException(nameof(callback));
            var web = CreateWebRequest(request);
            try
            {
                web.SendWebRequest().completed += _ =>
                {
                    try
                    {
                        ApiResult<T> result = web.result == UnityWebRequest.Result.ConnectionError
                            ? ApiResult<T>.NetworkFailure("NETWORK_UNCERTAIN", true)
                            : ApiResult<T>.FromJson(web.downloadHandler.text, (int)web.responseCode);
                        callback(result);
                    }
                    finally { web.Dispose(); }
                };
            }
            catch
            {
                web.Dispose();
                throw;
            }
        }

        private UnityWebRequest CreateWebRequest(ApiRequest request)
        {
            var web = new UnityWebRequest(new Uri(_origin, request.RelativePathAndQuery), request.Method)
            {
                downloadHandler = new DownloadHandlerBuffer(),
                timeout = 15,
                redirectLimit = 0
            };
            if (request.BodyJson != null)
            {
                web.uploadHandler = new UploadHandlerRaw(Encoding.UTF8.GetBytes(request.BodyJson));
                web.SetRequestHeader("Content-Type", "application/json");
            }
            web.SetRequestHeader("Accept", "application/json");
            web.SetRequestHeader("X-Platform", _platform);
            web.SetRequestHeader("X-Client-Version", _clientVersion);
            if (request.ProductId != null) web.SetRequestHeader("X-Product-Id", request.ProductId);
            if (request.IdempotencyKey != null) web.SetRequestHeader("Idempotency-Key", request.IdempotencyKey);
            if (request.AccessToken != null) web.SetRequestHeader("Authorization", "Bearer " + request.AccessToken);
            return web;
        }
    }
}
