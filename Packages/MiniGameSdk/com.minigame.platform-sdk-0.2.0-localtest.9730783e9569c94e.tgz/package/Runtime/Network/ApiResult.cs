using System;
using UnityEngine;

namespace MiniGamePlatform.SDK.Network
{
    public sealed class ApiResult<T>
    {
        [Serializable] private sealed class Envelope { public T data; public Error error; public Meta meta; }
        [Serializable] private sealed class Error { public string code; public string message; public bool retryable; }
        [Serializable] private sealed class Meta { public string requestId; }

        public T Data { get; private set; }
        public string ErrorCode { get; private set; }
        public string ErrorMessage { get; private set; }
        public string RequestId { get; private set; }
        public int HttpStatus { get; private set; }
        public bool Retryable { get; private set; }
        public bool IsSuccess { get { return ErrorCode == null; } }
        internal string ResponseJson { get; private set; }

        public static ApiResult<T> FromJson(string json, int httpStatus)
        {
            if (string.IsNullOrWhiteSpace(json)) return Failure("INVALID_RESPONSE", "Empty server response.", null, httpStatus, UnknownOutcome(httpStatus));
            try
            {
                Envelope envelope = JsonUtility.FromJson<Envelope>(json);
                bool hasError = envelope != null && envelope.error != null && !string.IsNullOrEmpty(envelope.error.code);
                if (envelope == null || (!hasError && (httpStatus < 200 || httpStatus >= 300)))
                    return Failure("INVALID_RESPONSE", "Invalid server response.", null, httpStatus, UnknownOutcome(httpStatus));
                string requestId = envelope.meta == null ? null : envelope.meta.requestId;
                if (hasError)
                    return Failure(envelope.error.code, envelope.error.message, requestId, httpStatus, envelope.error.retryable);
                return new ApiResult<T> { Data = envelope.data, RequestId = requestId, HttpStatus = httpStatus, ResponseJson = json };
            }
            catch (Exception)
            {
                return Failure("INVALID_RESPONSE", "Invalid server response.", null, httpStatus, UnknownOutcome(httpStatus));
            }
        }

        public static ApiResult<T> NetworkFailure(string code, bool retryable)
        {
            return Failure(code, null, null, 0, retryable);
        }

        // Local session restoration has no single HTTP response or request id.
        internal static ApiResult<T> FromData(T data)
        {
            return new ApiResult<T> { Data = data };
        }

        public ApiResult<T> WithError(string code, string message, bool retryable)
        {
            return Failure(code, message, RequestId, HttpStatus, retryable);
        }

        private static bool UnknownOutcome(int status)
        {
            return status == 0 || status >= 500 || (status >= 200 && status < 300);
        }

        private static ApiResult<T> Failure(string code, string message, string requestId, int status, bool retryable)
        {
            return new ApiResult<T> { ErrorCode = code, ErrorMessage = message, RequestId = requestId, HttpStatus = status, Retryable = retryable };
        }
    }
}
