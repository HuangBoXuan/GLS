using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Text.RegularExpressions;

namespace MiniGamePlatform.SDK.Network
{
    public sealed class ApiRequest
    {
        private static readonly Regex KeyPattern = new Regex("^[A-Za-z0-9._:-]{8,128}$", RegexOptions.CultureInvariant);

        public string Method { get; }
        public string Path { get; }
        public string BodyJson { get; }
        public string IdempotencyKey { get; }
        public string AccessToken { get; }
        public string ProductId { get; }
        public string RelativePathAndQuery { get; }
        public IReadOnlyDictionary<string, string> Query { get; }

        // Preserve the original six-argument constructor for precompiled SDK consumers.
        public ApiRequest(string method, string path, string bodyJson, string idempotencyKey, string accessToken,
            IReadOnlyDictionary<string, string> query)
            : this(method, path, bodyJson, idempotencyKey, accessToken, query, null) { }

        public ApiRequest(string method, string path, string bodyJson = null, string idempotencyKey = null, string accessToken = null,
            IReadOnlyDictionary<string, string> query = null, string productId = null)
        {
            if (method != "GET" && method != "POST" && method != "PUT" && method != "PATCH" && method != "DELETE")
                throw new ArgumentException("Unsupported API method.", nameof(method));
            if (!IsSafePath(path)) throw new ArgumentException("Invalid API path.", nameof(path));
            if (idempotencyKey != null && !KeyPattern.IsMatch(idempotencyKey))
                throw new ArgumentException("Invalid idempotency key.", nameof(idempotencyKey));
            if (productId != null && !Regex.IsMatch(productId, @"\A[A-Za-z0-9._-]{1,64}\z", RegexOptions.CultureInvariant))
                throw new ArgumentException("Invalid product ID.", nameof(productId));
            Method = method;
            Path = path;
            BodyJson = bodyJson;
            IdempotencyKey = idempotencyKey;
            AccessToken = accessToken;
            ProductId = productId;
            if (query != null)
            {
                var copy = new Dictionary<string, string>();
                foreach (KeyValuePair<string, string> pair in query) copy.Add(pair.Key, pair.Value);
                Query = new ReadOnlyDictionary<string, string>(copy);
            }
            var relative = new StringBuilder(path);
            if (Query != null)
            {
                foreach (KeyValuePair<string, string> pair in Query)
                {
                    if (string.IsNullOrEmpty(pair.Key) || !Regex.IsMatch(pair.Key, "^[A-Za-z][A-Za-z0-9_]*$", RegexOptions.CultureInvariant))
                        throw new ArgumentException("Invalid query key.", nameof(query));
                    relative.Append(relative.Length == path.Length ? '?' : '&');
                    relative.Append(Uri.EscapeDataString(pair.Key));
                    relative.Append('=');
                    relative.Append(Uri.EscapeDataString(pair.Value ?? string.Empty));
                }
            }
            RelativePathAndQuery = relative.ToString();
        }

        public static bool IsSafePath(string path)
        {
            if (string.IsNullOrEmpty(path) || !path.StartsWith("/v1/", StringComparison.Ordinal)) return false;
            if (path.IndexOfAny(new[] { '?', '#', '\\', '\r', '\n', '%' }) >= 0 || path.Contains("//")) return false;
            foreach (char c in path) if (char.IsControl(c)) return false;
            string[] segments = path.Substring(1).Split('/');
            foreach (string segment in segments)
            {
                if (segment.Length == 0) return false;
                string decoded;
                try { decoded = Uri.UnescapeDataString(segment); }
                catch (UriFormatException) { return false; }
                if (decoded == "." || decoded == ".." || decoded.IndexOfAny(new[] { '/', '\\', '?', '#' }) >= 0) return false;
                foreach (char c in decoded) if (char.IsControl(c)) return false;
            }
            return true;
        }
    }
}
