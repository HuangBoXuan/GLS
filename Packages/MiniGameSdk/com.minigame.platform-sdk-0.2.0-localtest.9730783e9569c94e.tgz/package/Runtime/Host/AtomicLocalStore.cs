using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace MiniGamePlatform.SDK.Host
{
    // Host-only storage backend. Modules never receive this object or filesystem paths.
    public sealed class AtomicLocalStore
    {
        private static readonly Encoding Utf8 = new UTF8Encoding(false, true);
        private readonly string _root;
        private readonly Action<string, string> _commit;
        public AtomicLocalStore(string root, Action<string, string> commit = null)
        {
            if (string.IsNullOrWhiteSpace(root)) throw new ArgumentException("Storage root is required.");
            _root = Path.GetFullPath(root);
            _commit = commit ?? Commit;
        }
        private static string Hash(string value)
        {
            using var sha = SHA256.Create();
            return BitConverter.ToString(sha.ComputeHash(Utf8.GetBytes(value))).Replace("-", "").ToLowerInvariant();
        }
        private string Location(string user, string game, string key)
        {
            if (string.IsNullOrWhiteSpace(user) || string.IsNullOrWhiteSpace(game) || string.IsNullOrEmpty(key))
                throw new ArgumentException("Account, game and key are required.");
            // Length-prefixed identities make the tuple unambiguous. One full SHA-256
            // keeps isolation without two long hash path segments on mobile runtimes.
            return Path.Combine(_root, Hash(user.Length + ":" + user + game.Length + ":" + game + key) + ".save");
        }
        public string Read(string user, string game, string key)
        {
            string path = Location(user, game, key);
            try { return File.ReadAllText(path, Utf8); }
            catch (FileNotFoundException)
            {
                // Some runtime/filesystem combinations report ENOENT for an unopenable
                // long path even while stat sees it. Do not misreport existing data as new.
                if (File.Exists(path)) throw;
                return null;
            }
            catch (DirectoryNotFoundException) { return null; }
        }
        public void Write(string user, string game, string key, string value)
        {
            if (value == null) throw new ArgumentNullException(nameof(value));
            byte[] bytes = Utf8.GetBytes(value);
            string path = Location(user, game, key);
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            // Keep the unique temp name short: app-data roots can put the final hashed path
            // near Windows' path limit; appending another GUID would make valid saves fail.
            string temporary = Path.Combine(Path.GetDirectoryName(path), Guid.NewGuid().ToString("N") + ".tmp");
            try
            {
                using (var stream = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                { stream.Write(bytes, 0, bytes.Length); stream.Flush(true); }
                _commit(temporary, path);
            }
            finally { if (File.Exists(temporary)) File.Delete(temporary); }
        }
        public void Delete(string user, string game, string key) { File.Delete(Location(user, game, key)); }
        private static void Commit(string temporary, string target)
        {
            if (File.Exists(target)) File.Replace(temporary, target, null);
            else File.Move(temporary, target);
        }
    }
}
