using System;
using MiniGamePlatform.SDK.Auth;
using MiniGamePlatform.SDK.Contracts;
using UnityEngine;

namespace MiniGamePlatform.SDK.Host
{
    // Per-activation views. Host implementation details and credentials are never properties.
    public sealed partial class ModuleHostServices : IModuleHostServices, IModuleServicePump
    {
        private readonly PlatformSession _session;
        private readonly string _user, _game;
        private readonly long _version;
        private readonly AtomicLocalStore _store;
        private readonly HostAdBroker _ads;
        private readonly IModuleNativeFeatures _native;
        private bool _invalid, _disposed;
        private Action _invalidated;
        public IModuleAccount Account { get; }
        public IModuleLocalStorage Storage { get; }
        public IModuleAds Ads { get; }
        // Optional API 7 surface; older independent hosts need not implement it.
        public IModuleNativeFeatures Native => _native;
        public void Pump()
        {
            _ads.MainThread.Drain();
            if (!_disposed) (_native as IModuleServicePump)?.Pump();
        }
        public ModuleHostServices(PlatformSession session, string game, AtomicLocalStore store, HostAdBroker ads,
            string productId = null, string serverGameId = null, IModuleNativeFeatures native = null)
        {
            _session = session; _user = session?.UserId; _version = session?.IdentityVersion ?? 0;
            _game = game; _store = store; _ads = ads ?? throw new ArgumentNullException(nameof(ads)); _native = native;
            _ads.RequireMainThread();
            if (string.IsNullOrWhiteSpace(game)) throw new ArgumentException("Module game identity is required.");
            if (store == null) throw new ArgumentNullException(nameof(store));
            if (serverGameId != null) new GameData.GameContext(productId, serverGameId);
            _requestProduct = productId; _requestGame = serverGameId;
            Account = new AccountView(this); Storage = new StorageView(this); Ads = new AdsView(this);
            Requests = new RequestView(this);
            if (_session != null) _session.IdentityChanged += Invalidate;
        }
        private bool Available => !_invalid && !_disposed && !string.IsNullOrEmpty(_user) &&
            _session.UserId == _user && _session.IdentityVersion == _version;
        // Exit and local device controls must remain reachable if login is absent.
        // An identity transition still disposes this activation's native scope.
        private bool NativeAvailable => !_invalid && !_disposed;
        private void RequireAvailable()
        {
            _ads.RequireMainThread();
            if (!Available) throw new InvalidOperationException("MODULE_ACCOUNT_UNAVAILABLE");
        }
        private void Invalidate()
        {
            if (_invalid || _disposed) return;
            _invalid = true;
            _requests.Clear();
            _ads.Detach(this);
            _native?.Dispose();
            if (_session != null) _session.IdentityChanged -= Invalidate;
            var listeners = _invalidated; _invalidated = null;
            if (listeners != null)
                foreach (Action listener in listeners.GetInvocationList())
                {
                    if (_disposed) break;
                    try { listener(); } catch (Exception e) { Debug.LogException(e); }
                }
        }
        public void Dispose()
        {
            _ads.RequireMainThread();
            if (_disposed) return;
            _disposed = true; _invalidated = null;
            _requests.Clear();
            if (_session != null) _session.IdentityChanged -= Invalidate;
            _ads.Detach(this);
            _native?.Dispose();
        }
        // Compatibility for already-exported Lua modules that look up methods on
        // host.Services directly. All behavior and ownership stay in the host.
        public float BannerTopPixels => NativeAvailable ? _native?.BannerTopPixels ?? 0 : 0;
        public string GetBannerContext() => NativeAvailable ? _native?.GetBannerContext() : null;
        public void SetHomeBanner(bool visible) { if (NativeAvailable) _native?.SetHomeBanner(visible); }
        public int BeginGameplayBanner(bool eligible) => NativeAvailable ? _native?.BeginGameplayBanner(eligible) ?? 0 : 0;
        public bool ShowGameplayBanner(int runId) => NativeAvailable && (_native?.ShowGameplayBanner(runId) ?? false);
        public bool IsGameplayBannerViable(int runId) => NativeAvailable && (_native?.IsGameplayBannerViable(runId) ?? false);
        public void SetGameplayBannerOverlay(int runId, bool obscured) { if (NativeAvailable) _native?.SetGameplayBannerOverlay(runId, obscured); }
        public void SuppressGameplayBanner(int runId) { if (NativeAvailable) _native?.SuppressGameplayBanner(runId); }
        public void EndGameplayBanner(int runId) { if (NativeAvailable) _native?.EndGameplayBanner(runId); }
        public bool IsFullscreenShowing() => NativeAvailable && (_native?.IsFullscreenShowing() ?? false);
        public bool OpenLegalDocument(string document) => NativeAvailable && (_native?.OpenLegalDocument(document) ?? false);
        public bool ShowPrivacyOptions(Action<bool> completion) => NativeAvailable && (_native?.ShowPrivacyOptions(completion) ?? false);
        public bool PlayHaptic(int cue) => NativeAvailable && (_native?.PlayHaptic(cue) ?? false);
        public bool CancelHaptic() => NativeAvailable && (_native?.CancelHaptic() ?? false);
        public bool RequestExit() => NativeAvailable && (_native?.RequestExit() ?? false);
        public sealed class AccountView : IModuleAccount
        {
            private readonly ModuleHostServices _scope;
            internal AccountView(ModuleHostServices scope) { _scope = scope; }
            public bool IsAvailable => _scope.Available;
            public string UserId => IsAvailable ? _scope._user : null;
            public event Action Invalidated
            {
                add { _scope.RequireAvailable(); _scope._invalidated += value; }
                remove { _scope._ads.RequireMainThread(); _scope._invalidated -= value; }
            }
        }
        public sealed class StorageView : IModuleLocalStorage
        {
            private readonly ModuleHostServices _scope;
            internal StorageView(ModuleHostServices scope) { _scope = scope; }
            public bool IsAvailable => _scope.Available;
            public string Read(string key) { _scope.RequireAvailable(); return _scope._store.Read(_scope._user, _scope._game, key); }
            public void Write(string key, string value) { _scope.RequireAvailable(); _scope._store.Write(_scope._user, _scope._game, key, value); }
            public void Delete(string key) { _scope.RequireAvailable(); _scope._store.Delete(_scope._user, _scope._game, key); }
        }
        public sealed class AdsView : IModuleAds, IModuleAdReadiness
        {
            private readonly ModuleHostServices _scope;
            internal AdsView(ModuleHostServices scope) { _scope = scope; }
            public bool IsAvailable => _scope.Available && _scope._ads.IsAvailable;
            public bool IsReady(string placement, string format)
            { return _scope.Available && _scope._ads.IsReady(_scope._game, placement, format); }
            public string Show(string placement, string format, Action<string> callback)
            { _scope.RequireAvailable(); return _scope._ads.Show(_scope, _scope._game, placement, format, callback); }
        }
    }
}
