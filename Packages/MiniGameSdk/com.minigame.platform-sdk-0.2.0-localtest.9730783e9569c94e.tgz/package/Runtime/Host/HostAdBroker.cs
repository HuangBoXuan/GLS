using System;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;

namespace MiniGamePlatform.SDK.Host
{
    public interface IHostAdDriver
    {
        bool IsTest { get; }
        bool IsReady(string gameId, string placement, string format);
        // Must report a terminal result after native fullscreen has actually closed.
        void Show(string requestId, string gameId, string placement, string format, Action<string, string> terminal);
    }
    // Native app-open ads and other product-owned fullscreen surfaces share the gate.
    public interface IHostAdFullscreenState
    {
        bool IsFullscreenShowing { get; }
    }

    // Created and drained by the host on Unity's main thread. Post never invokes inline.
    public sealed class HostMainThreadQueue
    {
        private readonly int _thread = Thread.CurrentThread.ManagedThreadId;
        private readonly Queue<Action> _pending = new Queue<Action>();
        public void RequireMainThread()
        { if (Thread.CurrentThread.ManagedThreadId != _thread) throw new InvalidOperationException("Host services require the main thread."); }
        public void Post(Action action) { lock (_pending) _pending.Enqueue(action); }
        public void Drain()
        {
            RequireMainThread();
            int count; lock (_pending) count = _pending.Count;
            for (int i = 0; i < count; i++)
            {
                Action action; lock (_pending) action = _pending.Dequeue();
                try { action(); } catch (Exception e) { Debug.LogException(e); }
            }
        }
    }

    public sealed class HostAdBroker
    {
        [Serializable] private sealed class Result
        { public string requestId, status, error; public bool isTest; }
        private sealed class Request
        { public string Id; public object Owner; public Action<string> Callback; public bool Done; }
        private readonly IHostAdDriver _driver;
        private readonly HostMainThreadQueue _queue;
        private readonly List<Request> _pending = new List<Request>();
        private Request _fullscreen;
        private bool _fullscreenStateWarned;
        public event Action FullscreenChanged;
        public HostAdBroker(IHostAdDriver driver, HostMainThreadQueue queue)
        {
#if !UNITY_EDITOR && !DEVELOPMENT_BUILD
            if (driver?.IsTest == true) throw new InvalidOperationException("Test ad driver cannot run in a release shell.");
#endif
            _driver = driver; _queue = queue ?? throw new ArgumentNullException(nameof(queue));
        }
        public bool IsAvailable => _driver != null;
        public HostMainThreadQueue MainThread => _queue;
        internal void RequireMainThread() { _queue.RequireMainThread(); }
        private bool ExternalFullscreen
        {
            get
            {
                try
                {
                    bool showing = _driver is IHostAdFullscreenState state && state.IsFullscreenShowing;
                    _fullscreenStateWarned = false; return showing;
                }
                catch (Exception e)
                {
                    if (!_fullscreenStateWarned) Debug.LogWarning("Fullscreen ad state unavailable: " + e.GetType().Name);
                    _fullscreenStateWarned = true;
                    return true; // Unknown native fullscreen state must not permit another ad.
                }
            }
        }
        public bool IsFullscreenShowing
        {
            get
            {
                RequireMainThread();
                return _fullscreen != null || ExternalFullscreen;
            }
        }
        public bool IsReady(string game, string placement, string format)
        {
            RequireMainThread();
            if (_driver == null || _fullscreen != null || string.IsNullOrWhiteSpace(game) ||
                string.IsNullOrWhiteSpace(placement) || (format != "rewarded" && format != "interstitial")) return false;
            try
            {
                return !ExternalFullscreen && _driver.IsReady(game, placement, format);
            }
            catch (Exception e) { Debug.LogWarning("Ad readiness unavailable: " + e.GetType().Name); return false; }
        }
        private void NotifyFullscreenChanged()
        {
            var listeners = FullscreenChanged;
            if (listeners == null) return;
            foreach (Action listener in listeners.GetInvocationList())
                try { listener(); } catch (Exception e) { Debug.LogException(e); }
        }
        internal string Show(object owner, string game, string placement, string format, Action<string> callback)
        {
            RequireMainThread();
            if (string.IsNullOrWhiteSpace(placement)) throw new ArgumentException("Logical placement is required.");
            if (format != "rewarded" && format != "interstitial") throw new ArgumentException("Unsupported fullscreen format.");
            if (callback == null) throw new ArgumentNullException(nameof(callback));
            var request = new Request { Id = Guid.NewGuid().ToString("N"), Owner = owner, Callback = callback };
            _pending.Add(request);
            if (IsFullscreenShowing) { QueueTerminal(request, "busy", null); return request.Id; }
            try
            {
                if (!IsReady(game, placement, format)) QueueTerminal(request, "not_ready", null);
                else
                {
                    _fullscreen = request;
                    NotifyFullscreenChanged();
                    _driver.Show(request.Id, game, placement, format, (status, error) => QueueTerminal(request, status, error));
                }
            }
            catch (Exception e) { QueueTerminal(request, "failed", e.Message); }
            return request.Id;
        }
        private void QueueTerminal(Request request, string status, string error)
        { _queue.Post(() => Complete(request, status, error)); }
        private void Complete(Request request, string status, string error)
        {
            RequireMainThread();
            if (request.Done) return;
            request.Done = true;
            bool wasFullscreen = ReferenceEquals(_fullscreen, request);
            if (wasFullscreen) _fullscreen = null;
            _pending.Remove(request);
            if (wasFullscreen) NotifyFullscreenChanged();
            var callback = request.Callback;
            request.Callback = null; request.Owner = null;
            if (status != "completed" && status != "canceled" && status != "failed" && status != "busy" && status != "not_ready")
            { status = "failed"; error = "INVALID_DRIVER_RESULT"; }
            callback?.Invoke(JsonUtility.ToJson(new Result { requestId = request.Id, status = status, error = error, isTest = _driver?.IsTest ?? false }));
        }
        internal void Detach(object owner)
        {
            RequireMainThread();
            foreach (var request in _pending)
                if (ReferenceEquals(request.Owner, owner)) { request.Callback = null; request.Owner = null; }
            // Do not release the native fullscreen lock until its terminal event.
        }
    }

}
