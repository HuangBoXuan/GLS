using System;
using System.Collections.Generic;
using MiniGamePlatform.SDK.Contracts;
using MiniGamePlatform.SDK.Network;
using UnityEngine;

namespace MiniGamePlatform.SDK.Host
{
    public sealed partial class ModuleHostServices
    {
        [Serializable] private sealed class QueryItem { public string key, value; }
        [Serializable] private sealed class RequestBody
        { public string method, path, bodyJson, idempotencyKey; public QueryItem[] query; }
        [Serializable] private sealed class RawPayload { }
        [Serializable] private sealed class RequestFailure
        { public RequestError error; public RequestMeta meta; }
        [Serializable] private sealed class RequestError
        { public string code, message; public bool retryable; }
        [Serializable] private sealed class RequestMeta
        { public string requestId; public int httpStatus; }

        private readonly string _requestProduct, _requestGame;
        private readonly Dictionary<string, Action<string>> _requests = new Dictionary<string, Action<string>>(StringComparer.Ordinal);
        public IModuleRequests Requests { get; }

        public sealed class RequestView : IModuleRequests
        {
            private readonly ModuleHostServices _scope;
            internal RequestView(ModuleHostServices scope) { _scope = scope; }
            public bool IsAvailable => _scope.Available && _scope._requestGame != null;
            public void Cancel(string requestId)
            {
                _scope._ads.RequireMainThread();
                if (requestId != null) _scope._requests.Remove(requestId);
            }
            public string Send(string requestJson, Action<string> callback)
            {
                _scope.RequireAvailable();
                if (!IsAvailable) throw new InvalidOperationException("MODULE_SERVER_SCOPE_UNAVAILABLE");
                if (callback == null) throw new ArgumentNullException(nameof(callback));
                if (string.IsNullOrWhiteSpace(requestJson) || requestJson.Length > 1024 * 1024)
                    throw new ArgumentException("Invalid module request JSON.");
                if (_scope._requests.Count >= 128) throw new InvalidOperationException("Too many pending module requests.");
                RequestBody body;
                try { body = JsonUtility.FromJson<RequestBody>(requestJson); }
                catch (Exception exception) { throw new ArgumentException("Invalid module request JSON.", exception); }
                if (body == null || string.IsNullOrEmpty(body.path) || body.path.StartsWith("/", StringComparison.Ordinal) ||
                    body.path.Contains(":")) throw new ArgumentException("A relative game API path is required.");
                string path = "/v1/games/" + _scope._requestGame + "/" + body.path;
                var query = new Dictionary<string, string>(StringComparer.Ordinal);
                if (body.query != null)
                {
                    if (body.query.Length > 64) throw new ArgumentException("Too many query parameters.");
                    foreach (var item in body.query)
                    {
                        if (item == null || item.key == null || query.ContainsKey(item.key)) throw new ArgumentException("Invalid query parameters.");
                        query.Add(item.key, item.value);
                    }
                }
                var request = new ApiRequest(body.method, path, body.bodyJson, body.idempotencyKey,
                    query: query, productId: _scope._requestProduct);
                string id = Guid.NewGuid().ToString("N");
                _scope._requests.Add(id, callback);
                try
                {
                    // The transport closure retains only the scope/id. Dispose/Cancel removes all Lua delegates.
                    _scope._session.SendAuthorized<RawPayload>(request, result =>
                        _scope._ads.MainThread.Post(() => _scope.CompleteRequest(id, result)), _scope._user);
                }
                catch { _scope._requests.Remove(id); throw; }
                return id;
            }
        }

        private void CompleteRequest(string id, ApiResult<RawPayload> result)
        {
            if (!_requests.TryGetValue(id, out var callback)) return;
            _requests.Remove(id);
            if (!Available) return;
            string json = result.IsSuccess ? result.ResponseJson : JsonUtility.ToJson(new RequestFailure
            {
                error = new RequestError { code = result.ErrorCode, message = result.ErrorMessage, retryable = result.Retryable },
                meta = new RequestMeta { requestId = result.RequestId, httpStatus = result.HttpStatus }
            });
            callback(json);
        }
    }
}
