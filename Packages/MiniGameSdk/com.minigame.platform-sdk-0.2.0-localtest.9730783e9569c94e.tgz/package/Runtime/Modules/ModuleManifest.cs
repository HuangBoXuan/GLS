using System;
using System.IO;
using System.Text.RegularExpressions;
using UnityEngine;

namespace MiniGamePlatform.HotUpdate
{
    [Serializable]
    public sealed class ModuleFile
    {
        public string path;
        public string sha256;
        public long size;
    }

    [Serializable]
    public sealed class ModuleManifest
    {
        public int formatVersion;
        public string gameId;
        public string version;
        public string runtimeType;
        public string entry;
        public int minHostApiVersion;
        public string platform;
        public string unityVersion;
        public string contentEncryption;
        public string contentKeyId;
        public string[] requiredCapabilities;
        public ModuleFile[] files;

        public const long MaxFileBytes = 512L * 1024 * 1024;
        public const long MaxModuleBytes = 2L * 1024 * 1024 * 1024;

        private static readonly Regex Identifier = new Regex("^[a-z][a-z0-9_]*$", RegexOptions.CultureInvariant);
        private static readonly Regex GameId = new Regex("^[a-z][a-z0-9_]{0,63}$", RegexOptions.CultureInvariant);
        private static readonly Regex Hash = new Regex("^[a-fA-F0-9]{64}$", RegexOptions.CultureInvariant);
        private static readonly Regex Entry = new Regex("^games\\.[a-z][a-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+$", RegexOptions.CultureInvariant);

        public static ModuleManifest Parse(string json)
        {
            ModuleManifest manifest = JsonUtility.FromJson<ModuleManifest>(json);
            if (manifest != null && manifest.runtimeType == null) manifest.runtimeType = "unity_lua";
            if (manifest == null || manifest.formatVersion != 1 || manifest.minHostApiVersion < 1 ||
                manifest.runtimeType != "unity_lua" ||
                (manifest.platform != "any" && manifest.platform != "android" && manifest.platform != "editor") ||
                manifest.requiredCapabilities == null ||
                !GameId.IsMatch(manifest.gameId ?? "") ||
                !Identifier.IsMatch(manifest.version ?? "") ||
                !Entry.IsMatch(manifest.entry ?? "") ||
                !manifest.entry.StartsWith("games." + manifest.gameId + ".", StringComparison.Ordinal) ||
                manifest.files == null || manifest.files.Length == 0 || manifest.files.Length > 2048)
            {
                throw new InvalidDataException("Invalid module manifest identity or entry.");
            }

            string entryPath = manifest.entry.Replace('.', '/') + ".lua";
            bool protectedContent = ModuleProtectionDeclaration.ValidateDeclaration(manifest);
            for (int i = 0; i < manifest.requiredCapabilities.Length; i++)
            {
                string capability = manifest.requiredCapabilities[i];
                if (!Identifier.IsMatch(capability ?? "")) throw new InvalidDataException("Invalid required capability.");
                for (int j = 0; j < i; j++)
                    if (manifest.requiredCapabilities[j] == capability) throw new InvalidDataException("Duplicate required capability.");
            }
            bool hasEntry = false;
            long totalBytes = 0;
            for (int i = 0; i < manifest.files.Length; i++)
            {
                ModuleFile file = manifest.files[i];
                if (file == null || !IsSafeRelativePath(file.path) || !IsAllowedModuleFile(manifest.gameId, file.path) ||
                    !Hash.IsMatch(file.sha256 ?? "") ||
                    file.size < 0 || file.size > MaxFileBytes || totalBytes > MaxModuleBytes - file.size ||
                    (protectedContent && (file.size < 44 || file.size > ModuleProtectionDeclaration.MaxPlainBytes + 65536L)))
                {
                    throw new InvalidDataException("Invalid module file declaration.");
                }
                totalBytes += file.size;
                if (file.path == entryPath) hasEntry = true;
                for (int j = 0; j < i; j++)
                {
                    if (manifest.files[j].path == file.path) throw new InvalidDataException("Duplicate module path.");
                }
            }
            if (!hasEntry) throw new InvalidDataException("Lua entry is missing from file list.");
            bool hasBundle = Array.Exists(manifest.files, file => file.path.EndsWith(".bundle", StringComparison.Ordinal));
            if (hasBundle && (string.IsNullOrEmpty(manifest.unityVersion) || manifest.platform == "any"))
                throw new InvalidDataException("AssetBundle modules require a Unity version and target platform.");
            return manifest;
        }

        public static bool IsSafeRelativePath(string path)
        {
            if (string.IsNullOrEmpty(path) || path.StartsWith("/", StringComparison.Ordinal) || path.Contains("\\") || path.Contains(":")) return false;
            string[] parts = path.Split('/');
            foreach (string part in parts)
            {
                if (part.Length == 0 || part == "." || part == ".." || !Regex.IsMatch(part, "^[A-Za-z0-9_.-]+$")) return false;
            }
            return true;
        }

        public static bool IsAllowedModuleFile(string gameId, string path)
        {
            if (!IsSafeRelativePath(path) || !GameId.IsMatch(gameId ?? "")) return false;
            if (path.EndsWith(".bundle", StringComparison.Ordinal) && path.IndexOf('/') < 0) return true;
            if (path.StartsWith("games/" + gameId + "/", StringComparison.Ordinal) &&
                path.EndsWith(".lua", StringComparison.Ordinal)) return true;
            if (path.StartsWith("data/" + gameId + "/", StringComparison.Ordinal))
                return path.EndsWith(".json", StringComparison.Ordinal) ||
                       path.EndsWith(".csv", StringComparison.Ordinal) ||
                       path.EndsWith(".txt", StringComparison.Ordinal);
            return false;
        }
    }
}
