using System;

namespace MiniGamePlatform.HotUpdate
{
    public sealed class ModuleLaunchContext
    {
        public string Source { get; }
        public string LevelId { get; }
        public string ModuleVersion { get; }

        public ModuleLaunchContext(string source, string levelId, string moduleVersion)
        {
            Source = string.IsNullOrWhiteSpace(source) ? throw new ArgumentException("Launch source is required.", nameof(source)) : source;
            LevelId = levelId;
            ModuleVersion = moduleVersion ?? throw new ArgumentNullException(nameof(moduleVersion));
        }
    }

    public sealed class ModuleRunException : Exception
    {
        public string Code { get; }
        public string Phase { get; }

        public ModuleRunException(string code, string phase, Exception cause)
            : base(code + " during " + phase + ": " + cause.Message, cause)
        {
            Code = code;
            Phase = phase;
        }
    }
}
