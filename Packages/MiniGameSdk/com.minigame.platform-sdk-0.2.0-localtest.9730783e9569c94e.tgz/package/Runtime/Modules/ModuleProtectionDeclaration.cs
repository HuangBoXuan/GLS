using System;
using System.IO;
using System.Text.RegularExpressions;
namespace MiniGamePlatform.HotUpdate
{
    public static class ModuleProtectionDeclaration
    {
        public const string Capability = "protected_content";
        public const int MaxPlainBytes = 64 * 1024 * 1024;
        public static bool ValidId(string id) => id != null && id.Length <= 64 &&
            Regex.IsMatch(id, "^[a-z][a-z0-9_]*$", RegexOptions.CultureInvariant);

        public static bool ValidateDeclaration(ModuleManifest manifest)
        {
            if (manifest == null) throw new ArgumentNullException(nameof(manifest));
            bool claimed = Array.IndexOf(manifest.requiredCapabilities ?? Array.Empty<string>(), Capability) >= 0;
            if (string.IsNullOrEmpty(manifest.contentEncryption) && string.IsNullOrEmpty(manifest.contentKeyId) && !claimed) return false;
            if (manifest.contentEncryption != "wpc1" || !ValidId(manifest.contentKeyId) || !claimed)
                throw new InvalidDataException("Incomplete or unsupported module protection declaration.");
            return true;
        }

    }
}
