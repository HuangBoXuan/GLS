using System;
using System.Collections.Generic;
using UnityEngine;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public static class SdkSeparationChecks
    {
        public static void Run()
        {
            var failures = new List<string>();
            void Suite(string name, Action run)
            {
                try { run(); Debug.Log("SEPARATION_SUITE_PASS " + name); }
                catch (Exception exception) { failures.Add(name); Debug.LogError("SEPARATION_SUITE_FAIL " + name + ": " + exception); }
            }
            Suite("native-runtime-and-services", SdkNativeLuaChecks.Run);
            Suite("game-scoped-requests", SdkModuleRequestChecks.Run);
            Suite("module-definition", ModuleDefinitionChecks.Run);
            Suite("asset-dependencies", AssetDependencyChecks.Run);
            Suite("module-packager", ModulePackagerChecks.Run);
            Suite("release-gate", ModuleReleaseGateChecks.Run);
            Suite("selection", ModuleSelectionChecks.Run);
            Suite("signed-catalog", SignedCatalogChecks.Run);
            Suite("trusted-catalog", TrustedCatalogChecks.Run);
            Suite("partner-import", () =>
            {
                if (!System.IO.Directory.Exists("Assets/PartnerGame")) PartnerImportChecks.ImportSample();
                PartnerImportChecks.Run();
            });
            Suite("resource-lifetime", ModuleResourceLifetimeChecks.Run);
            Suite("render-batch", RenderBatchChecks.Run);
            if (failures.Count != 0) throw new Exception("SDK separation failed suites: " + string.Join(", ", failures));
            Debug.Log("SDK_SEPARATION_CHECKS_PASSED suites=12");
        }
    }
}
