using System;
using MiniGamePlatform.HotUpdate;
using UnityEngine;
using XLua;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public static class SdkTimingChecks
    {
        public static void Run()
        {
            if (typeof(ModulePlayer).GetMethod("LateTick") == null)
                throw new Exception("Missing optional Lua late_update lifecycle.");
            using var env = new LuaEnv();
            env.DoString("function camera_callback(camera) end");
            Bind(env);
            var previous = Camera.onPreCull;
            try
            {
                Camera.onPreCull = null;
                env.DoString(@"
                    local callback=CS.UnityEngine.Camera.CameraCallback(camera_callback)
                    if CS.UnityEngine.Camera.onPreCull==nil then CS.UnityEngine.Camera.onPreCull=callback
                    else CS.UnityEngine.Camera.onPreCull=CS.UnityEngine.Camera.onPreCull+callback end
                    CS.UnityEngine.Camera.onPreCull=CS.UnityEngine.Camera.onPreCull-callback
                ");
                if (Camera.onPreCull != null) throw new Exception("Lua unsubscribe retained camera callback.");
            }
            finally { Camera.onPreCull = previous; }
            env.DoString("camera_callback=nil; collectgarbage('collect')");
            Debug.Log("TIMING_SIGNATURE_CHECKS_PASSED");
        }
        private static void Bind(LuaEnv env)
        {
            var callback = env.Global.Get<Camera.CameraCallback>("camera_callback");
            if (callback == null) throw new Exception("Missing static CameraCallback bridge.");
            Camera.onPreCull += callback; Camera.onPreCull -= callback;
        }
    }
}
