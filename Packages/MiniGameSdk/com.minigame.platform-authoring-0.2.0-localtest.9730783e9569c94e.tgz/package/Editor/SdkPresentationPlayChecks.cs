using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using MiniGamePlatform.HotUpdate;
using UnityEditor;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace MiniGamePlatform.SDK.EditorChecks
{
    [InitializeOnLoad]
    public static class SdkPresentationPlayChecks
    {
        private const string Pending = "MGP.PresentationPlayCheck";
        private static ModuleAssetScope _assets;
        private static GameHostBridge _bridge;
        private static ModulePresentation _p;
        private static EventSystem _previousSystem;
        private static GameObject _image;
        private static double _readyAt;

        static SdkPresentationPlayChecks() { EditorApplication.playModeStateChanged += Changed; }

        // Batch invocation deliberately omits -quit; exits after an actual Play Mode frame and cleanup.
        public static void Run()
        {
            if (EditorApplication.isPlaying) throw new InvalidOperationException("Start this check in Edit Mode.");
            SessionState.SetBool(Pending, true);
            SessionState.SetBool(Pending + ".failed", false);
            EditorApplication.EnterPlaymode();
        }

        private static void Changed(PlayModeStateChange state)
        {
            if (!SessionState.GetBool(Pending, false)) return;
            if (state == PlayModeStateChange.EnteredPlayMode)
            {
                try
                {
                    _previousSystem = EventSystem.current;
                    _assets = new ModuleAssetScope(new ModuleManifest { gameId = "playcheck", minHostApiVersion = 4,
                        requiredCapabilities = new[] { "presentation" }, files = Array.Empty<ModuleFile>() }, Path.GetTempPath());
                    _bridge = new GameHostBridge(null, _assets, "playcheck", null); _p = _bridge.Presentation;
                    int id = _p.CreateImage(0);
                    _p.ApplyNodes("{\"nodes\":[{\"id\":" + id + ",\"rect\":true,\"width\":300,\"height\":300}]}");
                    _p.BindTap(id, 42);
                    _image = Resources.FindObjectsOfTypeAll<GameObject>().Single(g => g.name == "Presentation Node " + id);
                    if (EventSystem.current == null) throw new Exception("Runtime did not create an active EventSystem.");
                    _readyAt = EditorApplication.timeSinceStartup + .5;
                    EditorApplication.update += CheckFrame;
                }
                catch (Exception e) { Fail(e); }
            }
            if (state == PlayModeStateChange.EnteredEditMode)
            {
                bool failed = SessionState.GetBool(Pending + ".failed", true);
                SessionState.SetBool(Pending, false);
                if (!failed) Debug.Log("Presentation Play Mode checks passed: active EventSystem, real UI raycast, tap delivery, paused gesture rejection and borrowed-system-safe exit.");
                if (Application.isBatchMode) EditorApplication.Exit(failed ? 1 : 0);
            }
        }

        private static void CheckFrame()
        {
            if (EditorApplication.timeSinceStartup < _readyAt) return;
            EditorApplication.update -= CheckFrame;
            try
            {
                Canvas.ForceUpdateCanvases();
                var data = new PointerEventData(EventSystem.current) { button = PointerEventData.InputButton.Left, pointerId = -1,
                    position = RectTransformUtility.WorldToScreenPoint(null, _image.transform.position) };
                var hits = new List<RaycastResult>(); EventSystem.current.RaycastAll(data, hits);
                if (hits.Count == 0 || hits[0].gameObject != _image) throw new Exception("Runtime raycast missed the presentation image: " +
                    "hits=" + string.Join(",", hits.Select(h => h.gameObject.name)) + " screen=" + Screen.width + "x" + Screen.height +
                    " point=" + data.position + " depth=" + _image.GetComponent<Image>().depth + " raycasters=" + RaycasterManager.GetRaycasters().Count);
                ExecuteEvents.Execute(_image, data, ExecuteEvents.pointerDownHandler);
                ExecuteEvents.Execute(_image, data, ExecuteEvents.pointerClickHandler);
                if (_p.PollTap() != 42 || _p.PollTap() != 0) throw new Exception("Runtime click not delivered once.");
                ExecuteEvents.Execute(_image, data, ExecuteEvents.pointerDownHandler);
                MethodInfo pause = typeof(GameHostBridge).GetMethod("SetPresentationPaused", BindingFlags.NonPublic | BindingFlags.Instance);
                pause.Invoke(_bridge, new object[] { true }); pause.Invoke(_bridge, new object[] { false });
                ExecuteEvents.Execute(_image, data, ExecuteEvents.pointerClickHandler);
                if (_p.PollTap() != 0) throw new Exception("Pre-pause gesture leaked after resume.");
                _bridge.Dispose(); _assets.Dispose();
                if (EventSystem.current != _previousSystem || _image.activeInHierarchy) throw new Exception("Runtime exit did not clear input objects.");
                EditorApplication.ExitPlaymode();
            }
            catch (Exception e) { Fail(e); }
        }

        private static void Fail(Exception error)
        {
            SessionState.SetBool(Pending + ".failed", true);
            Debug.LogException(error);
            EditorApplication.update -= CheckFrame;
            _bridge?.Dispose(); _assets?.Dispose();
            if (EditorApplication.isPlaying) EditorApplication.ExitPlaymode();
            else if (Application.isBatchMode) EditorApplication.Exit(1);
        }
    }
}
