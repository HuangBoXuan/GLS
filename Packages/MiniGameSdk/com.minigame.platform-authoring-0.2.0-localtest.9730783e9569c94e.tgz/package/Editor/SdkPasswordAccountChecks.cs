using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using MiniGamePlatform.SDK.Auth;
using MiniGamePlatform.SDK.Network;
using UnityEditor;
using UnityEngine;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public static class SdkPasswordAccountChecks
    {
        private static int _assertions;
        public static void RunRegression()
        {
            Run();
            SdkHostServicesChecks.Run();
            SdkModuleRequestChecks.Run();
            Debug.Log("SDK_PASSWORD_ACCOUNT_REGRESSION_PASSED suites=4");
        }
        [MenuItem("MiniGame Platform/SDK/Run Password Account Checks")]
        public static void Run()
        {
            _assertions = 0;
            BindPreservesIdentity();
            BindingFailuresPreserveCredentials();
            PasswordLoginReplacesCredentials();
            FailedLoginPreservesIdentity();
            ObsoleteResponsesAreIgnored();
            BoundRestoreAndRefreshRace();
            BindingReadRace();
            InputAndGuestCompatibility();
            KnownUserWithoutCredentialRequiresLogin();
            WindowsEditorCredentialStorePersistsEncryptedState();
            RestoreStorageFailureCanRetry();
            SdkAuthChecks.Run();
            Debug.Log("SDK_PASSWORD_ACCOUNT_CHECKS_PASSED assertions=" + _assertions);
        }

        private static void BindPreservesIdentity()
        {
            var h = new Harness(); h.Guest();
            long version = h.Session.IdentityVersion;
            ApiResult<AccountBinding> result = null;
            h.Session.BindAccount(" Player@Example.COM ", " passWord! ", r => result = r);
            ApiRequest request = h.Transport.Requests[1];
            Assert(request.AccessToken == "access-a" && request.ProductId == "hub", "binding lacks current authorization/product");
            Assert(request.BodyJson.Contains("\"accountName\":\"player@example.com\"") && request.BodyJson.Contains("\"password\":\" passWord! \""), "account normalization altered password");
            h.Transport.Reply(1, Binding("a", "player@example.com"));
            Assert(result.IsSuccess && h.Session.UserId == "a" && h.Session.IdentityVersion == version, "binding changed user identity");
            Assert(h.Store.State.GuestCredential == "guest-a" && h.Store.State.RefreshToken == "refresh-a", "binding replaced guest credentials");
            Assert(h.Session.AccountName == "player@example.com", "binding hint not persisted");
            Assert(!JsonUtility.ToJson(h.Store.State).Contains("passWord") && !JsonUtility.ToJson(h.Store.State).Contains("password"), "password persisted");
            h.Session.GetAccountBinding(r => result = r);
            h.Transport.Reply(2, Binding("a", "player@example.com"));
            Assert(result.IsSuccess, "binding query failed");
            var restarted = new PlatformSession(h.Transport, h.Store, "hub");
            Assert(restarted.UserId == "a" && restarted.AccountName == "player@example.com", "restart lost bound identity");
        }

        private static void BindingFailuresPreserveCredentials()
        {
            var h = new Harness(); h.Guest();
            ApiResult<AccountBinding> result = null;
            string before = JsonUtility.ToJson(h.Store.State);
            h.Session.BindAccount("player@example.com", "Password!", r => result = r);
            h.Transport.Fail(1, "ACCOUNT_NAME_TAKEN", 409);
            Assert(result.ErrorCode == "ACCOUNT_NAME_TAKEN" && JsonUtility.ToJson(h.Store.State) == before, "duplicate binding changed credentials");
            h.Session.BindAccount("player@example.com", "Password!", r => result = r);
            h.Transport.Reply(2, Binding("other-user", "player@example.com"));
            Assert(result.ErrorCode == "INVALID_RESPONSE" && h.Session.UserId == "a", "binding accepted another user");
            h.Session.BindAccount("player@example.com", "Password!", r => result = r);
            h.Store.FailSave = true;
            h.Transport.Reply(3, Binding("a", "player@example.com"));
            Assert(result.ErrorCode == "CREDENTIAL_STORAGE_FAILED" && h.Session.AccountName == null, "failed binding persistence changed memory");
        }

        private static void PasswordLoginReplacesCredentials()
        {
            var h = new Harness(); h.Guest();
            ApiResult<SessionIdentity> result = null;
            int changes = 0; h.Session.IdentityChanged += () => changes++;
            h.Session.LoginAccount("player@example.com", "Password!", r => result = r);
            Assert(h.Transport.Requests[1].AccessToken == null && h.Transport.Requests[1].BodyJson.Contains("\"deviceId\":"), "login reused guest bearer or omitted installation id");
            h.Transport.Reply(1, Identity("b", "player@example.com"));
            Assert(result.IsSuccess && h.Session.UserId == "b" && changes == 1, "login did not notify identity switch");
            Assert(h.Store.State.GuestCredential == "guest-b" && h.Store.State.RefreshToken == "refresh-b", "login kept old guest credentials");
            var clean = new Harness();
            clean.Session.LoginAccount("player@example.com", "Password!", r => result = r);
            clean.Transport.Reply(0, Identity("b", "player@example.com"));
            Assert(result.IsSuccess && clean.Session.UserId == "b", "clean installation requires guest login before password login");
        }

        private static void FailedLoginPreservesIdentity()
        {
            var h = new Harness(); h.Guest();
            string before = JsonUtility.ToJson(h.Store.State);
            ApiResult<SessionIdentity> result = null;
            h.Session.LoginAccount("player@example.com", "Password!", r => result = r);
            h.Transport.Fail(1, "INVALID_CREDENTIALS", 401);
            Assert(result.ErrorCode == "INVALID_CREDENTIALS" && JsonUtility.ToJson(h.Store.State) == before, "wrong password cleared guest");
            h.Session.LoginAccount("player@example.com", "Password!", r => result = r);
            h.Transport.Reply(2, Identity("b", "player@example.com").Replace("\"guestCredential\":\"guest-b\",", ""));
            Assert(result.ErrorCode == "INVALID_RESPONSE" && JsonUtility.ToJson(h.Store.State) == before, "login inherited old guest credential");
            h.Session.LoginAccount("player@example.com", "Password!", r => result = r);
            h.Store.FailSave = true;
            h.Transport.Reply(3, Identity("b", "player@example.com"));
            Assert(result.ErrorCode == "CREDENTIAL_STORAGE_FAILED" && h.Session.UserId == "a", "login storage failure changed identity");
        }

        private static void ObsoleteResponsesAreIgnored()
        {
            var h = new Harness(); h.Guest();
            ApiResult<AccountBinding> binding = null;
            ApiResult<SessionIdentity> first = null;
            h.Session.BindAccount("old@example.com", "Password!", r => binding = r);
            h.Session.LoginAccount("old@example.com", "Password!", r => first = r);
            h.Session.LoginAccount("new@example.com", "Password!", _ => { });
            h.Transport.Reply(3, Identity("b", "new@example.com"));
            h.Transport.Reply(1, Binding("a", "old@example.com"));
            h.Transport.Reply(2, Identity("a", "old@example.com"));
            Assert(binding.ErrorCode == "ACCOUNT_CHANGED" && first.ErrorCode == "ACCOUNT_CHANGED", "old auth response survived identity switch");
            Assert(h.Session.UserId == "b" && h.Session.AccountName == "new@example.com", "old request overwrote new account");
            h.Session.LoginAccount("new@example.com", "Password!", r => first = r);
            h.Session.Logout(_ => { });
            h.Transport.Reply(5, "{}");
            h.Transport.Reply(4, Identity("b", "new@example.com"));
            Assert(first.ErrorCode == "ACCOUNT_CHANGED" && h.Session.UserId == null, "late login resurrected logged-out account");
        }

        private static void BoundRestoreAndRefreshRace()
        {
            var h = new Harness(); h.Guest();
            h.Session.BindAccount("player@example.com", "Password!", _ => { });
            h.Transport.Reply(1, Binding("a", "player@example.com"));
            h.Session = new PlatformSession(h.Transport, h.Store, "hub");
            ApiResult<SessionIdentity> resumed = null;
            h.Session.ResumeSession(r => resumed = r);
            Assert(h.Transport.Requests[2].Path.EndsWith("/refresh"), "bound account did not prefer refresh token");
            h.Transport.Reply(2, Identity("a", null));
            Assert(resumed.IsSuccess && h.Session.AccountName == "player@example.com", "refresh lost binding hint");
            h.Session = new PlatformSession(h.Transport, h.Store, "hub");
            h.Session.ResumeSession(r => resumed = r);
            h.Transport.Fail(3, "INVALID_REFRESH_TOKEN", 401);
            Assert(!resumed.IsSuccess && h.Transport.Requests.Count == 4 && h.Session.UserId == "a", "bound recovery silently created another guest");

            // A slow binding response must not invalidate an unrelated token rotation.
            h = new Harness(); h.Guest();
            h.Session.BindAccount("player@example.com", "Password!", _ => { });
            bool protectedOk = false;
            h.Session.SendAuthorized<AccountBinding>(new ApiRequest("GET", "/v1/platform/probe"), r => protectedOk = r.IsSuccess);
            h.Transport.Fail(2, "UNAUTHORIZED", 401); // Starts refresh at index 3.
            h.Transport.Reply(1, Binding("a", "player@example.com"));
            h.Transport.Reply(3, Identity("a", null));
            Assert(h.Transport.Requests.Count == 5, "binding discarded an in-flight refresh response");
            h.Transport.Reply(4, "{}");
            Assert(protectedOk && h.Session.AccountName == "player@example.com", "binding and refresh race lost state");
        }

        private static void InputAndGuestCompatibility()
        {
            var h = new Harness();
            ExpectArgument(() => h.Session.BindAccount("bad", "Password!", _ => { }));
            ExpectArgument(() => h.Session.LoginAccount("a@b", "short", _ => { }));
            ExpectArgument(() => h.Session.LoginAccount("a@b", "password\n", _ => { }));
            Assert(h.Transport.Requests.Count == 0, "invalid input reached transport");
            h.Session.ResumeSession(_ => { });
            Assert(h.Transport.Requests[0].Path.EndsWith("/guest"), "unbound installation cannot create guest");
            h.Transport.Reply(0, Identity("a", null));
            h.Session.ResumeGuest(_ => { });
            Assert(h.Transport.Requests[1].BodyJson.Contains("guest-a"), "guest resume omitted secret");
            ApiResult<SessionIdentity> bad = null;
            h.Session.ResumeGuest(r => bad = r);
            h.Transport.Reply(2, Identity("b", null));
            Assert(bad.ErrorCode == "INVALID_IDENTITY" && h.Session.UserId == "a", "guest recovery silently changed account");
        }

        private static void BindingReadRace()
        {
            var h = new Harness(); h.Guest();
            ApiResult<AccountBinding> old = null;
            h.Session.GetAccountBinding(r => old = r);
            h.Session.BindAccount("player@example.com", "Password!", _ => { });
            h.Transport.Reply(2, Binding("a", "player@example.com"));
            h.Transport.Reply(1, "{\"userId\":\"a\",\"isBound\":false}");
            Assert(!old.IsSuccess && h.Session.AccountName == "player@example.com", "old query erased successful binding");
        }

        private static void KnownUserWithoutCredentialRequiresLogin()
        {
            var transport = new QueuedTransport();
            var store = new MemoryStore
            {
                State = new CredentialState
                {
                    DeviceId = "known-device-1234567890",
                    UserId = "existing-user"
                }
            };
            var session = new PlatformSession(transport, store, "hub");
            ApiResult<SessionIdentity> result = null;
            session.ResumeSession(r => result = r);
            Assert(result?.ErrorCode == "LOGIN_REQUIRED" && transport.Requests.Count == 0 &&
                session.UserId == "existing-user", "known user without guest secret silently created a different guest");
        }

        private static void WindowsEditorCredentialStorePersistsEncryptedState()
        {
#if UNITY_EDITOR_WIN
            Type type = typeof(EditorMemoryCredentialStore).Assembly.GetType(
                "MiniGamePlatform.SDK.Auth.WindowsEditorCredentialStore", false);
            Assert(type != null, "Windows Editor encrypted credential store is missing");
            string directory = Path.Combine(Path.GetTempPath(), "MiniGameCredentialChecks-" + Guid.NewGuid().ToString("N"));
            string path = Path.Combine(directory, "credentials.bin");
            try
            {
                var first = (ICredentialStore)Activator.CreateInstance(type, path);
                first.Save(new CredentialState
                {
                    DeviceId = "editor-device-1234567890", UserId = "editor-user",
                    GuestCredential = "guest-secret-editor-test", RefreshToken = "refresh-secret-editor-test"
                });
                string stored = Encoding.UTF8.GetString(File.ReadAllBytes(path));
                Assert(!stored.Contains("guest-secret-editor-test") && !stored.Contains("refresh-secret-editor-test"),
                    "Editor credentials were written in plaintext");
                var restarted = (ICredentialStore)Activator.CreateInstance(type, path);
                Assert(restarted.TryLoad(out CredentialState loaded) && loaded.UserId == "editor-user" &&
                    loaded.GuestCredential == "guest-secret-editor-test" && loaded.RefreshToken == "refresh-secret-editor-test",
                    "Editor credentials did not survive a new store instance");
                byte[] encrypted = File.ReadAllBytes(path);
                encrypted[encrypted.Length - 1] ^= 0x5a;
                File.WriteAllBytes(path, encrypted);
                bool rejected = false;
                try { restarted.TryLoad(out _); }
                catch (InvalidOperationException) { rejected = true; }
                Assert(rejected && File.Exists(path), "corrupt encrypted credentials were treated as a new installation");
                restarted.Clear();
                Assert(!File.Exists(path) && !restarted.TryLoad(out _), "Editor credentials were not cleared");
            }
            finally { if (Directory.Exists(directory)) Directory.Delete(directory, true); }
#endif
        }

        private static void RestoreStorageFailureCanRetry()
        {
            var h = new Harness(); h.Guest();
            h.Session.BindAccount("player@example.com", "Password!", _ => { });
            h.Transport.Reply(1, Binding("a", "player@example.com"));
            h.Session = new PlatformSession(h.Transport, h.Store, "hub");
            ApiResult<SessionIdentity> resumed = null;
            h.Store.FailSave = true;
            try { h.Session.ResumeSession(r => resumed = r); }
            catch (Exception e) { throw new Exception("bound resume threw instead of completing storage error callback", e); }
            Assert(resumed?.ErrorCode == "CREDENTIAL_STORAGE_FAILED" && h.Transport.Requests.Count == 2, "refresh sent before safely persisting retry key");
            h.Store.FailSave = false;
            h.Session.ResumeSession(r => resumed = r);
            Assert(h.Transport.Requests.Count == 3, "storage failure left refresh in-flight forever");
            string key = h.Transport.Requests[2].IdempotencyKey;
            h.Store.FailSave = true;
            h.Transport.Reply(2, Identity("a", null));
            Assert(resumed.ErrorCode == "CREDENTIAL_STORAGE_FAILED" && h.Store.State.PendingRefreshKey == key, "refresh result persistence failure lost retry state");
            h.Store.FailSave = false;
            h.Session.ResumeSession(r => resumed = r);
            Assert(h.Transport.Requests[3].IdempotencyKey == key, "retry after storage failure changed refresh key");
            h.Transport.Reply(3, Identity("a", null));
            Assert(resumed.IsSuccess, "could not resume after fixing storage");
        }

        private static void ExpectArgument(Action action)
        {
            try { action(); } catch (ArgumentException) { _assertions++; return; }
            throw new Exception("Expected input validation failure.");
        }

        private static string Identity(string id, string name) => "{\"userId\":\"" + id + "\",\"guestCredential\":\"guest-" + id + "\",\"accessToken\":\"access-" + id + "\",\"refreshToken\":\"refresh-" + id + "\",\"expiresInSeconds\":900,\"refreshExpiresInSeconds\":3600" + (name == null ? "" : ",\"accountName\":\"" + name + "\"") + "}";
        private static string Binding(string id, string name) => "{\"userId\":\"" + id + "\",\"accountName\":\"" + name + "\",\"isBound\":true}";

        private sealed class Harness
        {
            public readonly QueuedTransport Transport = new QueuedTransport();
            public readonly MemoryStore Store = new MemoryStore();
            public PlatformSession Session;
            public Harness() { Session = new PlatformSession(Transport, Store, "hub"); }
            public void Guest() { Session.LoginGuest(_ => { }); Transport.Reply(0, Identity("a", null)); }
        }

        private sealed class MemoryStore : ICredentialStore
        {
            public CredentialState State;
            public bool FailSave;
            public void Save(CredentialState state) { if (FailSave) throw new Exception("Simulated disk failure"); State = state.Copy(); }
            public bool TryLoad(out CredentialState state) { state = State?.Copy(); return state != null; }
            public void Clear() { State = null; }
        }

        private sealed class QueuedTransport : IPlatformTransport
        {
            public readonly List<ApiRequest> Requests = new List<ApiRequest>();
            private readonly List<Action<string, int>> _callbacks = new List<Action<string, int>>();
            public void Send<T>(ApiRequest request, Action<ApiResult<T>> callback)
            { Requests.Add(request); _callbacks.Add((json, status) => callback(ApiResult<T>.FromJson(json, status))); }
            public void Reply(int index, string data) { _callbacks[index]("{\"data\":" + data + ",\"meta\":{\"requestId\":\"test\"}}", 200); }
            public void Fail(int index, string code, int status) { _callbacks[index]("{\"error\":{\"code\":\"" + code + "\",\"retryable\":false}}", status); }
        }

        private static void Assert(bool condition, string message)
        {
            _assertions++;
            if (!condition) throw new Exception(message);
        }
    }
}
