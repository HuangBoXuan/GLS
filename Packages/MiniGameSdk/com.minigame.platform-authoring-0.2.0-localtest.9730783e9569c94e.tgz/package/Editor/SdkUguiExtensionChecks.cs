using System;
using System.Reflection;
using MiniGamePlatform.HotUpdate;
using UnityEngine;
using UnityEngine.UI;
using XLua;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public static class SdkUguiExtensionChecks
    {
        private static int _checks;
        private static void Check(bool value, string message) { _checks++; if (!value) throw new Exception(message); }
        public static void Run()
        {
            _checks = 0;
            Type meshType = typeof(GameHostBridge).Assembly.GetType("MiniGamePlatform.Components.ModuleMeshGraphic");
            Check(meshType != null, "Missing generic MaskableGraphic mesh carrier.");
            Type filterType = typeof(GameHostBridge).Assembly.GetType("MiniGamePlatform.Components.ModuleRaycastFilter");
            Check(filterType != null, "Missing generic raycast filter.");
            var root = new GameObject("MeshChecks", typeof(RectTransform), typeof(Canvas));
            var mesh = new Mesh { vertices = new[] { Vector3.zero, Vector3.right, Vector3.up }, triangles = new[] { 0, 1, 2 } };
            var result = new Mesh();
            var texture = new Texture2D(1, 1);
            var material = new Material(Shader.Find("UI/Default"));
            try
            {
                var go = new GameObject("Carrier", typeof(RectTransform)); go.transform.SetParent(root.transform, false);
                var graphic = (MaskableGraphic)go.AddComponent(meshType);
                Check(go.GetComponent<CanvasRenderer>() != null, "Adding mesh Graphic did not require a CanvasRenderer.");
                var meshProperty = meshType.GetProperty("Mesh");
                meshProperty.SetValue(graphic, mesh);
                meshType.GetProperty("Texture").SetValue(graphic, texture); graphic.material = material;
                Check(graphic.mainTexture == texture && graphic.material == material, "Borrowed native assets changed.");
                var populate = meshType.GetMethod("OnPopulateMesh", BindingFlags.Instance | BindingFlags.NonPublic, null, new[] { typeof(VertexHelper) }, null);
                using (var vh = new VertexHelper())
                {
                    populate.Invoke(graphic, new object[] { vh }); vh.FillMesh(result);
                    Check(result.vertexCount == 3 && result.triangles.Length == 3, "Triangle mesh was lost.");
                    Check(result.colors32[0].a == 255, "Missing vertex colors must default to white.");
                    graphic.color = new Color(1, .5f, .25f, .5f);
                    populate.Invoke(graphic, new object[] { vh }); vh.FillMesh(result);
                    Check(result.colors32[0].a >= 127 && result.colors32[0].a <= 128, "Graphic tint not applied.");
                    meshProperty.SetValue(graphic, null); populate.Invoke(graphic, new object[] { vh });
                    Check(vh.currentVertCount == 0, "Null mesh retained old geometry.");
                }
                mesh.subMeshCount = 2;
                bool rejected = false; try { meshProperty.SetValue(graphic, mesh); } catch (TargetInvocationException e) { rejected = e.InnerException is ArgumentException; }
                Check(rejected, "Multiple materials must not be silently collapsed into one Graphic.");
                mesh.subMeshCount = 1;
                var filter = (Behaviour)go.AddComponent(filterType);
                var raycast = (ICanvasRaycastFilter)filter;
                Check(raycast.IsRaycastLocationValid(Vector2.zero, null), "Unbound filter must defer to UGUI.");
                using (var env = new LuaEnv())
                {
                    env.Global.Set("filter", filter);
                    env.DoString("filter.Filter = function(p, camera) return p.x > 0 and camera == nil end");
                    Check(raycast.IsRaycastLocationValid(Vector2.one, null), "Lua bool callback rejected valid point.");
                    Check(!raycast.IsRaycastLocationValid(Vector2.zero, null), "Lua bool callback ignored rejection.");
                    filter.enabled = false;
                    Check(raycast.IsRaycastLocationValid(Vector2.zero, null), "Disabled filter still rejected point.");
                    filter.enabled = true;
                    env.DoString("filter.Filter = nil; filter=nil; collectgarbage('collect')");
                }
                UnityEngine.Object.DestroyImmediate(go);
                Check(mesh != null && texture != null && material != null, "Carrier destroyed borrowed assets.");
                var old = new HostProfile(5, "editor", Application.unityVersion, new[] { NativeLuaBaseline.Capability });
                Check(!old.SupportsCapability("unity_ugui_mesh_v1") && !old.SupportsCapability("unity_ugui_raycast_v1"), "Old native baseline claimed new capability.");
                Check(HostProfile.Current.SupportsCapability("unity_ugui_mesh_v1") && HostProfile.Current.SupportsCapability("unity_ugui_raycast_v1"), "Current host lacks extension capability.");
            }
            finally { UnityEngine.Object.DestroyImmediate(root); UnityEngine.Object.DestroyImmediate(mesh); UnityEngine.Object.DestroyImmediate(result); UnityEngine.Object.DestroyImmediate(texture); UnityEngine.Object.DestroyImmediate(material); }
            Debug.Log("UGUI_EXTENSION_CHECKS_PASSED assertions=" + _checks);
        }
    }
}
