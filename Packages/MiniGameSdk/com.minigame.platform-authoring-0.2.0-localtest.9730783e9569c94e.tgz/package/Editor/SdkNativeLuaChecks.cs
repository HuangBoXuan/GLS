using System;
using UnityEditor;
using UnityEngine;
using UnityEngine.Events;
using XLua;
using MiniGamePlatform.HotUpdate;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public static class SdkNativeLuaChecks
    {
        public static void RunDelegates()
        {
            // Deliberately disable Editor-only emitted delegates, matching the static Player path.
            DelegateBridge.Gen_Flag = true;
            using (var env = new LuaEnv())
            {
                env.DoString("function native_accept(value) native_result=value end");
                InvokeDelegates(env);
                env.DoString("native_accept=nil; native_result=nil; collectgarbage('collect')");
            }
            Debug.Log("Native xLua static UnityAction checks passed.");
        }

        private static void InvokeDelegates(LuaEnv env)
        {
            var number = env.Global.Get<UnityAction<float>>("native_accept"); number(0.75f);
            if (env.Global.Get<float>("native_result") != 0.75f) throw new Exception("Float callback mismatch.");
            var toggle = env.Global.Get<UnityAction<bool>>("native_accept"); toggle(true);
            if (!env.Global.Get<bool>("native_result")) throw new Exception("Bool callback mismatch.");
            var index = env.Global.Get<UnityAction<int>>("native_accept"); index(7);
            if (env.Global.Get<int>("native_result") != 7) throw new Exception("Int callback mismatch.");
            var text = env.Global.Get<UnityAction<string>>("native_accept"); text("native");
            if (env.Global.Get<string>("native_result") != "native") throw new Exception("String callback mismatch.");
            var scroll = env.Global.Get<UnityAction<Vector2>>("native_accept"); scroll(new Vector2(2, 3));
            if (env.Global.Get<Vector2>("native_result") != new Vector2(2, 3)) throw new Exception("Vector2 callback mismatch.");
            env.Global.Get<UnityAction<Vector3>>("native_accept")(new Vector3(1, 2, 3));
            if (env.Global.Get<Vector3>("native_result") != new Vector3(1, 2, 3)) throw new Exception("Vector3 callback mismatch.");
            env.Global.Get<UnityAction<Color>>("native_accept")(Color.red);
            if (env.Global.Get<Color>("native_result") != Color.red) throw new Exception("Color callback mismatch.");
            env.DoString("function native_return() return 42 end");
            if (env.Global.Get<Func<int>>("native_return")() != 42) throw new Exception("Static return callback mismatch.");
            env.DoString("native_return=nil");
        }

        public static void RunDisposal()
        {
            var env = new LuaEnv();
            env.DoString("return 42");
            env.Dispose();
            bool closed = false;
            try { var state = env.L; } catch (InvalidOperationException) { closed = true; }
            if (!closed) throw new Exception("LuaEnv.Dispose left the native Lua state open.");
            env.Dispose();
            Debug.Log("Native xLua disposal checks passed: state closed and repeated disposal safe.");
        }

        public static void RunPendingDisposal()
        {
            string directory = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "NativeDisposal-" + Guid.NewGuid().ToString("N"));
            System.IO.Directory.CreateDirectory(System.IO.Path.Combine(directory, "games/disposal"));
            const string relative = "games/disposal/main.lua";
            byte[] bytes = System.Text.Encoding.UTF8.GetBytes("return {enter=function(h) end, exit=function() end}");
            System.IO.File.WriteAllBytes(System.IO.Path.Combine(directory, relative), bytes);
            using var sha = System.Security.Cryptography.SHA256.Create();
            var manifest = new ModuleManifest { formatVersion = 1, gameId = "disposal", version = "v1", runtimeType = "unity_lua",
                platform = "editor", unityVersion = Application.unityVersion, minHostApiVersion = 5, entry = "games.disposal.main",
                requiredCapabilities = new[] { "lua" }, files = new[] { new ModuleFile { path = relative, size = bytes.Length,
                    sha256 = BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant() } } };
            var runner = new LuaGameRunner();
            var retained = typeof(LuaGameRunner).GetField("_environment", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
            var external = new UnityEvent();
            LuaEnv env = null;
            try
            {
                runner.Enter(manifest, directory, null);
                env = (LuaEnv)retained.GetValue(runner);
                env.Global.Set("external_event", external);
                env.DoString("external_event:AddListener(function() return end)");
                runner.Exit();
                if (runner.LastError == null || !runner.HasPendingExit || retained.GetValue(runner) != env)
                    throw new Exception("Failed disposal lost the pending Lua environment.");
                bool rejected = false;
                try { runner.Enter(manifest, directory, null); } catch (ModuleRunException) { rejected = true; }
                if (!rejected || retained.GetValue(runner) != env) throw new Exception("Re-entry replaced an unclosed Lua environment.");
                external.RemoveAllListeners(); env.DoString("external_event=nil; collectgarbage('collect')");
                runner.Exit();
                if (runner.HasPendingExit || retained.GetValue(runner) != null) throw new Exception("Pending environment did not close after unbind.");
                bool closed = false; try { var state = env.L; } catch (InvalidOperationException) { closed = true; }
                if (!closed) throw new Exception("Retried disposal did not close native state.");
                runner.Enter(manifest, directory, null); runner.Exit();
                if (runner.LastError != null) throw new Exception("Healthy re-entry failed after cleanup.");
                Debug.Log("Pending Lua disposal checks passed: retain, block re-entry, unbind, retry, re-enter.");
            }
            finally
            {
                external.RemoveAllListeners();
                if (env != null) { try { env.DoString("external_event=nil"); env.Dispose(); } catch (InvalidOperationException) { } }
                runner.Dispose();
                System.IO.Directory.Delete(directory, true);
            }
        }

        public static void RunLinkerRegistration()
        {
            Type type = typeof(SdkNativeLuaChecks).Assembly.GetType("MiniGamePlatform.SDK.EditorChecks.NativeLuaLinkerProcessor");
            if (type == null || !(Activator.CreateInstance(type) is UnityEditor.Build.IUnityLinkerProcessor processor))
                throw new Exception("Package linker baseline is not registered with UnityLinker.");
            string path = processor.GenerateAdditionalLinkXmlFile(null, null);
            if (!System.IO.File.Exists(path)) throw new Exception("Linker callback returned no file.");
            Debug.Log("Package linker registration check passed: " + path);
        }

        [MenuItem("MiniGame Platform/SDK/Run Native Lua Checks")]
        public static void Run()
        {
            SdkHostCompositionChecks.Run();
            SdkHostServicesChecks.Run();
            SdkTimingChecks.Run();
            SdkAuthChecks.Run();
            SdkUguiExtensionChecks.Run();
            SdkLocalizationChecks.Run();
            RunDelegates(); RunDisposal(); RunPendingDisposal(); RunLinkerRegistration();
            SdkNativeAdmissionChecks.Run();
            var inventory = HostComponentInventory.FromCapabilities(new[] { NativeLuaBaseline.Capability }, Array.Empty<string>());
            if (!inventory.HasComponent(typeof(UnityEngine.UI.Button).FullName, typeof(UnityEngine.UI.Button).Assembly.GetName().Name) ||
                !inventory.HasComponent(typeof(Animator).FullName, typeof(Animator).Assembly.GetName().Name) ||
                inventory.HasComponent("GameSpecificBehaviour", "Assembly-CSharp"))
                throw new Exception("Native component inventory does not match retained host assemblies.");
            var oldHost = new HostProfile(5, "editor", Application.unityVersion, new[] { "lua", "assetbundle" });
            var nativeManifest = new ModuleManifest { minHostApiVersion = 5, platform = "editor", unityVersion = Application.unityVersion,
                requiredCapabilities = new[] { "lua", NativeLuaBaseline.Capability }, runtimeType = "unity_lua" };
            if (oldHost.Supports(nativeManifest, out _)) throw new Exception("Legacy API 5 host accepted the new native baseline.");
            var package = UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(HostProfile).Assembly);
            var xml = new System.Xml.XmlDocument(); xml.Load(System.IO.Path.Combine(package.resolvedPath, "Runtime/link.xml"));
            foreach (string name in NativeLuaBaseline.RetainedAssemblies)
                if (xml.SelectSingleNode("/linker/assembly[@fullname='" + name + "' and @preserve='all']") == null)
                    throw new Exception("Native inventory lacks corresponding linker retention: " + name);
            Debug.Log("Native capability, component inventory and linker parity checks passed.");
            SdkModulePlayerChecks.RunRegression();
        }
    }
}
