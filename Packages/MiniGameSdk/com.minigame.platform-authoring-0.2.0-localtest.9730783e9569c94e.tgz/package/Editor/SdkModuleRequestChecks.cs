using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using MiniGamePlatform.SDK.Auth;
using MiniGamePlatform.SDK.Contracts;
using MiniGamePlatform.SDK.Host;
using MiniGamePlatform.SDK.Network;
using UnityEngine;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public static class SdkModuleRequestChecks
    {
        private sealed class Transport : IPlatformTransport
        {
            public string User = "A";
            public bool Deferred;
            public string Payload = "{\"data\":{\"score\":123,\"items\":[{\"player\":\"任意游戏字段\"}]},\"meta\":{\"requestId\":\"server-id\"}}";
            public ApiRequest Last;
            public readonly Queue<Action> Replies = new Queue<Action>();
            public void Send<T>(ApiRequest request, Action<ApiResult<T>> callback)
            {
                Last = request;
                string json = request.Path.StartsWith("/v1/platform/auth/", StringComparison.Ordinal)
                    ? "{\"data\":{\"userId\":\"" + User + "\",\"accessToken\":\"test-access\",\"refreshToken\":\"test-refresh\",\"expiresInSeconds\":3600}}"
                    : Payload;
                Action reply = () => callback(ApiResult<T>.FromJson(json, 200));
                if (Deferred) Replies.Enqueue(reply); else reply();
            }
        }
        private static int _checks;
        private static void Check(bool condition, string message)
        { _checks++; if (!condition) throw new Exception(message); }
        private static string Send(object service, string json, Action<string> callback)
        {
            try { return (string)service.GetType().GetMethod("Send").Invoke(service, new object[] { json, callback }); }
            catch (TargetInvocationException error) { throw error.InnerException; }
        }
        public static void Run()
        {
            _checks = 0;
            var property = typeof(IModuleHostServices).GetProperty("Requests");
            Check(property != null, "Missing stable game-scoped JSON request interface.");
            var transport = new Transport();
            var session = new PlatformSession(transport, new EditorMemoryCredentialStore(), "request-test");
            session.LoginGuest(_ => { });
            var queue = new HostMainThreadQueue();
            string root = Path.Combine(Path.GetTempPath(), "mgp-request-" + Guid.NewGuid().ToString("N"));
            var broker = new HostAdBroker(null, queue);
            using var services = new ModuleHostServices(session, "one", new AtomicLocalStore(root), broker, "request-test", "game-a");
            object requests = property.GetValue(services);
            string response = null;
            string id = Send(requests, "{\"method\":\"GET\",\"path\":\"leaderboard\",\"query\":[{\"key\":\"page\",\"value\":\"2\"}]}", value => response = value);
            Check(!string.IsNullOrEmpty(id), "Request has no cancellation identity.");
            queue.Drain();
            Check(transport.Last.RelativePathAndQuery == "/v1/games/game-a/leaderboard?page=2", "Wrong game path or pagination.");
            Check(transport.Last.ProductId == "request-test", "Host product identity missing.");
            Check(response != null && response.Contains("任意游戏字段") && response.Contains("123"), "Generic response lost game-specific JSON.");
            foreach (string payload in new[] { "{\"data\":[1,2,3]}", "{\"data\":123}", "{\"data\":\"text\"}" })
            {
                transport.Payload = payload; response = null;
                Send(requests, "{\"method\":\"GET\",\"path\":\"custom\"}", value => response = value);
                queue.Drain();
                Check(response == payload, "Core SDK constrained a game's JSON payload: " + payload);
            }
            foreach (string path in new[] { "../other", "/v1/platform/wallet", "https://example.com", "a?x=1", "%2e%2e/other" })
            {
                bool rejected = false;
                try { Send(requests, "{\"method\":\"POST\",\"path\":\"" + path + "\"}", _ => { }); }
                catch (ArgumentException) { rejected = true; }
                Check(rejected, "Unsafe module request accepted: " + path);
            }
            transport.Deferred = true;
            int callbacks = 0;
            Send(requests, "{\"method\":\"POST\",\"path\":\"sessions\",\"bodyJson\":\"{}\",\"idempotencyKey\":\"same-operation-key\"}", _ => callbacks++);
            Check(transport.Last.IdempotencyKey == "same-operation-key", "Idempotency key changed.");
            services.Dispose(); transport.Replies.Dequeue()(); queue.Drain();
            Check(callbacks == 0, "Disposed module received a network callback.");
            using var changed = new ModuleHostServices(session, "one", new AtomicLocalStore(root), broker, "request-test", "game-a");
            Send(property.GetValue(changed), "{\"method\":\"GET\",\"path\":\"progress\"}", _ => callbacks++);
            var old = transport.Replies.Dequeue();
            transport.Deferred = false; transport.User = "B"; session.LoginGuest(_ => { });
            old(); queue.Drain();
            Check(callbacks == 0, "Account switch delivered a stale callback.");
            Debug.Log("MODULE_REQUEST_CHECKS_PASSED assertions=" + _checks);
        }
    }
}
