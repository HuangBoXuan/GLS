using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Security.Cryptography;
using MiniGamePlatform.SDK.Contracts;
using MiniGamePlatform.HotUpdate;
using MiniGamePlatform.SDK.Auth;
using MiniGamePlatform.SDK.GameData;
using MiniGamePlatform.SDK.Network;
using UnityEngine;
using UnityEngine.Events;
using XLua;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public static class SdkHostCompositionChecks
    {
        private static int _checks;
        private static void Check(bool value, string message)
        { _checks++; if (!value) throw new Exception(message); }
        private static T Reject<T>(Action action) where T : Exception
        {
            _checks++;
            try { action(); }
            catch (T e) { return e; }
            throw new Exception("Expected " + typeof(T).Name);
        }
        private static ProductContext Product(string serverGame = null, string productId = "hub_local_test") =>
            new ProductContext(productId, "https://example.invalid", "1.0.0", new[] { "nativecheck" },
                serverGame == null ? null : new Dictionary<string, string> { { "nativecheck", serverGame } });
        private sealed class NoNetwork : IPlatformTransport
        {
            public int Calls;
            public void Send<T>(ApiRequest request, Action<ApiResult<T>> callback)
            { Calls++; throw new Exception("Service construction must not send network requests."); }
        }
        public static void RunFactory()
        {
            _checks = 0;
            var factory = MiniGamePlatform.SDK.Host.CommonModuleServiceFactory.CreateDefault();
            var manifest = new ModuleManifest { gameId = "nativecheck", requiredCapabilities = new[] { "lua" } };
            using (var offline = factory.CreateServices(manifest, null, null))
                Check(!offline.Account.IsAvailable, "Offline scope invented an account.");
            using (var garden = factory.CreateServices(manifest, Product("garden"), null))
                Check(!garden.Account.IsAvailable, "Factory invented a game-specific login.");
            Check(typeof(GameHostBridge).GetProperty("Platform") == null, "Bridge still exposes legacy business facade.");
            Check(typeof(PlatformSession).Assembly != typeof(LuaGameRunner).Assembly, "SDK still includes Unity runtime implementation.");
            Check(typeof(LuaGameRunner).Assembly.GetType("MiniGamePlatform.SDK.GameData.GardenDataClient") == null,
                "Host still compiles game-specific clients.");
            Reject<ArgumentException>(() => factory.CreateServices(null, null, null));
            Reject<InvalidOperationException>(() => factory.CreateServices(new ModuleManifest { gameId = "forbidden" }, Product(), null));
            Debug.Log("HOST_FACTORY_CHECKS_PASSED assertions=" + _checks);
        }
        private sealed class RecordingFactory : IModuleHostServiceFactory
        {
            public int Calls;
            public string LastGameId;
            public bool ThrowOnCreate;
            public IModuleHostServices CreateServices(ModuleManifest manifest, ProductContext product, PlatformSession session)
            {
                Calls++; LastGameId = manifest.gameId;
                if (ThrowOnCreate) throw new InvalidOperationException("factory-failed");
                return null;
            }
        }
        private sealed class Fixture : IDisposable
        {
            public readonly string DirectoryPath = Path.Combine(Path.GetTempPath(), "HostComposition-" + Guid.NewGuid().ToString("N"));
            public readonly byte[] Lua;
            public readonly string Hash;
            public string LuaPath => Path.Combine(DirectoryPath, "games/nativecheck/main.lua");
            public Fixture()
            {
                Directory.CreateDirectory(Path.GetDirectoryName(LuaPath));
                Lua = System.Text.Encoding.UTF8.GetBytes(@"return {
enter=function(h) assert(h.Launch ~= nil); h:ShowMessage('entered') end,
update=function(dt) end, pause=function() end, resume=function() end, exit=function() end }");
                File.WriteAllBytes(LuaPath, Lua);
                var manifest = new ModuleManifest { formatVersion = 1, gameId = "nativecheck", version = "v1", runtimeType = "unity_lua",
                    entry = "games.nativecheck.main", minHostApiVersion = 1, platform = "editor", unityVersion = Application.unityVersion,
                    requiredCapabilities = new[] { "lua" }, files = new[] { new ModuleFile { path = "games/nativecheck/main.lua", size = Lua.Length, sha256 = Digest(Lua) } } };
                byte[] json = System.Text.Encoding.UTF8.GetBytes(JsonUtility.ToJson(manifest));
                File.WriteAllBytes(Path.Combine(DirectoryPath, "manifest.json"), json); Hash = Digest(json);
            }
            private static string Digest(byte[] bytes)
            { using var sha = SHA256.Create(); return BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant(); }
            public void Dispose() { Directory.Delete(DirectoryPath, true); }
        }
        private static ModulePlayer Player(string shell, IModuleHostServiceFactory factory, string game = "nativecheck")
        {
            var ctor = typeof(ModulePlayer).GetConstructor(new[] { typeof(string), typeof(string), typeof(IModuleContentKeyProvider), typeof(IModuleHostServiceFactory) });
            Check(ctor != null, "ModulePlayer lacks host factory injection.");
            try { return (ModulePlayer)ctor.Invoke(new object[] { shell, shell == "independent" ? game : null, null, factory }); }
            catch (TargetInvocationException e) { throw e.InnerException; }
        }
        private static LuaEnv EnvironmentOf(ModulePlayer player)
        {
            const BindingFlags flags = BindingFlags.Instance | BindingFlags.NonPublic;
            var runner = typeof(ModulePlayer).GetField("_runner", flags).GetValue(player);
            return (LuaEnv)typeof(LuaGameRunner).GetField("_environment", flags).GetValue(runner);
        }
        public static void RunRunner()
        {
            using var fixture = new Fixture();
            Reject<ArgumentNullException>(() => Player("hub", null));
            foreach (string shell in new[] { "hub", "independent" })
            {
                var factory = new RecordingFactory();
                using var player = Player(shell, factory);
                for (int i = 1; i <= 2; i++)
                {
                    string status = null;
                    player.OpenInstalled(fixture.DirectoryPath, fixture.Hash, Product(), null, null, s => status = s);
                    Check(status == "entered" && factory.Calls == i && factory.LastGameId == "nativecheck", "Factory did not precede Lua enter exactly once.");
                    player.Tick(); player.Pause(); player.Tick();
                    Check(player.SuccessfulTicks == 1 && player.State == GameRunState.Paused, "Injected runtime pause changed.");
                    player.Resume(); player.Tick(); player.Exit();
                    Check(!player.HasPendingExit && player.LastError == null, "Injected offline module did not exit cleanly.");
                }
            }
            var guarded = new RecordingFactory();
            using (var player = Player("hub", guarded))
            {
                Reject<InvalidDataException>(() => player.OpenInstalled(fixture.DirectoryPath, new string('0', 64), Product(), null, null, null));
                File.WriteAllText(fixture.LuaPath, "tampered");
                Reject<InvalidDataException>(() => player.OpenInstalled(fixture.DirectoryPath, fixture.Hash, Product(), null, null, null));
                File.WriteAllBytes(fixture.LuaPath, fixture.Lua);
                var forbidden = new ProductContext("test", "https://example.invalid", "1.0.0", new[] { "another" });
                Reject<InvalidDataException>(() => player.OpenInstalled(fixture.DirectoryPath, fixture.Hash, forbidden, null, null, null));
            }
            using (var player = Player("independent", guarded, "another"))
                Reject<InvalidDataException>(() => player.OpenInstalled(fixture.DirectoryPath, fixture.Hash, Product(), null, null, null));
            Check(guarded.Calls == 0, "Rejected module called host factory.");
            var failing = new RecordingFactory { ThrowOnCreate = true };
            using (var player = Player("hub", failing))
            {
                bool entered = false;
                var failure = Reject<ModuleRunException>(() => player.OpenInstalled(fixture.DirectoryPath, fixture.Hash, Product(), null, null, s => entered = true));
                Check(failure.Code == "ENTER_FAILED" && failure.InnerException.Message == "factory-failed" && !entered, "Factory failure was hidden or entered Lua.");
                Check(player.State == GameRunState.Empty && !player.HasPendingExit && player.ManifestSha256 == null, "Factory failure leaked an activation.");
                Check(GameObject.Find("MiniGame Module Root") == null, "Factory failure leaked module root.");
                failing.ThrowOnCreate = false;
                player.OpenInstalled(fixture.DirectoryPath, fixture.Hash, Product(), null, null, null);
                Check(failing.Calls == 2 && player.LastError == null, "Healthy re-entry after factory failure failed.");
            }
            var pendingFactory = new RecordingFactory();
            using (var player = Player("hub", pendingFactory))
            {
                var external = new UnityEvent(); LuaEnv env = null;
                try
                {
                    player.OpenInstalled(fixture.DirectoryPath, fixture.Hash, Product(), null, null, null);
                    env = EnvironmentOf(player); env.Global.Set("external_event", external);
                    env.DoString("external_event:AddListener(function() end)"); player.Exit();
                    Check(player.HasPendingExit, "Live external callback did not prevent exit.");
                    var error = Reject<ModuleRunException>(() => player.OpenInstalled(fixture.DirectoryPath, fixture.Hash, Product(), null, null, null));
                    Check(error.Code == "EXIT_PENDING" && pendingFactory.Calls == 1, "Pending environment allowed new service construction.");
                    external.RemoveAllListeners(); env.DoString("external_event=nil; collectgarbage('collect')"); player.Exit();
                    Check(!player.HasPendingExit, "Unbound environment stayed pending.");
                    player.OpenInstalled(fixture.DirectoryPath, fixture.Hash, Product(), null, null, null);
                    Check(pendingFactory.Calls == 2, "Completed exit prevented next factory call.");
                }
                finally { external.RemoveAllListeners(); player.Exit(); }
            }
            Debug.Log("HOST_RUNNER_CHECKS_PASSED assertions=" + _checks);
        }
        private static void InitializeHost(ModulePlayerBehaviour host, string shell, ProductContext product, IModuleHostServiceFactory factory)
        {
            var method = typeof(ModulePlayerBehaviour).GetMethod("InitializeWithHost");
            Check(method != null, "ModulePlayerBehaviour lacks explicit host initialization.");
            try { method.Invoke(host, new object[] { shell, shell == "independent" ? "nativecheck" : null, product, null, factory, null }); }
            catch (TargetInvocationException e) { throw e.InnerException; }
        }
        public static void RunBehaviour()
        {
            using var fixture = new Fixture();
            var node = new GameObject("HostCompositionTest");
            var host = node.AddComponent<ModulePlayerBehaviour>();
            var external = new UnityEvent();
            try
            {
                var factory = new RecordingFactory();
                InitializeHost(host, "hub", Product(), factory);
                host.OpenInstalled(fixture.DirectoryPath, fixture.Hash, null, null);
                var original = host.Player;
                Reject<ArgumentNullException>(() => InitializeHost(host, "hub", null, factory));
                Reject<ArgumentNullException>(() => InitializeHost(host, "hub", Product(), null));
                Reject<ArgumentException>(() => InitializeHost(host, "bad", Product(), factory));
                Check(ReferenceEquals(original, host.Player) && original.State == GameRunState.Running, "Invalid host initialization replaced or stopped current module.");
                var env = EnvironmentOf(original); env.Global.Set("external_event", external);
                env.DoString("external_event:AddListener(function() end)");
                Reject<InvalidOperationException>(() => InitializeHost(host, "independent", Product(), factory));
                Check(ReferenceEquals(original, host.Player) && original.HasPendingExit, "Host discarded pending environment.");
                external.RemoveAllListeners(); env.DoString("external_event=nil; collectgarbage('collect')"); host.Exit();
                Check(!original.HasPendingExit, "Host could not complete pending exit.");
                InitializeHost(host, "independent", Product(), factory);
                host.OpenInstalled(fixture.DirectoryPath, fixture.Hash, null, null);
                Check(!ReferenceEquals(original, host.Player) && factory.Calls == 2, "Host reinitialization did not use same factory.");
                host.Exit();
                host.Initialize("hub", null, Product(), null);
                host.OpenInstalled(fixture.DirectoryPath, fixture.Hash, null, null);
                Check(host.Player.State == GameRunState.Running, "Legacy Initialize stopped working.");
                host.Exit();
            }
            finally { external.RemoveAllListeners(); host.Exit(); UnityEngine.Object.DestroyImmediate(node); }
            Debug.Log("HOST_BEHAVIOUR_CHECKS_PASSED assertions=" + _checks);
        }
        public static void Run()
        {
            RunFactory(); RunRunner(); RunBehaviour();
            Debug.Log("HOST_COMPOSITION_CHECKS_PASSED assertions=" + _checks);
        }
    }
}
