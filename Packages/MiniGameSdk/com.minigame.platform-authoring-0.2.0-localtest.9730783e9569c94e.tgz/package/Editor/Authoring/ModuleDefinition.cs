using System;
using System.IO;
using UnityEngine;

namespace MiniGamePlatform.SDK.EditorChecks
{
    [Serializable]
    public sealed class ModuleDefinition
    {
        public string gameId;
        public string moduleVersion;
        public string runtimeType;
        public string entry;
        public int minHostApiVersion;
        public string[] requiredCapabilities;
        public string luaRoot;
        public string[] dataRoots;
        public string[] assetRoots;
        public string ruleVersion;
        public string saveSchemaVersion;
        public string levelMapPath;
        public string platform;
        public string contentEncryption;
        public string contentKeyId;

        public static ModuleDefinition Load(string json)
        {
            if (string.IsNullOrWhiteSpace(json)) throw new InvalidDataException("Module definition is empty.");
            ModuleDefinition definition;
            try { definition = JsonUtility.FromJson<ModuleDefinition>(json); }
            catch (Exception exception) { throw new InvalidDataException("Invalid module definition JSON.", exception); }
            if (definition == null) throw new InvalidDataException("Invalid module definition JSON.");
            if (definition.runtimeType == null) definition.runtimeType = "unity_lua";
            return definition;
        }
    }
}
