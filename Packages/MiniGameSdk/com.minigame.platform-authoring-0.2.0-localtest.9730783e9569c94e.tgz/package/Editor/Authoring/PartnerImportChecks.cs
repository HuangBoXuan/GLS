using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using MiniGamePlatform.HotUpdate;
using UnityEditor;
using UnityEngine;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public static class PartnerImportChecks
    {
        [Serializable] private sealed class SampleEntry { public string displayName; public string path; }
        [Serializable] private sealed class PackageDescriptor { public SampleEntry[] samples; }

        [MenuItem("MiniGame Platform/SDK/Import PartnerGame Sample")]
        public static void ImportSample()
        {
            string source = Path.Combine(PackageRoot(), "Samples~", "PartnerGame");
            const string destination = "Assets/PartnerGame";
            if (!Directory.Exists(source)) throw new DirectoryNotFoundException(source);
            if (Directory.Exists(destination))
                throw new IOException("Assets/PartnerGame already exists; do not overwrite partner work.");
            CopyTree(source, destination);
            AssetDatabase.Refresh();
            Debug.Log("PartnerGame sample imported under Assets/PartnerGame.");
        }

        [MenuItem("MiniGame Platform/SDK/Run Partner Import Checks")]
        public static void Run()
        {
            string root = PackageRoot();
            string sample = Path.Combine(root, "Samples~", "PartnerGame");
            PackageDescriptor descriptor = JsonUtility.FromJson<PackageDescriptor>(
                File.ReadAllText(Path.Combine(root, "package.json")));
            if (descriptor?.samples == null || !descriptor.samples.Any(entry =>
                    entry.displayName == "PartnerGame" && entry.path == "Samples~/PartnerGame"))
                throw new Exception("PartnerGame is not registered as a Package Manager sample.");
            string definitionPath = Path.Combine(sample, "module-definition.json");
            if (!File.Exists(definitionPath)) throw new Exception("PartnerGame module definition is missing.");
            ModuleDefinition definition = ModuleDefinition.Load(File.ReadAllText(definitionPath));
            if (definition.gameId != "sample_partner" || definition.runtimeType != "unity_lua" ||
                definition.entry != "games.sample_partner.main")
                throw new Exception("PartnerGame definition has an invalid runtime or entry.");
            string lua = Path.Combine(sample, "games", "sample_partner", "main.lua");
            if (!File.Exists(lua)) throw new Exception("PartnerGame Lua entry is missing.");
            if (definition.assetRoots == null || definition.assetRoots.Length == 0 ||
                definition.assetRoots.Any(path => AssetDatabase.LoadMainAssetAtPath(path) == null))
                throw new Exception("Import PartnerGame under Assets/PartnerGame before building.");
            foreach (string folder in new[] { Path.Combine(root, "Editor"), sample })
            {
                foreach (string file in Directory.GetFiles(folder, "*", SearchOption.AllDirectories))
                {
                    if (!file.EndsWith(".cs", StringComparison.Ordinal) &&
                        !file.EndsWith(".lua", StringComparison.Ordinal) &&
                        !file.EndsWith(".json", StringComparison.Ordinal) &&
                        !file.EndsWith(".md", StringComparison.Ordinal)) continue;
                    if (File.ReadAllText(file).Contains("Assets/" + "MiniGamePlatform"))
                        throw new Exception("SDK authoring depends on platform product assets: " + file);
                }
            }
            Debug.Log("Partner import checks passed.");
        }

        [MenuItem("MiniGame Platform/SDK/Preview PartnerGame Sample")]
        public static void PreviewSample()
        {
            Run();
            ModuleDefinition definition = ModuleDefinition.Load(File.ReadAllText("Assets/PartnerGame/module-definition.json"));
            string modulePath = Path.GetFullPath("Builds/partner-output/modules/sample_partner/v1");
            string manifestPath = Path.Combine(modulePath, "manifest.json");
            if (!File.Exists(manifestPath)) throw new FileNotFoundException("Build the partner module first.", manifestPath);
            var host = HostProfile.ForPlatform("android");
            var inventory = HostComponentInventory.FromCapabilities(definition.requiredCapabilities, Array.Empty<string>());
            var issues = ModuleDefinitionValidator.Validate(definition, host).Concat(
                AssetDependencyValidator.Validate(definition, inventory)).ToArray();
            string hash;
            using (FileStream stream = File.OpenRead(manifestPath))
            using (SHA256 sha = SHA256.Create())
                hash = BitConverter.ToString(sha.ComputeHash(stream)).Replace("-", "").ToLowerInvariant();
            ModuleGateReport report = ModuleReleaseGate.Evaluate(new ModuleBuildResult(modulePath, hash, issues),
                host, host, null, null);
            if (!report.previewPassed || report.publishable)
                throw new Exception("Partner sample preview failed: " + string.Join(",", report.reasons));
            Debug.Log("Partner sample preview passed; Android dual-product evidence is still required for publication.");
        }

        private static string PackageRoot()
        {
            UnityEditor.PackageManager.PackageInfo package =
                UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(PartnerImportChecks).Assembly);
            if (package == null) throw new InvalidOperationException("Shared SDK package was not resolved.");
            return package.resolvedPath;
        }

        private static void CopyTree(string source, string destination)
        {
            Directory.CreateDirectory(destination);
            foreach (string file in Directory.GetFiles(source))
                File.Copy(file, Path.Combine(destination, Path.GetFileName(file)));
            foreach (string directory in Directory.GetDirectories(source))
                CopyTree(directory, Path.Combine(destination, Path.GetFileName(directory)));
        }
    }
}
