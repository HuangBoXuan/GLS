using System;

namespace MiniGamePlatform.SDK.EditorChecks
{
    [Serializable]
    public sealed class AndroidProductEvidence
    {
        public string productId;
        public string applicationId;
        public string apkPath;
        public string apkSha256;
        public string moduleManifestSha256;
        public string platform;
        public string androidBuildVersion;
        public string unityVersion;
        public string sdkVersion;
        public int hostApiVersion;
        public string[] capabilities;
        public string deviceId;
        public string deviceLogPath;
        public string deviceLogSha256;
        public string verifiedAtUtc;
        public string scriptingBackend;
        public string architecture;
        public bool entered;
        public bool paused;
        public bool resumed;
        public bool exited;
        public bool reentered;
        public bool switchedAtoBtoA;
        public bool missingScriptFree;
        public bool shaderAvailable;
        public bool downloadFailureRecovered;
        // contract_stub or real_server. The report preserves this distinction.
        public string settlementMode;
    }

    [Serializable]
    public sealed class ModuleGateReport
    {
        public string gameId;
        public string moduleVersion;
        public string moduleManifestSha256;
        public string modulePath;
        public bool previewPassed;
        public bool publishable;
        public bool sampleOnly;
        public string evaluatedAtUtc;
        public AndroidProductEvidence independent;
        public AndroidProductEvidence hub;
        public string[] reasons;
    }

    [Serializable]
    public sealed class HostProfileInput
    {
        public int apiVersion;
        public string platform;
        public string unityVersion;
        public string[] capabilities;
        public string[] retainedShaders;
    }

    [Serializable]
    public sealed class HostProfilesInput
    {
        public HostProfileInput oldest;
        public HostProfileInput current;
    }
}
