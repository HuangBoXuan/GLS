using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using MiniGamePlatform.HotUpdate;
using UnityEditor;
using UnityEngine;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public sealed class ModuleBuildResult
    {
        public string ModulePath { get; }
        public string ManifestSha256 { get; }
        public IReadOnlyList<AuthoringIssue> DependencyIssues { get; }

        public ModuleBuildResult(string modulePath, string manifestSha256, IReadOnlyList<AuthoringIssue> dependencyIssues)
        {
            ModulePath = modulePath;
            ManifestSha256 = manifestSha256;
            DependencyIssues = dependencyIssues;
        }
    }

    public static class AndroidModuleBuilder
    {
        public static void BuildFromCommandLine()
        {
            string[] args = Environment.GetCommandLineArgs();
            ModuleDefinition definition = ModuleDefinition.Load(File.ReadAllText(RequiredArg(args, "-moduleDefinition")));
            string shaderList = OptionalArg(args, "-retainedShaders");
            var inventory = HostComponentInventory.FromCapabilities(definition.requiredCapabilities,
                string.IsNullOrWhiteSpace(shaderList) ? Array.Empty<string>() :
                    shaderList.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries));
            ModuleBuildResult result = Build(definition, RequiredArg(args, "-moduleSource"),
                RequiredArg(args, "-moduleOutput"), inventory);
            Debug.Log("SDK Android module built: " + result.ModulePath + " manifest SHA-256 " + result.ManifestSha256);
        }

        public static ModuleBuildResult Build(ModuleDefinition definition, string sourceDirectory,
            string outputDirectory, IHostComponentInventory inventory)
        {
            if (definition == null) throw new ArgumentNullException(nameof(definition));
            if (inventory == null) throw new ArgumentNullException(nameof(inventory));
            if (string.IsNullOrWhiteSpace(sourceDirectory) || string.IsNullOrWhiteSpace(outputDirectory))
                throw new ArgumentException("Source and output directories are required.");
            string source = Path.GetFullPath(sourceDirectory).TrimEnd(Path.DirectorySeparatorChar);
            string output = Path.GetFullPath(outputDirectory).TrimEnd(Path.DirectorySeparatorChar);
            if (!Directory.Exists(source)) throw new DirectoryNotFoundException(source);
            // Check original roots before staging changes the source identity.
            ModuleBuildKeyRing.AssertOutsideArtifactTrees(source, output);
            if (output.StartsWith(source + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase) || source == output)
                throw new ModulePackagingException("OUTPUT_INSIDE_SOURCE", output, "Build output must be outside source.");
            if (definition.platform != "android")
                throw new ModulePackagingException("BUNDLE_PLATFORM", "platform", "AssetBundle target must be android.");
            if (definition.requiredCapabilities == null || !definition.requiredCapabilities.Contains("assetbundle"))
                throw new ModulePackagingException("CAPABILITY_REQUIRED", "requiredCapabilities", "AssetBundle capability is required.");
            if (definition.minHostApiVersion < 6 || !definition.requiredCapabilities.Contains("module_owned_resources_v1"))
                throw new ModulePackagingException("RESOURCE_OWNERSHIP_REQUIRED", "requiredCapabilities", "Use host API 6 and module_owned_resources_v1 before building a new AssetBundle module.");
            var host = HostProfile.ForPlatform("android");
            IReadOnlyList<AuthoringIssue> definitionIssues = ModuleDefinitionValidator.Validate(definition, host);
            if (definitionIssues.Count > 0)
                throw new ModulePackagingException(definitionIssues[0].Code, definitionIssues[0].Path, definitionIssues[0].Message);
            IReadOnlyList<AuthoringIssue> dependencies = AssetDependencyValidator.Validate(definition, inventory);
            if (dependencies.Count > 0)
                throw new ModulePackagingException(dependencies[0].Code, dependencies[0].Path, dependencies[0].Message);

            Directory.CreateDirectory(output);
            string work = Path.Combine(output, ".build-" + Guid.NewGuid().ToString("N"));
            string bundleOutput = Path.Combine(work, "bundles");
            string stageSource = Path.Combine(work, "source");
            try
            {
                Directory.CreateDirectory(bundleOutput);
                CopyTree(source, stageSource);
                string bundleName = definition.gameId + ".bundle";
                var builds = new[] { new AssetBundleBuild { assetBundleName = bundleName,
                    assetNames = definition.assetRoots } };
                AssetBundleManifest bundleManifest = BuildPipeline.BuildAssetBundles(bundleOutput, builds,
                    BuildAssetBundleOptions.ChunkBasedCompression, BuildTarget.Android);
                string builtBundle = Path.Combine(bundleOutput, bundleName);
                if (bundleManifest == null || !File.Exists(builtBundle) ||
                    !bundleManifest.GetAllAssetBundles().Contains(bundleName))
                    throw new InvalidOperationException("Android AssetBundle build failed: " + bundleName);
                File.Copy(builtBundle, Path.Combine(stageSource, bundleName), true);
                string module = ModulePackager.Pack(definition, stageSource, Path.Combine(output, "modules"));
                return new ModuleBuildResult(module, Sha256(Path.Combine(module, "manifest.json")), dependencies);
            }
            finally
            {
                if (Directory.Exists(work)) Directory.Delete(work, true);
            }
        }

        private static void CopyTree(string source, string destination)
        {
            if ((File.GetAttributes(source) & FileAttributes.ReparsePoint) != 0)
                throw new ModulePackagingException("LINK_IN_SOURCE", source, "Links are forbidden in module source.");
            Directory.CreateDirectory(destination);
            foreach (string entry in Directory.EnumerateFileSystemEntries(source))
            {
                FileAttributes attributes = File.GetAttributes(entry);
                if ((attributes & FileAttributes.ReparsePoint) != 0)
                    throw new ModulePackagingException("LINK_IN_SOURCE", entry, "Links are forbidden in module source.");
                string target = Path.Combine(destination, Path.GetFileName(entry));
                if ((attributes & FileAttributes.Directory) != 0) CopyTree(entry, target);
                else File.Copy(entry, target);
            }
        }

        private static string Sha256(string path)
        {
            using (FileStream stream = File.OpenRead(path))
            using (SHA256 sha = SHA256.Create())
                return BitConverter.ToString(sha.ComputeHash(stream)).Replace("-", "").ToLowerInvariant();
        }

        private static string RequiredArg(string[] args, string name)
        {
            string value = OptionalArg(args, name);
            if (string.IsNullOrWhiteSpace(value)) throw new ArgumentException("Missing command-line argument: " + name);
            return value;
        }

        private static string OptionalArg(string[] args, string name)
        {
            int index = Array.IndexOf(args, name);
            return index < 0 || index + 1 >= args.Length ? null : args[index + 1];
        }
    }
}
