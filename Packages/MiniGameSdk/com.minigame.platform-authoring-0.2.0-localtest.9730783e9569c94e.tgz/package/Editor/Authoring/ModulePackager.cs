using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using MiniGamePlatform.HotUpdate;
using UnityEngine;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public sealed class ModulePackagingException : IOException
    {
        public string Code { get; }
        public string Path { get; }

        public ModulePackagingException(string code, string path, string message) : base(code + ": " + message)
        {
            Code = code;
            Path = path;
        }
    }

    public static class ModulePackager
    {
        public static void PackFromCommandLine()
        {
            string[] args = Environment.GetCommandLineArgs();
            string source = RequiredArg(args, "-moduleSource");
            string output = RequiredArg(args, "-moduleOutput");
            string definitionPath = OptionalArg(args, "-moduleDefinition");
            ModuleDefinition definition;
            if (!string.IsNullOrEmpty(definitionPath))
            {
                definition = ModuleDefinition.Load(File.ReadAllText(definitionPath));
            }
            else
            {
                string gameId = RequiredArg(args, "-moduleGameId");
                string minApiText = OptionalArg(args, "-moduleMinHostApiVersion");
                int minApi = string.IsNullOrEmpty(minApiText) ? 1 : int.Parse(minApiText);
                string capabilityText = OptionalArg(args, "-moduleCapabilities");
                definition = new ModuleDefinition
                {
                    gameId = gameId,
                    moduleVersion = RequiredArg(args, "-moduleVersion"),
                    runtimeType = "unity_lua",
                    entry = RequiredArg(args, "-moduleEntry"),
                    minHostApiVersion = minApi,
                    requiredCapabilities = string.IsNullOrEmpty(capabilityText)
                        ? new[] { "lua" }
                        : capabilityText.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries),
                    luaRoot = "games/" + gameId,
                    dataRoots = new[] { "data/" + gameId },
                    assetRoots = new[] { "Assets/Legacy/PrebuiltBundle.prefab" },
                    ruleVersion = "legacy",
                    saveSchemaVersion = "legacy",
                    levelMapPath = "data/" + gameId + "/levels.json",
                    platform = OptionalArg(args, "-modulePlatform") ?? "any"
                };
            }
            string expectedUnityVersion = OptionalArg(args, "-moduleUnityVersion");
            if (!string.IsNullOrEmpty(expectedUnityVersion) && expectedUnityVersion != Application.unityVersion)
                throw new InvalidDataException("Unity Editor version differs from the requested bundle build version.");
            string artifact = Pack(definition, source, output);
            Debug.Log("Module artifact: " + artifact);
        }

        public static string Pack(ModuleDefinition definition, string sourceDirectory, string outputDirectory)
        {
            if (definition == null) throw new ArgumentNullException(nameof(definition));
            if (string.IsNullOrWhiteSpace(sourceDirectory) || string.IsNullOrWhiteSpace(outputDirectory))
                throw new ArgumentException("Source and output directories are required.");
            string source = Path.GetFullPath(sourceDirectory).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
            string output = Path.GetFullPath(outputDirectory).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
            if (!Directory.Exists(source)) throw new DirectoryNotFoundException(source);
            ModuleBuildKeyRing.AssertOutsideArtifactTrees(source, output);
            if (output.StartsWith(source + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
                throw new ModulePackagingException("OUTPUT_INSIDE_SOURCE", output, "Output must be outside the source tree.");
            if (definition.runtimeType != "unity_lua")
                throw new ModulePackagingException("UNSUPPORTED_RUNTIME", "runtimeType", "Only unity_lua is buildable.");
            var host = new HostProfile(HostProfile.ApiVersion, definition.platform, Application.unityVersion,
                definition.requiredCapabilities);
            IReadOnlyList<AuthoringIssue> definitionIssues = ModuleDefinitionValidator.Validate(definition, host);
            if (definitionIssues.Count > 0)
                throw new ModulePackagingException(definitionIssues[0].Code, definitionIssues[0].Path, definitionIssues[0].Message);

            string artifact = Path.Combine(output, definition.gameId, definition.moduleVersion);
            string stage = artifact + ".stage";
            if (Directory.Exists(artifact))
                throw new ModulePackagingException("IMMUTABLE_VERSION_EXISTS", artifact, "Module version already exists.");
            if (Directory.Exists(stage))
                throw new ModulePackagingException("UNFINISHED_STAGE", stage, "An unfinished staging directory exists.");
            var sourceFiles = new List<string>();
            CollectFiles(source, sourceFiles);
            sourceFiles.Sort(StringComparer.Ordinal);
            var relativeFiles = new List<string>();
            bool hasEntry = false;
            bool hasBundle = false;
            string entryPath = definition.entry.Replace('.', '/') + ".lua";
            foreach (string file in sourceFiles)
            {
                string relative = file.Substring(source.Length).TrimStart(Path.DirectorySeparatorChar).Replace('\\', '/');
                if (relative.EndsWith(".meta", StringComparison.Ordinal)) continue;
                if (!AllowedPath(relative) || !ModuleManifest.IsAllowedModuleFile(definition.gameId, relative) ||
                    !UnderDeclaredRoots(definition, relative) || SensitiveName(relative))
                    throw new ModulePackagingException("FORBIDDEN_MODULE_FILE", relative, "File is outside the module allowlist: " + relative);
                if (relative == entryPath) hasEntry = true;
                if (relative.EndsWith(".bundle", StringComparison.Ordinal)) hasBundle = true;
                relativeFiles.Add(relative);
            }
            if (!hasEntry) throw new ModulePackagingException("ENTRY_MISSING", entryPath, "Lua entry file is missing.");
            if (relativeFiles.Count == 0) throw new ModulePackagingException("MODULE_EMPTY", source, "No module files found.");
            if (hasBundle && definition.platform != "android")
                throw new ModulePackagingException("BUNDLE_PLATFORM", "platform", "Android bundles require the android target.");
            IReadOnlyList<AuthoringIssue> luaIssues = ModuleLuaValidator.Validate(definition, source);
            if (luaIssues.Count > 0)
                throw new ModulePackagingException(luaIssues[0].Code, luaIssues[0].Path, luaIssues[0].Message);

            var manifest = new ModuleManifest
            {
                formatVersion = 1,
                gameId = definition.gameId,
                version = definition.moduleVersion,
                runtimeType = "unity_lua",
                entry = definition.entry,
                minHostApiVersion = definition.minHostApiVersion,
                platform = definition.platform,
                unityVersion = hasBundle ? Application.unityVersion : "",
                contentEncryption = definition.contentEncryption,
                contentKeyId = definition.contentKeyId,
                requiredCapabilities = definition.requiredCapabilities,
                files = new ModuleFile[relativeFiles.Count]
            };
            bool protectedContent = ModuleContentProtection.ValidateDeclaration(manifest);
            using var keyRing = protectedContent ? ModuleBuildKeyRing.FromEnvironment() : null;
            var contentKey = new byte[32];
            if (protectedContent && !keyRing.CopyKey(manifest.gameId, manifest.contentKeyId, contentKey))
                throw new ModulePackagingException("MODULE_KEY_MISSING", "contentKeyId", "Build keyring does not provision this module key.");
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(artifact));
                Directory.CreateDirectory(stage);
                long totalBytes = 0;
                for (int i = 0; i < relativeFiles.Count; i++)
                {
                    string relative = relativeFiles[i];
                    string original = Path.Combine(source, relative.Replace('/', Path.DirectorySeparatorChar));
                    string target = Path.Combine(stage, relative.Replace('/', Path.DirectorySeparatorChar));
                    Directory.CreateDirectory(Path.GetDirectoryName(target));
                    if (protectedContent)
                    {
                        if (new FileInfo(original).Length > ModuleContentProtection.MaxPlainBytes)
                            throw new ModulePackagingException("PROTECTED_FILE_TOO_LARGE", relative, "Split protected content into files of at most 64 MiB.");
                        var plain = File.ReadAllBytes(original);
                        try { File.WriteAllBytes(target, ModuleContentProtection.Seal(manifest, relative, plain, contentKey)); }
                        finally { Array.Clear(plain, 0, plain.Length); }
                    }
                    else File.Copy(original, target);
                    long length = new FileInfo(target).Length;
                    if (length > ModuleManifest.MaxFileBytes || totalBytes > ModuleManifest.MaxModuleBytes - length)
                        throw new ModulePackagingException("MODULE_TOO_LARGE", relative, "Module exceeds the file or total size limit.");
                    totalBytes += length;
                    manifest.files[i] = new ModuleFile { path = relative, size = length, sha256 = Sha256(target) };
                }
                string manifestJson = JsonUtility.ToJson(manifest, true);
                ModuleManifest.Parse(manifestJson);
                File.WriteAllText(Path.Combine(stage, "manifest.json"), manifestJson, new UTF8Encoding(false));
                Directory.Move(stage, artifact);
                return artifact;
            }
            catch
            {
                if (stage.StartsWith(output + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase) &&
                    Directory.Exists(stage)) Directory.Delete(stage, true);
                throw;
            }
            finally { Array.Clear(contentKey, 0, contentKey.Length); }
        }

        public static bool AllowedPath(string relativePath)
        {
            if (!ModuleManifest.IsSafeRelativePath(relativePath)) return false;
            return relativePath.EndsWith(".lua", StringComparison.Ordinal) ||
                   relativePath.EndsWith(".bundle", StringComparison.Ordinal) ||
                   relativePath.EndsWith(".json", StringComparison.Ordinal) ||
                   relativePath.EndsWith(".csv", StringComparison.Ordinal) ||
                   relativePath.EndsWith(".txt", StringComparison.Ordinal);
        }

        private static bool UnderDeclaredRoots(ModuleDefinition definition, string relative)
        {
            if (relative.EndsWith(".bundle", StringComparison.Ordinal) && relative.IndexOf('/') < 0) return true;
            if (relative.StartsWith(definition.luaRoot + "/", StringComparison.Ordinal) &&
                relative.EndsWith(".lua", StringComparison.Ordinal)) return true;
            if (definition.dataRoots == null) return false;
            foreach (string root in definition.dataRoots)
                if (relative.StartsWith(root + "/", StringComparison.Ordinal) &&
                    (relative.EndsWith(".json", StringComparison.Ordinal) ||
                     relative.EndsWith(".csv", StringComparison.Ordinal) ||
                     relative.EndsWith(".txt", StringComparison.Ordinal))) return true;
            return false;
        }

        private static bool SensitiveName(string relative)
        {
            string name = Path.GetFileNameWithoutExtension(relative).ToLowerInvariant();
            return name.Contains("adunit") || name.Contains("appsflyer") || name.Contains("credential") ||
                   name.Contains("secret") || name.Contains("sdkkey") || name.Contains("token");
        }

        private static void CollectFiles(string directory, List<string> files)
        {
            if ((File.GetAttributes(directory) & FileAttributes.ReparsePoint) != 0)
                throw new ModulePackagingException("LINK_IN_SOURCE", directory, "Symlinks and junctions are forbidden in module source.");
            foreach (string entry in Directory.EnumerateFileSystemEntries(directory))
            {
                FileAttributes attributes = File.GetAttributes(entry);
                if ((attributes & FileAttributes.ReparsePoint) != 0)
                    throw new ModulePackagingException("LINK_IN_SOURCE", entry, "Symlinks and junctions are forbidden in module source.");
                if ((attributes & FileAttributes.Directory) != 0) CollectFiles(entry, files);
                else files.Add(entry);
            }
        }

        private static string Sha256(string path)
        {
            using (FileStream stream = File.OpenRead(path))
            using (SHA256 sha = SHA256.Create())
                return BitConverter.ToString(sha.ComputeHash(stream)).Replace("-", "").ToLowerInvariant();
        }

        private static string RequiredArg(string[] args, string name)
        {
            string value = OptionalArg(args, name);
            if (string.IsNullOrWhiteSpace(value)) throw new ArgumentException("Missing command-line argument: " + name);
            return value;
        }

        private static string OptionalArg(string[] args, string name)
        {
            int index = Array.IndexOf(args, name);
            return index < 0 || index + 1 >= args.Length ? null : args[index + 1];
        }
    }
}
