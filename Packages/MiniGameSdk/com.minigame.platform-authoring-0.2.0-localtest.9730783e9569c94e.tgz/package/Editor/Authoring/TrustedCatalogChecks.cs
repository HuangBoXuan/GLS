using System;
using System.Collections;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using MiniGamePlatform.HotUpdate;
using UnityEditor;
using UnityEngine;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public static class TrustedCatalogChecks
    {
        [MenuItem("MiniGame Platform/SDK/Run Trusted Catalog Checks")]
        public static void Run()
        {
            string root = Path.Combine(Path.GetTempPath(), "TrustedCatalog-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(root);
            try
            {
                using (RSA rsa = new RSACryptoServiceProvider(2048))
                {
                    RSAParameters pub = rsa.ExportParameters(false);
                    var key = new CatalogTrustKey("test_key", Convert.ToBase64String(pub.Modulus),
                        Convert.ToBase64String(pub.Exponent));
                    byte[] builtin = Encoding.UTF8.GetBytes(File.ReadAllText(
                        Path.Combine(Application.streamingAssetsPath, "MiniGames", "catalog.json")));
                    var cache = new CatalogCache(root, "minigame_platform", key);
                    var transport = new FakeTransport();
                    var url = new Uri("https://catalog.example.test/catalog.json");
                    var source = new TrustedCatalogSource("minigame_platform", url, key, cache, builtin, transport);
                    transport.Next = Sign(rsa, 3);
                    CatalogLoadResult fresh = Load(source, url, key);
                    if (fresh.Source != CatalogLoadSource.Remote || fresh.Catalog.CatalogVersion != 3)
                        throw new Exception("New signed remote catalog was not accepted.");
                    transport.Next = null;
                    CatalogLoadResult offline = Load(source, url, key);
                    if (offline.Source != CatalogLoadSource.VerifiedCache || offline.Catalog.CatalogVersion != 3)
                        throw new Exception("Offline catalog did not use verified cache.");
                    transport.Next = Encoding.UTF8.GetBytes("bad signature");
                    if (Load(source, url, key).Source != CatalogLoadSource.VerifiedCache)
                        throw new Exception("Bad signature replaced verified cache.");
                    transport.Next = Sign(rsa, 2);
                    if (Load(source, url, key).Catalog.CatalogVersion != 3)
                        throw new Exception("Older signed catalog rolled back accepted version.");
                    File.Delete(Path.Combine(root, "highest-version.txt"));
                    if (Load(source, url, key).Catalog.CatalogVersion != 3)
                        throw new Exception("Missing version counter allowed rollback despite valid cache.");
                    transport.Next = Sign(rsa, 3);
                    if (Load(source, url, key).Catalog.CatalogVersion != 3 ||
                        !File.Exists(Path.Combine(root, "highest-version.txt")))
                        throw new Exception("Verified cache did not restore the version counter.");
                    transport.Next = Sign(rsa, 4, 'b');
                    if (Load(source, url, key).Catalog.CatalogVersion != 3)
                        throw new Exception("Same game version was accepted with different bytes.");
                    File.WriteAllText(cache.EnvelopePath, "damaged");
                    transport.Next = null;
                    if (Load(source, url, key).Source != CatalogLoadSource.VerifiedCache)
                        throw new Exception("Damaged active cache did not use verified backup.");
                    File.WriteAllText(cache.EnvelopePath + ".backup", "damaged");
                    if (Load(source, url, key).Source != CatalogLoadSource.BuiltinFallback)
                        throw new Exception("Damaged cache did not use bundled fallback.");
                    transport.Next = Sign(rsa, 2);
                    if (Load(source, url, key).Source != CatalogLoadSource.BuiltinFallback)
                        throw new Exception("Deleted cache enabled signed rollback.");
                    transport.Next = Sign(rsa, 3, 'c');
                    if (Load(source, url, key).Source != CatalogLoadSource.BuiltinFallback)
                        throw new Exception("Damaged cache accepted different bytes under an already accepted catalog version.");
                    transport.Next = Sign(rsa, 3);
                    if (Load(source, url, key).Source != CatalogLoadSource.Remote)
                        throw new Exception("Original signed catalog could not repair a damaged cache.");
                    var interrupted = new CatalogCache(Path.Combine(root, "interrupted"), "minigame_platform", key);
                    interrupted.ReplaceVerified(Sign(rsa, 2));
                    byte[] next = Sign(rsa, 3);
                    byte[] nextPayload = CatalogSignatureVerifier.Verify(next, key,
                        "minigame_platform").PayloadBytes();
                    string nextHash;
                    using (SHA256 sha = SHA256.Create())
                        nextHash = BitConverter.ToString(sha.ComputeHash(nextPayload))
                            .Replace("-", "").ToLowerInvariant();
                    File.WriteAllText(Path.Combine(root, "interrupted", "highest-version.txt"),
                        "3\n" + nextHash, Encoding.ASCII);
                    if (interrupted.TryRead(out _))
                        throw new Exception("Old cache was accepted after a newer version fingerprint was persisted.");
                    byte[] alternate = Sign(rsa, 3, 'a', true);
                    if (CatalogSignatureVerifier.Verify(alternate, key, "minigame_platform").CatalogVersion != 3)
                        throw new Exception("Alternate signed catalog fixture was not valid.");
                    Reject(() => interrupted.ReplaceVerified(alternate));
                    if (interrupted.ReplaceVerified(next).CatalogVersion != 3)
                        throw new Exception("Original signed catalog did not repair interrupted replacement.");
                    Reject(() => new TrustedCatalogSource("minigame_platform", new Uri("http://catalog.example.test/a"),
                        key, cache, builtin, transport));
                    Reject(() => Load(source, new Uri("https://untrusted.example.test/a"), key));
                }
                Debug.Log("Trusted catalog checks passed.");
            }
            finally { Directory.Delete(root, true); }
        }

        private static CatalogLoadResult Load(TrustedCatalogSource source, Uri url, CatalogTrustKey key)
        {
            CatalogLoadResult result = null;
            RunCoroutine(source.Load("minigame_platform", url, key, value => result = value));
            if (result == null) throw new Exception("Catalog load callback was not called.");
            return result;
        }

        private static void RunCoroutine(IEnumerator routine)
        {
            while (routine.MoveNext())
                if (routine.Current is IEnumerator nested) RunCoroutine(nested);
        }

        private static byte[] Sign(RSA rsa, int version, char hashCharacter = 'a', bool extraWhitespace = false)
        {
            string payload = "{\"formatVersion\":2,\"catalogVersion\":" + version +
                ",\"productId\":\"minigame_platform\",\"releases\":[{\"gameId\":\"sample2d\",\"version\":\"v1\",\"runtimeType\":\"unity_lua\",\"manifestPath\":\"sample2d/v1/manifest.json\",\"manifestSha256\":\"" +
                new string(hashCharacter, 64) + "\",\"minHostApiVersion\":1,\"requiredCapabilities\":[\"lua\"],\"platform\":\"any\",\"unityVersion\":\"\",\"enabled\":true}]}";
            if (extraWhitespace) payload += " ";
            byte[] bytes = Encoding.UTF8.GetBytes(payload);
            return Encoding.UTF8.GetBytes(JsonUtility.ToJson(new SignedCatalogEnvelope {
                keyId = "test_key", payloadBase64 = Convert.ToBase64String(bytes),
                signatureBase64 = Convert.ToBase64String(rsa.SignData(bytes, HashAlgorithmName.SHA256,
                    RSASignaturePadding.Pkcs1)) }));
        }

        private static void Reject(Action action)
        {
            try { action(); } catch (InvalidDataException) { return; }
            throw new Exception("Untrusted catalog configuration was accepted.");
        }

        private sealed class FakeTransport : ITrustedCatalogTransport
        {
            public byte[] Next;
            public IEnumerator Fetch(Uri url, Action<byte[], string> done)
            {
                done(Next, Next == null ? "offline" : null);
                yield break;
            }
        }
    }
}
