using System;
using System.Collections.Generic;
using MiniGamePlatform.HotUpdate;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public interface IHostComponentInventory
    {
        bool HasComponent(string fullTypeName, string assemblyName);
        bool HasShader(string shaderName);
    }

    public sealed class HostComponentInventory : IHostComponentInventory
    {
        private readonly Dictionary<string, string> _components;
        private readonly HashSet<string> _shaders;

        private HostComponentInventory(Dictionary<string, string> components, HashSet<string> shaders)
        {
            _components = components;
            _shaders = shaders;
        }

        public bool HasComponent(string fullTypeName, string assemblyName)
        {
            return _components.TryGetValue(fullTypeName ?? "", out string expectedAssembly) &&
                   expectedAssembly == assemblyName;
        }

        public bool HasShader(string shaderName)
        {
            return _shaders.Contains(shaderName ?? "");
        }

        public static HostComponentInventory FromCapabilities(IEnumerable<string> capabilities, IEnumerable<string> shaders)
        {
            var names = new HashSet<string>(StringComparer.Ordinal) { "UnityEngine.Transform" };
            bool nativeBaseline = false;
            bool localizationBaseline = false;
            foreach (string capability in capabilities ?? Array.Empty<string>())
            {
                if (!HostCapabilityRegistry.TryGet(capability, out HostCapabilityDefinition definition)) continue;
                foreach (string name in definition.RetainedComponentTypes) names.Add(name);
                if (capability == "ugui") names.Add("UnityEngine.CanvasRenderer");
                if (capability == NativeLuaBaseline.Capability) nativeBaseline = true;
                if (capability == LocalizationBaseline.Capability) localizationBaseline = true;
            }
            var components = new Dictionary<string, string>(StringComparer.Ordinal);
            if (nativeBaseline || localizationBaseline)
            {
                // Native baseline retains these entire assemblies in link.xml. Game assemblies
                // remain excluded: assets cannot supply new C# code to an installed Player.
                var retained = new HashSet<string>(StringComparer.Ordinal);
                if (nativeBaseline) retained.UnionWith(NativeLuaBaseline.RetainedAssemblies);
                if (localizationBaseline) retained.UnionWith(LocalizationBaseline.RetainedAssemblies);
                foreach (System.Reflection.Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
                {
                    string assemblyName = assembly.GetName().Name;
                    if (!retained.Contains(assemblyName)) continue;
                    foreach (Type type in assembly.GetTypes())
                        if (!type.IsAbstract && typeof(UnityEngine.Component).IsAssignableFrom(type))
                            components[type.FullName] = assemblyName;
                }
            }
            foreach (string name in names)
            {
                foreach (System.Reflection.Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
                {
                    Type type = assembly.GetType(name, false);
                    if (type == null || !typeof(UnityEngine.Component).IsAssignableFrom(type)) continue;
                    components[name] = type.Assembly.GetName().Name;
                    break;
                }
            }
            return new HostComponentInventory(components,
                new HashSet<string>(shaders ?? Array.Empty<string>(), StringComparer.Ordinal));
        }
    }
}
