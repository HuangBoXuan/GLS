using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using MiniGamePlatform.HotUpdate;
using MiniGamePlatform.SDK;
using UnityEditor;
using UnityEngine;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public static class ModuleSelectionChecks
    {
        [MenuItem("MiniGame Platform/SDK/Run Module Selection Checks")]
        public static void Run()
        {
            string root = Path.Combine(Path.GetTempPath(), "ModuleActivation-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(root);
            try
            {
                string v1 = CreateModule(root, "v1", false, out ModuleManifest manifestV1);
                string v2 = CreateModule(root, "v2", true, out ModuleManifest manifestV2);
                string v3 = CreateModule(root, "v3", false, out ModuleManifest manifestV3);
                string v1Hash = Hash(File.ReadAllBytes(Path.Combine(v1, "manifest.json")));
                string v2Hash = Hash(File.ReadAllBytes(Path.Combine(v2, "manifest.json")));
                string v3Hash = Hash(File.ReadAllBytes(Path.Combine(v3, "manifest.json")));
                using (RSA rsa = new RSACryptoServiceProvider(2048))
                {
                RSAParameters pub = rsa.ExportParameters(false);
                var key = new CatalogTrustKey("test_key", Convert.ToBase64String(pub.Modulus),
                    Convert.ToBase64String(pub.Exponent));
                VerifiedProductCatalog catalog = CatalogSignatureVerifier.Verify(Sign(rsa, v1Hash, v2Hash, v3Hash), key, "minigame_platform");
                var product = new ProductContext("minigame_platform", "https://api.example.test", "1.0.0",
                    new[] { "sample2d" }, locallyDisabledGameIds: new[] { "blocked_game" });
                product.ApplyVerifiedCatalog(catalog);
                var ownedHost = HostProfile.ForPlatform("android");
                if (ModuleReleaseSelector.Select(catalog, ownedHost, product, "legacy_bundle").Status == ModuleSelectionStatus.Ready)
                    throw new Exception("API 6 offered a legacy Bundle without ownership rules.");
                var owned = ModuleReleaseSelector.Select(catalog, ownedHost, product, "bundle_update");
                if (owned.Status != ModuleSelectionStatus.Ready || owned.Release.version != "v2" ||
                    ModuleReleaseSelector.SelectFallback(catalog, ownedHost, product, owned, _ => true).Status == ModuleSelectionStatus.Ready)
                    throw new Exception("Bundle ownership compatibility differs between selection and fallback.");
                if (!product.AllowsGame("sample_new") || product.AllowsGame("blocked_game"))
                    throw new Exception("Signed catalog did not dynamically update product games.");
                if (product.TryResolveServerGameId("sample_new", out _))
                    throw new Exception("Development sample was falsely mapped to server game data.");
                if (!product.TryResolveServerGameId("new_game", out string serverGameId) || serverGameId != "new_game")
                    throw new Exception("Real catalog game did not retain stable server game ID.");
                var oldHost = new HostProfile(1, "android", "2022.3.76f1", new[] { "lua", "ugui", "sprite2d" });
                ModuleReleaseSelection chosen = ModuleReleaseSelector.Select(catalog, oldHost, product, "sample_new");
                if (chosen.Status != ModuleSelectionStatus.Ready || chosen.Release.version != "v1")
                    throw new Exception("Old host did not choose compatible v1 over mesh3d v2.");
                if (ModuleReleaseSelector.Select(catalog, oldHost, product, "web_game").Status !=
                    ModuleSelectionStatus.NeedsHostUpdate)
                    throw new Exception("H5 game was offered to a Lua-only host.");
                if (ModuleReleaseSelector.Select(catalog, oldHost, product, "blocked_game").Status !=
                    ModuleSelectionStatus.Disabled)
                    throw new Exception("Product local disabled policy was ignored.");
                if (ModuleReleaseSelector.Select(catalog, oldHost, product, "future_game").Status !=
                    ModuleSelectionStatus.NeedsHostUpdate)
                    throw new Exception("Missing host capability was ignored.");
                var fullHost = new HostProfile(1, "android", "2022.3.76f1",
                    new[] { "lua", "ugui", "sprite2d", "mesh3d" });
                ModuleReleaseSelection upgraded = ModuleReleaseSelector.Select(catalog, fullHost, product, "sample_new");
                if (upgraded.Status != ModuleSelectionStatus.Ready || upgraded.Release.version != "v3")
                    throw new Exception("Upgraded host did not choose newest compatible release.");
                if (ModuleReleaseSelector.SelectInstalled(catalog, fullHost, product, "sample_new", "v1", v1Hash).Status !=
                    ModuleSelectionStatus.Ready)
                    throw new Exception("Listed fallback was not allowed to run.");
                if (ModuleReleaseSelector.SelectInstalled(catalog, fullHost, product, "sample_new", "v2", v2Hash).Status ==
                    ModuleSelectionStatus.Ready)
                    throw new Exception("Legacy installed selector unexpectedly accepted a non-fallback grey release.");
                ModuleReleaseSelection assigned = ModuleReleaseSelector.SelectExact(catalog, fullHost, product,
                    "sample_new", "v2", v2Hash);
                if (assigned.Status != ModuleSelectionStatus.Ready || assigned.Release.version != "v2" ||
                    assigned.Release.manifestSha256 != v2Hash)
                    throw new Exception("Server-assigned grey release was not selected exactly.");
                if (ModuleReleaseSelector.SelectExact(catalog, fullHost, product, "sample_new", "v2", v1Hash).Status ==
                    ModuleSelectionStatus.Ready ||
                    ModuleReleaseSelector.SelectExact(catalog, fullHost, product, "sample_new", "v5", v2Hash).Status ==
                    ModuleSelectionStatus.Ready)
                    throw new Exception("Version or hash mismatch was accepted as a server assignment.");
                if (ModuleReleaseSelector.SelectExact(catalog, oldHost, product, "sample_new", "v2", v2Hash).Status ==
                    ModuleSelectionStatus.Ready ||
                    ModuleReleaseSelector.SelectExact(catalog, fullHost, product, "sample_new", "v4", new string('a', 64)).Status ==
                    ModuleSelectionStatus.Ready ||
                    ModuleReleaseSelector.SelectExact(catalog, fullHost, product, "blocked_game", "v1", new string('a', 64)).Status ==
                    ModuleSelectionStatus.Ready)
                    throw new Exception("Exact selection bypassed host compatibility or disabled release/game.");
                var otherProduct = new ProductContext("other_product", "https://api.example.test", "1.0.0",
                    new[] { "sample_new" });
                bool wrongProductRejected = false;
                try { ModuleReleaseSelector.SelectExact(catalog, fullHost, otherProduct, "sample_new", "v2", v2Hash); }
                catch (InvalidOperationException) { wrongProductRejected = true; }
                if (!wrongProductRejected) throw new Exception("Exact selection accepted another product's catalog.");
                VerifiedProductCatalog builtin = CatalogCache.LoadBuiltin(Encoding.UTF8.GetBytes(File.ReadAllText(
                    Path.Combine(Application.streamingAssetsPath, "MiniGames", "catalog.json"))), "minigame_platform");
                if (ModuleReleaseSelector.SelectExact(builtin, fullHost, product, "sample2d", "v1", new string('a', 64))
                    .Reason != "SIGNED_CATALOG_REQUIRED")
                    throw new Exception("An unsigned built-in catalog was accepted as a server assignment.");
                CheckSupportedCapabilities();
                VerifiedProductCatalog revoked = CatalogSignatureVerifier.Verify(
                    SignRevoked(rsa, v3Hash), key, "minigame_platform");
                product.ApplyVerifiedCatalog(revoked);
                if (ModuleReleaseSelector.SelectInstalled(revoked, fullHost, product, "sample_new", "v1", v1Hash).Status ==
                    ModuleSelectionStatus.Ready)
                    throw new Exception("Revoked installed module remained playable after a signed catalog update.");
                if (ModuleReleaseSelector.SelectExact(revoked, fullHost, product, "sample_new", "v2", v2Hash).Status ==
                    ModuleSelectionStatus.Ready)
                    throw new Exception("Revoked grey release remained selectable.");
                product.ApplyVerifiedCatalog(catalog);
                CheckActivation(chosen, upgraded, root, v1, manifestV1, v2, manifestV2, v3, manifestV3);
                Debug.Log("Module selection checks passed.");
                }
            }
            finally { Directory.Delete(root, true); }
        }

        private static void CheckSupportedCapabilities()
        {
            var current = new HostProfile(7, "android", "2022.3.76f1",
                new[] { "lua", "host_native_contract_v1", "unknown_capability", "lua" });
            string[] supported = current.GetSupportedCapabilities();
            if (supported.Length != 2 || supported[0] != "host_native_contract_v1" || supported[1] != "lua")
                throw new Exception("Reported capabilities include unknown values, duplicates or unstable ordering.");
            supported[0] = "tampered";
            if (current.GetSupportedCapabilities()[0] != "host_native_contract_v1" ||
                !current.SupportsCapability("host_native_contract_v1"))
                throw new Exception("Caller changed the host's supported capabilities.");
            var old = new HostProfile(6, "android", "2022.3.76f1",
                new[] { "lua", "host_native_contract_v1" });
            string[] oldCapabilities = old.GetSupportedCapabilities();
            if (oldCapabilities.Length != 1 || oldCapabilities[0] != "lua")
                throw new Exception("API 7 capability leaked into an API 6 host report.");
        }

        private static void CheckActivation(ModuleReleaseSelection selected, ModuleReleaseSelection upgraded,
            string root, string v1, ModuleManifest manifestV1, string v2, ModuleManifest manifestV2,
            string v3, ModuleManifest manifestV3)
        {
                var store = new ModuleActivationStore(Path.Combine(root, "activation"));
                using (var runner = new LuaGameRunner())
                {
                    runner.Enter(manifestV1, v1, _ => { });
                    runner.Tick();
                    store.MarkHealthy(selected, manifestV1, v1, runner);
                    runner.Exit();
                    if (store.Current("sample_new")?.version != "v1")
                        throw new Exception("Healthy v1 was not activated.");
                    if (store.KnownGameIds().Count != 1 || store.KnownGameIds()[0] != "sample_new")
                        throw new Exception("Installed game discovery lost a verified local activation.");
                    try { runner.Enter(manifestV2, v2, _ => { }); }
                    catch (ModuleRunException) { }
                    if (store.Current("sample_new")?.version != "v1")
                        throw new Exception("Failed v2 enter replaced healthy v1.");
                    runner.Enter(manifestV3, v3, _ => { });
                    runner.Tick();
                    store.MarkHealthy(upgraded, manifestV3, v3, runner);
                    runner.Exit();
                    if (store.Current("sample_new")?.version != "v3" ||
                        store.Previous("sample_new")?.version != "v1" ||
                        store.Rollback("sample_new")?.version != "v1")
                        throw new Exception("Healthy upgrade did not retain a rollback version.");
                }
                var reopened = new ModuleActivationStore(Path.Combine(root, "activation"));
                if (reopened.Current("sample_new")?.version != "v1")
                    throw new Exception("Last healthy version did not survive restart.");
        }

        private static string CreateModule(string root, string version, bool failEnter, out ModuleManifest manifest)
        {
            string path = Path.Combine(root, "sample_new", version);
            string luaPath = Path.Combine(path, "games", "sample_new", "main.lua");
            Directory.CreateDirectory(Path.GetDirectoryName(luaPath));
            byte[] lua = Encoding.UTF8.GetBytes(failEnter ? "local M={}\nfunction M.enter() error('bad') end\nreturn M\n" :
                "local M={}\nfunction M.enter(host) host:ShowMessage('ready') end\nreturn M\n");
            File.WriteAllBytes(luaPath, lua);
            using (SHA256 sha = SHA256.Create())
            {
                manifest = new ModuleManifest { formatVersion = 1, gameId = "sample_new", version = version,
                    runtimeType = "unity_lua", entry = "games.sample_new.main", minHostApiVersion = 1,
                    platform = "any", unityVersion = "", requiredCapabilities = new[] { "lua" },
                    files = new[] { new ModuleFile { path = "games/sample_new/main.lua", size = lua.Length,
                        sha256 = BitConverter.ToString(sha.ComputeHash(lua)).Replace("-", "").ToLowerInvariant() } } };
            }
            File.WriteAllText(Path.Combine(path, "manifest.json"), JsonUtility.ToJson(manifest));
            return path;
        }

        private static string Hash(byte[] bytes)
        {
            using (SHA256 sha = SHA256.Create())
                return BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant();
        }

        private static byte[] Sign(RSA rsa, string v1Hash, string v2Hash, string v3Hash)
        {
            string[] releases = {
                Release("legacy_bundle", "v1", "unity_lua", "assetbundle", Application.unityVersion, true, ""),
                Release("bundle_update", "v1", "unity_lua", "assetbundle", Application.unityVersion, true, ""),
                Release("bundle_update", "v2", "unity_lua", "assetbundle", Application.unityVersion, true, "v1")
                    .Replace("\"minHostApiVersion\":1", "\"minHostApiVersion\":6")
                    .Replace("[\"assetbundle\"]", "[\"assetbundle\",\"module_owned_resources_v1\"]"),
                Release("sample_new", "v1", "unity_lua", "lua", "", true, "", v1Hash),
                Release("sample_new", "v2", "unity_lua", "mesh3d", "2022.3.76f1", true, "v1", v2Hash),
                Release("sample_new", "v3", "unity_lua", "mesh3d", "2022.3.76f1", true, "v1", v3Hash),
                Release("sample_new", "v4", "unity_lua", "lua", "", false, ""),
                Release("new_game", "v1", "unity_lua", "lua", "", true, ""),
                Release("web_game", "v1", "h5", "lua", "", true, ""),
                Release("blocked_game", "v1", "unity_lua", "lua", "", true, ""),
                Release("future_game", "v1", "unity_lua", "mesh3d", "2022.3.76f1", true, "")
            };
            byte[] payload = Encoding.UTF8.GetBytes("{\"formatVersion\":2,\"catalogVersion\":2,\"productId\":\"minigame_platform\",\"releases\":[" +
                string.Join(",", releases) + "]}");
            return Encoding.UTF8.GetBytes(JsonUtility.ToJson(new SignedCatalogEnvelope { keyId = "test_key",
                payloadBase64 = Convert.ToBase64String(payload), signatureBase64 = Convert.ToBase64String(
                    rsa.SignData(payload, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1)) }));
        }

        private static byte[] SignRevoked(RSA rsa, string v3Hash)
        {
            byte[] payload = Encoding.UTF8.GetBytes(
                "{\"formatVersion\":2,\"catalogVersion\":3,\"productId\":\"minigame_platform\",\"releases\":[" +
                Release("sample_new", "v3", "unity_lua", "mesh3d", "2022.3.76f1", true, "", v3Hash) + "]}");
            return Encoding.UTF8.GetBytes(JsonUtility.ToJson(new SignedCatalogEnvelope { keyId = "test_key",
                payloadBase64 = Convert.ToBase64String(payload), signatureBase64 = Convert.ToBase64String(
                    rsa.SignData(payload, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1)) }));
        }

        private static string Release(string gameId, string version, string runtime, string capability,
            string unityVersion, bool enabled, string fallback, string hash = null)
        {
            return "{\"gameId\":\"" + gameId + "\",\"version\":\"" + version +
                "\",\"runtimeType\":\"" + runtime + "\",\"manifestPath\":\"" + gameId + "/" + version +
                "/manifest.json\",\"manifestSha256\":\"" + (hash ?? new string('a', 64)) +
                "\",\"minHostApiVersion\":1,\"requiredCapabilities\":[\"" + capability +
                "\"],\"platform\":\"" + (capability == "assetbundle" ? "android" : "any") + "\",\"unityVersion\":\"" + unityVersion +
                "\",\"enabled\":" + (enabled ? "true" : "false") + ",\"fallbackVersion\":\"" + fallback + "\"}";
        }
    }
}
