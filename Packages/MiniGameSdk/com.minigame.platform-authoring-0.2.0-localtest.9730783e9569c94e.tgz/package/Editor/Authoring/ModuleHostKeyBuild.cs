using System;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;

namespace MiniGamePlatform.SDK.EditorChecks
{
    [InitializeOnLoad]
    public sealed class ModuleHostKeyBuild : IPreprocessBuildWithReport, IPostprocessBuildWithReport
    {
        public const string GeneratedSource = "Assets/Plugins/Android/MiniGameModuleKeys.cpp";
        private const string Marker = "// MGP generated module keys. PRIVATE; NEVER COMMIT.";
        private static bool cleanupPending;
        public int callbackOrder => -500;

        static ModuleHostKeyBuild()
        {
            // Recover this generator's source after a crash/domain reload, never unrelated files.
            if (File.Exists(GeneratedSource))
            {
                using var input = new StreamReader(GeneratedSource);
                cleanupPending = input.ReadLine() == Marker;
            }
            EditorApplication.update += CleanupWhenIdle;
        }

        private static void CleanupWhenIdle()
        {
            if (!cleanupPending || BuildPipeline.isBuildingPlayer) return;
            cleanupPending = false;
            CleanupGeneratedSource();
        }

        public static BuildReport BuildPlayer(BuildPlayerOptions options)
        {
            try { return BuildPipeline.BuildPlayer(options); }
            finally { if (options.target == BuildTarget.Android) CleanupGeneratedSource(); }
        }

        public void OnPreprocessBuild(BuildReport report)
        {
            if (report.summary.platform != BuildTarget.Android) return;
            cleanupPending = true;
            CleanupGeneratedSource();
            if (PlayerSettings.GetScriptingBackend(BuildTargetGroup.Android) != ScriptingImplementation.IL2CPP)
                throw new BuildFailedException("Module native keys require Android IL2CPP.");
            Prepare();
        }

        public static void Prepare()
        {
            EnsureOwnedPath();
            using var ring = ModuleBuildKeyRing.FromEnvironment();
            if (Environment.GetEnvironmentVariable("MINIGAME_REQUIRE_MODULE_KEYS") == "1" && ring.Count == 0)
                throw new BuildFailedException("Host build requires provisioned module keys.");
            Directory.CreateDirectory(Path.GetDirectoryName(GeneratedSource));
            // Empty keyring still emits a deny-all symbol; no stale secrets from a previous build.
            File.WriteAllText(GeneratedSource, ring.GenerateNativeSource(), new UTF8Encoding(false));
            AssetDatabase.ImportAsset(GeneratedSource, ImportAssetOptions.ForceSynchronousImport);
            var importer = AssetImporter.GetAtPath(GeneratedSource) as PluginImporter;
            if (importer == null) throw new BuildFailedException("Module native key source was not imported.");
            importer.SetCompatibleWithAnyPlatform(false);
            importer.SetCompatibleWithEditor(false);
            importer.SetCompatibleWithPlatform(BuildTarget.Android, true);
            importer.SaveAndReimport();
        }

        public void OnPostprocessBuild(BuildReport report)
        {
            if (report.summary.platform == BuildTarget.Android) CleanupGeneratedSource();
        }

        public static void CleanupGeneratedSource()
        {
            EnsureOwnedPath();
            if (File.Exists(GeneratedSource) && !AssetDatabase.DeleteAsset(GeneratedSource))
                throw new BuildFailedException("Could not remove private generated module key source.");
        }

        private static void EnsureOwnedPath()
        {
            var full = Path.GetFullPath(GeneratedSource);
            for (var cursor = full; !string.IsNullOrEmpty(cursor); cursor = Path.GetDirectoryName(cursor))
                if ((File.Exists(cursor) || Directory.Exists(cursor)) && (File.GetAttributes(cursor) & FileAttributes.ReparsePoint) != 0)
                    throw new BuildFailedException("Native key output cannot traverse links.");
            if (File.Exists(full))
            {
                using var input = new StreamReader(full);
                if (input.ReadLine() != Marker) throw new BuildFailedException("Native key output is not owned by this generator; refusing overwrite.");
            }
        }
    }
}
