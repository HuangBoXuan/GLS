using System;
using System.Collections;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using MiniGamePlatform.HotUpdate;
using MiniGamePlatform.SDK;
using UnityEditor;
using UnityEngine;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public static class ModuleVersionDecisionChecks
    {
        [MenuItem("MiniGame Platform/SDK/Run Server Version Decision Checks")]
        public static void Run()
        {
            string root = Path.Combine(Path.GetTempPath(), "ModuleVersionDecision-" + Guid.NewGuid().ToString("N"));
            DateTime now = new DateTime(2026, 10, 9, 0, 0, 0, DateTimeKind.Utc);
            Directory.CreateDirectory(root);
            try
            {
                using (RSA rsa = new RSACryptoServiceProvider(2048))
                {
                    RSAParameters publicKey = rsa.ExportParameters(false);
                    var key = new CatalogTrustKey("decision_test", Convert.ToBase64String(publicKey.Modulus),
                        Convert.ToBase64String(publicKey.Exponent));
                    var host = new HostProfile(7, "android", Application.unityVersion, new[] { "lua" });
                    var product = new ProductContext("minigame_platform", "https://api.example.test", "1.0.0",
                        new[] { "garden" });
                    SignedCatalogEnvelope envelope = Sign(rsa);
                    var ready = new ModuleVersionDecision
                    {
                        productId = product.ProductId, gameId = "garden", status = "ready", reason = "SELECTED",
                        selectionRevision = 1, catalogVersion = 1, maxAgeSeconds = 30,
                        moduleBaseUrl = "https://cdn.example.test/modules/", catalogEnvelope = envelope,
                        selected = new ModuleVersionReference { gameId = "garden", version = "v1",
                            manifestSha256 = new string('a', 64) }
                    };
                    var fake = new FakeTransport();
                    fake.Next = Reply(ready);
                    var source = NewSource(root, host, product, key, fake, () => now);
                    string failure = Load(source);
                    if (failure != null || !source.IsAuthorized || source.Offline ||
                        source.Selected?.Release.version != "v1")
                        throw new Exception("Exact server-selected version was not accepted.");
                    now = now.AddSeconds(31);
                    if (source.IsAuthorized || source.CanDownload)
                        throw new Exception("Expired online decision still allowed entry or download.");
                    now = now.AddHours(2);
                    fake.Next = new ModuleVersionReply { HttpStatus = 503 };
                    source = NewSource(root, host, product, key, fake, () => now);
                    failure = Load(source);
                    if (failure != null || !source.IsAuthorized || !source.Offline || source.MayUseBundled ||
                        source.Selected?.Release.version != "v1")
                        throw new Exception("Temporary service outage lost the verified installed-only decision.");
                    fake.Next = new ModuleVersionReply { HttpStatus = -1, TransportUnavailable = true };
                    source = NewSource(root, host, product, key, fake, () => now);
                    if (Load(source) != null || !source.IsAuthorized || !source.Offline)
                        throw new Exception("Unity's negative no-response status lost the local decision.");

                    fake.Next = Reply(new ModuleVersionDecision { productId = product.ProductId,
                        gameId = "garden", status = "blocked", reason = "DISABLED",
                        selectionRevision = 2, catalogVersion = 1 });
                    source = NewSource(root, host, product, key, fake, () => now);
                    if (Load(source) == null || source.IsAuthorized) throw new Exception("Explicit disable was ignored.");
                    fake.Next = new ModuleVersionReply { HttpStatus = 503 };
                    source = NewSource(root, host, product, key, fake, () => now);
                    if (Load(source) == null || source.IsAuthorized || source.MayUseBundled)
                        throw new Exception("An outage bypassed the known disable policy.");

                    string fresh = Path.Combine(root, "fresh");
                    var freshProduct = new ProductContext("minigame_platform", "https://api.example.test", "1.0.0",
                        new[] { "garden" });
                    fake.Next = new ModuleVersionReply { HttpStatus = 503 };
                    source = NewSource(fresh, host, freshProduct, key, fake, () => now);
                    if (Load(source) != null || !source.MayUseBundled || source.IsAuthorized)
                        throw new Exception("First-install outage did not allow a separately verified bundled module.");
                    fake.Next = Reply(new ModuleVersionDecision { productId = freshProduct.ProductId,
                        gameId = "garden", status = "blocked", reason = "UNPUBLISHED",
                        selectionRevision = 0, catalogVersion = 0 });
                    source = NewSource(fresh, host, freshProduct, key, fake, () => now);
                    if (Load(source) != null || !source.MayUseBundled)
                        throw new Exception("Initial unpublished response did not allow the bundled module.");
                    Debug.Log("Module server version decision checks passed.");
                }
            }
            finally { Directory.Delete(root, true); }
        }

        private static ModuleVersionDecisionSource NewSource(string root, HostProfile host,
            ProductContext product, CatalogTrustKey key, FakeTransport fake, Func<DateTime> clock) =>
            new ModuleVersionDecisionSource("garden", root, host, product, key, fake, clock);

        private static string Load(ModuleVersionDecisionSource source)
        {
            string failure = null;
            RunEnumerator(source.Load(message => failure = message));
            return failure;
        }

        private static void RunEnumerator(IEnumerator routine)
        {
            while (routine.MoveNext())
                if (routine.Current is IEnumerator nested) RunEnumerator(nested);
            (routine as IDisposable)?.Dispose();
        }

        private static ModuleVersionReply Reply(ModuleVersionDecision decision) =>
            new ModuleVersionReply { HttpStatus = 200, Bytes = Encoding.UTF8.GetBytes(
                JsonUtility.ToJson(new ModuleVersionResponse { data = decision })) };

        private static SignedCatalogEnvelope Sign(RSA rsa)
        {
            byte[] payload = Encoding.UTF8.GetBytes(JsonUtility.ToJson(new ProductModuleCatalog
            {
                formatVersion = 2, catalogVersion = 1, productId = "minigame_platform",
                releases = new[] { new ModuleRelease { gameId = "garden", version = "v1",
                    manifestPath = "garden/v1/manifest.json", manifestSha256 = new string('a', 64),
                    runtimeType = "unity_lua", minHostApiVersion = 1,
                    requiredCapabilities = new[] { "lua" }, platform = "any", unityVersion = "",
                    enabled = true } }
            }));
            return new SignedCatalogEnvelope { keyId = "decision_test",
                payloadBase64 = Convert.ToBase64String(payload), signatureBase64 = Convert.ToBase64String(
                    rsa.SignData(payload, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1)) };
        }

        private sealed class FakeTransport : IModuleVersionTransport
        {
            public ModuleVersionReply Next;
            public IEnumerator Query(Uri endpoint, ModuleVersionQuery query, Action<ModuleVersionReply> done)
            {
                done(Next);
                yield break;
            }
        }
    }
}
