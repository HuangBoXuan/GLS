using System;
using System.IO;
using System.Security.Cryptography;
using MiniGamePlatform.HotUpdate;
using UnityEditor;
using UnityEngine;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public static class ModuleReleaseGateChecks
    {
        [MenuItem("MiniGame Platform/SDK/Run Module Release Gate Checks")]
        public static void Run()
        {
            string root = Path.Combine(Path.GetTempPath(), "MiniGameGate-" + Guid.NewGuid().ToString("N"));
            string source = Path.Combine(root, "source");
            string output = Path.Combine(root, "output");
            Directory.CreateDirectory(Path.Combine(source, "games", "sample_gate"));
            try
            {
                File.WriteAllText(Path.Combine(source, "games", "sample_gate", "main.lua"),
                    "local M={}\nfunction M.enter(host) end\nfunction M.exit() end\nreturn M\n");
                File.WriteAllBytes(Path.Combine(source, "sample_gate.bundle"), new byte[] { 1, 2, 3 });
                var definition = new ModuleDefinition
                {
                    gameId = "sample_gate", moduleVersion = "v1", runtimeType = "unity_lua", entry = "games.sample_gate.main",
                    minHostApiVersion = 1, requiredCapabilities = new[] { "lua", "ugui", "assetbundle" },
                    luaRoot = "games/sample_gate", dataRoots = new[] { "data/sample_gate" },
                    assetRoots = new[] { "Assets/Sample/Ui.prefab" }, ruleVersion = "r1", saveSchemaVersion = "s1",
                    levelMapPath = "data/sample_gate/levels.json", platform = "android"
                };
                string modulePath = ModulePackager.Pack(definition, source, output);
                string manifestHash = Hash(Path.Combine(modulePath, "manifest.json"));
                var module = new ModuleBuildResult(modulePath, manifestHash, Array.Empty<AuthoringIssue>());
                var host = new HostProfile(1, "android", Application.unityVersion, definition.requiredCapabilities);
                ModuleGateReport preview = ModuleReleaseGate.Evaluate(module, host, host, null, null);
                Assert(preview.previewPassed && !preview.publishable, "Editor-only preview was marked publishable.");

                string independentApk = Path.Combine(root, "independent.apk");
                string hubApk = Path.Combine(root, "hub.apk");
                File.WriteAllBytes(independentApk, new byte[] { 11, 12 });
                File.WriteAllBytes(hubApk, new byte[] { 21, 22 });
                AndroidProductEvidence independent = Evidence("arrow_demo", "com.minigame.arrowdemo", independentApk, manifestHash);
                AndroidProductEvidence hub = Evidence("hub_demo", "com.minigame.hubdemo", hubApk, manifestHash);
                hub.switchedAtoBtoA = true;
                ModuleGateReport passed = ModuleReleaseGate.Evaluate(module, host, host, independent, hub);
                Assert(passed.previewPassed && passed.publishable && passed.sampleOnly,
                    "Dual Android sample evidence was rejected or mislabeled as real server settlement.");
                hub.moduleManifestSha256 = new string('a', 64);
                Assert(!ModuleReleaseGate.Evaluate(module, host, host, independent, hub).publishable,
                    "Different module bytes passed dual-package gate.");
                hub.moduleManifestSha256 = manifestHash;
                hub.deviceId = "";
                Assert(!ModuleReleaseGate.Evaluate(module, host, host, independent, hub).publishable,
                    "Missing device proof passed gate.");
                hub.deviceId = "emulator-5554";
                hub.deviceLogSha256 = new string('b', 64);
                Assert(!ModuleReleaseGate.Evaluate(module, host, host, independent, hub).publishable,
                    "Tampered device log passed gate.");
                hub.deviceLogSha256 = Hash(hub.deviceLogPath);
                Assert(!ModuleReleaseGate.Evaluate(module,
                    new HostProfile(1, "android", Application.unityVersion, new[] { "lua" }), host,
                    independent, hub).previewPassed, "Oldest host without UGUI was accepted.");
                Debug.Log("Module release gate checks passed.");
            }
            finally
            {
                if (Directory.Exists(root)) Directory.Delete(root, true);
            }
        }

        private static AndroidProductEvidence Evidence(string productId, string applicationId, string apk, string moduleHash)
        {
            string log = apk + ".log";
            File.WriteAllText(log, "ANDROID_GATE_PASS productId=" + productId + " appId=" + applicationId +
                " manifest=" + moduleHash + " A-B-A download-failure-recovered");
            return new AndroidProductEvidence
            {
                productId = productId, applicationId = applicationId, apkPath = apk, apkSha256 = Hash(apk),
                moduleManifestSha256 = moduleHash, platform = "android", unityVersion = Application.unityVersion,
                sdkVersion = "0.1.0", hostApiVersion = 1, capabilities = new[] { "lua", "ugui", "assetbundle" },
                androidBuildVersion = "1.0.0+1", deviceId = "emulator-5554", deviceLogPath = log,
                deviceLogSha256 = Hash(log), verifiedAtUtc = DateTime.UtcNow.ToString("o"),
                scriptingBackend = "IL2CPP", architecture = "arm64", entered = true, paused = true, resumed = true,
                exited = true, reentered = true, missingScriptFree = true, shaderAvailable = true,
                downloadFailureRecovered = true, settlementMode = "contract_stub"
            };
        }

        private static string Hash(string path)
        {
            using (FileStream stream = File.OpenRead(path))
            using (SHA256 sha = SHA256.Create())
                return BitConverter.ToString(sha.ComputeHash(stream)).Replace("-", "").ToLowerInvariant();
        }

        private static void Assert(bool value, string message)
        {
            if (!value) throw new Exception(message);
        }
    }
}
