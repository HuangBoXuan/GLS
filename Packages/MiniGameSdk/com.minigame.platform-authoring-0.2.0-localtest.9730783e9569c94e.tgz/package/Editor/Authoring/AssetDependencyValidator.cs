using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public static class AssetDependencyValidator
    {
        public static IReadOnlyList<AuthoringIssue> Validate(ModuleDefinition definition, IHostComponentInventory inventory)
        {
            if (definition == null) throw new ArgumentNullException(nameof(definition));
            if (inventory == null) throw new ArgumentNullException(nameof(inventory));
            var issues = new List<AuthoringIssue>();
            if (definition.assetRoots == null || definition.assetRoots.Length == 0)
            {
                issues.Add(new AuthoringIssue("ASSET_ROOT_REQUIRED", "assetRoots", "Declare the assets to bundle."));
                return issues;
            }
            foreach (string root in definition.assetRoots)
            {
                if (string.IsNullOrWhiteSpace(root) || !root.StartsWith("Assets/", StringComparison.Ordinal) ||
                    AssetDatabase.LoadMainAssetAtPath(root) == null)
                {
                    issues.Add(new AuthoringIssue("ASSET_MISSING", root ?? "assetRoots", "Selected asset does not exist."));
                    continue;
                }
                foreach (string dependency in AssetDatabase.GetDependencies(root, true))
                {
                    string forbidden = ForbiddenDependency(dependency);
                    if (forbidden != null)
                    {
                        issues.Add(new AuthoringIssue("FORBIDDEN_SDK", root, dependency + " references " + forbidden));
                        continue;
                    }
                    GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(dependency);
                    if (prefab != null && dependency.EndsWith(".prefab", StringComparison.OrdinalIgnoreCase))
                    {
                        foreach (Transform transform in prefab.GetComponentsInChildren<Transform>(true))
                        {
                            foreach (Component component in transform.GetComponents<Component>())
                                issues.AddRange(InspectComponentSlot(root, component, inventory));
                        }
                    }
                    Material material = AssetDatabase.LoadAssetAtPath<Material>(dependency);
                    if (material != null && !IsBundledShader(material.shader))
                        issues.AddRange(InspectShader(root, material.shader == null ? null : material.shader.name, inventory));
                }
            }
            return issues;
        }

        private static bool IsBundledShader(Shader shader)
        {
            if (shader == null) return false;
            string path = AssetDatabase.GetAssetPath(shader);
            // A material's referenced shader asset is included by Unity's dependency packaging.
            // Only host/built-in shader references need the host retention inventory.
            return (path.StartsWith("Assets/", StringComparison.Ordinal) || path.StartsWith("Packages/", StringComparison.Ordinal)) &&
                (path.EndsWith(".shader", StringComparison.OrdinalIgnoreCase) || path.EndsWith(".shadergraph", StringComparison.OrdinalIgnoreCase));
        }

        public static IReadOnlyList<AuthoringIssue> InspectComponentSlot(string sourcePath, Component component,
            IHostComponentInventory inventory)
        {
            if (component == null)
                return new[] { new AuthoringIssue("MISSING_SCRIPT", sourcePath, "Prefab has a missing script component.") };
            Type type = component.GetType();
            return InspectComponentName(sourcePath, type.FullName, type.Assembly.GetName().Name, inventory);
        }

        public static IReadOnlyList<AuthoringIssue> InspectComponentName(string sourcePath, string typeName,
            string assemblyName, IHostComponentInventory inventory)
        {
            if (inventory == null) throw new ArgumentNullException(nameof(inventory));
            string forbidden = ForbiddenDependency((typeName ?? "") + "/" + (assemblyName ?? ""));
            if (forbidden != null)
                return new[] { new AuthoringIssue("FORBIDDEN_SDK", sourcePath, "Component references " + forbidden) };
            if (!inventory.HasComponent(typeName, assemblyName))
                return new[] { new AuthoringIssue("COMPONENT_UNAVAILABLE", sourcePath,
                    "Host does not retain component " + typeName + " from " + assemblyName) };
            return Array.Empty<AuthoringIssue>();
        }

        public static IReadOnlyList<AuthoringIssue> InspectShader(string sourcePath, string shaderName,
            IHostComponentInventory inventory)
        {
            if (inventory == null) throw new ArgumentNullException(nameof(inventory));
            if (inventory.HasShader(shaderName)) return Array.Empty<AuthoringIssue>();
            return new[] { new AuthoringIssue("SHADER_UNAVAILABLE", sourcePath,
                "Host does not retain shader " + (shaderName ?? "<missing>")) };
        }

        private static string ForbiddenDependency(string path)
        {
            string lower = (path ?? "").ToLowerInvariant();
            if (lower.Contains("ygui")) return "YGUI";
            if (lower.Contains("appsflyer")) return "AppsFlyer";
            if (lower.Contains("applovin") || lower.Contains("/max/") || lower.Contains(".max.")) return "MAX";
            return null;
        }
    }
}
