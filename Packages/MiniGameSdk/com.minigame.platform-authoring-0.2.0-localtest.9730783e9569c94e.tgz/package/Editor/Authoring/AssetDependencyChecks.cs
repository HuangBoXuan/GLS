using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public static class AssetDependencyChecks
    {
        [MenuItem("MiniGame Platform/SDK/Run Asset Dependency Checks")]
        public static void Run()
        {
            const string root = "Assets/SdkAssetChecks";
            Directory.CreateDirectory(root);
            AssetDatabase.Refresh();
            try
            {
                string validPath = root + "/Valid.prefab";
                var canvas = new GameObject("Canvas", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler));
                var label = new GameObject("Label", typeof(RectTransform), typeof(Text));
                label.transform.SetParent(canvas.transform, false);
                PrefabUtility.SaveAsPrefabAsset(canvas, validPath);
                UnityEngine.Object.DestroyImmediate(canvas);

                string unsupportedPath = root + "/Unsupported.prefab";
                var light = new GameObject("Unretained", typeof(Light));
                PrefabUtility.SaveAsPrefabAsset(light, unsupportedPath);
                UnityEngine.Object.DestroyImmediate(light);

                var inventory = HostComponentInventory.FromCapabilities(new[] { "lua", "ugui", "sprite2d", "mesh3d", "assetbundle" },
                    new[] { "MiniGamePlatform/FlatColor" });
                AssertNoIssue(AssetDependencyValidator.Validate(Definition(validPath), inventory));
                AssertIssue(AssetDependencyValidator.Validate(Definition(unsupportedPath), inventory), "COMPONENT_UNAVAILABLE", unsupportedPath);
                AssertIssue(AssetDependencyValidator.InspectComponentSlot(unsupportedPath, null, inventory), "MISSING_SCRIPT", unsupportedPath);
                AssertIssue(AssetDependencyValidator.InspectComponentName(unsupportedPath, "YGUI.UIWidget", "YGUI", inventory), "FORBIDDEN_SDK", unsupportedPath);
                AssertIssue(AssetDependencyValidator.InspectComponentName(unsupportedPath, "UnityEngine.Canvas", "PartnerAssembly", inventory), "COMPONENT_UNAVAILABLE", unsupportedPath);
                AssertIssue(AssetDependencyValidator.InspectShader(unsupportedPath, "Unretained/Shader", inventory), "SHADER_UNAVAILABLE", unsupportedPath);

                string missingPath = root + "/Missing.prefab";
                var missingObject = new GameObject("Missing", typeof(EventSystem));
                PrefabUtility.SaveAsPrefabAsset(missingObject, missingPath);
                UnityEngine.Object.DestroyImmediate(missingObject);
                string yaml = File.ReadAllText(missingPath);
                string modified = Regex.Replace(yaml, "guid: [0-9a-f]{32}", "guid: ffffffffffffffffffffffffffffffff", RegexOptions.IgnoreCase);
                if (modified == yaml) throw new Exception("Could not create Missing Script prefab fixture.");
                File.WriteAllText(missingPath, modified);
                AssetDatabase.ImportAsset(missingPath, ImportAssetOptions.ForceUpdate);
                AssertIssue(AssetDependencyValidator.Validate(Definition(missingPath), inventory), "MISSING_SCRIPT", missingPath);

                string source = Path.Combine(Path.GetTempPath(), "MiniGameAssetSource-" + Guid.NewGuid().ToString("N"));
                string output = Path.Combine(Path.GetTempPath(), "MiniGameAssetOutput-" + Guid.NewGuid().ToString("N"));
                try
                {
                    string lua = Path.Combine(source, "games", "check");
                    Directory.CreateDirectory(lua);
                    File.WriteAllText(Path.Combine(lua, "main.lua"), "local M={}\nfunction M.enter(host) end\nfunction M.exit() end\nreturn M\n");
                    ModuleBuildResult result = AndroidModuleBuilder.Build(Definition(validPath), source, output, inventory);
                    if (!File.Exists(Path.Combine(result.ModulePath, "check.bundle")))
                        throw new Exception("Android module bundle was not packaged.");
                    if (string.IsNullOrEmpty(result.ManifestSha256) || result.DependencyIssues.Count != 0)
                        throw new Exception("Android module result is incomplete.");
                }
                finally
                {
                    if (Directory.Exists(source)) Directory.Delete(source, true);
                    if (Directory.Exists(output)) Directory.Delete(output, true);
                }
                Debug.Log("Asset dependency checks passed.");
            }
            finally
            {
                AssetDatabase.DeleteAsset(root);
            }
        }

        private static ModuleDefinition Definition(string assetPath)
        {
            return new ModuleDefinition { gameId = "check", moduleVersion = "v1", runtimeType = "unity_lua",
                entry = "games.check.main", minHostApiVersion = 6, requiredCapabilities = new[] { "lua", "ugui", "assetbundle", "module_owned_resources_v1" },
                luaRoot = "games/check", dataRoots = new[] { "data/check" }, assetRoots = new[] { assetPath },
                ruleVersion = "r1", saveSchemaVersion = "s1", levelMapPath = "data/check/levels.json", platform = "android" };
        }

        private static void AssertIssue(IEnumerable<AuthoringIssue> issues, string code, string path)
        {
            if (!issues.Any(issue => issue.Code == code && issue.Path == path))
                throw new Exception("Expected issue missing: " + code + " at " + path);
        }

        private static void AssertNoIssue(IEnumerable<AuthoringIssue> issues)
        {
            AuthoringIssue first = issues.FirstOrDefault();
            if (first != null) throw new Exception("Unexpected asset issue: " + first.Code + " at " + first.Path + " — " + first.Message);
        }
    }
}
