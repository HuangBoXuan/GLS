using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using MiniGamePlatform.HotUpdate;
using UnityEngine;

namespace MiniGamePlatform.SDK.EditorChecks
{
    /// <summary>Build-machine input only. A public keyId is a selector, never key material.</summary>
    public sealed class ModuleBuildKeyRing : IModuleContentKeyProvider, IDisposable
    {
        public const string EnvironmentName = "MINIGAME_MODULE_KEYS_FILE";
        [Serializable] private sealed class Document { public int version; public Entry[] entries; }
        [Serializable] private sealed class Entry { public string gameId; public string keyId; public string keyBase64; }
        private readonly Dictionary<string, byte[]> keys = new Dictionary<string, byte[]>(StringComparer.Ordinal);
        public int Count => keys.Count;

        public static void AssertOutsideArtifactTrees(string sourceDirectory, string outputDirectory)
        {
            var input = Environment.GetEnvironmentVariable(EnvironmentName);
            if (string.IsNullOrWhiteSpace(input)) return;
            var full = Path.GetFullPath(input);
            foreach (var directory in new[] { sourceDirectory, outputDirectory })
            {
                var root = Path.GetFullPath(directory).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                if (full.Equals(root, StringComparison.OrdinalIgnoreCase) || full.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
                    throw new ModulePackagingException("PRIVATE_KEY_IN_ARTIFACT_TREE", "moduleSource", "Private key input must be outside source and output trees.");
            }
        }

        public static ModuleBuildKeyRing FromEnvironment()
        {
            var path = Environment.GetEnvironmentVariable(EnvironmentName);
            if (string.IsNullOrWhiteSpace(path)) return new ModuleBuildKeyRing();
            return Load(path, Path.GetFullPath(Path.Combine(Application.dataPath, "..")));
        }

        public static ModuleBuildKeyRing Load(string path, string projectRoot)
        {
            var ring = new ModuleBuildKeyRing();
            try
            {
                var full = Path.GetFullPath(path);
                var root = Path.GetFullPath(projectRoot).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                if (full.Equals(root, StringComparison.OrdinalIgnoreCase) || full.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidDataException();
                for (var cursor = full; !string.IsNullOrEmpty(cursor); cursor = Path.GetDirectoryName(cursor))
                    if ((File.Exists(cursor) || Directory.Exists(cursor)) && (File.GetAttributes(cursor) & FileAttributes.ReparsePoint) != 0)
                        throw new InvalidDataException();
                if (new FileInfo(full).Length > 65536) throw new InvalidDataException();
                var document = JsonUtility.FromJson<Document>(File.ReadAllText(full, Encoding.UTF8));
                if (document == null || document.version != 1 || document.entries == null || document.entries.Length > 64)
                    throw new InvalidDataException();
                foreach (var entry in document.entries)
                {
                    if (entry == null || !ModuleContentProtection.ValidId(entry.gameId) || !ModuleContentProtection.ValidId(entry.keyId))
                        throw new InvalidDataException();
                    var identity = entry.gameId + "/" + entry.keyId;
                    if (ring.keys.ContainsKey(identity)) throw new InvalidDataException();
                    var bytes = Convert.FromBase64String(entry.keyBase64 ?? "");
                    if (bytes.Length != 32 || bytes.All(b => b == 0))
                    { Array.Clear(bytes, 0, bytes.Length); throw new InvalidDataException(); }
                    ring.keys.Add(identity, bytes);
                }
                return ring;
            }
            catch
            {
                ring.Dispose();
                // Do not log secret input, parser excerpts, full file paths or inner exceptions.
                throw new InvalidDataException("Invalid private module key file; keep it outside the Unity project and use version 1, unique gameId/keyId pairs and 32-byte keys.");
            }
        }

        public bool CopyKey(string gameId, string keyId, byte[] destination)
        {
            if (destination == null || destination.Length != 32 || !keys.TryGetValue(gameId + "/" + keyId, out var source)) return false;
            Buffer.BlockCopy(source, 0, destination, 0, 32);
            return true;
        }

        public string GenerateNativeSource()
        {
            var text = new StringBuilder("// MGP generated module keys. PRIVATE; NEVER COMMIT.\n");
            text.Append("static int eq(const char*a,const char*b){if(!a||!b)return 0;while(*a&&*b&&*a==*b){++a;++b;}return *a==*b;}\n");
            int index = 0;
            foreach (var pair in keys.OrderBy(p => p.Key, StringComparer.Ordinal))
            {
                var mask = new byte[32];
                using (var random = RandomNumberGenerator.Create()) random.GetBytes(mask);
                text.Append("static volatile const unsigned char a").Append(index).Append("[32]={")
                    .Append(string.Join(",", mask)).Append("};\nstatic volatile const unsigned char b").Append(index).Append("[32]={")
                    .Append(string.Join(",", pair.Value.Select((b, i) => (byte)(b ^ mask[i])))).Append("};\n");
                Array.Clear(mask, 0, mask.Length);
                index++;
            }
            text.Append("extern \"C\" int mgp_module_key(const char*g,const char*k,unsigned char*out,int size){if(!out||size!=32)return 0;\n");
            index = 0;
            foreach (var pair in keys.OrderBy(p => p.Key, StringComparer.Ordinal))
            {
                var identity = pair.Key.Split('/');
                text.Append("if(eq(g,\"").Append(identity[0]).Append("\")&&eq(k,\"").Append(identity[1]).Append("\")){for(int i=0;i<32;++i)out[i]=a")
                    .Append(index).Append("[i]^b").Append(index).Append("[i];return 1;}\n");
                index++;
            }
            return text.Append("return 0;}\n").ToString();
        }

        public void Dispose()
        {
            foreach (var key in keys.Values) Array.Clear(key, 0, key.Length);
            keys.Clear();
        }
    }
}
