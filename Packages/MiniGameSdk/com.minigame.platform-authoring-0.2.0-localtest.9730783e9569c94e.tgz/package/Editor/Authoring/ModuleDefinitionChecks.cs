using System;
using System.Collections.Generic;
using MiniGamePlatform.HotUpdate;
using MiniGamePlatform.SDK.GameData;
using UnityEditor;
using UnityEngine;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public static class ModuleDefinitionChecks
    {
        private const string ValidJson =
            "{\"gameId\":\"arrow\",\"moduleVersion\":\"v1\",\"runtimeType\":\"unity_lua\",\"entry\":\"games.arrow.main\"," +
            "\"minHostApiVersion\":1,\"requiredCapabilities\":[\"lua\",\"ugui\"],\"luaRoot\":\"games/arrow\"," +
            "\"dataRoots\":[\"data/arrow\"],\"assetRoots\":[\"Assets/Arrow/Board.prefab\"]," +
            "\"ruleVersion\":\"r1\",\"saveSchemaVersion\":\"s1\",\"levelMapPath\":\"data/arrow/levels.json\",\"platform\":\"android\"}";

        [MenuItem("MiniGame Platform/SDK/Run Module Definition Checks")]
        public static void Run()
        {
            var host = new HostProfile(1, "android", "2022.3.76f1", new[] { "lua", "ugui" });
            AssertNoIssue(ModuleDefinitionValidator.Validate(ModuleDefinition.Load(ValidJson), host));
            AssertHasIssue(ModuleDefinitionValidator.Validate(
                ModuleDefinition.Load(ValidJson.Replace("\"gameId\":\"arrow\"", "\"gameId\":\"garden\"")), host),
                "ENTRY_GAME_MISMATCH");
            AssertHasIssue(ModuleDefinitionValidator.Validate(
                ModuleDefinition.Load(ValidJson.Replace("\"gameId\":\"arrow\"", "\"gameId\":\"" + new string('a', 65) + "\"")), host),
                "INVALID_GAME_ID");
            AssertHasIssue(ModuleDefinitionValidator.Validate(
                ModuleDefinition.Load(ValidJson.Replace("\"gameId\":\"arrow\"", "\"gameId\":\"garden-war\"")), host),
                "INVALID_GAME_ID");
            AssertNoIssue(ModuleDefinitionValidator.Validate(
                ModuleDefinition.Load(ValidJson.Replace("arrow", new string('a', 64))), host));
            Assert(new GameContext("hub_local_test", "garden_war").GameId == "garden_war",
                "registered underscore GameID was rejected by the SDK context");
            Assert(new GameContext("hub_local_test", "game-a").GameId == "game-a",
                "legacy server GameID stopped working");
            AssertHasIssue(ModuleDefinitionValidator.Validate(
                ModuleDefinition.Load(ValidJson.Replace("\"minHostApiVersion\":1", "\"minHostApiVersion\":2")), host),
                "HOST_API_UNAVAILABLE");
            AssertHasIssue(ModuleDefinitionValidator.Validate(
                ModuleDefinition.Load(ValidJson.Replace("[\"Assets/Arrow/Board.prefab\"]", "[\"Assets/Arrow/Board.prefab\",\"Assets/Arrow/Board.prefab\"]")), host),
                "DUPLICATE_ASSET_ROOT");
            AssertHasIssue(ModuleDefinitionValidator.Validate(
                ModuleDefinition.Load(ValidJson.Replace("\"ruleVersion\":\"r1\"", "\"ruleVersion\":\"\"")), host),
                "RULE_VERSION_REQUIRED");
            AssertHasIssue(ModuleDefinitionValidator.Validate(
                ModuleDefinition.Load(ValidJson.Replace("\"saveSchemaVersion\":\"s1\"", "\"saveSchemaVersion\":\"\"")), host),
                "SAVE_SCHEMA_REQUIRED");
            AssertHasIssue(ModuleDefinitionValidator.Validate(
                ModuleDefinition.Load(ValidJson.Replace("\"levelMapPath\":\"data/arrow/levels.json\"", "\"levelMapPath\":\"\"")), host),
                "LEVEL_MAP_REQUIRED");
            Assert(ModuleDefinition.Load(ValidJson.Replace("\"runtimeType\":\"unity_lua\",", "")).runtimeType == "unity_lua",
                "legacy definition did not default to unity_lua");
            AssertNoIssue(ModuleDefinitionValidator.Validate(
                ModuleDefinition.Load(ValidJson.Replace("\"platform\":\"android\"", "\"platform\":\"any\"")), host));
            AssertHasIssue(ModuleDefinitionValidator.Validate(
                ModuleDefinition.Load(ValidJson.Replace("\"runtimeType\":\"unity_lua\"", "\"runtimeType\":\"h5\"")), host),
                "UNSUPPORTED_RUNTIME");
            Assert(HostCapabilityRegistry.Contains("ugui", 1), "existing UGUI capability was lost");
            Assert(!HostCapabilityRegistry.Contains("unknown", 1), "unknown capability was accepted");
            var dataDefinition = ModuleDefinition.Load(ValidJson);
            dataDefinition.requiredCapabilities = new[] { "lua", "data_text" };
            var dataHost = new HostProfile(2, "android", "2022.3.76f1", dataDefinition.requiredCapabilities);
            AssertHasIssue(ModuleDefinitionValidator.Validate(dataDefinition, dataHost), "CAPABILITY_UNAVAILABLE");
            dataDefinition.minHostApiVersion = 2;
            AssertNoIssue(ModuleDefinitionValidator.Validate(dataDefinition, dataHost));
            AssertHasIssue(ModuleDefinitionValidator.Validate(dataDefinition, host), "HOST_API_UNAVAILABLE");
            Debug.Log("Module definition checks passed.");
        }

        private static void AssertHasIssue(IReadOnlyList<AuthoringIssue> issues, string code)
        {
            foreach (AuthoringIssue issue in issues)
                if (issue.Code == code) return;
            throw new Exception("Expected issue was missing: " + code);
        }

        private static void AssertNoIssue(IReadOnlyList<AuthoringIssue> issues)
        {
            if (issues.Count > 0) throw new Exception("Valid definition was rejected: " + issues[0].Code);
        }

        private static void Assert(bool value, string message)
        {
            if (!value) throw new Exception(message);
        }
    }
}
