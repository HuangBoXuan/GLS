using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using MiniGamePlatform.HotUpdate;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public sealed class AuthoringIssue
    {
        public string Code { get; }
        public string Path { get; }
        public string Message { get; }

        public AuthoringIssue(string code, string path, string message)
        {
            Code = code;
            Path = path;
            Message = message;
        }
    }

    public static class ModuleDefinitionValidator
    {
        private static readonly Regex Identifier = new Regex("^[a-z][a-z0-9_]*$", RegexOptions.CultureInvariant);
        private static readonly Regex GameId = new Regex("^[a-z][a-z0-9_]{0,63}$", RegexOptions.CultureInvariant);
        private static readonly Regex Entry = new Regex("^games\\.[a-z][a-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+$", RegexOptions.CultureInvariant);

        public static IReadOnlyList<AuthoringIssue> Validate(ModuleDefinition definition, HostProfile host)
        {
            if (definition == null) throw new ArgumentNullException(nameof(definition));
            if (host == null) throw new ArgumentNullException(nameof(host));
            var issues = new List<AuthoringIssue>();
            try { ModuleContentProtection.ValidateDeclaration(new ModuleManifest {
                contentEncryption = definition.contentEncryption, contentKeyId = definition.contentKeyId,
                requiredCapabilities = definition.requiredCapabilities }); }
            catch (InvalidDataException) { Add(issues, "CONTENT_PROTECTION_INVALID", "contentEncryption", "Protection requires wpc1, a key ID and protected_content capability."); }
            if (!GameId.IsMatch(definition.gameId ?? ""))
                Add(issues, "INVALID_GAME_ID", "gameId", "Use the registered GameID: 1-64 lowercase letters, digits or underscores, starting with a letter.");
            if (!Identifier.IsMatch(definition.moduleVersion ?? ""))
                Add(issues, "INVALID_MODULE_VERSION", "moduleVersion", "Use an immutable lowercase version ID.");
            if (definition.runtimeType != "unity_lua")
                Add(issues, "UNSUPPORTED_RUNTIME", "runtimeType", "This SDK build only packages unity_lua modules.");
            if (!Entry.IsMatch(definition.entry ?? "") ||
                !definition.entry.StartsWith("games." + definition.gameId + ".", StringComparison.Ordinal))
                Add(issues, "ENTRY_GAME_MISMATCH", "entry", "Lua entry must be under games.<gameId>.");
            if (definition.minHostApiVersion < 1 || definition.minHostApiVersion > host.Version)
                Add(issues, "HOST_API_UNAVAILABLE", "minHostApiVersion", "The target host does not support this API version.");
            if (definition.platform != "android" && definition.platform != "editor" && definition.platform != "any")
                Add(issues, "INVALID_PLATFORM", "platform", "Select an explicit build platform.");
            else if (definition.platform != "any" && definition.platform != host.Platform)
                Add(issues, "HOST_PLATFORM_MISMATCH", "platform", "The target host has a different platform.");
            if (definition.luaRoot != "games/" + definition.gameId)
                Add(issues, "INVALID_LUA_ROOT", "luaRoot", "Lua root must be games/<gameId>.");
            if (string.IsNullOrWhiteSpace(definition.ruleVersion))
                Add(issues, "RULE_VERSION_REQUIRED", "ruleVersion", "Rule version is required.");
            if (string.IsNullOrWhiteSpace(definition.saveSchemaVersion))
                Add(issues, "SAVE_SCHEMA_REQUIRED", "saveSchemaVersion", "Save schema version is required.");
            if (!SafeDataPath(definition.levelMapPath))
                Add(issues, "LEVEL_MAP_REQUIRED", "levelMapPath", "A safe level map path is required.");
            ValidateRoots(definition.dataRoots, "dataRoots", "DUPLICATE_DATA_ROOT", issues, SafeDataPath);
            ValidateRoots(definition.assetRoots, "assetRoots", "DUPLICATE_ASSET_ROOT", issues,
                path => path != null && path.StartsWith("Assets/", StringComparison.Ordinal) && SafePath(path));
            if (definition.requiredCapabilities == null || definition.requiredCapabilities.Length == 0)
                Add(issues, "CAPABILITY_REQUIRED", "requiredCapabilities", "At least one capability is required.");
            else
            {
                var seen = new HashSet<string>(StringComparer.Ordinal);
                foreach (string capability in definition.requiredCapabilities)
                {
                    if (!seen.Add(capability ?? "") || !Identifier.IsMatch(capability ?? "") ||
                        !HostCapabilityRegistry.Contains(capability, definition.minHostApiVersion) ||
                        !host.SupportsCapability(capability))
                        Add(issues, "CAPABILITY_UNAVAILABLE", "requiredCapabilities", "Unknown, duplicate or unavailable capability: " + capability);
                }
            }
            return issues;
        }

        private static void ValidateRoots(string[] roots, string field, string duplicateCode,
            List<AuthoringIssue> issues, Func<string, bool> valid)
        {
            if (roots == null || roots.Length == 0)
            {
                Add(issues, "ROOT_REQUIRED", field, "At least one root is required.");
                return;
            }
            var seen = new HashSet<string>(StringComparer.Ordinal);
            foreach (string root in roots)
            {
                if (!valid(root)) Add(issues, "INVALID_ROOT", field, "Invalid root: " + root);
                if (!seen.Add(root ?? "")) Add(issues, duplicateCode, field, "Duplicate root: " + root);
            }
        }

        private static bool SafeDataPath(string path)
        {
            return path != null && path.StartsWith("data/", StringComparison.Ordinal) && SafePath(path);
        }

        private static bool SafePath(string path)
        {
            if (string.IsNullOrWhiteSpace(path) || path.Contains("\\") || path.Contains(":")) return false;
            foreach (string part in path.Split('/'))
                if (part.Length == 0 || part == "." || part == "..") return false;
            return true;
        }

        private static void Add(List<AuthoringIssue> issues, string code, string path, string message)
        {
            issues.Add(new AuthoringIssue(code, path, message));
        }
    }
}
