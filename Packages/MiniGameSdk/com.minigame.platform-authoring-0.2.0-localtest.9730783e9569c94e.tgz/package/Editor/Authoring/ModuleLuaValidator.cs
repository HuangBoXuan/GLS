using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using XLua;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public static class ModuleLuaValidator
    {
        private static readonly Regex LiteralRequire = new Regex(
            "\\brequire\\s*\\(\\s*['\"]([^'\"]+)['\"]", RegexOptions.CultureInvariant);
        private static readonly Regex GlobalAccess = new Regex(
            "\\b_G\\s*(?:\\.|\\[)", RegexOptions.CultureInvariant);
        private static readonly Regex LoadedWrite = new Regex(
            "\\bpackage\\s*\\.\\s*loaded\\s*\\[\\s*['\"]([^'\"]+)['\"]\\s*\\]\\s*=",
            RegexOptions.CultureInvariant);

        public static IReadOnlyList<AuthoringIssue> Validate(ModuleDefinition definition, string sourceDirectory)
        {
            if (definition == null) throw new ArgumentNullException(nameof(definition));
            if (string.IsNullOrWhiteSpace(sourceDirectory)) throw new ArgumentException("Source is required.", nameof(sourceDirectory));
            var issues = new List<AuthoringIssue>();
            string root = Path.GetFullPath(sourceDirectory);
            string luaRoot = Path.Combine(root, definition.luaRoot.Replace('/', Path.DirectorySeparatorChar));
            if (!Directory.Exists(luaRoot))
            {
                issues.Add(new AuthoringIssue("LUA_ROOT_MISSING", definition.luaRoot, "Lua root does not exist."));
                return issues;
            }

            using (var environment = new LuaEnv())
            {
                foreach (string path in Directory.EnumerateFiles(luaRoot, "*.lua", SearchOption.AllDirectories))
                {
                    string relative = path.Substring(root.Length).TrimStart(Path.DirectorySeparatorChar).Replace('\\', '/');
                    string source = File.ReadAllText(path);
                    environment.Global.Set("__module_source", source);
                    try
                    {
                        object[] result = environment.DoString("return load(__module_source)", relative);
                        if (result.Length == 0 || result[0] == null)
                            issues.Add(new AuthoringIssue("LUA_SYNTAX", relative, "Lua source does not compile."));
                        if (result.Length > 0 && result[0] is LuaFunction function) function.Dispose();
                    }
                    catch (Exception exception)
                    {
                        issues.Add(new AuthoringIssue("LUA_SYNTAX", relative, exception.Message));
                    }
                    foreach (Match match in LiteralRequire.Matches(source))
                    {
                        string name = match.Groups[1].Value;
                        if (!name.StartsWith("games." + definition.gameId + ".", StringComparison.Ordinal) &&
                            !name.StartsWith("sdk.", StringComparison.Ordinal))
                            issues.Add(new AuthoringIssue("FOREIGN_REQUIRE", relative, "Lua require is outside this game: " + name));
                    }
                    if (GlobalAccess.IsMatch(source))
                        issues.Add(new AuthoringIssue("GLOBAL_WRITE", relative, "Direct _G access is forbidden in game modules."));
                    foreach (Match match in LoadedWrite.Matches(source))
                    {
                        string name = match.Groups[1].Value;
                        if (!name.StartsWith("games." + definition.gameId + ".", StringComparison.Ordinal))
                            issues.Add(new AuthoringIssue("FOREIGN_PACKAGE_LOADED", relative,
                                "Cannot modify another module's package.loaded entry: " + name));
                    }
                }
            }
            return issues;
        }
    }
}
