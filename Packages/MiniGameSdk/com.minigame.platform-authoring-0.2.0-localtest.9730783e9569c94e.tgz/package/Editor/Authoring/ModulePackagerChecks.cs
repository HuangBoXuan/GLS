using System;
using System.IO;
using System.Text;
using MiniGamePlatform.HotUpdate;
using UnityEditor;
using UnityEngine;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public static class ModulePackagerChecks
    {
        [MenuItem("MiniGame Platform/SDK/Run Module Packager Checks")]
        public static void Run()
        {
            string root = Path.Combine(Path.GetTempPath(), "MiniGameModuleChecks-" + Guid.NewGuid().ToString("N"));
            string source = Path.Combine(root, "source");
            string output = Path.Combine(root, "output");
            Directory.CreateDirectory(Path.Combine(source, "games", "arrow"));
            Directory.CreateDirectory(Path.Combine(root, "Assets", "Plugins", "Max"));
            try
            {
                string lua = Path.Combine(source, "games", "arrow", "main.lua");
                File.WriteAllText(lua, "local M = {}\nfunction M.enter(host) end\nfunction M.exit() end\nreturn M\n");
                File.WriteAllBytes(Path.Combine(source, "arrow.bundle"), Encoding.UTF8.GetBytes("test bundle bytes"));
                File.WriteAllText(Path.Combine(root, "Assets", "Plugins", "Max", "StandaloneAds.cs"), "// outside source");
                ModuleDefinition definition = Definition();

                foreach (string file in new[] { "helper.dll", "game.cs", "lib.so", "AdUnitIds.json", "extra.unknown" })
                {
                    string path = Path.Combine(source, file);
                    File.WriteAllText(path, "forbidden");
                    ExpectPackagingIssue(() => ModulePackager.Pack(definition, source, output), "FORBIDDEN_MODULE_FILE");
                    File.Delete(path);
                }
                AssertHasLuaIssue(definition, source, lua, "function M.enter(", "LUA_SYNTAX");
                AssertHasLuaIssue(definition, source, lua, "require('games.garden.main')", "FOREIGN_REQUIRE");
                AssertHasLuaIssue(definition, source, lua, "_G.foo = 1", "GLOBAL_WRITE");
                AssertHasLuaIssue(definition, source, lua, "package.loaded['games.garden.main'] = nil", "FOREIGN_PACKAGE_LOADED");
                File.WriteAllText(lua, "local M = {}\nfunction M.enter(host) end\nreturn M\n");

                string artifact = ModulePackager.Pack(definition, source, output);
                Assert(Directory.Exists(artifact), "Module artifact was not created.");
                string manifestPath = Path.Combine(artifact, "manifest.json");
                ModuleManifest manifest = ModuleManifest.Parse(File.ReadAllText(manifestPath));
                Assert(manifest.runtimeType == "unity_lua", "Runtime type was not pinned.");
                Assert(manifest.files.Length == 2, "Unexpected module file count.");
                byte[] original = File.ReadAllBytes(manifestPath);
                File.WriteAllText(lua, "local M = {}\nfunction M.enter(host) host:ShowMessage('changed') end\nreturn M\n");
                ExpectPackagingIssue(() => ModulePackager.Pack(definition, source, output), "IMMUTABLE_VERSION_EXISTS");
                Assert(ByteEqual(original, File.ReadAllBytes(manifestPath)), "Existing immutable manifest was changed.");

                string manifestJson = File.ReadAllText(manifestPath);
                try
                {
                    ModuleManifest.Parse(manifestJson.Replace("games/arrow/main.lua", "games/arrow/game.dll"));
                    throw new Exception("Installer accepted a DLL in the manifest.");
                }
                catch (InvalidDataException) { }
                Debug.Log("Module packager checks passed.");
            }
            finally
            {
                string expectedPrefix = Path.Combine(Path.GetTempPath(), "MiniGameModuleChecks-");
                if (!root.StartsWith(expectedPrefix, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("Temporary test root escaped its expected prefix.");
                if (Directory.Exists(root)) Directory.Delete(root, true);
            }
        }

        private static ModuleDefinition Definition()
        {
            return ModuleDefinition.Load("{\"gameId\":\"arrow\",\"moduleVersion\":\"v1\",\"runtimeType\":\"unity_lua\"," +
                "\"entry\":\"games.arrow.main\",\"minHostApiVersion\":1,\"requiredCapabilities\":[\"lua\",\"assetbundle\"]," +
                "\"luaRoot\":\"games/arrow\",\"dataRoots\":[\"data/arrow\"],\"assetRoots\":[\"Assets/Arrow/Board.prefab\"]," +
                "\"ruleVersion\":\"r1\",\"saveSchemaVersion\":\"s1\",\"levelMapPath\":\"data/arrow/levels.json\",\"platform\":\"android\"}");
        }

        private static void AssertHasLuaIssue(ModuleDefinition definition, string source, string lua, string text, string code)
        {
            File.WriteAllText(lua, text);
            foreach (AuthoringIssue issue in ModuleLuaValidator.Validate(definition, source))
                if (issue.Code == code && issue.Path.EndsWith("main.lua", StringComparison.Ordinal)) return;
            throw new Exception("Expected Lua issue was missing: " + code);
        }

        private static void ExpectPackagingIssue(Action action, string code)
        {
            try { action(); }
            catch (ModulePackagingException exception) when (exception.Code == code) { return; }
            throw new Exception("Expected packaging issue was missing: " + code);
        }

        private static bool ByteEqual(byte[] a, byte[] b)
        {
            if (a.Length != b.Length) return false;
            for (int i = 0; i < a.Length; i++) if (a[i] != b[i]) return false;
            return true;
        }

        private static void Assert(bool value, string message)
        {
            if (!value) throw new Exception(message);
        }
    }
}
