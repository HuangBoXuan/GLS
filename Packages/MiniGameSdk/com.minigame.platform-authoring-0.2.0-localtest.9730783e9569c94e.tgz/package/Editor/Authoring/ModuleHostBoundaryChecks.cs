using System;
using System.IO;
using System.Security.Cryptography;
using System.Reflection;
using System.Text;
using MiniGamePlatform.HotUpdate.Security;
using MiniGamePlatform.HotUpdate;
using UnityEditor;
using UnityEngine;

namespace MiniGamePlatform.SDK.Editor.Authoring
{
    public static class ModuleHostBoundaryChecks
    {
        [MenuItem("MiniGame Platform/Run Module Host Boundary Checks")]
        public static void Run()
        {
            RunLifecycle();
            RunData();
            RunProtectedData();
            Debug.Log("Module host boundary checks passed.");
        }

        public static void RunWithProtectionRegression()
        {
            Run();
            MiniGamePlatform.SDK.EditorChecks.ModuleProtectionChecks.RunRegression();
        }

        public static void RunProtectedData()
        {
            string root = Path.Combine(Path.GetTempPath(), "ModuleProtectedData-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(Path.Combine(root, "games/hostcheck"));
            Directory.CreateDirectory(Path.Combine(root, "data/hostcheck"));
            var keys = new TestKeys();
            try
            {
                var manifest = new ModuleManifest
                {
                    formatVersion = 1, gameId = "hostcheck", version = "v1", runtimeType = "unity_lua",
                    entry = "games.hostcheck.main", minHostApiVersion = 2, platform = "any", unityVersion = "",
                    requiredCapabilities = new[] { "lua", "data_text", "protected_content" },
                    contentEncryption = "wpc1", contentKeyId = "test_v1"
                };
                void Write(string path, byte[] plain, bool compress = false)
                {
                    byte[] stored = compress ? ModuleProtectedEnvelope.Seal(plain, keys.Bytes,
                        "module/v1/hostcheck/v1/test_v1/" + path, true) : ModuleContentProtection.Seal(manifest, path, plain, keys.Bytes);
                    File.WriteAllBytes(Path.Combine(root, path), stored);
                }
                Write("games/hostcheck/main.lua", Encoding.UTF8.GetBytes(
                    "return {enter=function(host) host:ShowMessage(host:ReadDataText('data/hostcheck/levels.json')) end}"));
                Write("data/hostcheck/levels.json", Encoding.UTF8.GetBytes("{\"protected\":true}"));
                Write("data/hostcheck/compressed.txt", new byte[ModuleAssetScope.MaxDataTextBytes + 1], true);
                Write("data/hostcheck/bad.txt", new byte[] { 0xc3, 0x28 });
                manifest.files = new[] { FileEntry(root, "games/hostcheck/main.lua"), FileEntry(root, "data/hostcheck/levels.json"),
                    FileEntry(root, "data/hostcheck/compressed.txt"), FileEntry(root, "data/hostcheck/bad.txt") };
                using var assets = new ModuleAssetScope(manifest, root, keys);
                using var bridge = new GameHostBridge(_ => { }, assets, "hostcheck", null);
                Check(bridge.ReadDataText("data/hostcheck/levels.json") == "{\"protected\":true}", "Protected data bridge failed.");
                using (var runner = new LuaGameRunner(keys))
                {
                    string seen = null;
                    runner.Enter(manifest, root, value => seen = value);
                    Check(seen == "{\"protected\":true}", "Protected Lua data bridge failed.");
                }
                Reject<InvalidDataException>(() => bridge.ReadDataText("data/other/levels.json"), "Protected cross-game read accepted.");
                Reject<InvalidDataException>(() => bridge.ReadDataText("data/hostcheck/../levels.json"), "Protected traversal accepted.");
                Reject<CryptographicException>(() => bridge.ReadDataText("data/hostcheck/compressed.txt"), "Oversized decompression accepted.");
                Reject<DecoderFallbackException>(() => bridge.ReadDataText("data/hostcheck/bad.txt"), "Encrypted malformed UTF-8 accepted.");
                keys.Available = false;
                Reject<CryptographicException>(() => bridge.ReadDataText("data/hostcheck/levels.json"), "Read with missing key accepted.");
                Reject<CryptographicException>(() => new ModuleAssetScope(manifest, root, keys), "Missing key accepted at scope creation.");
                keys.Available = true;
                keys.Bytes[0] ^= 1;
                Reject<CryptographicException>(() => bridge.ReadDataText("data/hostcheck/levels.json"), "Wrong key accepted.");
                keys.Bytes[0] ^= 1;
                string dataPath = Path.Combine(root, "data/hostcheck/levels.json");
                byte[] tampered = File.ReadAllBytes(dataPath);
                tampered[tampered.Length - 1] ^= 1;
                File.WriteAllBytes(dataPath, tampered);
                Reject<CryptographicException>(() => bridge.ReadDataText("data/hostcheck/levels.json"), "Ciphertext hash tamper accepted.");
                manifest.files[1] = FileEntry(root, "data/hostcheck/levels.json");
                Reject<CryptographicException>(() => bridge.ReadDataText("data/hostcheck/levels.json"), "GCM tag tamper accepted with matching hash.");
                bridge.Dispose();
                Reject<ObjectDisposedException>(() => bridge.ReadDataText("data/hostcheck/levels.json"), "Exited protected bridge still reads.");
                Debug.Log("Protected data boundary regression passed: Lua execution, compression budget, UTF-8, key absence/revocation, tamper and disposal.");
            }
            finally { Array.Clear(keys.Bytes, 0, keys.Bytes.Length); Directory.Delete(root, true); }
        }

        private sealed class TestKeys : IModuleContentKeyProvider
        {
            public readonly byte[] Bytes = new byte[32];
            public bool Available = true;
            public TestKeys() { using var rng = RandomNumberGenerator.Create(); rng.GetBytes(Bytes); }
            public bool CopyKey(string gameId, string keyId, byte[] destination)
            {
                if (!Available || gameId != "hostcheck" || keyId != "test_v1") return false;
                Array.Copy(Bytes, destination, Bytes.Length);
                return true;
            }
        }

        public static void RunData()
        {
            var method = typeof(GameHostBridge).GetMethod("ReadDataText", new[] { typeof(string) });
            Check(method != null && method.ReturnType == typeof(string), "ReadDataText(string) is not exposed to Lua.");
            string Read(GameHostBridge bridge, string path)
            {
                try { return (string)method.Invoke(bridge, new object[] { path }); }
                catch (TargetInvocationException exception) { throw exception.InnerException; }
            }
            string root = Path.Combine(Path.GetTempPath(), "ModuleDataBoundary-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(Path.Combine(root, "games/hostcheck"));
            Directory.CreateDirectory(Path.Combine(root, "data/hostcheck"));
            try
            {
                File.WriteAllText(Path.Combine(root, "games/hostcheck/main.lua"),
                    "return { enter=function(host) host:ShowMessage(host:ReadDataText('data/hostcheck/levels.json')) end }");
                File.WriteAllText(Path.Combine(root, "data/hostcheck/levels.json"), "{\"name\":\"花园\"}", new UTF8Encoding(false));
                File.WriteAllText(Path.Combine(root, "data/hostcheck/table.csv"), "id,name\n1,花园", new UTF8Encoding(false));
                File.WriteAllBytes(Path.Combine(root, "data/hostcheck/bad.txt"), new byte[] { 0xc3, 0x28 });
                File.WriteAllBytes(Path.Combine(root, "data/hostcheck/large.txt"), new byte[4 * 1024 * 1024 + 1]);
                File.WriteAllBytes(Path.Combine(root, "data/hostcheck/bom.txt"), new byte[] { 0xef, 0xbb, 0xbf, 0x61 });
                var manifest = Manifest(root);
                manifest.minHostApiVersion = 2;
                manifest.requiredCapabilities = new[] { "lua", "data_text" };
                manifest.files = new[] { manifest.files[0], FileEntry(root, "data/hostcheck/levels.json"),
                    FileEntry(root, "data/hostcheck/table.csv"), FileEntry(root, "data/hostcheck/bad.txt"),
                    FileEntry(root, "data/hostcheck/large.txt"), FileEntry(root, "data/hostcheck/bom.txt") };
                using var assets = new ModuleAssetScope(manifest, root);
                using var bridge = new GameHostBridge(_ => { }, assets, "hostcheck", null);
                using (var wrongIdentity = new GameHostBridge(_ => { }, assets, "other", null))
                    Reject<InvalidOperationException>(() => Read(wrongIdentity, "data/hostcheck/levels.json"), "Bridge identity disagrees with its data scope.");
                Check(Read(bridge, "data/hostcheck/levels.json") == "{\"name\":\"花园\"}", "UTF-8 JSON read failed.");
                Check(Read(bridge, "data/hostcheck/table.csv") == "id,name\n1,花园", "CSV read failed.");
                Check(Read(bridge, "data/hostcheck/bom.txt") == "a", "UTF-8 BOM was not stripped.");
                foreach (string invalid in new[] { null, "", "../private.json", "/data/hostcheck/levels.json",
                    "data/hostcheck/../other/levels.json", "data/other/levels.json", "data/hostcheck2/levels.json",
                    "data\\hostcheck\\levels.json", "data/hostcheck/levels.json:stream", "games/hostcheck/main.lua",
                    "data/hostcheck/missing.json", "data/hostcheck/image.png" })
                    Reject<InvalidDataException>(() => Read(bridge, invalid), "Invalid data path accepted: " + invalid);
                Reject<DecoderFallbackException>(() => Read(bridge, "data/hostcheck/bad.txt"), "Malformed UTF-8 accepted.");
                Reject<InvalidDataException>(() => Read(bridge, "data/hostcheck/large.txt"), "Oversized data accepted.");
                Check(!new HostProfile(1, "any", "", new[] { "lua", "data_text" }).Supports(manifest, out _), "Old host accepted data_text.");
                Check(HostProfile.Current.Supports(manifest, out _), "Current host did not advertise data_text.");
                using (var runner = new LuaGameRunner())
                {
                    string seen = null;
                    runner.Enter(manifest, root, value => seen = value);
                    Check(seen == "{\"name\":\"花园\"}", "Lua did not receive the bounded data text.");
                }
                manifest.requiredCapabilities = new[] { "lua" };
                Reject<InvalidDataException>(() => Read(bridge, "data/hostcheck/levels.json"), "Undeclared data_text capability accepted.");
                manifest.requiredCapabilities = new[] { "lua", "data_text" };
                manifest.minHostApiVersion = 1;
                Check(!HostProfile.Current.Supports(manifest, out _), "Host accepted an underdeclared capability API.");
                Reject<InvalidDataException>(() => Read(bridge, "data/hostcheck/levels.json"), "Underdeclared host API accepted.");
                manifest.minHostApiVersion = 2;
                File.WriteAllText(Path.Combine(root, "data/hostcheck/levels.json"), "{\"name\":\"篡改\"}", new UTF8Encoding(false));
                Reject<CryptographicException>(() => Read(bridge, "data/hostcheck/levels.json"), "Tampered data accepted.");
                assets.Dispose();
                Reject<ObjectDisposedException>(() => Read(bridge, "data/hostcheck/table.csv"), "Disposed asset scope still reads data.");
                bridge.Dispose();
                Reject<ObjectDisposedException>(() => Read(bridge, "data/hostcheck/table.csv"), "Disposed bridge still reads data.");
                Debug.Log("Module data boundary regression passed: Lua, UTF-8, scope, capability, size, tamper and disposal.");
            }
            finally { Directory.Delete(root, true); }
        }

        public static void RunLifecycle()
        {
            string root = Path.Combine(Path.GetTempPath(), "ModuleHostBoundary-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(Path.Combine(root, "games/hostcheck"));
            try
            {
                string path = Path.Combine(root, "games/hostcheck/main.lua");
                foreach (string phase in new[] { "update", "pause", "resume" })
                {
                    File.WriteAllText(path, "local M={} function M.enter(host) end function M." + phase +
                        "() error('primary lifecycle failure') end function M.exit() error('cleanup failure') end return M");
                    using var runner = new LuaGameRunner();
                    runner.Enter(Manifest(root), root, _ => { });
                    if (phase == "resume") runner.Pause();
                    ModuleRunException observed = null;
                    try
                    {
                        if (phase == "update") runner.Tick();
                        else if (phase == "pause") runner.Pause();
                        else runner.Resume();
                    }
                    catch (ModuleRunException exception) { observed = exception; }
                    Check(observed != null && observed.Code == phase.ToUpperInvariant() + "_FAILED" && observed.Phase == phase,
                        "Missing structured failure for " + phase);
                    Check(observed.InnerException.Message.Contains("primary lifecycle failure"), "Cleanup hid the primary failure.");
                    Check(runner.LastError == observed && runner.State == GameRunState.Empty &&
                        runner.CurrentGameId == null && runner.SuccessfulTicks == 0, "Failed module retained running state.");
                    Check(GameObject.Find("MiniGame Module Root") == null, "Failed module leaked its scene root in Editor.");
                    runner.Exit(); runner.Tick(); runner.Pause(); runner.Resume();
                    File.WriteAllText(path, "return {enter=function(host) end, update=function(dt) end}");
                    runner.Enter(Manifest(root), root, _ => { });
                    runner.Tick();
                    Check(runner.LastError == null && runner.State == GameRunState.Running && runner.SuccessfulTicks == 1,
                        "Runner could not re-enter after failure.");
                    runner.Exit();
                }
                Debug.Log("Module lifecycle failure regression passed: update, pause, resume, cleanup and re-entry.");
            }
            finally { Directory.Delete(root, true); }
        }

        private static ModuleManifest Manifest(string root)
        {
            return new ModuleManifest
            {
                formatVersion = 1, gameId = "hostcheck", version = "v1", runtimeType = "unity_lua",
                entry = "games.hostcheck.main", minHostApiVersion = 1, platform = "any", unityVersion = "",
                requiredCapabilities = new[] { "lua" },
                files = new[] { FileEntry(root, "games/hostcheck/main.lua") }
            };
        }

        private static ModuleFile FileEntry(string root, string relative)
        {
            byte[] bytes = File.ReadAllBytes(Path.Combine(root, relative));
            using var sha = SHA256.Create();
            return new ModuleFile { path = relative, size = bytes.Length,
                sha256 = BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant() };
        }

        private static void Check(bool condition, string message)
        { if (!condition) throw new Exception(message); }

        private static void Reject<T>(Action action, string message) where T : Exception
        { try { action(); } catch (T) { return; } throw new Exception(message); }
    }
}
