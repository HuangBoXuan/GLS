using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using MiniGamePlatform.HotUpdate;
using UnityEditor;
using UnityEngine;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public static class SignedCatalogChecks
    {
        [MenuItem("MiniGame Platform/SDK/Run Signed Catalog Checks")]
        public static void Run()
        {
            using (RSA rsa = new RSACryptoServiceProvider(2048))
            {
                RSAParameters publicKey = rsa.ExportParameters(false);
                var key = new CatalogTrustKey("test_key", Convert.ToBase64String(publicKey.Modulus),
                    Convert.ToBase64String(publicKey.Exponent));
                byte[] payload = Encoding.UTF8.GetBytes(Payload("minigame_platform", "v1"));
                byte[] signed = Sign(rsa, payload, "test_key");
                VerifiedProductCatalog accepted = CatalogSignatureVerifier.Verify(signed, key, "minigame_platform");
                if (accepted.ProductId != "minigame_platform" || accepted.CatalogVersion != 2 ||
                    accepted.Releases.Count != 2) throw new Exception("Valid signed catalog was not accepted.");
                Reject(() => CatalogSignatureVerifier.Verify(Sign(rsa, Encoding.UTF8.GetBytes(Payload("other_product", "v1")),
                    "test_key"), key, "minigame_platform"));
                Reject(() => CatalogSignatureVerifier.Verify(Sign(rsa, Encoding.UTF8.GetBytes(Payload("minigame_platform", "v1")),
                    "wrong_key"), key, "minigame_platform"));
                byte[] changed = Encoding.UTF8.GetBytes(Payload("minigame_platform", "v2"));
                var tampered = new SignedCatalogEnvelope { keyId = "test_key", payloadBase64 = Convert.ToBase64String(changed),
                    signatureBase64 = Convert.ToBase64String(rsa.SignData(payload, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1)) };
                Reject(() => CatalogSignatureVerifier.Verify(Encoding.UTF8.GetBytes(JsonUtility.ToJson(tampered)), key,
                    "minigame_platform"));
                string duplicate = Payload("minigame_platform", "v1")
                    .Replace("\"gameId\":\"sample_new\"", "\"gameId\":\"sample2d\"")
                    .Replace("sample_new/v1/manifest.json", "sample2d/v1/manifest.json");
                Reject(() => CatalogSignatureVerifier.Verify(Sign(rsa, Encoding.UTF8.GetBytes(duplicate), "test_key"),
                    key, "minigame_platform"));
                Reject(() => CatalogSignatureVerifier.Verify(Sign(rsa, Encoding.UTF8.GetBytes(
                    "{\"catalogVersion\":2,\"productId\":\"minigame_platform\",\"releases\":[]}"), "test_key"),
                    key, "minigame_platform"));
                Debug.Log("Signed catalog checks passed.");
            }
        }

        private static byte[] Sign(RSA rsa, byte[] payload, string keyId)
        {
            var envelope = new SignedCatalogEnvelope { keyId = keyId,
                payloadBase64 = Convert.ToBase64String(payload),
                signatureBase64 = Convert.ToBase64String(rsa.SignData(payload, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1)) };
            return Encoding.UTF8.GetBytes(JsonUtility.ToJson(envelope));
        }

        private static string Payload(string productId, string newVersion)
        {
            string first = "{\"gameId\":\"sample2d\",\"version\":\"v1\",\"runtimeType\":\"unity_lua\",\"manifestPath\":\"sample2d/v1/manifest.json\",\"manifestSha256\":\"" + new string('a', 64) + "\",\"minHostApiVersion\":1,\"requiredCapabilities\":[\"lua\"],\"platform\":\"any\",\"unityVersion\":\"\",\"enabled\":true}";
            string second = "{\"gameId\":\"sample_new\",\"version\":\"" + newVersion + "\",\"runtimeType\":\"unity_lua\",\"manifestPath\":\"sample_new/" + newVersion + "/manifest.json\",\"manifestSha256\":\"" + new string('b', 64) + "\",\"minHostApiVersion\":1,\"requiredCapabilities\":[\"lua\"],\"platform\":\"any\",\"unityVersion\":\"\",\"enabled\":true}";
            return "{\"formatVersion\":2,\"catalogVersion\":2,\"productId\":\"" + productId + "\",\"releases\":[" + first + "," + second + "]}";
        }

        private static void Reject(Action action)
        {
            try { action(); }
            catch (InvalidDataException) { return; }
            throw new Exception("Invalid signed catalog was accepted.");
        }
    }
}
