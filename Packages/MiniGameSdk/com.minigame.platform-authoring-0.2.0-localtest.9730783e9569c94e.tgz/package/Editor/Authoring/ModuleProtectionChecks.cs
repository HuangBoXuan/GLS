using System;
using System.Reflection;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.IO;
using System.Diagnostics;
using System.Runtime.InteropServices;
using MiniGamePlatform.HotUpdate;
using UnityEditor;
using XLua;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public static class ModuleProtectionChecks
    {
        [MenuItem("MiniGame Platform/SDK/Run Module Protection Checks")]
        public static void Run()
        {
            var type = typeof(LuaGameRunner).Assembly.GetType("MiniGamePlatform.HotUpdate.ModuleContentProtection");
            if (type == null) throw new Exception("Protected module codec/key binding is missing.");
            var manifest = ModuleManifest.Parse("{\"formatVersion\":1,\"gameId\":\"garden\",\"version\":\"v1\",\"runtimeType\":\"unity_lua\",\"entry\":\"games.garden.main\",\"minHostApiVersion\":1,\"platform\":\"any\",\"requiredCapabilities\":[\"lua\",\"protected_content\"],\"contentEncryption\":\"wpc1\",\"contentKeyId\":\"test_v1\",\"files\":[{\"path\":\"games/garden/main.lua\",\"sha256\":\"" + new string('a',64) + "\",\"size\":100}]}");
            var key = Enumerable.Range(1, 32).Select(i => (byte)i).ToArray();
            var plain = Encoding.UTF8.GetBytes("return {enter=function(host) end}");
            const string path = "games/garden/main.lua";
            byte[] Call(string method, ModuleManifest context, byte[] bytes, byte[] material)
            {
                try { return (byte[])type.GetMethod(method).Invoke(null, new object[]{ context, path, bytes, material }); }
                catch (TargetInvocationException e) { throw e.InnerException; }
            }
            var encrypted = Call("Seal", manifest, plain, key);
            if (!Call("Open", manifest, encrypted, key).SequenceEqual(plain)) throw new Exception("Protected round trip failed.");
            if (encrypted.SequenceEqual(Call("Seal", manifest, plain, key))) throw new Exception("Nonce was reused.");
            void Reject(Action action)
            { try { action(); } catch (CryptographicException) { return; } throw new Exception("Unauthenticated content accepted."); }
            Reject(() => Call("Open", manifest, encrypted, new byte[32]));
            encrypted[encrypted.Length - 1] ^= 1;
            Reject(() => Call("Open", manifest, encrypted, key));
            encrypted[encrypted.Length - 1] ^= 1;
            manifest.version = "v2";
            Reject(() => Call("Open", manifest, encrypted, key));
            manifest.version = "v1";
            PipelineChecks(key);
            UnityEngine.Debug.Log("Module protection checks passed: envelope, packaging, Lua execution, key isolation and native host selector.");
        }

        public static void RunRegression()
        {
            Run();
            ModuleDefinitionChecks.Run();
            ModulePackagerChecks.Run();
            SignedCatalogChecks.Run();
            TrustedCatalogChecks.Run();
            ModuleReleaseGateChecks.Run();
            UnityEngine.Debug.Log("Protected module integration regression passed (6 suites).");
        }

        private static void PipelineChecks(byte[] key)
        {
            string root = Path.Combine(Path.GetTempPath(), "ModuleProtectionChecks-" + Guid.NewGuid().ToString("N"));
            string source = Path.Combine(root, "source");
            string output = Path.Combine(root, "output");
            string privateFile = Path.Combine(root, "private.json");
            string previous = Environment.GetEnvironmentVariable(ModuleBuildKeyRing.EnvironmentName);
            Directory.CreateDirectory(Path.Combine(source, "games/garden"));
            Directory.CreateDirectory(Path.Combine(source, "data/garden"));
            try
            {
                string document = "{\"version\":1,\"entries\":[{\"gameId\":\"garden\",\"keyId\":\"test_v1\",\"keyBase64\":\"" + Convert.ToBase64String(key) + "\"}]}";
                File.WriteAllText(privateFile, document);
                const string lua = "return { enter=function(host) end, answer=42 }";
                File.WriteAllText(Path.Combine(source, "games/garden/main.lua"), lua);
                File.WriteAllText(Path.Combine(source, "data/garden/levels.json"), "{\"level\":1}");
                var definition = ModuleDefinition.Load("{\"gameId\":\"garden\",\"moduleVersion\":\"v1\",\"runtimeType\":\"unity_lua\",\"entry\":\"games.garden.main\",\"minHostApiVersion\":1,\"requiredCapabilities\":[\"lua\",\"protected_content\"],\"contentEncryption\":\"wpc1\",\"contentKeyId\":\"test_v1\",\"luaRoot\":\"games/garden\",\"dataRoots\":[\"data/garden\"],\"assetRoots\":[\"Assets/Fixture.prefab\"],\"ruleVersion\":\"r1\",\"saveSchemaVersion\":\"s9\",\"levelMapPath\":\"data/garden/levels.json\",\"platform\":\"any\"}");
                Environment.SetEnvironmentVariable(ModuleBuildKeyRing.EnvironmentName, privateFile);
                Check(!File.Exists(ModuleHostKeyBuild.GeneratedSource), "Existing host key source must not be overwritten by tests.");
                try
                {
                    ModuleHostKeyBuild.Prepare();
                    Check(File.Exists(ModuleHostKeyBuild.GeneratedSource), "Host build did not create the native source.");
                    Check(!File.ReadAllText(ModuleHostKeyBuild.GeneratedSource).Contains(Convert.ToBase64String(key)), "Host generator retained raw input encoding.");
                }
                finally { ModuleHostKeyBuild.CleanupGeneratedSource(); }
                Check(!File.Exists(ModuleHostKeyBuild.GeneratedSource) && !File.Exists(ModuleHostKeyBuild.GeneratedSource + ".meta"), "Generated private source was not cleaned.");
                string artifact = ModulePackager.Pack(definition, source, output);
                var manifest = ModuleManifest.Parse(File.ReadAllText(Path.Combine(artifact, "manifest.json")));
                Check(manifest.files.Length == 2 && ModuleInstaller.IsValid(manifest, artifact), "Ciphertext manifest verification failed.");
                Check(!new HostProfile(1, "any", UnityEngine.Application.unityVersion, new[] { "lua" }).Supports(manifest, out _), "Old host accepted protected content.");
                var invalid = UnityEngine.JsonUtility.ToJson(manifest).Replace("wpc1", "unknown");
                Reject<InvalidDataException>(() => ModuleManifest.Parse(invalid), "Unsupported encryption accepted.");
                using (var ring = ModuleBuildKeyRing.FromEnvironment())
                {
                    var reader = new ModuleContentReader(manifest, artifact, ring);
                    Check(Encoding.UTF8.GetString(reader.Read("games/garden/main.lua")) == lua, "Packaged Lua round trip failed.");
                    Check(Encoding.UTF8.GetString(reader.Read("data/garden/levels.json")) == "{\"level\":1}", "Packaged data round trip failed.");
                    using (var environment = new XLua.LuaEnv())
                    {
                        environment.AddLoader((ref string name, ModuleLuaBuffer buffer) =>
                        {
                            byte[] bytes = reader.Read(name.Replace('.', '/') + ".lua");
                            try { buffer.Copy(bytes); } finally { Array.Clear(bytes, 0, bytes.Length); }
                            return true;
                        });
                        Check(Convert.ToInt32(environment.DoString("return require('games.garden.main').answer")[0]) == 42, "Encrypted Lua was not executed.");
                    }
                    Reject<CryptographicException>(() => new ModuleContentReader(manifest, artifact), "Editor unexpectedly has a native production key.");
                    Reject<InvalidDataException>(() => reader.Read("../private.json"), "Traversal accepted.");
                    Reject<InvalidDataException>(() => reader.Read("data/garden/missing.json"), "Undeclared file accepted.");
                    byte[] encrypted = File.ReadAllBytes(Path.Combine(artifact, "games/garden/main.lua"));
                    Reject<CryptographicException>(() => ModuleContentProtection.Open(manifest, "games/garden/other.lua", encrypted, key), "Path binding missing.");
                    manifest.contentKeyId = "test_v2";
                    Reject<CryptographicException>(() => ModuleContentProtection.Open(manifest, "games/garden/main.lua", encrypted, key), "Key id binding missing.");
                    manifest.contentKeyId = "test_v1";
                    manifest.gameId = "other";
                    Reject<CryptographicException>(() => ModuleContentProtection.Open(manifest, "games/other/main.lua", encrypted, key), "Game binding missing.");
                    manifest.gameId = "garden";
                    NativeChecks(root, ring, key, manifest, artifact);
                    encrypted[encrypted.Length - 1] ^= 1;
                    File.WriteAllBytes(Path.Combine(artifact, "games/garden/main.lua"), encrypted);
                    Check(!ModuleInstaller.IsValid(manifest, artifact), "Installer accepted tampering.");
                    Reject<CryptographicException>(() => reader.Read("games/garden/main.lua"), "Reader accepted tampering.");
                }
                Reject<InvalidDataException>(() => ModuleBuildKeyRing.Load(privateFile, root), "Project-contained key accepted.");
                File.WriteAllText(privateFile, document.Replace("test_v1", "bad\\\"id"));
                Reject<InvalidDataException>(() => ModuleBuildKeyRing.FromEnvironment(), "Invalid selector accepted.");
                File.WriteAllText(privateFile, document);
                // This file has an ordinary allowed data filename: name filtering is insufficient.
                string misplaced = Path.Combine(source, "data/garden/settings.json");
                File.WriteAllText(misplaced, document);
                Environment.SetEnvironmentVariable(ModuleBuildKeyRing.EnvironmentName, misplaced);
                definition.moduleVersion = "v2";
                Reject<ModulePackagingException>(() => ModulePackager.Pack(definition, source, output), "Private key input was packaged as module data.");
                RejectPrivateBuildInput(() => AndroidModuleBuilder.Build(definition, source, output,
                    HostComponentInventory.FromCapabilities(definition.requiredCapabilities, Array.Empty<string>())));
                File.Delete(misplaced);
                misplaced = Path.Combine(output, "private.json");
                File.WriteAllText(misplaced, document);
                Environment.SetEnvironmentVariable(ModuleBuildKeyRing.EnvironmentName, misplaced);
                Reject<ModulePackagingException>(() => ModulePackager.Pack(definition, source, output), "Private key input was allowed in publication output.");
                RejectPrivateBuildInput(() => AndroidModuleBuilder.Build(definition, source, output,
                    HostComponentInventory.FromCapabilities(definition.requiredCapabilities, Array.Empty<string>())));
                File.Delete(misplaced);
                Environment.SetEnvironmentVariable(ModuleBuildKeyRing.EnvironmentName, null);
                definition.moduleVersion = "v3";
                Reject<ModulePackagingException>(() => ModulePackager.Pack(definition, source, output), "Protected packaging accepted a missing key.");
                definition.contentEncryption = null;
                definition.contentKeyId = null;
                definition.requiredCapabilities = new[] { "lua" };
                artifact = ModulePackager.Pack(definition, source, output);
                manifest = ModuleManifest.Parse(File.ReadAllText(Path.Combine(artifact, "manifest.json")));
                Check(Encoding.UTF8.GetString(new ModuleContentReader(manifest, artifact).Read("games/garden/main.lua")) == lua, "Legacy plaintext compatibility failed.");
            }
            finally
            {
                Environment.SetEnvironmentVariable(ModuleBuildKeyRing.EnvironmentName, previous);
                if (!root.StartsWith(Path.Combine(Path.GetTempPath(), "ModuleProtectionChecks-"), StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("Invalid temporary test root.");
                if (Directory.Exists(root)) Directory.Delete(root, true);
            }
        }

        [UnmanagedFunctionPointer(CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
        private delegate int KeyFunction(string game, string key, [Out] byte[] destination, int size);
        [DllImport("kernel32", CharSet = CharSet.Unicode, SetLastError = true)] private static extern IntPtr LoadLibrary(string name);
        [DllImport("kernel32", CharSet = CharSet.Ansi, ExactSpelling = true)] private static extern IntPtr GetProcAddress(IntPtr library, string name);
        [DllImport("kernel32")] private static extern bool FreeLibrary(IntPtr library);
        private sealed class NativeFixture : IModuleContentKeyProvider
        {
            public KeyFunction Function;
            public bool CopyKey(string gameId, string keyId, byte[] destination) => Function(gameId, keyId, destination, destination.Length) == 1;
        }

        private static void NativeChecks(string root, ModuleBuildKeyRing ring, byte[] expected, ModuleManifest manifest, string artifact)
        {
            if (UnityEngine.Application.platform != UnityEngine.RuntimePlatform.WindowsEditor)
                throw new PlatformNotSupportedException("Native fixture currently requires Windows Editor and bundled Android NDK.");
            string bin = Path.Combine(Path.GetDirectoryName(EditorApplication.applicationPath), "Data/PlaybackEngines/AndroidPlayer/NDK/toolchains/llvm/prebuilt/windows-x86_64/bin");
            File.WriteAllText(Path.Combine(root, "fixture.cpp"), ring.GenerateNativeSource());
            RunTool(Path.Combine(bin, "clang.exe"), "--target=x86_64-pc-windows-msvc -c fixture.cpp -o fixture.obj", root);
            RunTool(Path.Combine(bin, "ld.lld.exe"), "-flavor link /dll /noentry /nodefaultlib /export:mgp_module_key /out:fixture.dll fixture.obj", root);
            RunTool(Path.Combine(bin, "clang.exe"), "--target=aarch64-linux-android21 -c fixture.cpp -o arm64.o", root);
            RunTool(Path.Combine(bin, "clang.exe"), "--target=armv7a-linux-androideabi21 -c fixture.cpp -o armv7.o", root);
            IntPtr library = LoadLibrary(Path.Combine(root, "fixture.dll"));
            Check(library != IntPtr.Zero, "Cannot load compiled native fixture.");
            try
            {
                var function = Marshal.GetDelegateForFunctionPointer<KeyFunction>(GetProcAddress(library, "mgp_module_key"));
                var buffer = new byte[32];
                Check(function("garden", "test_v1", buffer, 32) == 1 && buffer.SequenceEqual(expected), "Native key selection failed.");
                Check(function("other", "test_v1", buffer, 32) == 0 && function("garden", "missing", buffer, 32) == 0 && function("garden", "test_v1", buffer, 31) == 0, "Native key boundary failed.");
                Check(new ModuleContentReader(manifest, artifact, new NativeFixture { Function = function }).Read("games/garden/main.lua").Length > 0, "Native-backed decryption failed.");
                Array.Clear(buffer, 0, buffer.Length);
            }
            finally { FreeLibrary(library); }
        }

        private static void RunTool(string executable, string arguments, string directory)
        {
            using var process = Process.Start(new ProcessStartInfo(executable, arguments) { WorkingDirectory = directory, UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true, RedirectStandardError = true });
            var stdout = process.StandardOutput.ReadToEndAsync();
            var stderr = process.StandardError.ReadToEndAsync();
            if (!process.WaitForExit(30000)) { process.Kill(); throw new Exception("Native fixture compiler timed out."); }
            // Never echo generated source or compiler excerpts: real generators handle private data.
            Check(process.ExitCode == 0, "Native fixture compilation failed: " + Path.GetFileName(executable));
        }

        private static void Check(bool condition, string message) { if (!condition) throw new Exception(message); }
        private static void RejectPrivateBuildInput(Action action)
        {
            try { action(); }
            catch (ModulePackagingException e) when (e.Code == "PRIVATE_KEY_IN_ARTIFACT_TREE") { return; }
            throw new Exception("Android build did not reject private input before staging/asset validation.");
        }
        private static void Reject<T>(Action action, string message) where T : Exception
        { try { action(); } catch (T) { return; } throw new Exception(message); }
    }
}
