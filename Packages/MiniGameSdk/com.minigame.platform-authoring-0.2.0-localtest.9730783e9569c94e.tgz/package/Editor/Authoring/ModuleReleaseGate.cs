using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using MiniGamePlatform.HotUpdate;
using UnityEngine;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public static class ModuleReleaseGate
    {
        public static ModuleGateReport Evaluate(ModuleBuildResult module, HostProfile oldest,
            HostProfile current, AndroidProductEvidence independent, AndroidProductEvidence hub)
        {
            if (module == null) throw new ArgumentNullException(nameof(module));
            if (oldest == null || current == null) throw new ArgumentNullException("Host profiles are required.");
            var reasons = new List<string>();
            var report = new ModuleGateReport
            {
                modulePath = module.ModulePath, moduleManifestSha256 = module.ManifestSha256,
                independent = independent, hub = hub, evaluatedAtUtc = DateTime.UtcNow.ToString("o")
            };
            string manifestPath = Path.Combine(module.ModulePath ?? "", "manifest.json");
            ModuleManifest manifest = null;
            if (!File.Exists(manifestPath) || !HashEquals(module.ManifestSha256, Hash(manifestPath)))
                reasons.Add("MODULE_MANIFEST_HASH_MISMATCH");
            else
            {
                try
                {
                    manifest = ModuleManifest.Parse(File.ReadAllText(manifestPath));
                    if (!ModuleInstaller.IsValid(manifest, module.ModulePath)) reasons.Add("MODULE_FILES_INVALID");
                }
                catch (Exception) { reasons.Add("MODULE_MANIFEST_INVALID"); }
            }
            if (manifest != null)
            {
                report.gameId = manifest.gameId;
                report.moduleVersion = manifest.version;
                if (!oldest.Supports(manifest, out _)) reasons.Add("OLDEST_HOST_INCOMPATIBLE");
                if (!current.Supports(manifest, out _)) reasons.Add("CURRENT_HOST_INCOMPATIBLE");
            }
            if (module.DependencyIssues == null || module.DependencyIssues.Count != 0)
                reasons.Add("ASSET_DEPENDENCIES_FAILED");
            report.previewPassed = reasons.Count == 0;
            if (independent == null || hub == null)
                reasons.Add("ANDROID_EVIDENCE_REQUIRED");
            else if (manifest != null)
            {
                CheckEvidence(independent, "INDEPENDENT", oldest, manifest, module.ManifestSha256, reasons);
                CheckEvidence(hub, "HUB", current, manifest, module.ManifestSha256, reasons);
                if (independent.productId == hub.productId || independent.applicationId == hub.applicationId ||
                    independent.apkSha256 == hub.apkSha256)
                    reasons.Add("PRODUCTS_NOT_DISTINCT");
                if (!hub.switchedAtoBtoA) reasons.Add("HUB_SWITCH_NOT_VERIFIED");
                report.sampleOnly = independent.settlementMode != "real_server" || hub.settlementMode != "real_server";
            }
            report.reasons = reasons.ToArray();
            report.publishable = report.previewPassed && reasons.Count == 0;
            return report;
        }

        public static void VerifyFromCommandLine()
        {
            string[] args = Environment.GetCommandLineArgs();
            string modulePath = RequiredArg(args, "-modulePath");
            string definitionPath = RequiredArg(args, "-moduleDefinition");
            string profilesPath = RequiredArg(args, "-hostProfiles");
            string independentPath = RequiredArg(args, "-independentEvidence");
            string hubPath = RequiredArg(args, "-hubEvidence");
            string reportPath = RequiredArg(args, "-gateReport");
            ModuleDefinition definition = ModuleDefinition.Load(File.ReadAllText(definitionPath));
            HostProfilesInput profiles = JsonUtility.FromJson<HostProfilesInput>(File.ReadAllText(profilesPath));
            if (profiles?.oldest == null || profiles.current == null)
                throw new InvalidDataException("Both host profiles are required.");
            var oldest = MakeHost(profiles.oldest);
            var current = MakeHost(profiles.current);
            var inventory = HostComponentInventory.FromCapabilities(profiles.oldest.capabilities,
                profiles.oldest.retainedShaders);
            var dependencies = new List<AuthoringIssue>(ModuleDefinitionValidator.Validate(definition, oldest));
            dependencies.AddRange(AssetDependencyValidator.Validate(definition, inventory));
            string manifestPath = Path.Combine(modulePath, "manifest.json");
            var build = new ModuleBuildResult(modulePath, File.Exists(manifestPath) ? Hash(manifestPath) : "", dependencies);
            var independent = JsonUtility.FromJson<AndroidProductEvidence>(File.ReadAllText(independentPath));
            var hub = JsonUtility.FromJson<AndroidProductEvidence>(File.ReadAllText(hubPath));
            ModuleGateReport report = Evaluate(build, oldest, current, independent, hub);
            Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(reportPath)));
            File.WriteAllText(reportPath, JsonUtility.ToJson(report, true));
            Debug.Log(report.publishable ? "MODULE_GATE_PUBLISHABLE " + report.gameId :
                "MODULE_GATE_REJECTED " + string.Join(",", report.reasons));
            if (!report.publishable) throw new InvalidDataException("Module release gate rejected: " + string.Join(",", report.reasons));
        }

        private static HostProfile MakeHost(HostProfileInput input)
        {
            if (input == null) throw new InvalidDataException("Host profile is missing.");
            return new HostProfile(input.apiVersion, input.platform, input.unityVersion, input.capabilities);
        }

        private static void CheckEvidence(AndroidProductEvidence evidence, string role, HostProfile host,
            ModuleManifest manifest, string moduleHash, List<string> reasons)
        {
            if (string.IsNullOrWhiteSpace(evidence.productId) || string.IsNullOrWhiteSpace(evidence.applicationId) ||
                string.IsNullOrWhiteSpace(evidence.androidBuildVersion) || string.IsNullOrWhiteSpace(evidence.sdkVersion) ||
                string.IsNullOrWhiteSpace(evidence.deviceId) || evidence.platform != "android" ||
                evidence.scriptingBackend != "IL2CPP" || evidence.architecture != "arm64" ||
                evidence.hostApiVersion != host.Version || evidence.unityVersion != host.UnityVersion ||
                evidence.capabilities == null || !manifest.requiredCapabilities.All(evidence.capabilities.Contains))
                reasons.Add(role + "_BUILD_METADATA_INVALID");
            if (!HashEquals(moduleHash, evidence.moduleManifestSha256)) reasons.Add(role + "_MODULE_HASH_MISMATCH");
            if (string.IsNullOrWhiteSpace(evidence.apkPath) || !File.Exists(evidence.apkPath) ||
                !HashEquals(evidence.apkSha256, Hash(evidence.apkPath)))
                reasons.Add(role + "_APK_HASH_MISMATCH");
            if (string.IsNullOrWhiteSpace(evidence.deviceLogPath) || !File.Exists(evidence.deviceLogPath) ||
                !HashEquals(evidence.deviceLogSha256, Hash(evidence.deviceLogPath)) ||
                !File.ReadAllText(evidence.deviceLogPath).Contains("ANDROID_GATE_PASS productId=" + evidence.productId +
                    " appId=" + evidence.applicationId + " manifest=" + moduleHash))
                reasons.Add(role + "_DEVICE_LOG_INVALID");
            if (!DateTime.TryParse(evidence.verifiedAtUtc, CultureInfo.InvariantCulture,
                    DateTimeStyles.AdjustToUniversal | DateTimeStyles.AssumeUniversal, out DateTime verified) ||
                verified.Kind != DateTimeKind.Utc || verified > DateTime.UtcNow.AddMinutes(5) ||
                verified < DateTime.UtcNow.AddDays(-30))
                reasons.Add(role + "_DEVICE_TIME_INVALID");
            if (!evidence.entered || !evidence.paused || !evidence.resumed || !evidence.exited || !evidence.reentered ||
                !evidence.missingScriptFree || !evidence.shaderAvailable || !evidence.downloadFailureRecovered)
                reasons.Add(role + "_DEVICE_CHECKS_INCOMPLETE");
            if (evidence.settlementMode != "contract_stub" && evidence.settlementMode != "real_server")
                reasons.Add(role + "_SETTLEMENT_UNVERIFIED");
        }

        private static bool HashEquals(string expected, string actual)
        {
            return !string.IsNullOrEmpty(expected) && !string.IsNullOrEmpty(actual) &&
                   expected.Length == 64 && string.Equals(expected, actual, StringComparison.OrdinalIgnoreCase);
        }

        private static string Hash(string path)
        {
            using (FileStream stream = File.OpenRead(path))
            using (SHA256 sha = SHA256.Create())
                return BitConverter.ToString(sha.ComputeHash(stream)).Replace("-", "").ToLowerInvariant();
        }

        private static string RequiredArg(string[] args, string name)
        {
            int index = Array.IndexOf(args, name);
            if (index < 0 || index + 1 >= args.Length || string.IsNullOrWhiteSpace(args[index + 1]))
                throw new ArgumentException("Missing command-line argument: " + name);
            return args[index + 1];
        }
    }
}
