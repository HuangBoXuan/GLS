using System;
using MiniGamePlatform.HotUpdate;
using MiniGamePlatform.Components;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public static class SdkNativeAdmissionChecks
    {
        public static void Run()
        {
            if (typeof(GameHostBridge).GetMethod("LoadAsset", new[] { typeof(string), typeof(string), typeof(Type) }) == null)
                throw new Exception("Missing module-scoped non-generic native LoadAsset entry.");
            if (typeof(GameHostBridge).Assembly.GetType("MiniGamePlatform.Components.ModulePointerRelay") == null)
                throw new Exception("Missing native pointer relay without drag interception.");
            var parent = new GameObject("RelayCheck", typeof(RectTransform), typeof(ScrollRect));
            try
            {
                var child = new GameObject("Button", typeof(RectTransform), typeof(Button), typeof(ModulePointerRelay));
                child.transform.SetParent(parent.transform, false);
                var relay = child.GetComponent<ModulePointerRelay>();
                if (ExecuteEvents.GetEventHandler<IDragHandler>(child) != parent)
                    throw new Exception("Relay intercepted parent ScrollRect drag.");
                int down = 0, up = 0, exit = 0, submit = 0, canceled = 0;
                relay.PointerDown.AddListener(e => down++); relay.PointerUp.AddListener(e => up++);
                relay.PointerExit.AddListener(e => exit++); relay.Submit.AddListener(e => submit++);
                relay.PointerCanceled.AddListener(id => { if (id != 12) throw new Exception("Canceled wrong finger."); canceled++; });
                var first = new PointerEventData(null) { pointerId = 11 };
                var second = new PointerEventData(null) { pointerId = 12 };
                relay.OnPointerDown(first); relay.OnPointerDown(first); relay.OnPointerDown(second);
                relay.OnPointerExit(first); relay.OnPointerUp(first); relay.OnSubmit(new BaseEventData(null));
                relay.enabled = false;
                // EditMode does not dispatch ordinary MonoBehaviour lifecycle messages.
                // Actual automatic OnDisable is exercised by the Play Mode/Android probe.
                typeof(ModulePointerRelay).GetMethod("OnDisable", System.Reflection.BindingFlags.NonPublic |
                    System.Reflection.BindingFlags.Instance).Invoke(relay, null);
                if (down != 2 || up != 1 || exit != 1 || submit != 1 || canceled != 1)
                    throw new Exception("Relay lost multi-pointer lifecycle events.");
                relay.enabled = true; relay.OnPointerUp(second);
                if (up != 1) throw new Exception("Stale press survived disable/re-enable.");
                Debug.Log("Native pointer relay checks passed: parent drag, multi-pointer, submit, cancel and stale release.");
            }
            finally { UnityEngine.Object.DestroyImmediate(parent); }
        }
    }
}
