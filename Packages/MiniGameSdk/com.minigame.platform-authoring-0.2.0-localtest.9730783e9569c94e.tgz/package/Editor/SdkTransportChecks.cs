using System;
using System.Collections.Generic;
using MiniGamePlatform.SDK.Network;
using UnityEditor;
using UnityEngine;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public static class SdkTransportChecks
    {
        [MenuItem("MiniGame Platform/SDK/Run Transport Checks")]
        public static void Run()
        {
            Assert(!ApiRequest.IsSafePath("https://evil.example/path"), "absolute URL accepted");
            Assert(!ApiRequest.IsSafePath("/v1/games/../wallet"), "traversal accepted");
            Assert(!ApiRequest.IsSafePath("/v1/games/%2e%2e/wallet"), "encoded traversal accepted");
            Assert(!ApiRequest.IsSafePath("/v1/games/%252e%252e/wallet"), "double-encoded traversal accepted");
            Assert(!ApiRequest.IsSafePath("/v1/games/%zz/wallet"), "malformed escape accepted");
            Assert(!ApiRequest.IsSafePath("/v1/platform/wallet?userId=other"), "query injection accepted");
            Assert(ApiRequest.IsSafePath("/v1/platform/wallet"), "valid path rejected");
            var boardRequest = new ApiRequest("GET", "/v1/games/game-a/leaderboards/campaign_progress",
                query: new Dictionary<string, string> { { "seasonId", "all_time" }, { "limit", "20" }, { "offset", "0" } });
            Assert(boardRequest.RelativePathAndQuery.Contains("seasonId=all_time") && !boardRequest.Path.Contains("?"), "query was not encoded separately");

            ApiResult<Probe> success = ApiResult<Probe>.FromJson(
                "{\"data\":{\"name\":\"ready\"},\"meta\":{\"requestId\":\"r-1\"}}", 200);
            Assert(success.IsSuccess && success.Data.name == "ready" && success.RequestId == "r-1", "success envelope lost data");
            ApiResult<Probe> failure = ApiResult<Probe>.FromJson(
                "{\"error\":{\"code\":\"WAIT\",\"retryable\":true},\"meta\":{\"requestId\":\"r-2\"}}", 409);
            Assert(!failure.IsSuccess && failure.ErrorCode == "WAIT" && failure.Retryable && failure.RequestId == "r-2", "error envelope lost metadata");
            ApiResult<Probe> malformedSuccess = ApiResult<Probe>.FromJson("{\"data\":", 200);
            Assert(!malformedSuccess.IsSuccess && malformedSuccess.Retryable, "malformed successful settlement response was treated as definitive");

            var fake = new FakeTransport();
            var request = new ApiRequest("GET", "/v1/platform/wallet");
            fake.Send<Probe>(request, result => Assert(result.IsSuccess, "fake result was not passed through"));
            Assert(fake.Requests.Count == 1 && ReferenceEquals(fake.Requests[0], request), "fake did not record request");
            Debug.Log("SDK transport checks passed.");
        }

        private static void Assert(bool condition, string message)
        {
            if (!condition) throw new Exception(message);
        }

        [Serializable] internal sealed class Probe { public string name; }

        internal sealed class FakeTransport : IPlatformTransport
        {
            public readonly List<ApiRequest> Requests = new List<ApiRequest>();

            public void Send<T>(ApiRequest request, Action<ApiResult<T>> callback)
            {
                Requests.Add(request);
                callback(ApiResult<T>.FromJson("{\"data\":{},\"meta\":{\"requestId\":\"fake\"}}", 200));
            }
        }
    }
}
