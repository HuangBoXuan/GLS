using System.IO;
using MiniGamePlatform.HotUpdate;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEditor.PackageManager;
using UnityEditor.UnityLinker;
using UnityEngine;

namespace MiniGamePlatform.SDK.EditorChecks
{
    // UPM package link.xml files must be explicitly supplied to UnityLinker.
    public sealed class NativeLuaLinkerProcessor : IUnityLinkerProcessor
    {
        public int callbackOrder => 0;
        public string GenerateAdditionalLinkXmlFile(BuildReport report, UnityLinkerBuildPipelineData data)
        {
            var package = PackageInfo.FindForAssembly(typeof(LuaGameRunner).Assembly);
            if (package == null) throw new BuildFailedException("Cannot locate the installed MiniGame SDK package for linker retention.");
            string path = Path.GetFullPath(Path.Combine(package.resolvedPath, "Runtime/link.xml"));
            if (!File.Exists(path)) throw new BuildFailedException("MiniGame SDK linker baseline is missing: " + path);
            Debug.Log("MGP_NATIVE_LINKER_INPUT " + path);
            return path;
        }
    }
}
