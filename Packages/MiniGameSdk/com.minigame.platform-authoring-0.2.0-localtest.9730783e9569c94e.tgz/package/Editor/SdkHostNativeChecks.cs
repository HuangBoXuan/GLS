using System;
using System.IO;
using MiniGamePlatform.HotUpdate;
using MiniGamePlatform.SDK.Auth;
using MiniGamePlatform.SDK.Contracts;
using MiniGamePlatform.SDK.GameData;
using MiniGamePlatform.SDK.Host;
using MiniGamePlatform.SDK.Network;
using UnityEngine;
using XLua;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public static class SdkHostNativeChecks
    {
        private static int _checks;
        private static void Check(bool value, string message)
        { _checks++; if (!value) throw new Exception(message); }

        private sealed class Transport : IPlatformTransport
        {
            public string User = "A";
            public void Send<T>(ApiRequest request, Action<ApiResult<T>> callback)
            {
                callback(ApiResult<T>.FromJson("{\"data\":{\"userId\":\"" + User +
                    "\",\"accessToken\":\"access\",\"refreshToken\":\"refresh\",\"guestCredential\":\"guest\",\"expiresInSeconds\":3600}}", 200));
            }
        }
        private sealed class Ads : IHostAdDriver, IHostAdFullscreenState
        {
            public bool IsTest => false;
            public bool Ready = true;
            public bool ExternalFullscreen;
            public bool IsFullscreenShowing => ExternalFullscreen;
            public Action<string, string> Terminal;
            public bool IsReady(string gameId, string placement, string format) => Ready && placement == "entry";
            public void Show(string requestId, string gameId, string placement, string format, Action<string, string> terminal)
            { Terminal = terminal; }
        }
        private sealed class Banner : IHostBannerDriver
        {
            public bool Ready = true;
            public int Shows, Hides;
            public string Placement;
            public bool IsReady => Ready;
            public bool TryGetGeometry(out Rect screen, out Rect safe, out Rect banner, out float density)
            {
                screen = new Rect(0, 0, 1080, 2400); safe = new Rect(0, 0, 1080, 2400);
                banner = new Rect(0, 0, 1080, 150); density = 3; return Ready;
            }
            public bool Show(string placement) { Placement = placement; Shows++; return Ready; }
            public void Hide() { Placement = null; Hides++; }
        }
        private sealed class Privacy : IHostPrivacyDriver
        {
            public Action<bool> Complete;
            public bool OpenDocument(string document) => document == "privacy";
            public bool ShowOptions(Action<bool> completion) { Complete = completion; return true; }
        }
        private sealed class Haptics : IHostHapticDriver
        {
            public int Plays, Cancels;
            public bool Play(int cue) { Plays++; return cue > 0; }
            public bool Cancel() { Cancels++; return true; }
        }
        private static PlatformSession Session(Transport transport)
        {
            var store = new EditorMemoryCredentialStore();
            store.Save(new CredentialState { DeviceId = "native-test", UserId = "A", RefreshToken = "refresh" });
            return new PlatformSession(transport, store, "host-native-test");
        }

        public static void Run()
        {
            _checks = 0;
            string root = Path.Combine(Path.GetTempPath(), "mgp-native-" + Guid.NewGuid().ToString("N"));
            try
            {
                var queue = new HostMainThreadQueue(); var ads = new Ads(); var broker = new HostAdBroker(ads, queue);
                var banner = new Banner(); var privacy = new Privacy(); var haptics = new Haptics(); int exits = 0;
                var native = new HostNativeCoordinator(broker, banner, privacy, haptics, () => { exits++; return true; });
                var factory = new CommonModuleServiceFactory(new AtomicLocalStore(root), broker, native);
                var product = new ProductContext("test", "https://example.invalid", "1.0.0", new[] { "garden" });
                var transport = new Transport(); var session = Session(transport);
                var manifest = new ModuleManifest { gameId = "garden" };
                using var scope = (ModuleHostServices)factory.CreateServices(manifest, product, session);
                Check(((IModuleAdReadiness)scope.Ads).IsReady("entry", "rewarded"), "Ready ad should be reported.");
                Check(!((IModuleAdReadiness)scope.Ads).IsReady("missing", "rewarded"), "Missing placement was reported ready.");
                Check(scope.GetBannerContext().Contains("\"trusted\":true"), "Banner context lacks real geometry.");
                scope.SetHomeBanner(true);
                Check(banner.Placement == "home" && scope.BannerTopPixels == 150, "Home banner geometry was not owned.");
                string request = scope.Ads.Show("entry", "rewarded", _ => { });
                Check(request.Length == 32 && !((IModuleAdReadiness)scope.Ads).IsReady("entry", "rewarded") &&
                    banner.Placement == null && scope.IsFullscreenShowing(), "Fullscreen did not hide banner or readiness.");
                ads.Terminal("canceled", null); queue.Drain();
                Check(banner.Placement == "home" && !scope.IsFullscreenShowing(), "Banner did not restore after fullscreen.");
                ads.ExternalFullscreen = true; scope.Pump();
                Check(banner.Placement == null && scope.IsFullscreenShowing() &&
                    !((IModuleAdReadiness)scope.Ads).IsReady("entry", "rewarded"), "External fullscreen bypassed the shared gate.");
                ads.ExternalFullscreen = false; scope.Pump();
                Check(banner.Placement == "home", "External fullscreen left banner hidden.");
                native.SetApplicationPaused(true);
                Check(banner.Placement == null, "Backgrounded app left banner visible.");
                native.SetApplicationPaused(false);
                Check(banner.Placement == "home", "Foreground return did not reconcile banner.");
                int run = scope.BeginGameplayBanner(true);
                Check(run > 0 && scope.ShowGameplayBanner(run) && banner.Placement == "gameplay", "Gameplay lease failed.");
                scope.SetGameplayBannerOverlay(run, true);
                Check(banner.Placement == null && scope.IsGameplayBannerViable(run), "Overlay destroyed a valid banner lease.");
                scope.SetGameplayBannerOverlay(run, false);
                Check(scope.IsGameplayBannerViable(run) && banner.Placement == "gameplay", "Overlay release did not restore.");
                scope.SuppressGameplayBanner(run);
                Check(banner.Placement == null && !scope.ShowGameplayBanner(run), "Suppressed run revived.");
                scope.EndGameplayBanner(run);
                Check(!scope.ShowGameplayBanner(run), "Ended run revived.");
                bool consentCalled = false;
                Check(scope.OpenLegalDocument("privacy") && !scope.OpenLegalDocument("unknown"), "Legal document mapping wrong.");
                scope.SetHomeBanner(true);
                Check(scope.ShowPrivacyOptions(ok => consentCalled = ok), "Privacy options did not open.");
                Check(banner.Placement == null, "Privacy overlay left banner visible.");
                privacy.Complete(true); Check(!consentCalled, "Privacy callback ran inline."); queue.Drain();
                Check(banner.Placement == "home", "Privacy completion did not reconcile banner.");
                Check(consentCalled && scope.PlayHaptic(2) && scope.CancelHaptic() && scope.RequestExit() && exits == 1,
                    "Native service forwarding failed.");
                Check(scope.PlayHaptic(3), "Second haptic did not begin.");
                using var env = new LuaEnv(); env.Global.Set("services", scope);
                env.DoString("assert(services:GetBannerContext() ~= nil); assert(services.Ads:IsReady('entry','rewarded'))");
                transport.User = "B"; session.LoginGuest(_ => { });
                Check(haptics.Cancels == 2 && !scope.RequestExit() && !scope.PlayHaptic(2) && !scope.ShowGameplayBanner(run) &&
                    !((IModuleAdReadiness)scope.Ads).IsReady("entry", "rewarded"), "Old account kept native access.");
                using var next = (ModuleHostServices)factory.CreateServices(manifest, product, session);
                Check(next.RequestExit() && exits == 2, "New scope cannot use native service.");
                next.SetHomeBanner(true); Check(next.PlayHaptic(4), "New scope haptic failed."); next.Dispose();
                Check(banner.Placement == null && haptics.Cancels == 3, "Exit did not release banner and haptics.");
                using var noDrivers = (ModuleHostServices)new CommonModuleServiceFactory(
                    new AtomicLocalStore(root), new HostAdBroker(null, queue)).CreateServices(manifest, product, session);
                Check(!((IModuleAdReadiness)noDrivers.Ads).IsReady("entry", "rewarded") &&
                    noDrivers.BeginGameplayBanner(true) == 0 && !noDrivers.OpenLegalDocument("privacy") &&
                    !noDrivers.RequestExit(), "Missing capabilities were simulated as success.");
            }
            finally { if (Directory.Exists(root)) Directory.Delete(root, true); }
            Debug.Log("HOST_NATIVE_CHECKS_PASSED assertions=" + _checks);
        }
    }
}
