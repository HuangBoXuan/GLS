using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using MiniGamePlatform.HotUpdate;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public static class SdkPresentationSurfaceChecks
    {
        private static int _checks;
        private static void Check(bool ok, string why) { _checks++; if (!ok) throw new Exception(why); }
        private static void Reject<T>(Action call) where T : Exception
        { _checks++; try { call(); } catch (T) { return; } throw new Exception("Expected " + typeof(T).Name); }
        private static Transform TransformOf(ModulePresentation p, int id)
        {
            var node = typeof(ModulePresentation).GetMethod("Get", BindingFlags.Instance | BindingFlags.NonPublic).Invoke(p, new object[] { id });
            return (Transform)node.GetType().GetField("Transform").GetValue(node);
        }
        private static string Property(int node, int slot, string name, string kind, string valueFields) =>
            "{\"node\":" + node + ",\"slot\":" + slot + ",\"property\":\"" + name + "\",\"kind\":\"" + kind + "\"," + valueFields + "}";
        private static string Batch(params string[] rows) => "{\"properties\":[" + string.Join(",", rows) + "]}";

        private static void CheckNativeAssets(ModuleManifest source, string directory, string folder)
        {
            var manifest = JsonUtility.FromJson<ModuleManifest>(JsonUtility.ToJson(source));
            manifest.requiredCapabilities = manifest.requiredCapabilities.Concat(new[] { NativeLuaBaseline.Capability }).ToArray();
            using var assets = new ModuleAssetScope(manifest, directory);
            using var bridge = new GameHostBridge(null, assets, manifest.gameId, null);
            Check(bridge.LoadAsset("surface.bundle", folder + "/Model.prefab", typeof(GameObject)) is GameObject, "Native prefab read failed.");
            Check(bridge.LoadAsset("surface.bundle", folder + "/Game.mat", typeof(Material)) is Material, "Native material read failed.");
            Check(bridge.LoadAsset("surface.bundle", folder + "/Green.asset", typeof(Texture2D)) is Texture2D, "Native texture read failed.");
            Reject<ArgumentException>(() => bridge.LoadAsset("surface.bundle", folder + "/Game.mat", typeof(string)));
            Reject<ArgumentNullException>(() => bridge.LoadAsset("surface.bundle", folder + "/Game.mat", null));
            Reject<InvalidDataException>(() => bridge.LoadAsset("surface.bundle", "../Game.mat", typeof(Material)));
            Reject<InvalidDataException>(() => bridge.LoadAsset("../surface.bundle", folder + "/Game.mat", typeof(Material)));
            Reject<InvalidDataException>(() => bridge.LoadAsset("other.bundle", folder + "/Game.mat", typeof(Material)));
            Reject<InvalidDataException>(() => bridge.LoadAsset("surface.bundle", folder + "/Game.mat", typeof(AudioClip)));
            using (var other = new GameHostBridge(null, assets, "othergame", null))
                Reject<InvalidOperationException>(() => other.LoadAsset("surface.bundle", folder + "/Game.mat", typeof(Material)));
            assets.Dispose();
            Reject<ObjectDisposedException>(() => bridge.LoadAsset("surface.bundle", folder + "/Game.mat", typeof(Material)));
            bridge.Dispose();
            Reject<ObjectDisposedException>(() => bridge.LoadAsset("surface.bundle", folder + "/Game.mat", typeof(Material)));
        }

        [MenuItem("MiniGame Platform/SDK/Run Presentation Surface Checks")]
        public static void Run()
        {
            _checks = 0;
            if (typeof(ModulePresentation).GetMethod("ApplyMaterialProperties") == null)
                throw new Exception("Missing generic shader-property bridge; game properties must not be hardcoded in SDK.");
            if (typeof(ModulePresentation).GetMethod("CreateWorldView") == null)
                throw new Exception("Missing module-owned world viewport.");
            string folder = "Assets/SDKSurfaceCheck_" + Guid.NewGuid().ToString("N");
            string output = Path.Combine(Path.GetTempPath(), "SDKSurfaceBundle-" + Guid.NewGuid().ToString("N"));
            AssetDatabase.CreateFolder("Assets", Path.GetFileName(folder)); Directory.CreateDirectory(output);
            GameObject source = null;
            var hostCameraObject = new GameObject("SDK surface check host camera", typeof(Camera));
            Camera hostCamera = hostCameraObject.GetComponent<Camera>(); hostCamera.cullingMask = -1;
            try
            {
                File.WriteAllText(folder + "/Game.shader", @"Shader ""SDKTests/OwnedGameShader"" {
Properties { _Accent(""Game Accent"",Color)=(1,1,1,1) _Gain(""Gain"",Float)=1 _Phase(""Phase"",Vector)=(0,0,0,0) _Map(""Map"",2D)=""white"" {} }
SubShader { Pass { CGPROGRAM
#pragma vertex vert
#pragma fragment frag
#include ""UnityCG.cginc""
struct v2f { float4 pos:SV_POSITION; float2 uv:TEXCOORD0; };
v2f vert(appdata_base v) { v2f o; o.pos=UnityObjectToClipPos(v.vertex); o.uv=v.texcoord; return o; }
sampler2D _Map; float4 _Accent; float _Gain;
float4 frag(v2f i):SV_Target { return tex2D(_Map,i.uv)*_Accent*_Gain; }
ENDCG } } }");
                AssetDatabase.ImportAsset(folder + "/Game.shader");
                var shader = AssetDatabase.LoadAssetAtPath<Shader>(folder + "/Game.shader");
                Check(shader != null && !ShaderUtil.ShaderHasError(shader), "Fixture shader compilation failed.");
                var material = new Material(shader); AssetDatabase.CreateAsset(material, folder + "/Game.mat");
                var texture = new Texture2D(4, 4); texture.SetPixels(Enumerable.Repeat(Color.green, 16).ToArray()); texture.Apply();
                AssetDatabase.CreateAsset(texture, folder + "/Green.asset");
                source = GameObject.CreatePrimitive(PrimitiveType.Cube); source.name = "Surface Cube";
                UnityEngine.Object.DestroyImmediate(source.GetComponent<Collider>());
                source.GetComponent<Renderer>().sharedMaterials = new[] { material, material };
                PrefabUtility.SaveAsPrefabAsset(source, folder + "/Model.prefab");
                UnityEngine.Object.DestroyImmediate(source); source = null;
                var issues = AssetDependencyValidator.Validate(new ModuleDefinition { assetRoots = new[] { folder + "/Model.prefab" } },
                    HostComponentInventory.FromCapabilities(new[] { "presentation" }, Array.Empty<string>()));
                Check(issues.Count == 0, "Bundled game shader required SDK name allowlisting: " + string.Join(",", issues.Select(i => i.Code)));
                Check(BuildPipeline.BuildAssetBundles(output, new[] { new AssetBundleBuild { assetBundleName = "surface.bundle", assetNames =
                    new[] { folder + "/Model.prefab", folder + "/Game.mat", folder + "/Green.asset" } } },
                    BuildAssetBundleOptions.ForceRebuildAssetBundle, BuildTarget.StandaloneWindows64) != null, "Surface bundle build failed.");
                byte[] bytes = File.ReadAllBytes(Path.Combine(output, "surface.bundle"));
                using var sha = SHA256.Create();
                var manifest = new ModuleManifest { gameId = "surfacecheck", minHostApiVersion = 5,
                    requiredCapabilities = new[] { "presentation", "assetbundle", "presentation_surface", "world_view" }, files = new[] {
                        new ModuleFile { path = "surface.bundle", size = bytes.Length, sha256 = BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant() } } };
                using var assets = new ModuleAssetScope(manifest, output);
                using var bridge = new GameHostBridge(null, assets, manifest.gameId, null);
                CheckNativeAssets(manifest, output, folder);
                ModulePresentation p = bridge.Presentation;
                int image = p.CreateImage(0), raw = p.CreateRawImage(0);
                p.SetImageMode(image, "sliced", false); p.SetUvRect(raw, .2f, -.5f, 2.5f, -3);
                Check(TransformOf(p, image).GetComponent<Image>().type == Image.Type.Sliced, "Nine slice not set.");
                Check(TransformOf(p, raw).GetComponent<RawImage>().uvRect.width == 2.5f, "UV repeat not set.");
                Reject<ArgumentException>(() => p.SetImageMode(raw, "sliced", false));
                Reject<ArgumentException>(() => p.SetUvRect(image, 0, 0, 1, 1));
                Reject<ArgumentException>(() => p.SetUvRect(raw, 0, 0, float.NaN, 1));
                p.SetGraphicMaterial(raw, "surface.bundle", folder + "/Game.mat");
                Check(TransformOf(p, raw).GetComponent<RawImage>().material.shader.name == "SDKTests/OwnedGameShader", "Game UI material not bound.");
                int view = p.CreateWorldView(0, 256, 256), world = p.GetWorldRoot(view);
                int layer = TransformOf(p, world).gameObject.layer;
                Check(layer >= 24 && layer <= 31 && (hostCamera.cullingMask & (1 << layer)) == 0, "World layer leaked into host camera.");
                int model = p.CreatePrefab(world, "surface.bundle", folder + "/Model.prefab");
                var renderer = TransformOf(p, model).GetComponent<Renderer>();
                Check(renderer.gameObject.layer == layer, "New model did not inherit leased world layer.");
                p.ApplyMaterialProperties(Batch(Property(model, 0, "_Accent", "color", "\"r\":3,\"g\":0.5,\"b\":0.2,\"a\":1"),
                    Property(model, 0, "_Gain", "float", "\"value\":2.75"), Property(model, 1, "_Phase", "vector", "\"x\":1,\"y\":2,\"z\":3,\"w\":4")));
                var block = new MaterialPropertyBlock(); renderer.GetPropertyBlock(block, 0);
                Check(Mathf.Approximately(block.GetColor("_Accent").r, 3) && block.GetFloat("_Gain") == 2.75f,
                    "Game-defined property/HDR value was restricted: " + block.GetColor("_Accent").r.ToString("R") + ", gain=" + block.GetFloat("_Gain").ToString("R"));
                Check(renderer.sharedMaterials[0].GetFloat("_Gain") == 1, "Shared material asset was mutated.");
                renderer.GetPropertyBlock(block, 1); Check(block.GetVector("_Phase").w == 4 && block.GetFloat("_Gain") == 0, "Material slots were mixed.");
                Reject<ArgumentException>(() => p.ApplyMaterialProperties(Batch(Property(model, 0, "_Gain", "float", "\"value\":8"),
                    Property(model, 0, "_MissingGameProperty", "float", "\"value\":1"))));
                renderer.GetPropertyBlock(block, 0); Check(block.GetFloat("_Gain") == 2.75f, "Rejected batch partially changed renderer.");
                Reject<ArgumentException>(() => p.ApplyMaterialProperties(Batch(Property(model, 0, "_Accent", "float", "\"value\":1"))));
                Reject<ArgumentException>(() => p.ApplyMaterialProperties(Batch(Property(model, 2, "_Gain", "float", "\"value\":1"))));
                string duplicate = Property(model, 0, "_Gain", "float", "\"value\":1");
                Reject<ArgumentException>(() => p.ApplyMaterialProperties(Batch(duplicate, duplicate)));
                Reject<InvalidDataException>(() => p.ApplyMaterialProperties(Batch(Property(model, 0, "_Gain", "float", "\"value\":9"),
                    Property(model, 0, "_Map", "texture", "\"bundle\":\"other.bundle\",\"asset\":\"missing\""))));
                renderer.GetPropertyBlock(block, 0); Check(block.GetFloat("_Gain") == 2.75f, "Missing texture partially applied numeric properties.");
                using (var otherAssets = new ModuleAssetScope(manifest, output))
                using (var otherBridge = new GameHostBridge(null, otherAssets, manifest.gameId, null))
                {
                    Reject<ArgumentException>(() => otherBridge.Presentation.ApplyMaterialProperties(Batch(duplicate)));
                    Reject<ArgumentException>(() => otherBridge.Presentation.ConfigureWorldView(view, "{}"));
                }
                using (var lua = new XLua.LuaEnv())
                {
                    lua.Global.Set("surface", p);
                    lua.Global.Set("surfaceBatch", Batch(Property(model, 0, "_Gain", "float", "\"value\":1.5")));
                    lua.DoString("surface:ApplyMaterialProperties(surfaceBatch)");
                }
                renderer.GetPropertyBlock(block, 0);
                Check(block.GetFloat("_Gain") == 1.5f, "Lua could not invoke generic material properties.");
                p.ApplyMaterialProperties(Batch(Property(model, 0, "_Accent", "color", "\"r\":1,\"g\":1,\"b\":1,\"a\":1"),
                    Property(model, 0, "_Gain", "float", "\"value\":1"),
                    Property(model, 0, "_Map", "texture", "\"bundle\":\"surface.bundle\",\"asset\":\"" + folder + "/Green.asset\"")));
                string config = "{\"orthographic\":true,\"size\":2,\"fov\":45,\"near\":0.1,\"far\":200,\"z\":-10}";
                p.ConfigureWorldView(view, config);
                Camera camera = TransformOf(p, world).GetComponentInChildren<Camera>(true);
                Check(camera.orthographicSize == 2 && camera.targetTexture.width == 256, "World projection/target mismatch.");
                Reject<ArgumentException>(() => p.ConfigureWorldView(view, "{\"size\":3,\"fov\":45,\"near\":10,\"far\":2}"));
                Check(camera.orthographicSize == 2, "Invalid camera config partially applied.");
                Reject<InvalidOperationException>(() => p.CreateWorldView(0, 256, 256));
                Reject<ArgumentException>(() => p.SetImage(view, "surface.bundle", folder + "/Green.asset"));
                p.ApplyNodes("{\"nodes\":[{\"id\":" + view + ",\"visibility\":true,\"active\":false}]}");
                Check(!camera.enabled, "Hidden world view kept rendering.");
                p.ApplyNodes("{\"nodes\":[{\"id\":" + view + ",\"visibility\":true,\"active\":true}]}");
                Check(camera.enabled, "Visible world view did not resume.");
                typeof(GameHostBridge).GetMethod("SetPresentationPaused", BindingFlags.Instance | BindingFlags.NonPublic).Invoke(bridge, new object[] { true });
                Check(!camera.enabled, "Paused world view kept rendering.");
                typeof(GameHostBridge).GetMethod("SetPresentationPaused", BindingFlags.Instance | BindingFlags.NonPublic).Invoke(bridge, new object[] { false });
                var rt = camera.targetTexture;
                // Slot 1 intentionally has an unmodified second material, remove only in this render fixture.
                renderer.sharedMaterials = new[] { renderer.sharedMaterials[0] };
                camera.Render(); var beforeRt = RenderTexture.active; var pixels = new Texture2D(1, 1);
                try { RenderTexture.active = rt; pixels.ReadPixels(new Rect(128, 128, 1, 1), 0, 0); pixels.Apply();
                    Color color = pixels.GetPixel(0, 0); Check(color.g > .8f && color.r < .2f, "Bundled game shader/texture did not render into world view."); }
                finally { RenderTexture.active = beforeRt; UnityEngine.Object.DestroyImmediate(pixels); }
                hostCamera.cullingMask &= ~(1 << 10);
                p.DestroyNode(view);
                Check(camera == null && rt == null && renderer == null && (hostCamera.cullingMask & (1 << layer)) != 0 &&
                    (hostCamera.cullingMask & (1 << 10)) == 0, "World view cleanup leaked resources or overwrote unrelated camera bits.");
                Reject<ArgumentException>(() => p.GetWorldRoot(view));
                int secondView = p.CreateWorldView(0, 128, 128);
                p.DestroyNode(p.GetWorldRoot(secondView));
                Reject<ArgumentException>(() => p.GetWorldRoot(secondView));
                manifest.minHostApiVersion = 4;
                Reject<InvalidDataException>(() => p.SetImageMode(image, "simple", false));
                Debug.Log("Presentation surface checks passed: " + _checks + " assertions; game-owned bundled shader, typed arbitrary properties, HDR, material slots, UI modes/UV, real render target and cleanup.");
            }
            finally
            {
                if (source != null) UnityEngine.Object.DestroyImmediate(source);
                UnityEngine.Object.DestroyImmediate(hostCameraObject);
                AssetDatabase.DeleteAsset(folder); Directory.Delete(output, true);
            }
        }
    }
}
