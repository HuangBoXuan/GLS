using System;
using System.IO;
using System.Globalization;
using System.Linq;
using System.Collections.Generic;
using MiniGamePlatform.HotUpdate;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

namespace MiniGamePlatform.SDK.EditorChecks
{
    // Editor-only example. It never connects to a server or reads a player's save.
    public sealed class SdkPresentationPreview : IDisposable
    {
        private static SdkPresentationPreview _active;
        private ModuleAssetScope _assets;
        private GameHostBridge _bridge;
        private ModulePresentation _presentation;
        private int _status;
        private int _clicks;

        [MenuItem("MiniGame Platform/SDK/Open Presentation Preview (Play Mode)")]
        public static void Open()
        {
            if (!Application.isPlaying) throw new InvalidOperationException("Enter Play Mode first, then open the SDK presentation preview.");
            if (_active != null) return;
            _active = new SdkPresentationPreview();
            try { _active.Initialize(); }
            catch { Close(); throw; }
            EditorApplication.update += _active.Update;
            EditorApplication.playModeStateChanged += OnPlayMode;
            AssemblyReloadEvents.beforeAssemblyReload += Close;
        }

        private static void OnPlayMode(PlayModeStateChange state)
        { if (state == PlayModeStateChange.ExitingPlayMode || state == PlayModeStateChange.EnteredEditMode) Close(); }
        private static void Close() { _active?.Dispose(); }

        private void Initialize()
        {
            _assets = new ModuleAssetScope(new ModuleManifest { gameId = "preview", minHostApiVersion = 4,
                requiredCapabilities = new[] { "presentation" }, files = Array.Empty<ModuleFile>() }, Path.GetTempPath());
            _bridge = new GameHostBridge(null, _assets, "preview", null);
            _presentation = _bridge.Presentation;
            int background = _presentation.CreateImage(0);
            Rect(background, 0, 0, 16000, 16000, .04f, .07f, .12f);
            _presentation.BindTap(background, 1000);
            int title = _presentation.CreateText(0, "SDK / PRESENTATION", 50);
            Rect(title, 0, 510, 940, 100, .9f, .95f, 1);
            int subtitle = _presentation.CreateText(0, "UGUI  -  API 4  -  LOCAL PREVIEW", 24);
            Rect(subtitle, 0, 415, 940, 80, .5f, .67f, .8f);
            for (int i = 0; i < 3; i++)
            {
                int tile = _presentation.CreateImage(0);
                Rect(tile, (i - 1) * 270, 90, 220, 220, i == 0 ? .18f : .8f, i == 1 ? .45f : .7f, i == 2 ? .75f : .4f);
                _presentation.BindTap(tile, i + 1);
                int number = _presentation.CreateText(tile, (i + 1).ToString(), 64);
                Rect(number, 0, 0, 200, 160, .04f, .07f, .12f);
            }
            _status = _presentation.CreateText(0, "Tap a tile", 34);
            Rect(_status, 0, -160, 920, 100, .9f, .95f, 1);
            int exit = _presentation.CreateImage(0);
            Rect(exit, 0, -400, 400, 100, .16f, .23f, .32f); _presentation.BindTap(exit, 99);
            int exitText = _presentation.CreateText(exit, "CLOSE PREVIEW", 25);
            Rect(exitText, 0, 0, 380, 90, .9f, .95f, 1);
        }

        private void Rect(int node, float x, float y, float width, float height, float r, float g, float b)
        {
            _presentation.ApplyNodes(string.Format(CultureInfo.InvariantCulture,
                "{{\"nodes\":[{{\"id\":{0},\"pose\":true,\"x\":{1},\"y\":{2},\"sx\":1,\"sy\":1,\"sz\":1,\"rect\":true,\"width\":{3},\"height\":{4},\"tint\":true,\"r\":{5},\"g\":{6},\"b\":{7},\"a\":1}}]}}",
                node, x, y, width, height, r, g, b));
        }

        private void Update()
        {
            if (_presentation == null) return;
            for (int tap = _presentation.PollTap(); tap != 0; tap = _presentation.PollTap())
            {
                if (tap == 99) { Dispose(); return; }
                if (tap <= 3) _presentation.SetText(_status, "Tile " + tap + " / clicks " + (++_clicks));
            }
        }

        public void Dispose()
        {
            if (_active == this)
            {
                EditorApplication.update -= Update;
                EditorApplication.playModeStateChanged -= OnPlayMode;
                AssemblyReloadEvents.beforeAssemblyReload -= Close;
                _active = null;
            }
            _bridge?.Dispose(); _assets?.Dispose(); _presentation = null;
        }

        // Run without -nographics. The image verifies the demo layout, not a Garden asset migration.
        public static void Capture()
        {
            var cameraObject = new GameObject("SDK Presentation Capture Camera");
            using var demo = new SdkPresentationPreview();
            var target = new RenderTexture(540, 960, 24);
            Texture2D image = null;
            RenderTexture previous = RenderTexture.active;
            try
            {
                demo.Initialize();
                Camera camera = cameraObject.AddComponent<Camera>();
                camera.clearFlags = CameraClearFlags.SolidColor; camera.backgroundColor = Color.black; camera.targetTexture = target;
                Canvas canvas = Resources.FindObjectsOfTypeAll<Canvas>().Single(c => c.name == "Presentation Canvas" &&
                    c.transform.parent != null && c.transform.parent.name == "Module Presentation");
                canvas.renderMode = RenderMode.ScreenSpaceCamera; canvas.worldCamera = camera; canvas.planeDistance = 1;
                Canvas.ForceUpdateCanvases(); camera.Render();
                Image tile = canvas.GetComponentsInChildren<Image>().First(i => i.rectTransform.sizeDelta == new Vector2(220, 220));
                var system = Resources.FindObjectsOfTypeAll<EventSystem>().Single(e => e.name == "Presentation EventSystem");
                var pointer = new PointerEventData(system) { position = RectTransformUtility.WorldToScreenPoint(camera, tile.transform.position),
                    button = PointerEventData.InputButton.Left, pointerId = -1 };
                var hits = new List<RaycastResult>(); canvas.GetComponent<GraphicRaycaster>().Raycast(pointer, hits);
                if (hits.Count == 0 || hits[0].gameObject != tile.gameObject) throw new Exception("Preview UGUI raycast did not hit the tile above its background.");
                ExecuteEvents.Execute(tile.gameObject, pointer, ExecuteEvents.pointerDownHandler);
                ExecuteEvents.Execute(tile.gameObject, pointer, ExecuteEvents.pointerClickHandler);
                demo.Update();
                if (demo._clicks != 1) throw new Exception("Preview click failed to reach the game loop.");
                Canvas.ForceUpdateCanvases(); camera.Render();
                RenderTexture.active = target;
                image = new Texture2D(540, 960, TextureFormat.RGB24, false);
                image.ReadPixels(new UnityEngine.Rect(0, 0, 540, 960), 0, 0); image.Apply();
                Directory.CreateDirectory("Logs/sdk-presentation");
                File.WriteAllBytes("Logs/sdk-presentation/preview.png", image.EncodeToPNG());
                Debug.Log("Presentation preview captured; real UGUI raycast and click-to-loop checked.");
            }
            finally
            {
                RenderTexture.active = previous;
                if (image != null) UnityEngine.Object.DestroyImmediate(image);
                if (cameraObject.TryGetComponent<Camera>(out var camera)) camera.targetTexture = null;
                target.Release(); UnityEngine.Object.DestroyImmediate(target); UnityEngine.Object.DestroyImmediate(cameraObject);
            }
        }
    }

}
