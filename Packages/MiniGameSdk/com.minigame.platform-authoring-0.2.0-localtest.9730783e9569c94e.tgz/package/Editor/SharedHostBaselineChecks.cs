using System;
using System.Collections;
using System.IO;
using System.Reflection;
using MiniGamePlatform.Components;
using MiniGamePlatform.HotUpdate;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

namespace MiniGamePlatform.SDK.EditorChecks
{
    // Host-only regressions: no game assets, game DTOs or Android build required.
    public static class SharedHostBaselineChecks
    {
        [MenuItem("MiniGame Platform/SDK/Run Shared Host Baseline Checks")]
        public static void Run()
        {
            CheckRepair();
            CheckBoundedManifest();
            CheckGraphicAndPackedLua();
            CheckCapabilities();
            Require(typeof(GameHostBridge).GetMethod("BeginLoadAsset") != null, "Scoped async asset entry missing.");
            Debug.Log("Shared host baseline checks passed.");
        }

        private static void CheckCapabilities()
        {
            foreach (string capability in new[]{"unity_async_asset_v1","unity_render_batch_packed_v1"})
            {
                Require(HostProfile.Current.SupportsCapability(capability), "New host capability missing.");
                var old = new HostProfile(7, "editor", Application.unityVersion, new[]{"lua","unity_render_batch_v1"});
                var module = new ModuleManifest { platform="editor", minHostApiVersion=7, files=Array.Empty<ModuleFile>(), requiredCapabilities=new[]{capability} };
                Require(!old.Supports(module, out _), "Old API 7 host accepted a new required capability.");
            }
        }

        public static IEnumerator CheckAsyncAssets()
        {
            const string source="Assets/__SharedHostAsync.txt";
            Require(!File.Exists(source), "Async fixture already exists.");
            string directory=Path.GetFullPath("Temp/SharedHostAsync-"+Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(directory);
            ModuleAssetScope scope=null; GameHostBridge host=null;
            try
            {
                File.WriteAllText(source,"shared-host-async"); AssetDatabase.ImportAsset(source);
                var build=new AssetBundleBuild {assetBundleName="async.bundle",assetNames=new[]{source},addressableNames=new[]{"settings"}};
                Require(BuildPipeline.BuildAssetBundles(directory,new[]{build},BuildAssetBundleOptions.ForceRebuildAssetBundle,BuildTarget.StandaloneWindows64)!=null,"Async bundle build failed.");
                byte[] bytes=File.ReadAllBytes(Path.Combine(directory,"async.bundle"));
                string hash; using(var sha=System.Security.Cryptography.SHA256.Create()) hash=BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-","").ToLowerInvariant();
                var manifest=new ModuleManifest { gameId="hostcheck", version="v1", minHostApiVersion=7,
                    requiredCapabilities=new[]{"lua","assetbundle","module_owned_resources_v1","unity_native_v1","unity_async_asset_v1"},
                    files=new[]{new ModuleFile{path="async.bundle",size=bytes.Length,sha256=hash}} };
                scope=new ModuleAssetScope(manifest,directory); host=new GameHostBridge(null,scope,"hostcheck",null);
                try { host.BeginLoadAsset("async.bundle","../settings",typeof(TextAsset)); throw new Exception("Invalid async asset address accepted."); }
                catch(InvalidDataException) { }
                var request=host.BeginLoadAsset("async.bundle","settings",typeof(TextAsset));
                Require(!request.IsDone,"Expected in-flight request for release check.");
                host.Dispose(); scope.Dispose();
                Require(!scope.IsReleaseComplete,"Unloaded bundle with in-flight request."); request.Dispose();
                for(int i=0;i<600&&!scope.TryCompleteRelease();i++) yield return null;
                Require(scope.IsReleaseComplete,"Detached request blocked resource release.");
                scope=new ModuleAssetScope(manifest,directory);host=new GameHostBridge(null,scope,"hostcheck",null);
                request=host.BeginLoadAsset("async.bundle","settings",typeof(TextAsset));
                for(int i=0;i<600&&!request.IsDone;i++) yield return null;
                Require(request.IsDone && ((TextAsset)request.Asset).text=="shared-host-async","Re-entry asset load failed.");
                var asset=request.Asset; request.Dispose();host.Dispose();scope.Dispose();
                Require(scope.IsReleaseComplete && asset==null,"Last scope retained loaded assets.");
                Debug.Log("Shared host async resource checks passed.");
            }
            finally {host?.Dispose();scope?.Dispose();AssetDatabase.DeleteAsset(source);Directory.Delete(directory,true);}
        }

        private static void CheckRepair()
        {
            string root = Path.Combine(Path.GetTempPath(), "SharedHostRepair-" + Guid.NewGuid().ToString("N"));
            string final = Path.Combine(root, "v1");
            Directory.CreateDirectory(final);
            File.WriteAllText(Path.Combine(final, "old.txt"), "preserve until ready");
            Type type = typeof(ModuleInstaller).Assembly.GetType("MiniGamePlatform.HotUpdate.ModuleDownloadWorkspace");
            const BindingFlags flags = BindingFlags.Instance | BindingFlags.NonPublic;
            try
            {
                using (var workspace = (IDisposable)Activator.CreateInstance(type, flags, null, new object[] { final, new byte[] { 1 } }, null))
                {
                    Require(File.Exists(Path.Combine(final, "old.txt")), "Starting repair destroyed previous bytes.");
                    string content = (string)type.GetField("Content", flags).GetValue(workspace);
                    File.WriteAllText(Path.Combine(content, "new.txt"), "verified replacement");
                    type.GetMethod("Publish", flags).Invoke(workspace, new object[] { final, new byte[] { 1 } });
                    Require(File.Exists(Path.Combine(final, "new.txt")) && !File.Exists(Path.Combine(final, "old.txt")), "Repair did not replace old cache.");
                }
                // An incomplete/cancelled workspace must leave an installed version intact.
                using ((IDisposable)Activator.CreateInstance(type, flags, null, new object[] { final, new byte[] { 2 } }, null)) { }
                Require(File.Exists(Path.Combine(final, "new.txt")), "Cancelled repair destroyed installed bytes.");
            }
            finally { Directory.Delete(root, true); }
        }

        private static void CheckBoundedManifest()
        {
            Type type = typeof(ModuleInstaller).GetNestedType("BoundedManifestDownload", BindingFlags.NonPublic);
            Require(type != null, "Manifest must bound bytes before buffering, not once per frame.");
            using var output = new MemoryStream();
            using var receiver = (IDisposable)Activator.CreateInstance(type, new object[] { output });
            var receive = type.GetMethod("ReceiveData", BindingFlags.NonPublic | BindingFlags.Instance);
            var chunk = new byte[65536];
            for (int i = 0; i < 16; i++) Require((bool)receive.Invoke(receiver, new object[] { chunk, chunk.Length }), "Valid manifest prefix rejected.");
            Require(!(bool)receive.Invoke(receiver, new object[] { chunk, 1 }), "Oversized manifest accepted.");
            Require(output.Length == 1024 * 1024, "Receiver allocated/wrote beyond manifest limit.");
        }

        private static void CheckGraphicAndPackedLua()
        {
            var manifest = new ModuleManifest { formatVersion=1, gameId="hostcheck", version="v1", runtimeType="unity_lua",
                platform="editor", entry="games.hostcheck.main", minHostApiVersion=7, files=Array.Empty<ModuleFile>(),
                requiredCapabilities=new[]{"lua","assetbundle","unity_native_v1","module_owned_resources_v1","unity_render_batch_v1","unity_ugui_mesh_v1"} };
            using var scope = new ModuleAssetScope(manifest, Path.GetTempPath());
            using var host = new GameHostBridge(null, scope, "hostcheck", null);
            var factory = typeof(GameHostBridge).GetMethod("CreateGraphicBuffer");
            Require(factory != null, "Direct UGUI buffer factory missing.");
            var root = new GameObject("Host check", typeof(RectTransform));
            root.transform.SetParent(host.Root, false);
            var graphic = root.AddComponent<ModuleMeshGraphic>();
            using var buffer = (ModuleMeshBuffer)factory.Invoke(host, new object[]{graphic});
            buffer.SetTriangles(new[]{0,1,2});
            using (var lua = new XLua.LuaEnv())
            {
                lua.Global.Set("buffer", buffer);
                using var batch=host.CreateTransformBatch();
                lua.Global.Set("batch",batch);lua.Global.Set("handle",batch.Bind(root.transform));
                lua.DoString(@"local function vertex(x) return string.pack('<ffffffffffBBBBffffffff',x,0,0,0,0,-1,1,0,0,-1,255,255,255,255,0,0,0,0,0,0,0,0) end
                    local v=vertex(3); buffer:UploadPackedChunks({v,v,v},3,3)
                    assert(not pcall(function() buffer:UploadPackedChunks({v,'x',v},3,3) end))
                    assert(not pcall(function() buffer:UploadPacked(vertex(9)..vertex(0/0)..v,3) end))
                    local function pose(x) return string.pack('<i4i4ffffffffff',handle,1,x,0,0,0,0,0,1,1,1,1) end
                    batch:ApplyPackedChunks({pose(5)},1)
                    assert(not pcall(function() batch:ApplyPackedChunks({pose(9),'x'},2) end))
                    assert(not pcall(function() batch:ApplyPacked(pose(9)..pose(0/0)) end))
                    buffer=nil; batch=nil; handle=nil; collectgarbage('collect')");
                Require(root.transform.localPosition.x==5,"Rejected transform payload partly changed scene state.");
            }
            Require(graphic.Mesh == null, "Direct UGUI path creates intermediate Mesh.");
            using var helper = new VertexHelper();
            typeof(ModuleMeshGraphic).GetMethod("OnPopulateMesh", BindingFlags.NonPublic | BindingFlags.Instance, null,
                new[]{typeof(VertexHelper)}, null).Invoke(graphic,new object[]{helper});
            var vertex = new UIVertex(); helper.PopulateUIVertex(ref vertex,0);
            Require(helper.currentVertCount==3 && vertex.position.x==3, "Rejected upload partly overwrote accepted geometry.");
            root.transform.SetParent(null,false);
            try { buffer.Clear(); throw new Exception("Escaped graphic accepted."); } catch(InvalidOperationException) { }
            finally { root.transform.SetParent(host.Root,false); }
            buffer.Dispose(); helper.Clear();
            typeof(ModuleMeshGraphic).GetMethod("OnPopulateMesh", BindingFlags.NonPublic | BindingFlags.Instance, null,
                new[]{typeof(VertexHelper)}, null).Invoke(graphic,new object[]{helper});
            Require(helper.currentVertCount==0, "Disposed buffer retained geometry.");
        }
        private static void Require(bool value, string message) { if (!value) throw new Exception(message); }
    }
}
