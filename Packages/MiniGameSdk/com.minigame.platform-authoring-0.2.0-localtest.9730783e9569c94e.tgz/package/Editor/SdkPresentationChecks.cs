using System;
using System.Reflection;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using MiniGamePlatform.HotUpdate;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public static class SdkPresentationChecks
    {
        private static int _checks;
        private static object Call(object target, string name, params object[] args)
        {
            try { return target.GetType().GetMethod(name, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance).Invoke(target, args); }
            catch (TargetInvocationException e) { throw e.InnerException; }
        }
        private static void Check(bool ok, string why) { _checks++; if (!ok) throw new Exception(why); }
        private static void Reject<T>(Action action) where T : Exception
        { _checks++; try { action(); } catch (T) { return; } throw new Exception("Expected rejection: " + typeof(T).Name); }
        private static object Presentation(GameHostBridge bridge) => typeof(GameHostBridge).GetProperty("Presentation").GetValue(bridge);
        private static GameObject Node(int id) => Resources.FindObjectsOfTypeAll<GameObject>().Single(go => go.name == "Presentation Node " + id);
        private static void Click(GameObject go, bool down = true)
        {
            var data = new PointerEventData(EventSystem.current) { button = PointerEventData.InputButton.Left, pointerId = -1 };
            if (down) ExecuteEvents.Execute(go, data, ExecuteEvents.pointerDownHandler);
            ExecuteEvents.Execute(go, data, ExecuteEvents.pointerClickHandler);
        }
        private static ModuleManifest Manifest(int api = 4) => new ModuleManifest {
            gameId = "presentationcheck", minHostApiVersion = api,
            requiredCapabilities = new[] { "lua", "presentation", "tmp_text", "assetbundle" }, files = Array.Empty<ModuleFile>() };

        [MenuItem("MiniGame Platform/SDK/Run Presentation Checks")]
        public static void Run()
        {
            _checks = 0;
            var property = typeof(GameHostBridge).GetProperty("Presentation");
            if (property == null) throw new Exception("Missing scoped GameHostBridge.Presentation entry.");
            if (!HostProfile.Current.SupportsCapability("presentation"))
                throw new Exception("Missing host presentation capability.");
            var previousSystem = EventSystem.current;
            using var assets = new ModuleAssetScope(Manifest(), Path.GetTempPath());
            using var bridge = new GameHostBridge(null, assets, "presentationcheck", null);
            object p = Presentation(bridge);
            int group = (int)Call(p, "CreateGroup", true, 0);
            int block = (int)Call(p, "CreateImage", group);
            int other = (int)Call(p, "CreateRawImage", group);
            int label = (int)Call(p, "CreateText", group, "Ready", 32);
            var blockGo = Node(block);
            Check(blockGo.GetComponent<Image>() != null && Node(label).GetComponent<Text>().text == "Ready", "UGUI creation failed.");
            Check(blockGo.GetComponent<Image>().raycastTarget == false, "Unbound image consumes input.");
            Call(p, "ApplyNodes", "{\"nodes\":[{\"id\":" + block + ",\"rect\":true,\"width\":160,\"height\":80,\"tint\":true,\"r\":0.2,\"g\":0.7,\"b\":0.3,\"a\":1}]}");
            Check(blockGo.GetComponent<RectTransform>().sizeDelta == new Vector2(160, 80) && blockGo.GetComponent<Image>().color.g == .7f, "Rect/tint not applied.");
            string pose = "{\"id\":" + block + ",\"pose\":true,\"x\":25,\"sx\":1,\"sy\":1,\"sz\":1}";
            Reject<ArgumentException>(() => Call(p, "ApplyNodes", "{\"nodes\":[" + pose + ",{\"id\":2147483647}]}"));
            Check(blockGo.transform.localPosition.x == 0, "Invalid batch partially mutated earlier node.");
            Reject<ArgumentException>(() => Call(p, "ApplyNodes", "{\"nodes\":[" + pose + "," + pose + "]}"));
            Reject<ArgumentException>(() => Call(p, "ApplyNodes", "{\"nodes\":[{\"id\":" + block + ",\"pose\":true}]}"));
            Reject<ArgumentException>(() => Call(p, "ApplyNodes", "{\"nodes\":null}"));
            Reject<ArgumentException>(() => Call(p, "SetText", label, new string('a', 2049)));
            Reject<ArgumentException>(() => Call(p, "SetText", block, "bad"));
            Call(p, "SetText", label, "<b>literal</b>");
            Check(!Node(label).GetComponent<Text>().supportRichText, "Text interpreted markup.");
            Call(p, "BindTap", block, 17); Click(blockGo);
            Check((int)Call(p, "PollTap") == 17 && (int)Call(p, "PollTap") == 0, "Click not delivered exactly once.");
            Click(blockGo); Call(p, "BindTap", block, 18);
            Check((int)Call(p, "PollTap") == 0, "Rebind delivered stale click.");
            Click(blockGo); Call(p, "UnbindTap", block);
            Check((int)Call(p, "PollTap") == 0 && !blockGo.GetComponent<Image>().raycastTarget, "Unbind did not clean input.");
            Call(p, "BindTap", block, 17);
            Click(blockGo); Call(bridge, "SetPresentationPaused", true);
            Click(blockGo);
            Check((int)Call(p, "PollTap") == 0, "Pause retained/accepted click.");
            Call(bridge, "SetPresentationPaused", false); Click(blockGo, false);
            Check((int)Call(p, "PollTap") == 0, "Pre-pause pointer was accepted after resume.");
            Click(blockGo);
            Call(p, "ApplyNodes", "{\"nodes\":[{\"id\":" + group + ",\"visibility\":true,\"active\":false}]}");
            Call(p, "ApplyNodes", "{\"nodes\":[{\"id\":" + group + ",\"visibility\":true,\"active\":true}]}");
            Check((int)Call(p, "PollTap") == 0, "Hide/show resurrected old input.");
            for (int i = 0; i < 129; i++) Click(blockGo);
            Check((int)p.GetType().GetProperty("DroppedTapCount").GetValue(p) == 1, "Input overflow unreported.");
            for (int i = 0; i < 128; i++) Check((int)Call(p, "PollTap") == 17, "Queue order/size lost.");
            Check((int)Call(p, "PollTap") == 0, "Queue exceeded capacity.");
            using (var second = new GameHostBridge(null, assets, "presentationcheck", null))
            {
                object q = Presentation(second);
                int foreign = (int)Call(q, "CreateGroup", true, 0);
                Check(foreign != group, "Cross-instance handle collision.");
                Reject<ArgumentException>(() => Call(p, "CreateImage", foreign));
                var system = EventSystem.current;
                int secondImage = (int)Call(q, "CreateImage", 0); Call(q, "BindTap", secondImage, 1);
                second.Dispose(); Check(EventSystem.current == system, "Secondary scope destroyed a borrowed EventSystem.");
            }
            int world = (int)Call(p, "CreateGroup", false, 0);
            Reject<ArgumentException>(() => Call(p, "CreateImage", world));
            Reject<ArgumentException>(() => Call(p, "BindTap", world, 1));
            Reject<ArgumentException>(() => Call(p, "FindNode", world, "../other"));
            Reject<ArgumentException>(() => Call(p, "ApplyNodes", new string(' ', 262145)));
            Reject<ArgumentException>(() => Call(p, "ApplyNodes", "{\"nodes\":[" + string.Join(",", Enumerable.Repeat("{\"id\":" + block + "}", 513)) + "]}"));
            Reject<ArgumentException>(() => Call(p, "ApplyNodes", "{\"nodes\":[{\"id\":" + world + ",\"rect\":true,\"width\":1,\"height\":1}]}"));
            Reject<ArgumentException>(() => Call(p, "ApplyNodes", "{\"nodes\":[{\"id\":" + block + ",\"tint\":true,\"r\":2}]}"));
            using (var lua = new XLua.LuaEnv())
            {
                lua.Global.Set("host", bridge);
                lua.DoString("local p=host.Presentation; local n=p:CreateImage(0); p:BindTap(n,99); assert(p:PollTap()==0); p:DestroyNode(n)");
            }
            Click(blockGo); Call(p, "DestroyNode", group);
            Check(blockGo == null && (int)Call(p, "PollTap") == 0, "Subtree deletion leaked object/input.");
            Reject<ArgumentException>(() => Call(p, "SetText", label, "stale"));
            while ((int)p.GetType().GetProperty("NodeCount").GetValue(p) < 4096) Call(p, "CreateGroup", false, 0);
            Reject<InvalidOperationException>(() => Call(p, "CreateGroup", false, 0));
            bridge.Dispose();
            Reject<ObjectDisposedException>(() => Call(p, "PollTap"));
            Check(EventSystem.current == previousSystem, "Disposal destroyed/replaced host EventSystem.");
            using var legacyAssets = new ModuleAssetScope(Manifest(3), Path.GetTempPath());
            using var legacy = new GameHostBridge(null, legacyAssets, "presentationcheck", null);
            Reject<InvalidDataException>(() => { try { Presentation(legacy); } catch (TargetInvocationException e) { throw e.InnerException; } });
            Debug.Log("Presentation checks passed: " + _checks + " assertions; UGUI, batch validation, input lifecycle and real xLua.");
        }

        public static void RunRegression()
        {
            Run(); RunBundles();
            MiniGamePlatform.SDK.Editor.Authoring.ModuleHostBoundaryChecks.RunWithProtectionRegression();
            SdkTransportChecks.Run(); SdkAuthChecks.Run();
            Debug.Log("Presentation full regression passed.");
        }

        [MenuItem("MiniGame Platform/SDK/Run Presentation AssetBundle Checks")]
        public static void RunBundles()
        {
            string folder = "Assets/SDKPresentationCheck_" + Guid.NewGuid().ToString("N");
            string output = Path.Combine(Path.GetTempPath(), "SDKPresentationBundle-" + Guid.NewGuid().ToString("N"));
            AssetDatabase.CreateFolder("Assets", Path.GetFileName(folder)); Directory.CreateDirectory(output);
            var source = new GameObject("model");
            var child = new GameObject("bone"); child.transform.SetParent(source.transform, false);
            try
            {
                var texture = new Texture2D(4, 4); texture.SetPixels(Enumerable.Repeat(Color.green, 16).ToArray()); texture.Apply();
                File.WriteAllBytes(folder + "/color.png", texture.EncodeToPNG()); UnityEngine.Object.DestroyImmediate(texture);
                AssetDatabase.ImportAsset(folder + "/color.png");
                var importer = (TextureImporter)AssetImporter.GetAtPath(folder + "/color.png");
                importer.textureType = TextureImporterType.Sprite; importer.spriteImportMode = SpriteImportMode.Single; importer.SaveAndReimport();
                source.AddComponent<MeshFilter>(); source.AddComponent<MeshRenderer>();
                child.AddComponent<SkinnedMeshRenderer>().rootBone = child.transform;
                PrefabUtility.SaveAsPrefabAsset(source, folder + "/safe.prefab");
                source.AddComponent<Animator>();
                // Check Animator before building: a minimal consumer may disable Animation and
                // Unity would strip it from the negative fixture, invalidating the rejection test.
                Reject<InvalidDataException>(() => {
                    try { typeof(GameHostBridge).Assembly.GetType("MiniGamePlatform.HotUpdate.ModulePresentation")
                        .GetMethod("ValidatePrefab", BindingFlags.NonPublic | BindingFlags.Static).Invoke(null, new object[] { source }); }
                    catch (TargetInvocationException e) { throw e.InnerException; }
                });
                UnityEngine.Object.DestroyImmediate(source.GetComponent<Animator>());
                source.AddComponent<BoxCollider>();
                PrefabUtility.SaveAsPrefabAsset(source, folder + "/unsafe.prefab");
                UnityEngine.Object.DestroyImmediate(source); source = null;
                var build = new AssetBundleBuild { assetBundleName = "presentation.bundle", assetNames = new[] {
                    folder + "/safe.prefab", folder + "/unsafe.prefab", folder + "/color.png" } };
                Check(BuildPipeline.BuildAssetBundles(output, new[] { build }, BuildAssetBundleOptions.ForceRebuildAssetBundle,
                    BuildTarget.StandaloneWindows64) != null, "Editor bundle build failed.");
                var manifest = Manifest();
                byte[] bytes = File.ReadAllBytes(Path.Combine(output, "presentation.bundle"));
                using var hash = SHA256.Create();
                manifest.files = new[] { new ModuleFile { path = "presentation.bundle", size = bytes.Length,
                    sha256 = BitConverter.ToString(hash.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant() } };
                using var assets = new ModuleAssetScope(manifest, output);
                using var bridge = new GameHostBridge(null, assets, manifest.gameId, null);
                object p = Presentation(bridge);
                int model = (int)Call(p, "CreatePrefab", 0, "presentation.bundle", folder + "/safe.prefab");
                int bone = (int)Call(p, "FindNode", model, "bone");
                Call(p, "ApplyNodes", "{\"nodes\":[{\"id\":" + bone + ",\"pose\":true,\"x\":7,\"sx\":1,\"sy\":1,\"sz\":1}]}");
                Check(Resources.FindObjectsOfTypeAll<GameObject>().Any(go => go.scene.IsValid() && go.name == "bone" && go.transform.localPosition.x == 7), "World child pose failed.");
                int before = (int)p.GetType().GetProperty("NodeCount").GetValue(p);
                Reject<InvalidDataException>(() => Call(p, "CreatePrefab", 0, "presentation.bundle", folder + "/unsafe.prefab"));
                Check((int)p.GetType().GetProperty("NodeCount").GetValue(p) == before, "Rejected prefab leaked nodes.");
                int image = (int)Call(p, "CreateImage", 0);
                int raw = (int)Call(p, "CreateRawImage", 0);
                Call(p, "SetImage", image, "presentation.bundle", folder + "/color.png");
                Call(p, "SetImage", raw, "presentation.bundle", folder + "/color.png");
                Check(Node(image).GetComponent<Image>().sprite != null && Node(raw).GetComponent<RawImage>().texture != null, "Image bundle assets not loaded.");
                Reject<InvalidDataException>(() => Call(p, "SetImage", image, "other.bundle", folder + "/color.png"));
                Reject<InvalidDataException>(() => Call(p, "SetImage", image, "presentation.bundle", "../color.png"));
                Reject<InvalidDataException>(() => Call(p, "SetImage", image, "presentation.bundle", folder + "/safe.prefab"));
                Call(p, "DestroyNode", model);
                Reject<ArgumentException>(() => Call(p, "FindNode", bone, "child"));
                Debug.Log("Presentation AssetBundle checks passed: real Windows Editor bundle, pure prefab, skin bone, Sprite/Texture; source Animator and bundled Collider/path/type rejected.");
            }
            finally
            {
                if (source != null) UnityEngine.Object.DestroyImmediate(source);
                AssetDatabase.DeleteAsset(folder);
                Directory.Delete(output, true);
            }
        }

        // Explicit isolated-project preparation; never called by the ordinary regression entry point.
        public static void ImportTmpValidationResources()
        {
            string package = UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(TMPro.TMP_Text).Assembly).resolvedPath;
            if (Application.isBatchMode)
            {
                AssetDatabase.importPackageCompleted += name => { Debug.Log("TMP validation resources import completed: " + name); EditorApplication.Exit(0); };
                AssetDatabase.importPackageFailed += (name, error) => { Debug.LogError(name + ": " + error); EditorApplication.Exit(1); };
                AssetDatabase.importPackageCancelled += name => { Debug.LogError("TMP import cancelled: " + name); EditorApplication.Exit(1); };
            }
            AssetDatabase.ImportPackage(Path.Combine(package, "Package Resources/TMP Essential Resources.unitypackage"), false);
        }

        public static void RunTmpAssets()
        {
            const string fontPath = "Assets/TextMesh Pro/Resources/Fonts & Materials/LiberationSans SDF.asset";
            Check(TMPro.TMP_Settings.LoadDefaultSettings() != null && AssetDatabase.LoadAssetAtPath<TMPro.TMP_FontAsset>(fontPath) != null,
                "Import TMP Essential Resources in this isolated validation project first.");
            string output = Path.Combine(Path.GetTempPath(), "SDKPresentationTmp-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(output);
            try
            {
                Check(BuildPipeline.BuildAssetBundles(output, new[] { new AssetBundleBuild { assetBundleName = "font.bundle", assetNames = new[] { fontPath } } },
                    BuildAssetBundleOptions.ForceRebuildAssetBundle, BuildTarget.StandaloneWindows64) != null, "TMP bundle build failed.");
                var manifest = Manifest();
                byte[] bytes = File.ReadAllBytes(Path.Combine(output, "font.bundle"));
                using var sha = SHA256.Create();
                manifest.files = new[] { new ModuleFile { path = "font.bundle", size = bytes.Length,
                    sha256 = BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant() } };
                using var assets = new ModuleAssetScope(manifest, output);
                using var bridge = new GameHostBridge(null, assets, manifest.gameId, null);
                object p = Presentation(bridge);
                int label = (int)Call(p, "CreateTmpText", 0, "font.bundle", fontPath, "Module ready", 32);
                Call(p, "ApplyNodes", "{\"nodes\":[{\"id\":" + label + ",\"rect\":true,\"width\":600,\"height\":100}]}");
                var tmp = Node(label).GetComponent<TMPro.TextMeshProUGUI>();
                Canvas.ForceUpdateCanvases(); tmp.ForceMeshUpdate(true, true);
                Check(tmp.font != null && tmp.textInfo.characterCount == 12 && tmp.mesh.vertexCount > 0, "TMP font bundle did not generate text geometry.");
                Call(p, "SetText", label, "Changed"); tmp.ForceMeshUpdate(true, true);
                Check(tmp.textInfo.characterCount == 7 && !tmp.richText, "TMP text update failed.");
                Debug.Log("Presentation TMP bundle checks passed: imported host resources, explicit bundled font/atlas/material, generated glyph geometry and text update.");
            }
            finally { Directory.Delete(output, true); }
        }
    }
}
