using System;
using System.IO;
using System.Collections.Generic;
using System.Threading;
using MiniGamePlatform.HotUpdate;
using MiniGamePlatform.SDK.Auth;
using MiniGamePlatform.SDK.Contracts;
using MiniGamePlatform.SDK.Host;
using MiniGamePlatform.SDK.GameData;
using MiniGamePlatform.SDK.Network;
using UnityEngine;
using XLua;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public static class SdkHostServicesChecks
    {
        private static int _checks;
        private static void Check(bool value, string message) { _checks++; if (!value) throw new Exception(message); }
        private static void Reject<T>(Action action) where T : Exception
        { _checks++; try { action(); } catch (T) { return; } throw new Exception("Expected " + typeof(T).Name); }
        private sealed class Transport : IPlatformTransport
        {
            public string User = "A";
            public bool Deferred;
            public int Status = 200, Calls;
            public readonly Queue<Action> Responses = new Queue<Action>();
            public void Send<T>(ApiRequest request, Action<ApiResult<T>> callback)
            {
                Calls++;
                string json = "{\"data\":{\"userId\":\"" + User + "\",\"accessToken\":\"test-access\",\"refreshToken\":\"test-refresh\",\"guestCredential\":\"test-guest\",\"expiresInSeconds\":3600}}";
                int status = Status;
                Action reply = () => callback(ApiResult<T>.FromJson(json, status));
                if (Deferred) Responses.Enqueue(reply); else reply();
            }
        }
        private sealed class Driver : IHostAdDriver
        {
            public bool IsTest => true;
            public bool Ready = true, Throw;
            public int Calls;
            public Action<string, string> Terminal;
            public bool IsReady(string gameId, string placement, string format) => Ready;
            public void Show(string requestId, string gameId, string placement, string format, Action<string, string> terminal)
            { Calls++; if (Throw) throw new IOException("test-driver-failure"); Terminal = terminal; }
        }
        private static ProductContext Product() => new ProductContext("test", "https://example.invalid", "1.0.0", new[] { "one", "two" });
        private static IModuleHostServices Scope(CommonModuleServiceFactory factory, PlatformSession session, string game = "one") =>
            factory.CreateServices(new ModuleManifest { gameId = game }, Product(), session);
        private static PlatformSession Session(Transport transport)
        {
            var store = new EditorMemoryCredentialStore();
            store.Save(new CredentialState { DeviceId = "test-device", UserId = "A", RefreshToken = "test-refresh" });
            return new PlatformSession(transport, store, "test");
        }
        public static void Run()
        {
            _checks = 0;
            Check(typeof(GameHostBridge).GetProperty("Services") != null, "Missing host services.");
            string root = Path.Combine(Path.GetTempPath(), "mgp-services-" + Guid.NewGuid().ToString("N"));
            try { RunScopes(root); RunAds(root); RunLua(root); RunAuthRaces(); }
            finally { if (Directory.Exists(root)) Directory.Delete(root, true); }
            Debug.Log("HOST_SERVICES_CHECKS_PASSED assertions=" + _checks);
        }
        private static CommonModuleServiceFactory Factory(AtomicLocalStore store, HostAdBroker broker) =>
            new CommonModuleServiceFactory(store, broker);
        private static void RunScopes(string root)
        {
            var transport = new Transport(); var session = Session(transport);
            var store = new AtomicLocalStore(root);
            var factory = Factory(store, new HostAdBroker(null, new HostMainThreadQueue()));
            using var first = Scope(factory, session);
            Check(first.Account.UserId == "A" && first.Storage.IsAvailable && !first.Ads.IsAvailable, "Availability wrong.");
            string key = "../../中文/../save";
            first.Storage.Write(key, "old"); first.Storage.Write(key, "new");
            using (var reentry = Scope(factory, session)) Check(reentry.Storage.Read(key) == "new", "Re-entry lost data.");
            using (var otherGame = Scope(factory, session, "two")) Check(otherGame.Storage.Read(key) == null, "Game scope leaked.");
            var failing = new AtomicLocalStore(root, (a, b) => { throw new IOException("commit-fault"); });
            Reject<IOException>(() => failing.Write("A", "one", key, "bad"));
            Check(first.Storage.Read(key) == "new" && Directory.GetFiles(root, "*.tmp", SearchOption.AllDirectories).Length == 0, "Failed commit replaced data or leaked temp.");
            Reject<ArgumentNullException>(() => first.Storage.Write(key, null));
            Reject<ArgumentException>(() => first.Storage.Read(""));
            string longRoot = Path.Combine(root, new string('r', Math.Max(1, 180 - root.Length - 1)));
            var longPathStore = new AtomicLocalStore(longRoot);
            longPathStore.Write("A", "one", "key", "first"); longPathStore.Write("A", "one", "key", "second");
            Check(longPathStore.Read("A", "one", "key") == "second", "Temp path broke a valid long app-data path.");
            int invalidated = 0; first.Account.Invalidated += () => invalidated++;
            long revision = session.IdentityVersion;
            session.WithAccessToken(_ => { }, _ => { throw new Exception("refresh failed"); });
            Check(session.IdentityVersion == revision && first.Storage.IsAvailable, "Refresh invalidated same identity.");
            transport.User = "B"; session.LoginGuest(_ => { });
            Check(invalidated == 1 && !first.Storage.IsAvailable && first.Account.UserId == null, "Identity transition did not invalidate old view.");
            Reject<InvalidOperationException>(() => first.Storage.Write(key, "leak"));
            using (var b = Scope(factory, session)) Check(b.Storage.Read(key) == null, "Account scope leaked.");
            transport.User = "A"; session.LoginGuest(_ => { });
            Check(!first.Storage.IsAvailable && invalidated == 1, "A-B-A revived stale handle.");
            using (var a = Scope(factory, session))
            {
                Check(a.Storage.Read(key) == "new", "New A cannot recover own data.");
                a.Storage.Delete(key); a.Storage.Delete(key); Check(a.Storage.Read(key) == null, "Delete failed.");
                a.Dispose(); Reject<InvalidOperationException>(() => a.Storage.Read(key));
            }
            using (var missing = Scope(factory, null))
            { Check(!missing.Account.IsAvailable && !missing.Storage.IsAvailable, "Missing session acquired common guest store."); Reject<InvalidOperationException>(() => missing.Storage.Read(key)); }
            using (var logout = Scope(factory, session))
            { session.Logout(_ => { }); Check(!logout.Storage.IsAvailable && session.UserId == null, "Logout kept view alive."); }
        }
        private static void RunAds(string root)
        {
            var queue = new HostMainThreadQueue(); var driver = new Driver();
            var factory = Factory(new AtomicLocalStore(root), new HostAdBroker(driver, queue));
            var transport = new Transport(); var session = Session(transport);
            using var a = Scope(factory, session); using var b = Scope(factory, session, "two");
            int calls = 0; string result = null, busy = null;
            string id = a.Ads.Show("continue", "rewarded", json => { calls++; result = json; });
            string second = b.Ads.Show("end", "interstitial", json => busy = json);
            Check(id != second && driver.Calls == 1 && calls == 0, "Ads not exclusive/asynchronous.");
            queue.Drain(); Check(busy.Contains("busy"), "Busy result missing.");
            var terminal = driver.Terminal;
            var worker = new Thread(() => { terminal("completed", null); terminal("failed", "duplicate"); });
            worker.Start(); worker.Join(); Check(calls == 0, "Worker invoked Lua callback inline.");
            queue.Drain(); Check(calls == 1 && result.Contains(id) && result.Contains("completed") && result.Contains("\"isTest\":true"), "Terminal duplicated or malformed.");
            a.Ads.Show("continue", "rewarded", _ => calls++); terminal = driver.Terminal;
            a.Dispose(); b.Ads.Show("end", "interstitial", json => busy = json); queue.Drain();
            Check(driver.Calls == 2 && busy.Contains("busy"), "Exit released native fullscreen early.");
            terminal("completed", null); queue.Drain(); Check(calls == 1, "Exit delivered stale callback.");
            b.Ads.Show("end", "interstitial", _ => calls++); terminal = driver.Terminal;
            transport.User = "B"; session.LoginGuest(_ => { }); terminal("completed", null); queue.Drain();
            Check(calls == 1, "Account switch delivered stale callback.");
            using var next = Scope(factory, session);
            driver.Throw = true; next.Ads.Show("x", "rewarded", json => result = json); queue.Drain(); Check(result.Contains("failed"), "Throw did not fail request.");
            driver.Throw = false; driver.Ready = false; next.Ads.Show("x", "rewarded", json => result = json); queue.Drain(); Check(result.Contains("not_ready"), "Unready not explicit.");
            Reject<ArgumentException>(() => next.Ads.Show("x", "banner", _ => { }));
            Reject<ArgumentNullException>(() => next.Ads.Show("x", "rewarded", null));
            var local = new LocalTestAdDriver();
            using var test = Scope(Factory(new AtomicLocalStore(root), new HostAdBroker(local, queue)), session);
            test.Ads.Show("manual", "rewarded", json => result = json); local.Cancel(); queue.Drain(); Check(result.Contains("canceled"), "Test cancel missing.");
            test.Ads.Show("manual", "rewarded", json => result = json); local.Fail("manual"); queue.Drain(); Check(result.Contains("failed"), "Test fail missing.");
        }
        private static void RunLua(string root)
        {
            var queue = new HostMainThreadQueue(); var driver = new LocalTestAdDriver(); var transport = new Transport();
            var session = Session(transport);
            using var services = Scope(Factory(new AtomicLocalStore(root), new HostAdBroker(driver, queue)), session);
            using var env = new LuaEnv();
            env.Global.Set("services", services);
            env.DoString(@"
                assert(services.Account.IsAvailable and services.Account.UserId == 'A')
                services.Storage:Write('lua', 'value')
                assert(services.Storage:Read('lua') == 'value')
                services.Account:Invalidated('+', function() invalidated = true end)
                request = services.Ads:Show('continue', 'rewarded', function(json) result = json end)
            ");
            driver.Complete(); queue.Drain();
            Check(env.Global.Get<string>("result").Contains(env.Global.Get<string>("request")), "Real Lua callback failed.");
            transport.User = "B"; session.LoginGuest(_ => { });
            Check(env.Global.Get<bool>("invalidated"), "Lua invalidation missing.");
            services.Dispose(); env.DoString("services=nil; collectgarbage('collect')");
        }
        private static void RunAuthRaces()
        {
            var transport = new Transport { Deferred = true }; var session = Session(transport);
            string error = null;
            session.LoginGuest(result => error = result.ErrorCode);
            transport.User = "B"; session.LoginGuest(_ => { });
            var stale = transport.Responses.Dequeue(); transport.Responses.Dequeue()(); stale();
            Check(session.UserId == "B" && error == "ACCOUNT_CHANGED", "Stale login overwrote new identity.");
            foreach (bool returnToA in new[] { false, true })
            {
                var t = new Transport(); var s = Session(t); s.LoginGuest(_ => { });
                t.Deferred = true; t.Status = 401;
                string failure = null;
                s.RedeemLinkCode("local-code", result => failure = result.ErrorCode);
                var oldResponse = t.Responses.Dequeue();
                t.Deferred = false; t.Status = 200; t.User = "B"; s.LoginGuest(_ => { });
                if (returnToA) { t.User = "A"; s.LoginGuest(_ => { }); }
                int before = t.Calls; oldResponse();
                Check(t.Calls == before && failure == "ACCOUNT_CHANGED", "Old 401 retried binding under a new identity generation.");
            }
        }
    }
}
