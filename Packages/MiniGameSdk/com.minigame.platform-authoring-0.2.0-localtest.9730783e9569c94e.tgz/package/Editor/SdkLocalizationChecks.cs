using System;
using MiniGamePlatform.HotUpdate;
using UnityEditor.PackageManager;
using UnityEngine;
using XLua;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public static class SdkLocalizationChecks
    {
        public static void Run()
        {
            var type = Type.GetType("UnityEngine.Localization.SmartFormat.Smart, Unity.Localization", false);
            if (type == null) throw new Exception("Localization SmartFormatter host dependency is missing.");
            var package = PackageInfo.FindForAssembly(type.Assembly);
            if (package == null || package.version != "1.4.4") throw new Exception("Localization baseline is not 1.4.4.");
            using (var env = new LuaEnv())
                env.DoString(@"
local fmt = CS.UnityEngine.Localization.SmartFormat.Smart.CreateDefaultSmartFormat()
local values = CS.System.Collections.Generic.Dictionary(CS.System.String, CS.System.Object)()
values:Add('name', 'player'); values:Add('count', 2)
assert(values:ContainsKey('name') and values.Count == 2)
local culture = CS.System.Globalization.CultureInfo.GetCultureInfo('en-US')
assert(fmt:Format(culture, '{name}: {count:0}', values) == 'player: 2')
assert(fmt:Format(culture, '{count:plural:one|many}', values) == 'many')
assert(fmt:Format(culture, '{count:cond:>1?more|single}', values) == 'more')
values=nil; fmt=nil; collectgarbage('collect')
");
            if (!HostProfile.Current.SupportsCapability("unity_localization_1_4_4")) throw new Exception("Missing localization capability.");
            var old = new HostProfile(5, "editor", Application.unityVersion, new[] { NativeLuaBaseline.Capability });
            if (old.SupportsCapability("unity_localization_1_4_4")) throw new Exception("Old native baseline advertises localization.");
            Debug.Log("LOCALIZATION_CHECKS_PASSED version=1.4.4 named/numeric/plural/conditional Lua formatting");
        }
    }
}
