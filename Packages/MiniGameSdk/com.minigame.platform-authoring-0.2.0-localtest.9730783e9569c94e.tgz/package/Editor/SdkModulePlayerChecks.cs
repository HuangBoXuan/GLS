using System;
using System.IO;
using System.Security.Cryptography;
using MiniGamePlatform.HotUpdate;
using UnityEditor;
using UnityEngine;

namespace MiniGamePlatform.SDK.EditorChecks
{
    // Tests the retained shell contract without relying on the retired presentation wrappers.
    public static class SdkModulePlayerChecks
    {
        private static int _checks;
        private static void Check(bool value, string reason)
        { _checks++; if (!value) throw new Exception(reason); }
        private static void Reject<T>(Action action) where T : Exception
        { _checks++; try { action(); } catch (T) { return; } throw new Exception("Expected " + typeof(T).Name); }
        private static string Hash(byte[] bytes)
        { using var sha = SHA256.Create(); return BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant(); }

        [MenuItem("MiniGame Platform/SDK/Run Shared Module Player Checks")]
        public static void Run()
        {
            _checks = 0;
            string directory = Path.Combine(Path.GetTempPath(), "SdkModulePlayer-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(Path.Combine(directory, "games/playercheck"));
            try
            {
                const string relative = "games/playercheck/main.lua";
                File.WriteAllText(Path.Combine(directory, relative), @"
local host
return {
 enter = function(h) host=h; host:ShowMessage('enter:' .. host.Launch.ModuleVersion) end,
 update = function(dt) host:ShowMessage('tick') end,
 pause = function() host:ShowMessage('pause') end,
 resume = function() host:ShowMessage('resume') end,
 exit = function() host:ShowMessage('exit'); host=nil end
}", new System.Text.UTF8Encoding(false));
                byte[] lua = File.ReadAllBytes(Path.Combine(directory, relative));
                var manifest = new ModuleManifest {
                    formatVersion = 1, gameId = "playercheck", version = "v1", runtimeType = "unity_lua",
                    entry = "games.playercheck.main", minHostApiVersion = 1, platform = "editor",
                    unityVersion = Application.unityVersion, requiredCapabilities = new[] { "lua" },
                    files = new[] { new ModuleFile { path = relative, size = lua.Length, sha256 = Hash(lua) } }
                };
                string manifestPath = Path.Combine(directory, "manifest.json");
                File.WriteAllText(manifestPath, JsonUtility.ToJson(manifest), new System.Text.UTF8Encoding(false));
                string hash = Hash(File.ReadAllBytes(manifestPath));
                var product = new ProductContext("test", "https://example.invalid", "1.0.0", new[] { "playercheck" });
                foreach (string shell in new[] { "hub", "independent" })
                {
                    using var player = new ModulePlayer(shell, shell == "independent" ? "playercheck" : null);
                    string message = null;
                    player.OpenInstalled(directory, hash, product, null, "level2", s => message = s);
                    Check(player.State == GameRunState.Running && message == "enter:v1", shell + " enter failed");
                    Check(player.ManifestSha256 == hash && player.CurrentGameId == "playercheck", "Selected module identity lost");
                    player.Tick(); Check(player.SuccessfulTicks == 1 && message == "tick", "Lua update failed");
                    player.Pause(); Check(player.State == GameRunState.Paused && message == "pause", "Lua pause failed");
                    player.Tick(); Check(player.SuccessfulTicks == 1 && message == "pause", "Paused module updated");
                    player.Resume(); Check(player.State == GameRunState.Running && message == "resume", "Lua resume failed");
                    player.Exit(); Check(player.State == GameRunState.Empty && player.ManifestSha256 == null && message == "exit", "Exit failed");
                    player.OpenInstalled(directory, hash.ToUpperInvariant(), product, null, null, null);
                    Check(player.State == GameRunState.Running, "Uppercase hash rejected"); player.Exit();
                    Reject<InvalidDataException>(() => player.OpenInstalled(directory, new string('0', 64), product, null, null, null));
                    Check(player.State == GameRunState.Empty, "Hash mismatch launched module");
                    player.Enter(manifest, directory, null, product, null);
                    Check(player.State == GameRunState.Running, "Resolved manifest entry failed"); player.Exit();
                    manifest.version = "v2";
                    Reject<InvalidDataException>(() => player.Enter(manifest, directory, null, product, null));
                    manifest.version = "v1";
                }
                using (var player = new ModulePlayer("independent", "other"))
                    Reject<InvalidDataException>(() => player.OpenInstalled(directory, hash, product, null, null, null));
                using (var player = new ModulePlayer())
                    Reject<InvalidDataException>(() => player.OpenInstalled(directory, hash,
                        new ProductContext("other", "https://example.invalid", "1.0.0", new[] { "other" }), null, null, null));
                Reject<ArgumentException>(() => new ModulePlayer("unknown"));
                Reject<ArgumentException>(() => new ModulePlayer("independent"));
                Debug.Log("Shared ModulePlayer checks passed: " + _checks + " assertions; identical Lua bytes in both shells.");
            }
            finally
            {
                // Only the exact unique temporary directory created by this test is removed.
                Directory.Delete(directory, true);
            }
        }

        public static void RunRegression()
        {
            Run();
            SdkPresentationSurfaceChecks.Run();
            SdkPresentationChecks.RunRegression();
            Debug.Log("SDK scope cleanup regression passed.");
        }
    }
}
