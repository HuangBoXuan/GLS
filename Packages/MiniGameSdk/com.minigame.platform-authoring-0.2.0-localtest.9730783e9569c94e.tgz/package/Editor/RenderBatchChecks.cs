using System;
using System.Collections;
using System.IO;
using System.Reflection;
using MiniGamePlatform.HotUpdate;
using UnityEditor;
using UnityEngine;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public static class RenderBatchChecks
    {
        [MenuItem("MiniGame Platform/SDK/Run Render Batch Checks")]
        public static void Run()
        {
            if (!HostCapabilityRegistry.Contains("unity_render_batch_v1", 7) ||
                HostCapabilityRegistry.Contains("unity_render_batch_v1", 6))
                throw new Exception("Render batch capability must be available from host API 7 only.");
            if (typeof(GameHostBridge).GetMethod("CreateMeshBuffer") == null ||
                typeof(GameHostBridge).GetMethod("CreateTransformBatch") == null)
                throw new Exception("Module-scoped render batch factories are missing.");
            CheckMesh();
            CheckTransforms();
            CheckRepeatedLevelCleanup();
            CheckUnsupportedModule();
            Debug.Log("Render batch contract checks passed.");
        }

        private static ModuleAssetScope Scope(bool withCapability = true)
        {
            var manifest = new ModuleManifest {
                formatVersion = 1, gameId = "batchcheck", version = "v1", runtimeType = "unity_lua",
                entry = "games.batchcheck.main", platform = "editor", unityVersion = Application.unityVersion,
                minHostApiVersion = 7, requiredCapabilities = withCapability ?
                    new[] { "lua", "unity_render_batch_v1" } : new[] { "lua" },
                files = Array.Empty<ModuleFile>()
            };
            return new ModuleAssetScope(manifest, Path.GetTempPath());
        }

        private static void CheckMesh()
        {
            using var scope = Scope();
            using var bridge = new GameHostBridge(null, scope, "batchcheck", null);
            if (!bridge.SupportsRenderBatch) throw new Exception("Declared render batch capability was not detected.");
            var mesh = new Mesh();
            try
            {
                ModuleMeshBuffer buffer = bridge.CreateMeshBuffer(mesh);
                buffer.SetTriangles(new[] { 0, 1, 2 });
                byte[] data = new byte[3 * ModuleMeshBuffer.VertexStride];
                WriteVertex(data, 0, new Vector3(1, 2, 0));
                WriteVertex(data, 1, new Vector3(3, 2, 0));
                WriteVertex(data, 2, new Vector3(1, 4, 0));
                buffer.Upload(data, 3);
                if (mesh.vertexCount != 3 || mesh.GetVertexBufferStride(0) != 76 ||
                    mesh.triangles.Length != 3 || Vector3.Distance(mesh.vertices[1], new Vector3(3, 2, 0)) > 0.0001f)
                    throw new Exception("Mesh byte ABI did not reach the borrowed Unity Mesh.");
                Vector3 before = mesh.vertices[0];
                Reject<ArgumentException>(() => buffer.Upload(new byte[10], 3));
                data[0] = 0; WriteFloat(data, 0, float.NaN);
                Reject<ArgumentException>(() => buffer.Upload(data, 3));
                Reject<ArgumentOutOfRangeException>(() => buffer.SetTriangles(new[] { 0, 1, 3 }));
                if (mesh.vertices[0] != before || mesh.triangles.Length != 3)
                    throw new Exception("Invalid mesh payload partly changed the previous geometry.");
                WriteFloat(data, 0, 5f);
                buffer.Upload(data, 3);
                if (Mathf.Abs(mesh.vertices[0].x - 5f) > 0.0001f) throw new Exception("Repeated vertex upload failed.");
                WriteFloat(data, 0, 6f);
                using (var lua = new XLua.LuaEnv())
                {
                    lua.Global.Set("render_host", bridge);
                    lua.Global.Set("render_buffer", buffer);
                    lua.Global.Set("render_data", data);
                    lua.DoString("assert(render_host.SupportsRenderBatch); render_buffer:Upload(render_data, 3); " +
                        "render_host=nil; render_buffer=nil; render_data=nil; collectgarbage('collect')");
                }
                if (Mathf.Abs(mesh.vertices[0].x - 6f) > 0.0001f)
                    throw new Exception("Lua could not submit the packed vertex buffer.");
                buffer.Upload(Array.Empty<byte>(), 0);
                if (mesh.vertexCount != 0) throw new Exception("Mesh Clear did not clear geometry.");
                buffer.Upload(data, 3);
                buffer.Clear();
                buffer.Upload(data, 3);
                buffer.Dispose();
                Reject<ObjectDisposedException>(() => buffer.Upload(data, 3));
                if (mesh == null || mesh.vertexCount != 3) throw new Exception("Batch Dispose destroyed the borrowed Mesh.");
                if (TrackedBatchCount(bridge) != 0 ||
                    typeof(ModuleMeshBuffer).GetField("_mesh", BindingFlags.NonPublic | BindingFlags.Instance)?.GetValue(buffer) != null)
                    throw new Exception("Disposed mesh batch still retains the bridge or borrowed Mesh.");
                ModuleMeshBuffer ownedByBridge = bridge.CreateMeshBuffer(mesh);
                float large = float.MaxValue * 0.75f;
                WriteVertex(data, 0, new Vector3(large, 0, 0));
                WriteVertex(data, 1, new Vector3(large, 2, 0));
                WriteVertex(data, 2, new Vector3(large, 4, 0));
                ownedByBridge.Upload(data, 3);
                if (float.IsNaN(mesh.bounds.center.x) || float.IsInfinity(mesh.bounds.center.x))
                    throw new Exception("Finite large positions produced invalid Mesh bounds.");
                WriteVertex(data, 0, new Vector3(-float.MaxValue, 0, 0));
                Reject<ArgumentOutOfRangeException>(() => ownedByBridge.Upload(data, 3));
                if (float.IsNaN(mesh.bounds.center.x) || float.IsInfinity(mesh.bounds.center.x))
                    throw new Exception("Rejected extreme bounds changed the previous Mesh.");
                bridge.Dispose();
                Reject<ObjectDisposedException>(() => ownedByBridge.Upload(data, 3));
                if (mesh == null) throw new Exception("Bridge exit destroyed the borrowed Mesh.");
            }
            finally { UnityEngine.Object.DestroyImmediate(mesh); }
        }

        private static void CheckTransforms()
        {
            using var scope = Scope();
            using var bridge = new GameHostBridge(null, scope, "batchcheck", null);
            var child = new GameObject("batch-target");
            child.transform.SetParent(bridge.Root, false);
            var foreign = new GameObject("foreign-target");
            try
            {
                ModuleTransformBatch batch = bridge.CreateTransformBatch();
                int handle = batch.Bind(child.transform);
                if (handle != batch.Bind(child.transform)) throw new Exception("Repeated Bind changed the handle.");
                Reject<ArgumentException>(() => batch.Bind(foreign.transform));
                byte[] record = new byte[ModuleTransformBatch.RecordStride];
                WriteRecord(record, 0, handle, 7, new Vector3(2, 3, 4), Quaternion.identity, new Vector3(2, 2, 2));
                batch.Apply(record);
                if (child.transform.localPosition != new Vector3(2, 3, 4) ||
                    child.transform.localScale != new Vector3(2, 2, 2))
                    throw new Exception("Transform byte ABI did not apply the local pose.");
                using (var lua = new XLua.LuaEnv())
                {
                    lua.Global.Set("render_batch", batch);
                    lua.Global.Set("render_target", child.transform);
                    lua.Global.Set("render_record", record);
                    lua.DoString("assert(render_batch:Bind(render_target) == 1); " +
                        "render_batch:Apply(render_record); " +
                        "render_batch=nil; render_target=nil; render_record=nil; collectgarbage('collect')");
                }
                byte[] invalid = new byte[2 * ModuleTransformBatch.RecordStride];
                WriteRecord(invalid, 0, handle, 1, new Vector3(9, 9, 9), Quaternion.identity, Vector3.one);
                WriteRecord(invalid, 1, 999, 1, new Vector3(8, 8, 8), Quaternion.identity, Vector3.one);
                Reject<ArgumentOutOfRangeException>(() => batch.Apply(invalid));
                if (child.transform.localPosition != new Vector3(2, 3, 4))
                    throw new Exception("Invalid later record caused a partial Transform update.");
                WriteFloat(record, 8, float.NaN);
                Reject<ArgumentException>(() => batch.Apply(record));
                if (child.transform.localPosition != new Vector3(2, 3, 4))
                    throw new Exception("Non-finite record caused a partial Transform update.");
                bridge.Root.position = new Vector3(10, 0, 0);
                WriteRecord(record, 0, handle, 1 | 8, new Vector3(7, 8, 9), Quaternion.identity, Vector3.one);
                batch.Apply(record);
                if (child.transform.position != new Vector3(7, 8, 9) ||
                    child.transform.localPosition != new Vector3(-3, 8, 9))
                    throw new Exception("World-space Transform update used local coordinates.");
                var dead = new GameObject("dead-batch-target");
                dead.transform.SetParent(bridge.Root, false);
                int deadHandle = batch.Bind(dead.transform);
                UnityEngine.Object.DestroyImmediate(dead);
                WriteRecord(invalid, 0, handle, 1, new Vector3(5, 5, 5), Quaternion.identity, Vector3.one);
                WriteRecord(invalid, 1, deadHandle, 1, new Vector3(6, 6, 6), Quaternion.identity, Vector3.one);
                Reject<InvalidOperationException>(() => batch.Apply(invalid));
                if (child.transform.position != new Vector3(7, 8, 9))
                    throw new Exception("Destroyed later target caused a partial Transform update.");
                batch.Dispose();
                Reject<ObjectDisposedException>(() => batch.Apply(Array.Empty<byte>()));
                if (TrackedBatchCount(bridge) != 0)
                    throw new Exception("Disposed Transform batch still retains the bridge.");
                if (child == null) throw new Exception("Batch Dispose destroyed the borrowed Transform.");
            }
            finally { UnityEngine.Object.DestroyImmediate(foreign); }
        }

        private static void CheckUnsupportedModule()
        {
            var oldProfile = new HostProfile(7, "editor", Application.unityVersion, new[] { "lua" });
            if (oldProfile.SupportsCapability("unity_render_batch_v1"))
                throw new Exception("Registry advertised a capability absent from an installed host profile.");
            using var scope = Scope(false);
            using var bridge = new GameHostBridge(null, scope, "batchcheck", null);
            if (bridge.SupportsRenderBatch) throw new Exception("Undeclared capability was offered to an old module.");
            Reject<InvalidOperationException>(() => bridge.CreateTransformBatch());
        }

        private static void CheckRepeatedLevelCleanup()
        {
            using var scope = Scope();
            using var bridge = new GameHostBridge(null, scope, "batchcheck", null);
            var buffers = new ModuleMeshBuffer[64];
            var meshes = new Mesh[64];
            try
            {
                for (int i = 0; i < buffers.Length; i++)
                {
                    meshes[i] = new Mesh();
                    buffers[i] = bridge.CreateMeshBuffer(meshes[i]);
                }
                if (TrackedBatchCount(bridge) != 64)
                    throw new Exception("Mesh batch pressure setup did not create 64 tracked buffers.");
                for (int i = 0; i < buffers.Length; i++)
                {
                    buffers[i].Dispose();
                    buffers[i].Dispose();
                    if (TrackedBatchCount(bridge) != 63 - i || BorrowedMesh(buffers[i]) != null)
                        throw new Exception("Disposed Mesh buffer remained in the host registry or retained its Mesh.");
                    UnityEngine.Object.DestroyImmediate(meshes[i]);
                    meshes[i] = null;
                }

                for (int level = 0; level < 4; level++)
                {
                    var root = new GameObject("batch-level-" + level);
                    root.transform.SetParent(bridge.Root, false);
                    var levelBatch = bridge.CreateTransformBatch();
                    levelBatch.Bind(root.transform);
                    var levelBuffers = new ModuleMeshBuffer[7];
                    var levelMeshes = new Mesh[7];
                    try
                    {
                        for (int i = 0; i < levelBuffers.Length; i++)
                        {
                            levelMeshes[i] = new Mesh();
                            levelBuffers[i] = bridge.CreateMeshBuffer(levelMeshes[i]);
                        }
                        if (TrackedBatchCount(bridge) != 8)
                            throw new Exception("Repeated level setup did not track eight batches.");
                    }
                    finally
                    {
                        foreach (ModuleMeshBuffer buffer in levelBuffers) buffer?.Dispose();
                        foreach (Mesh mesh in levelMeshes)
                            if (mesh != null) UnityEngine.Object.DestroyImmediate(mesh);
                        levelBatch.Dispose();
                        UnityEngine.Object.DestroyImmediate(root);
                    }
                    if (TrackedBatchCount(bridge) != 0)
                        throw new Exception("Host registry grew after a completed level cycle.");
                }

                var pendingMesh = new Mesh();
                try
                {
                    ModuleMeshBuffer pendingBuffer = bridge.CreateMeshBuffer(pendingMesh);
                    ModuleTransformBatch pendingBatch = bridge.CreateTransformBatch();
                    if (TrackedBatchCount(bridge) != 2)
                        throw new Exception("Host disposal setup did not track both pending batches.");
                    bridge.Dispose();
                    bridge.Dispose();
                    if (TrackedBatchCount(bridge) != 0 || BorrowedMesh(pendingBuffer) != null)
                        throw new Exception("Host disposal did not release pending batch references.");
                    Reject<ObjectDisposedException>(() => pendingBuffer.Clear());
                    Reject<ObjectDisposedException>(() => pendingBatch.Clear());
                    if (pendingMesh == null) throw new Exception("Host destroyed a borrowed Mesh.");
                }
                finally { UnityEngine.Object.DestroyImmediate(pendingMesh); }
            }
            finally
            {
                foreach (Mesh mesh in meshes)
                    if (mesh != null) UnityEngine.Object.DestroyImmediate(mesh);
            }
        }

        private static void WriteVertex(byte[] bytes, int index, Vector3 position)
        {
            int o = index * ModuleMeshBuffer.VertexStride;
            WriteFloat(bytes, o, position.x); WriteFloat(bytes, o + 4, position.y); WriteFloat(bytes, o + 8, position.z);
            WriteFloat(bytes, o + 20, -1f); WriteFloat(bytes, o + 24, 1f); WriteFloat(bytes, o + 36, -1f);
            bytes[o + 40] = bytes[o + 41] = bytes[o + 42] = bytes[o + 43] = 255;
        }

        private static void WriteRecord(byte[] bytes, int index, int handle, int flags,
            Vector3 position, Quaternion rotation, Vector3 scale)
        {
            int o = index * ModuleTransformBatch.RecordStride;
            WriteInt(bytes, o, handle); WriteInt(bytes, o + 4, flags);
            WriteFloat(bytes, o + 8, position.x); WriteFloat(bytes, o + 12, position.y); WriteFloat(bytes, o + 16, position.z);
            WriteFloat(bytes, o + 20, rotation.x); WriteFloat(bytes, o + 24, rotation.y);
            WriteFloat(bytes, o + 28, rotation.z); WriteFloat(bytes, o + 32, rotation.w);
            WriteFloat(bytes, o + 36, scale.x); WriteFloat(bytes, o + 40, scale.y); WriteFloat(bytes, o + 44, scale.z);
        }

        private static void WriteFloat(byte[] bytes, int offset, float value) =>
            Array.Copy(BitConverter.GetBytes(value), 0, bytes, offset, 4);
        private static void WriteInt(byte[] bytes, int offset, int value) =>
            Array.Copy(BitConverter.GetBytes(value), 0, bytes, offset, 4);
        private static void Reject<T>(Action action) where T : Exception
        {
            try { action(); } catch (T) { return; }
            throw new Exception("Expected " + typeof(T).Name + " was not thrown.");
        }

        private static int TrackedBatchCount(GameHostBridge bridge)
        {
            var field = typeof(GameHostBridge).GetField("_renderBatches", BindingFlags.NonPublic | BindingFlags.Instance);
            return ((ICollection)field.GetValue(bridge)).Count;
        }

        private static object BorrowedMesh(ModuleMeshBuffer buffer) =>
            typeof(ModuleMeshBuffer).GetField("_mesh", BindingFlags.NonPublic | BindingFlags.Instance)?.GetValue(buffer);
    }
}
