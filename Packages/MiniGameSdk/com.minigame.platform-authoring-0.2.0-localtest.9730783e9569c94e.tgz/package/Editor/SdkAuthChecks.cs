using System;
using System.Collections.Generic;
using MiniGamePlatform.SDK.Auth;
using MiniGamePlatform.SDK.Network;
using UnityEditor;
using UnityEngine;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public static class SdkAuthChecks
    {
        [MenuItem("MiniGame Platform/SDK/Run Auth Checks")]
        public static void Run()
        {
            var transport = new ScriptedTransport();
            var store = new EditorMemoryCredentialStore();
            var session = new PlatformSession(transport, store, "hub");
            session.LoginGuest(result => Assert(result.IsSuccess && result.Data.userId == "account-1", "guest login failed"));
            Assert(store.TryLoad(out CredentialState saved) && saved.GuestCredential == "guest-secret" && saved.RefreshToken == "refresh-old", "guest credentials were not persisted");
            session.CreateLinkCode(_ => { });
            Assert(transport.LastLinkRequest != null && transport.LastLinkRequest.BodyJson == "{}", "link-code request did not declare empty JSON body");
            session.SendAuthorized<Probe>(new ApiRequest("GET", "/v1/games/game-a/leaderboards/campaign_progress",
                query: new Dictionary<string, string> { { "seasonId", "all_time" } }), _ => { });
            Assert(transport.LastProtectedPathAndQuery.Contains("seasonId=all_time"), "auth wrapper discarded query parameters");

            int completed = 0;
            transport.ExpiredAccessToken = "access-old";
            session.SendAuthorized<Probe>(new ApiRequest("GET", "/v1/platform/wallet"), result => { Assert(result.IsSuccess, "first protected request failed"); completed++; });
            session.SendAuthorized<Probe>(new ApiRequest("GET", "/v1/platform/wallet"), result => { Assert(result.IsSuccess, "second protected request failed"); completed++; });
            Assert(transport.RefreshKeys.Count == 1 && completed == 0, "concurrent 401s did not share one refresh");
            transport.CompleteRefresh();
            Assert(completed == 2, "protected requests were not replayed");
            Assert(store.TryLoad(out saved) && saved.RefreshToken == "refresh-new" && saved.PendingRefreshKey == null, "refreshed credentials were not saved atomically");

            transport.ExpiredAccessToken = "access-new";
            transport.FailNextRefresh = true;
            session.SendAuthorized<Probe>(new ApiRequest("GET", "/v1/platform/wallet"), result => Assert(!result.IsSuccess && result.Retryable, "uncertain refresh was treated as definitive"));
            string pendingKey = transport.RefreshKeys[1];
            Assert(store.TryLoad(out saved) && saved.PendingRefreshKey == pendingKey, "uncertain refresh key was not persisted");
            bool retrySucceeded = false;
            session.SendAuthorized<Probe>(new ApiRequest("GET", "/v1/platform/wallet"), result => { Assert(result.IsSuccess, "refresh retry failed"); retrySucceeded = true; });
            Assert(transport.RefreshKeys[2] == pendingKey, "uncertain refresh changed its idempotency key");
            transport.CompleteRefresh();
            Assert(retrySucceeded, "refresh retry did not resume request");
            transport.ExpiredAccessToken = "access-final";
            session.Logout(result => Assert(result.IsSuccess, "logout failed"));
            transport.CompleteRefresh();
            Assert(transport.LogoutHadBearer, "logout did not carry platform bearer token");
            Assert(transport.LogoutUsedCurrentRefreshToken, "logout used a refresh token rotated after its body was built");
            Assert(!store.TryLoad(out saved), "logout did not erase local credentials");

            var staleStore = new EditorMemoryCredentialStore();
            staleStore.Save(new CredentialState
            {
                DeviceId = "device-installation-1234567890",
                UserId = "account-1",
                GuestCredential = "guest-secret",
                RefreshToken = "refresh-old",
                PendingRefreshKey = "stale-refresh-key",
                PendingRefreshStartedAtUnixSeconds = 1
            });
            var staleTransport = new ScriptedTransport();
            var staleSession = new PlatformSession(staleTransport, staleStore, "hub");
            bool recovered = false;
            staleSession.SendAuthorized<Probe>(new ApiRequest("GET", "/v1/platform/wallet"), result => recovered = result.IsSuccess);
            Assert(recovered && staleTransport.RefreshKeys.Count == 0, "expired refresh recovery retried the old token");
            Assert(staleStore.TryLoad(out saved) && saved.GuestCredential == "guest-secret" && saved.PendingRefreshKey == null, "guest recovery lost the saved credential");

            Debug.Log("SDK auth checks passed.");
        }

        private static void Assert(bool condition, string message)
        {
            if (!condition) throw new Exception(message);
        }

        [Serializable] private sealed class Probe { public string value; }

        private sealed class ScriptedTransport : IPlatformTransport
        {
            public readonly List<string> RefreshKeys = new List<string>();
            public string ExpiredAccessToken;
            public bool FailNextRefresh;
            public bool LogoutHadBearer;
            public bool LogoutUsedCurrentRefreshToken;
            public string LastProtectedPathAndQuery;
            public ApiRequest LastLinkRequest;
            private Action _completeRefresh;

            public void Send<T>(ApiRequest request, Action<ApiResult<T>> callback)
            {
                if (request.Path == "/v1/platform/auth/guest")
                {
                    string guest = request.BodyJson != null && request.BodyJson.Contains("guestCredential") ? "" : "\"guestCredential\":\"guest-secret\",";
                    callback(ApiResult<T>.FromJson("{\"data\":{\"userId\":\"account-1\"," + guest + "\"accessToken\":\"access-old\",\"refreshToken\":\"refresh-old\",\"expiresInSeconds\":900},\"meta\":{\"requestId\":\"guest\"}}", 201));
                    return;
                }
                if (request.Path == "/v1/platform/auth/refresh")
                {
                    RefreshKeys.Add(request.IdempotencyKey);
                    if (FailNextRefresh)
                    {
                        FailNextRefresh = false;
                        callback(ApiResult<T>.NetworkFailure("NETWORK_UNCERTAIN", true));
                    }
                    else
                    {
                        string access = RefreshKeys.Count == 1 ? "access-new" : RefreshKeys.Count < 4 ? "access-final" : "access-logout";
                        string refresh = RefreshKeys.Count == 1 ? "refresh-new" : RefreshKeys.Count < 4 ? "refresh-final" : "refresh-logout";
                        _completeRefresh = () => callback(ApiResult<T>.FromJson("{\"data\":{\"accessToken\":\"" + access + "\",\"refreshToken\":\"" + refresh + "\",\"expiresInSeconds\":900},\"meta\":{\"requestId\":\"refresh\"}}", 200));
                    }
                    return;
                }
                if (request.AccessToken == ExpiredAccessToken)
                {
                    callback(ApiResult<T>.FromJson("{\"error\":{\"code\":\"UNAUTHORIZED\",\"retryable\":false},\"meta\":{\"requestId\":\"expired\"}}", 401));
                    return;
                }
                if (request.Path == "/v1/platform/auth/logout")
                {
                    LogoutHadBearer = !string.IsNullOrEmpty(request.AccessToken);
                    LogoutUsedCurrentRefreshToken = request.BodyJson != null && request.BodyJson.Contains("\"refreshToken\":\"refresh-logout\"");
                }
                if (request.Path == "/v1/platform/auth/link-code") LastLinkRequest = request;
                LastProtectedPathAndQuery = request.RelativePathAndQuery;
                callback(ApiResult<T>.FromJson("{\"data\":{\"value\":\"ok\"},\"meta\":{\"requestId\":\"protected\"}}", 200));
            }

            public void CompleteRefresh()
            {
                Action complete = _completeRefresh;
                _completeRefresh = null;
                if (complete == null) throw new Exception("No refresh to complete.");
                complete();
            }
        }
    }
}
