using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using MiniGamePlatform.HotUpdate;
using UnityEditor;
using UnityEngine;

namespace MiniGamePlatform.SDK.EditorChecks
{
    // Real bundles, in one Editor domain; no global unload or cache reset between iterations.
    public static class ModuleResourceLifetimeChecks
    {
        private const string Source = "Assets/__ModuleResourceLifetimeChecks";
        private static int _checks;
        private static void Check(bool condition, string message)
        { _checks++; if (!condition) throw new Exception(message); }

        [MenuItem("MiniGame Platform/Run Resource Lifetime Checks")]
        public static void Run()
        {
            if (AssetDatabase.IsValidFolder(Source))
                throw new InvalidOperationException("Resource test folder already exists; refusing to overwrite it.");
            string output = Path.GetFullPath("Temp/sdk-resource-lifetime-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(output);
            AssetDatabase.CreateFolder("Assets", "__ModuleResourceLifetimeChecks");
            _checks = 0;
            try
            {
                var material = new Material(Shader.Find("Unlit/Color"));
                AssetDatabase.CreateAsset(material, Source + "/material.mat");
                var node = new GameObject("Lifetime prefab");
                node.AddComponent<MeshRenderer>().sharedMaterial = material;
                PrefabUtility.SaveAsPrefabAsset(node, Source + "/prefab.prefab");
                UnityEngine.Object.DestroyImmediate(node);
                AssetDatabase.SaveAssets();
                for (int iteration = 0; iteration < 3; iteration++)
                {
                    var build = new AssetBundleBuild { assetBundleName = "lifetime.bundle",
                        assetNames = new[] { Source + "/prefab.prefab", Source + "/material.mat" } };
                    Check(BuildPipeline.BuildAssetBundles(output, new[] { build },
                        BuildAssetBundleOptions.ForceRebuildAssetBundle, BuildTarget.StandaloneWindows64) != null,
                        "Bundle rebuild failed at iteration " + iteration);
                    byte[] bytes = File.ReadAllBytes(Path.Combine(output, "lifetime.bundle"));
                    string hash;
                    using (var sha = SHA256.Create()) hash = BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant();
                    var manifest = new ModuleManifest { gameId = "lifetime", version = "v1",
                        minHostApiVersion = 6, requiredCapabilities = new[] { "assetbundle", "module_owned_resources_v1" },
                        files = new[] { new ModuleFile { path = "lifetime.bundle", size = bytes.Length, sha256 = hash } } };
                    using (var first = new ModuleAssetScope(manifest, output))
                    {
                        GameObject instance = first.InstantiatePrefab("lifetime.bundle", Source + "/prefab.prefab", null);
                        Material borrowed = instance.GetComponent<MeshRenderer>().sharedMaterial;
                        first.Dispose();
                        Check(instance == null, "Disposed scope left its owned instance alive.");
                        Check(borrowed == null, "Last bundle lease left its borrowed material alive.");
                        first.Dispose();
                    }
                    using (var first = new ModuleAssetScope(manifest, output))
                    using (var second = new ModuleAssetScope(manifest, output))
                    {
                        GameObject a = first.InstantiatePrefab("lifetime.bundle", Source + "/prefab.prefab", null);
                        GameObject b = second.InstantiatePrefab("lifetime.bundle", Source + "/prefab.prefab", null);
                        Material shared = b.GetComponent<MeshRenderer>().sharedMaterial;
                        Check(a.GetComponent<MeshRenderer>().sharedMaterial == shared, "Scopes did not share one bundle lease.");
                        first.Dispose();
                        Check(a == null && b != null && shared != null, "First release destroyed another scope's resources.");
                        second.Dispose();
                        Check(b == null && shared == null, "Last release did not reclaim resources.");
                    }
                    Check(!AssetBundle.GetAllLoadedAssetBundles().Any(bundle => bundle.name == "lifetime.bundle"),
                        "Test bundle still loaded after both scopes exited.");
                }
                Debug.Log("RESOURCE_LIFETIME_CHECKS_PASSED assertions=" + _checks);
            }
            finally { AssetDatabase.DeleteAsset(Source); }
        }
    }
}
