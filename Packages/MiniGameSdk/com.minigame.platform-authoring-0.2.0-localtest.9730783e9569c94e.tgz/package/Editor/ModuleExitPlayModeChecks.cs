using System;
using System.IO;
using System.Security.Cryptography;
using MiniGamePlatform.HotUpdate;
using UnityEditor;
using UnityEngine;

namespace MiniGamePlatform.SDK.EditorChecks
{
    [InitializeOnLoad]
    public static class ModuleExitPlayModeChecks
    {
        private const string Key = "MGP.ExitBoundaryCheck";
        private static ModulePlayerBehaviour _host;
        private static ModulePlayer _player;
        private static ProductContext _product;
        private static string _directory, _hash;
        private static int _phase, _frame;
        private static double _started;
        private static LuaGameRunner _pendingRunner;
        private static XLua.LuaEnv _pendingEnv;
        private static UnityEngine.Events.UnityEvent _external;
        private static double _retryAt;
        private static System.Reflection.FieldInfo RetryTime => typeof(LuaGameRunner).GetField("_nextAutomaticExitRetryAt",
            System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
        static ModuleExitPlayModeChecks()
        {
            EditorApplication.playModeStateChanged += Changed;
            EditorApplication.update += Tick;
        }
        public static void Run()
        {
            SessionState.SetBool(Key, true); SessionState.SetBool(Key + ".failed", false);
            EditorApplication.isPlaying = true;
        }
        private static void Check(bool value, string message) { if (!value) throw new Exception(message); }
        private static void Changed(PlayModeStateChange state)
        {
            if (!SessionState.GetBool(Key, false)) return;
            if (state == PlayModeStateChange.EnteredPlayMode)
            {
                _phase = 1; _started = EditorApplication.timeSinceStartup;
            }
            if (state == PlayModeStateChange.EnteredEditMode)
            {
                bool failed = SessionState.GetBool(Key + ".failed", true);
                SessionState.SetBool(Key, false);
                if (!failed) Debug.Log("MODULE_EXIT_PLAYMODE_CHECKS_PASSED");
                if (Application.isBatchMode) EditorApplication.Exit(failed ? 1 : 0);
            }
        }
        private static void Tick()
        {
            if (!SessionState.GetBool(Key, false) || !EditorApplication.isPlaying || _phase == 0) return;
            try
            {
                if (EditorApplication.timeSinceStartup - _started > 30) throw new TimeoutException("Exit boundary play check timed out.");
                if (_phase == 1)
                {
                    _directory = Path.Combine(Application.temporaryCachePath, "exit-boundary-" + Guid.NewGuid().ToString("N"));
                    Directory.CreateDirectory(Path.Combine(_directory, "games/exitcheck"));
                    byte[] lua = System.Text.Encoding.UTF8.GetBytes("return {enter=function(h) local n=CS.UnityEngine.GameObject('Owned Child'); n.transform:SetParent(h.Root,false) end}");
                    File.WriteAllBytes(Path.Combine(_directory, "games/exitcheck/main.lua"), lua);
                    string Hash(byte[] data) { using var sha = SHA256.Create(); return BitConverter.ToString(sha.ComputeHash(data)).Replace("-", "").ToLowerInvariant(); }
                    var manifest = new ModuleManifest { formatVersion=1, gameId="exitcheck", version="v1", runtimeType="unity_lua",
                        entry="games.exitcheck.main", minHostApiVersion=6, platform="editor", unityVersion=Application.unityVersion,
                        requiredCapabilities=new[]{"lua","module_owned_resources_v1"},
                        files=new[]{new ModuleFile {path="games/exitcheck/main.lua",size=lua.Length,sha256=Hash(lua)}} };
                    byte[] json = System.Text.Encoding.UTF8.GetBytes(JsonUtility.ToJson(manifest));
                    File.WriteAllBytes(Path.Combine(_directory,"manifest.json"),json); _hash=Hash(json);
                    _product = new ProductContext("exit_test","https://example.invalid","1.0.0",new[]{"exitcheck"});
                    _host = new GameObject("Exit Boundary Host").AddComponent<ModulePlayerBehaviour>();
                    _host.Initialize("hub",null,_product,null);
                    _host.OpenInstalled(_directory,_hash,null,null); _player=_host.Player;
                    _host.Exit();
                    Check(_player.HasPendingExit,"Player falsely completed exit before deferred Destroy.");
                    bool rejected=false;
                    try { _host.OpenInstalled(_directory,_hash,null,null); }
                    catch(ModuleRunException error) { rejected=error.Code=="EXIT_PENDING"; }
                    Check(rejected,"Player entered another module during pending resource release.");
                    _frame=Time.frameCount; _phase=2;
                }
                else if (_phase==2 && Time.frameCount>_frame+2)
                {
                    Check(!_player.HasPendingExit,"Deferred resource release did not complete.");
                    _host.OpenInstalled(_directory,_hash,null,null);
                    Check(_player.State==GameRunState.Running,"Player could not re-enter after cleanup.");
                    UnityEngine.Object.Destroy(_host.gameObject);
                    _frame=Time.frameCount; _phase=3;
                }
                else if (_phase==3 && Time.frameCount>_frame+3)
                {
                    Check(_host==null && !_player.HasPendingExit,"Destroying the product shell lost pending cleanup.");
                    Check(GameObject.Find("Owned Child")==null,"Module child survived host destruction.");
                    _pendingRunner = new LuaGameRunner();
                    _pendingRunner.Enter(ModuleManifest.Parse(File.ReadAllText(Path.Combine(_directory,"manifest.json"))), _directory, null);
                    _pendingEnv = (XLua.LuaEnv)typeof(LuaGameRunner).GetField("_environment",
                        System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance).GetValue(_pendingRunner);
                    _external = new UnityEngine.Events.UnityEvent();
                    _pendingEnv.Global.Set("external_event", _external);
                    _pendingEnv.DoString("external_event:AddListener(function() end)");
                    _pendingRunner.Exit();
                    Check(_pendingRunner.HasPendingExit, "Retained external callback did not block VM close.");
                    _retryAt = (double)RetryTime.GetValue(_pendingRunner);
                    _frame=Time.frameCount; _phase=4;
                }
                else if (_phase==4)
                {
                    _pendingRunner.Tick(); // An idle shell must not add a second automatic GC/retry loop.
                    if (Time.realtimeSinceStartupAsDouble < _retryAt)
                        Check((double)RetryTime.GetValue(_pendingRunner)==_retryAt, "Pending VM was retried before its backoff expired.");
                    if (Time.frameCount<=_frame+3) return;
                    _external.RemoveAllListeners();
                    _pendingEnv.DoString("external_event=nil");
                    _phase=5;
                }
                else if (_phase==5 && !_pendingRunner.HasPendingExit)
                {
                    Check(GameObject.Find("Owned Child")==null,"Resource scope released before/without successful VM cleanup.");
                    bool closed=false;
                    try { var state=_pendingEnv.L; } catch(InvalidOperationException) {closed=true;}
                    Check(closed,"Persistent retry driver did not close the recovered VM.");
                    _pendingRunner=null; _pendingEnv=null; _external=null;
                    _phase=0; EditorApplication.isPlaying=false;
                }
            }
            catch(Exception exception)
            {
                SessionState.SetBool(Key+".failed",true); Debug.LogException(exception);
                _external?.RemoveAllListeners(); _pendingRunner?.Exit();
                _player?.Exit(); if(_host!=null) UnityEngine.Object.Destroy(_host.gameObject);
                _phase=0; EditorApplication.isPlaying=false;
            }
        }
    }
}
