using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using MiniGamePlatform.SDK.Network;
using UnityEngine;

namespace MiniGamePlatform.SDK.GameData
{
    [Serializable] public sealed class GardenStartRequest
    {
        public int contractVersion = 1, ruleVersion = 1;
        public long expectedProgressVersion;
        public string moduleVersion, moduleManifestSha256, levelBaselineSha256;
    }
    [Serializable] public sealed class GardenInputFact
    {
        public int sequence;
        public string kind;
        public int boxId;
        public double deltaSeconds;
        public static GardenInputFact Tap(int sequence, int boxId) => new GardenInputFact { sequence = sequence, kind = "tap", boxId = boxId };
        public static GardenInputFact Advance(int sequence, double deltaSeconds) => new GardenInputFact { sequence = sequence, kind = "advance", deltaSeconds = deltaSeconds };
    }
    [Serializable] public sealed class GardenFactsRequest
    {
        public int contractVersion = 1, ruleVersion = 1;
        public string stableLevelId, moduleManifestSha256, levelBaselineSha256;
        public GardenInputFact[] facts;
    }
    [Serializable] public sealed class GardenSyncRequest
    {
        public int contractVersion = 1, saveSchemaVersion = 9;
        public string operationId;
        public long expectedProgressVersion;
        public string[] completedLevelIds;
    }
    [Serializable] public sealed class GardenProgress
    {
        public string gameId, userId, activeSessionId;
        public bool localOnly, sharedRewardsEnabled, leaderboardEnabled;
        public long progressVersion;
        public string[] reportedCompletedLevelIds, verifiedCompletedLevelIds;
        public bool HasActiveSession => !string.IsNullOrEmpty(activeSessionId);
    }
    [Serializable] public sealed class GardenSessionStart
    {
        public string gameId, sessionId, stableLevelId, moduleVersion, moduleManifestSha256, levelBaselineSha256, expiresAt, status;
        public int contractVersion, ruleVersion;
        public long configVersion, progressVersion;
        public bool localOnly, authoritativeValidation, settlementEnabled;
    }
    [Serializable] public sealed class GardenFactsReceipt
    {
        public string gameId, sessionId, stableLevelId, validationStatus, reason, factsSha256;
        public int contractVersion, ruleVersion, receivedFactCount;
        public long configVersion;
        public bool localOnly, rewardsGranted, leaderboardUpdated;
    }
    [Serializable] public sealed class GardenCapabilities
    {
        public string gameId, gameStatus, ruleStatus;
        public int contractVersion, ruleVersion, offlineSaveSchemaVersion, maxFactsPerSubmission;
        public bool localOnly, authoritativeValidation, settlementEnabled, sharedRewardsEnabled, leaderboardEnabled;
        public string[] supportedSessionLevelIds, supportedFactKinds, missingValidationInputs;
    }

    // Capture acknowledgement deliberately has no IsSuccess/outcome/reward model.
    public sealed class GardenFactsResult
    {
        public GardenFactsReceipt Receipt { get; }
        public string ErrorCode { get; }
        public string ErrorMessage { get; }
        public string RequestId { get; }
        public int HttpStatus { get; }
        public bool Retryable { get; }
        public bool IsAcceptedUnverified => ErrorCode == null && Receipt != null;
        public bool IsVerifiedWin => false;
        public bool RewardsGranted => false;
        public bool LeaderboardUpdated => false;
        internal GardenFactsResult(ApiResult<GardenFactsReceipt> result)
        {
            Receipt = result.IsSuccess ? result.Data : null;
            ErrorCode = result.ErrorCode; ErrorMessage = result.ErrorMessage; RequestId = result.RequestId;
            HttpStatus = result.HttpStatus; Retryable = result.Retryable;
        }
    }

    public static class GardenContract
    {
        public const string TrialLevelId = "garden.campaign.2";
        public const int MaxFacts = 4096;
        public const long MaxVersion = 9007199254740991;
        public const string Capability = "garden_local_api";
        private static readonly Regex Level = new Regex(@"\Agarden\.campaign\.([1-9]|[1-9][0-9]|[12][0-9]{2}|300)\z", RegexOptions.CultureInvariant);
        private static readonly Regex Hash = new Regex(@"\A[a-f0-9]{64}\z", RegexOptions.CultureInvariant);
        private static readonly Regex Module = new Regex(@"\A[A-Za-z0-9._-]{1,64}\z", RegexOptions.CultureInvariant);
        private static readonly Regex Key = new Regex(@"\A[A-Za-z0-9._:-]{8,128}\z", RegexOptions.CultureInvariant);
        public static bool IsStableLevelId(string value) => value != null && Level.IsMatch(value);
        internal static bool IsVersion(long value) => value >= 1 && value <= MaxVersion;
        internal static bool IsHash(string value) => value != null && Hash.IsMatch(value);
        internal static bool IsSessionId(string value) => Guid.TryParseExact(value, "D", out _);
        internal static bool IsOperationId(string value) => value != null && Key.IsMatch(value);
        internal static bool IsProduct(string value) => value == "garden_local_test" || value == "hub_local_test";

        public static string SerializeStart(GardenStartRequest value)
        {
            if (value == null || value.contractVersion != 1 || value.ruleVersion != 1 || !IsVersion(value.expectedProgressVersion) ||
                !IsHash(value.moduleManifestSha256) || !IsHash(value.levelBaselineSha256) || !Module.IsMatch(value.moduleVersion ?? ""))
                throw new ArgumentException("Invalid Garden v1 start context.");
            return Budget(JsonUtility.ToJson(value));
        }

        [Serializable] private sealed class FactsHeader
        {
            public int contractVersion, ruleVersion;
            public string stableLevelId, moduleManifestSha256, levelBaselineSha256;
        }
        public static string SerializeFacts(GardenFactsRequest value)
        {
            if (value == null || value.contractVersion != 1 || value.ruleVersion != 1 || value.stableLevelId != TrialLevelId ||
                !IsHash(value.moduleManifestSha256) || !IsHash(value.levelBaselineSha256) ||
                value.facts == null || value.facts.Length < 1 || value.facts.Length > MaxFacts)
                throw new ArgumentException("Invalid Garden v1 facts context or count; inputs must not be dropped or truncated.");
            string header = JsonUtility.ToJson(new FactsHeader { contractVersion = 1, ruleVersion = 1,
                stableLevelId = value.stableLevelId, moduleManifestSha256 = value.moduleManifestSha256, levelBaselineSha256 = value.levelBaselineSha256 });
            var json = new StringBuilder(header.Substring(0, header.Length - 1)).Append(",\"facts\":[");
            for (int i = 0; i < value.facts.Length; i++)
            {
                var fact = value.facts[i];
                if (fact == null || fact.sequence != i) throw new ArgumentException("Facts must have contiguous zero-based sequence numbers.");
                if (i > 0) json.Append(',');
                json.Append("{\"sequence\":").Append(i.ToString(CultureInfo.InvariantCulture));
                if (fact.kind == "tap" && fact.boxId > 0 && fact.deltaSeconds == 0)
                    json.Append(",\"kind\":\"tap\",\"boxId\":").Append(fact.boxId.ToString(CultureInfo.InvariantCulture));
                else if (fact.kind == "advance" && fact.boxId == 0 && fact.deltaSeconds > 0 && fact.deltaSeconds <= 1 && !double.IsNaN(fact.deltaSeconds))
                    json.Append(",\"kind\":\"advance\",\"deltaSeconds\":").Append(fact.deltaSeconds.ToString("R", CultureInfo.InvariantCulture));
                else throw new ArgumentException("Unsupported or invalid Garden fact. Do not omit gameplay inputs to fit this contract.");
                json.Append('}');
            }
            return Budget(json.Append("]}").ToString());
        }

        public static string SerializeSync(GardenSyncRequest value)
        {
            if (value == null || value.contractVersion != 1 || value.saveSchemaVersion != 9 || !IsOperationId(value.operationId) ||
                !IsVersion(value.expectedProgressVersion) || !ValidLevels(value.completedLevelIds))
                throw new ArgumentException("Invalid Garden schema 9 milestone sync. Only explicit stable IDs are supported.");
            var levels = (string[])value.completedLevelIds.Clone();
            Array.Sort(levels, StringComparer.Ordinal);
            return Budget(JsonUtility.ToJson(new GardenSyncRequest { contractVersion = 1, saveSchemaVersion = 9,
                operationId = value.operationId, expectedProgressVersion = value.expectedProgressVersion, completedLevelIds = levels }));
        }

        internal static bool ValidLevels(string[] values)
        {
            if (values == null || values.Length > 300) return false;
            var seen = new HashSet<string>(StringComparer.Ordinal);
            foreach (string value in values) if (!IsStableLevelId(value) || !seen.Add(value)) return false;
            return true;
        }

        internal static bool ValidProgress(GardenProgress value, string userId) => value != null && value.gameId == "garden" &&
            value.userId == userId && value.localOnly && IsVersion(value.progressVersion) && ValidLevels(value.reportedCompletedLevelIds) &&
            value.verifiedCompletedLevelIds != null && value.verifiedCompletedLevelIds.Length == 0 &&
            // Unity JsonUtility maps a JSON null string to an empty string.
            (string.IsNullOrEmpty(value.activeSessionId) || IsSessionId(value.activeSessionId)) && !value.sharedRewardsEnabled && !value.leaderboardEnabled;

        internal static bool ValidStart(GardenSessionStart value, GardenStartRequest request) => value != null && value.gameId == "garden" &&
            IsSessionId(value.sessionId) && value.stableLevelId == TrialLevelId && value.contractVersion == 1 && value.ruleVersion == 1 &&
            IsVersion(value.configVersion) && value.progressVersion == request.expectedProgressVersion &&
            value.moduleVersion == request.moduleVersion && value.moduleManifestSha256 == request.moduleManifestSha256 &&
            value.levelBaselineSha256 == request.levelBaselineSha256 && value.status == "started" && value.localOnly &&
            !value.authoritativeValidation && !value.settlementEnabled && DateTimeOffset.TryParse(value.expiresAt,
                CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out _);

        internal static bool ValidReceipt(GardenFactsReceipt value, string sessionId, GardenFactsRequest request) => value != null &&
            value.gameId == "garden" && value.sessionId == sessionId && value.stableLevelId == request.stableLevelId &&
            value.contractVersion == 1 && value.ruleVersion == 1 && IsVersion(value.configVersion) && value.localOnly &&
            value.validationStatus == "unverified" && value.reason == "GARDEN_VALIDATOR_NOT_IMPLEMENTED" &&
            value.receivedFactCount == request.facts.Length && IsHash(value.factsSha256) && !value.rewardsGranted && !value.leaderboardUpdated;

        internal static bool ValidCapabilities(GardenCapabilities value) => value != null && value.gameId == "garden" &&
            !string.IsNullOrEmpty(value.gameStatus) && value.localOnly && value.contractVersion == 1 && value.ruleVersion == 1 &&
            value.ruleStatus == "capture_only" && value.offlineSaveSchemaVersion == 9 && value.maxFactsPerSubmission == MaxFacts &&
            !value.authoritativeValidation && !value.settlementEnabled && !value.sharedRewardsEnabled && !value.leaderboardEnabled &&
            value.supportedSessionLevelIds != null && value.supportedSessionLevelIds.Length == 1 && value.supportedSessionLevelIds[0] == TrialLevelId &&
            value.supportedFactKinds != null && value.supportedFactKinds.Length == 2 &&
            Array.IndexOf(value.supportedFactKinds, "tap") >= 0 && Array.IndexOf(value.supportedFactKinds, "advance") >= 0 &&
            value.missingValidationInputs != null;

        private static string Budget(string json)
        {
            if (Encoding.UTF8.GetByteCount(json) > 1024 * 1024) throw new ArgumentException("Garden body exceeds 1 MiB.");
            return json;
        }
    }
}
