using System;
using MiniGamePlatform.SDK.Auth;

namespace MiniGamePlatform.SDK.GameData
{
    // Only this game-scoped object is handed to a Lua module. Credentials and transport stay with the host.
    public sealed class ModulePlatformFacade
    {
        public GameDataClient Game { get; }
        public GardenDataClient Garden { get; }
        public SharedWalletClient Wallet { get; }
        public LeaderboardClient Leaderboard { get; }

        public ModulePlatformFacade(PlatformSession session, GameContext context, IPendingOperationStore pending)
        {
            if (session == null) throw new ArgumentNullException(nameof(session));
            if (context == null) throw new ArgumentNullException(nameof(context));
            if (context.GameId == "garden") Garden = new GardenDataClient(session, context, pending);
            else Game = new GameDataClient(session, context, pending);
            Wallet = new SharedWalletClient(session);
            if (context.GameId != "garden") Leaderboard = new LeaderboardClient(session, context);
        }
    }
}
