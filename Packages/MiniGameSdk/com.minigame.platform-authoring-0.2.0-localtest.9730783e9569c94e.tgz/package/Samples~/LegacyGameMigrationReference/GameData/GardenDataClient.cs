using System;
using System.IO;
using MiniGamePlatform.SDK.Auth;
using MiniGamePlatform.SDK.Network;
using UnityEngine;

namespace MiniGamePlatform.SDK.GameData
{
    public sealed class GardenDataClient
    {
        private const string Prefix = "/v1/games/garden";
        private readonly PlatformSession _session;
        private readonly GameContext _context;
        private readonly IPendingOperationStore _pending;
        private bool _writeInFlight;

        public GardenDataClient(PlatformSession session, GameContext context, IPendingOperationStore pending)
        {
            _session = session ?? throw new ArgumentNullException(nameof(session));
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _pending = pending ?? throw new ArgumentNullException(nameof(pending));
            if (context.GameId != "garden" || !GardenContract.IsProduct(context.ProductId))
                throw new ArgumentException("Garden v1 is limited to garden_local_test / hub_local_test and gameId garden.");
        }

        public void GetCapabilities(Action<ApiResult<GardenCapabilities>> callback) => Read("GET", "/capabilities", GardenContract.ValidCapabilities, callback);
        public void EnsureProfile(Action<ApiResult<GardenProgress>> callback)
        {
            string owner = RequireUserId();
            Read("PUT", "/profile", data => GardenContract.ValidProgress(data, owner), callback);
        }
        public void GetProgress(Action<ApiResult<GardenProgress>> callback)
        {
            string owner = RequireUserId();
            Read("GET", "/progress", data => GardenContract.ValidProgress(data, owner), callback);
        }

        public void StartSession(string stableLevelId, GardenStartRequest request, Action<ApiResult<GardenSessionStart>> callback)
        {
            RequireCallback(callback);
            if (stableLevelId != GardenContract.TrialLevelId) throw new ArgumentException("Garden local sessions only support garden.campaign.2.");
            var operation = Prepare("garden_start", "level:" + stableLevelId, GardenContract.SerializeStart(request));
            SendStart(operation, callback);
        }
        public void RetryPendingStart(Action<ApiResult<GardenSessionStart>> callback) => SendStart(Load("garden_start"), callback);

        public void SubmitFacts(string sessionId, GardenFactsRequest request, Action<GardenFactsResult> callback)
        {
            RequireCallback(callback);
            if (!GardenContract.IsSessionId(sessionId)) throw new ArgumentException("Invalid Garden session ID.");
            SendFacts(Prepare("garden_facts", sessionId, GardenContract.SerializeFacts(request)), callback);
        }
        public void RetryPendingFacts(Action<GardenFactsResult> callback) => SendFacts(Load("garden_facts"), callback);

        public void SyncReportedProgress(GardenSyncRequest request, Action<ApiResult<GardenProgress>> callback)
        {
            RequireCallback(callback);
            string body = GardenContract.SerializeSync(request);
            SendSync(Prepare("garden_sync", "progress", body, request.operationId), callback);
        }
        public void RetryPendingSync(Action<ApiResult<GardenProgress>> callback) => SendSync(Load("garden_sync"), callback);

        private void Read<T>(string method, string suffix, Func<T, bool> valid, Action<ApiResult<T>> callback)
        {
            RequireCallback(callback);
            string owner = RequireUserId();
            _session.SendAuthorized<T>(Request(method, suffix), result =>
            {
                callback(Validate(result, owner, 200, valid));
            }, owner);
        }

        private void SendStart(PendingOperation operation, Action<ApiResult<GardenSessionStart>> callback)
        {
            Verify(operation, "garden_start");
            var body = JsonUtility.FromJson<GardenStartRequest>(operation.BodyJson);
            if (operation.SessionId != "level:" + GardenContract.TrialLevelId || GardenContract.SerializeStart(body) != operation.BodyJson)
                throw new InvalidDataException("Invalid pending Garden start.");
            Send(operation, "/levels/" + GardenContract.TrialLevelId + "/start", 200,
                (GardenSessionStart data) => GardenContract.ValidStart(data, body), callback);
        }
        private void SendFacts(PendingOperation operation, Action<GardenFactsResult> callback)
        {
            RequireCallback(callback);
            Verify(operation, "garden_facts");
            var body = JsonUtility.FromJson<GardenFactsRequest>(operation.BodyJson);
            if (!GardenContract.IsSessionId(operation.SessionId) || GardenContract.SerializeFacts(body) != operation.BodyJson)
                throw new InvalidDataException("Invalid pending Garden facts.");
            Send(operation, "/sessions/" + operation.SessionId + "/facts", 202,
                (GardenFactsReceipt data) => GardenContract.ValidReceipt(data, operation.SessionId, body),
                result => callback(new GardenFactsResult(result)));
        }
        private void SendSync(PendingOperation operation, Action<ApiResult<GardenProgress>> callback)
        {
            Verify(operation, "garden_sync");
            var body = JsonUtility.FromJson<GardenSyncRequest>(operation.BodyJson);
            if (operation.SessionId != "progress" || body.operationId != operation.IdempotencyKey || GardenContract.SerializeSync(body) != operation.BodyJson)
                throw new InvalidDataException("Invalid pending Garden milestone sync.");
            Send(operation, "/offline-progress/sync", 200, (GardenProgress data) => GardenContract.ValidProgress(data, operation.UserId), callback);
        }

        private PendingOperation Prepare(string kind, string marker, string body, string key = null)
        {
            if (_writeInFlight) throw new InvalidOperationException("A Garden write is already in flight.");
            string owner = RequireUserId();
            if (_pending.TryLoad("garden", owner, out var existing))
            {
                Verify(existing, kind);
                if (existing.SessionId != marker || existing.BodyJson != body || (key != null && existing.IdempotencyKey != key))
                    throw new InvalidOperationException("Resolve the existing Garden operation before submitting different input.");
                return existing;
            }
            var operation = PendingOperation.Create("garden", owner, marker, kind, body);
            if (key != null) operation.IdempotencyKey = key;
            _pending.Save(operation); // Durable store completes before any network send.
            return operation;
        }
        private PendingOperation Load(string kind)
        {
            if (!_pending.TryLoad("garden", RequireUserId(), out var operation)) throw new InvalidOperationException("No Garden operation is pending.");
            Verify(operation, kind);
            return operation;
        }
        private void Verify(PendingOperation operation, string kind)
        {
            operation.Verify();
            if (operation.GameId != "garden" || operation.UserId != RequireUserId() || operation.Kind != kind || !GardenContract.IsOperationId(operation.IdempotencyKey))
                throw new InvalidOperationException("Pending operation is not the requested Garden action for this account.");
        }

        private void Send<T>(PendingOperation operation, string suffix, int status, Func<T, bool> valid, Action<ApiResult<T>> callback)
        {
            RequireCallback(callback);
            if (_writeInFlight) throw new InvalidOperationException("A Garden write is already in flight.");
            _writeInFlight = true;
            bool completed = false;
            try
            {
                _session.SendAuthorized<T>(Request("POST", suffix, operation.BodyJson, operation.IdempotencyKey), result =>
                {
                    if (completed) return;
                    completed = true;
                    _writeInFlight = false;
                    var checkedResult = Validate(result, operation.UserId, status, valid);
                    // A late callback must never delete a replacement operation or another account's work.
                    // Refresh/login failures have no Garden HTTP receipt. Keep their original key/body for recovery.
                    if (!checkedResult.Retryable && checkedResult.HttpStatus > 0 && checkedResult.HttpStatus != 401 &&
                        _pending.TryLoad("garden", operation.UserId, out var current) &&
                        current.IdempotencyKey == operation.IdempotencyKey && current.RequestFingerprint == operation.RequestFingerprint)
                        _pending.Remove("garden", operation.UserId);
                    callback(checkedResult);
                }, operation.UserId);
            }
            catch { _writeInFlight = false; throw; }
        }

        private ApiResult<T> Validate<T>(ApiResult<T> result, string owner, int expectedStatus, Func<T, bool> valid)
        {
            if (_session.UserId != owner) return result.WithError("ACCOUNT_CHANGED", "Garden response belongs to the previous account.", true);
            if (!result.IsSuccess) return result;
            if (result.HttpStatus != expectedStatus || !valid(result.Data))
                return result.WithError("GARDEN_CONTRACT_MISMATCH", "Response does not match the capture-only Garden v1 contract.", true);
            return result;
        }
        private ApiRequest Request(string method, string suffix, string body = null, string key = null) =>
            new ApiRequest(method, Prefix + suffix, body, key, productId: _context.ProductId);
        private string RequireUserId()
        {
            if (string.IsNullOrEmpty(_session.UserId)) throw new InvalidOperationException("Sign in before using Garden data.");
            return _session.UserId;
        }
        private static void RequireCallback<T>(Action<T> callback)
        { if (callback == null) throw new ArgumentNullException(nameof(callback)); }
    }
}
