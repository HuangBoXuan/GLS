using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using MiniGamePlatform.SDK.Auth;
using MiniGamePlatform.SDK.GameData;
using MiniGamePlatform.SDK.Network;
using UnityEditor;
using UnityEngine;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public static class SdkGameDataChecks
    {
        [MenuItem("MiniGame Platform/SDK/Run Game Data Checks")]
        public static void Run()
        {
            var fake = new FakeTransport();
            var session = new PlatformSession(fake, new EditorMemoryCredentialStore(), "hub");
            session.LoginGuest(result => Assert(result.IsSuccess, "fixture login failed"));
            var context = new GameContext("hub", "game-a");
            var pending = new MemoryPendingOperationStore();
            var game = new GameDataClient(session, context, pending);
            Assert(game.ProgressPath == "/v1/games/game-a/progress", "game route mismatch");
            Assert(!typeof(GameContext).GetProperty("GameId").CanWrite, "module can retarget another game");

            game.GetProgress(result => Assert(result.IsSuccess && result.Data.currentLevel == 2, "progress parse failed"));
            var wallet = new SharedWalletClient(session);
            wallet.GetSnapshot(result => Assert(result.IsSuccess && result.Data.assets[0].balance == "9007199254740993", "decimal wallet balance was rounded"));
            var board = new LeaderboardClient(session, context);
            board.GetBoard("campaign_progress", "all_time", 20, 0, result =>
                Assert(result.IsSuccess && result.Data.entries[0].score == "9007199254740993" && !result.Data.HasSelf, "leaderboard score or empty self rank was parsed incorrectly"));
            Assert(fake.Requests.Any(r => r.RelativePathAndQuery.Contains("seasonId=all_time") && r.Path.Contains("leaderboards")), "leaderboard query missing");

            string sessionId = "008c0571-f68f-4387-9a9d-694704f1d5c1";
            int[] moves = { 2, 0, 3, 1 };
            game.SettleSession(sessionId, 1, moves, result => Assert(!result.IsSuccess && result.Retryable, "timeout treated as definitive"));
            Assert(pending.TryLoad("game-a", "user-1", out PendingOperation uncertain) && uncertain.SessionId == sessionId, "uncertain settlement was discarded");
            game.RetryPendingSettlement(result => Assert(result.IsSuccess && result.Data.outcome == "passed", "settlement retry failed"));
            ApiRequest[] settlements = fake.Requests.Where(r => r.Path.EndsWith("/settle", StringComparison.Ordinal)).ToArray();
            Assert(settlements.Length == 2 && settlements[0].IdempotencyKey == settlements[1].IdempotencyKey, "settlement retry changed key");
            Assert(!pending.TryLoad("game-a", "user-1", out _), "settlement remained pending after definitive result");

            game.StartSession(2, 2, result => Assert(!result.IsSuccess && result.Retryable, "uncertain start was treated as definitive"));
            Assert(pending.TryLoad("game-a", "user-1", out PendingOperation uncertainStart) && uncertainStart.Kind == "start", "uncertain start was not persisted");
            game.RetryPendingStart(result => Assert(result.IsSuccess && result.Data.levelNumber == 2, "start retry failed"));
            ApiRequest[] starts = fake.Requests.Where(r => r.Path.EndsWith("/start", StringComparison.Ordinal)).ToArray();
            Assert(starts.Length == 2 && starts[0].IdempotencyKey == starts[1].IdempotencyKey, "start retry changed key");
            Assert(!pending.TryLoad("game-a", "user-1", out _), "start remained pending after definitive result");

            var firstTransport = new FakeTransport();
            var firstSession = new PlatformSession(firstTransport, new EditorMemoryCredentialStore(), "hub");
            firstSession.LoginGuest(result => Assert(result.IsSuccess, "first account login failed"));
            var firstGame = new GameDataClient(firstSession, context, pending);
            firstGame.StartSession(4, 2, result => Assert(!result.IsSuccess && result.Retryable, "first account start was not pending"));
            var secondTransport = new FakeTransport("user-2");
            var secondSession = new PlatformSession(secondTransport, new EditorMemoryCredentialStore(), "hub");
            secondSession.LoginGuest(result => Assert(result.IsSuccess, "second account login failed"));
            var secondGame = new GameDataClient(secondSession, context, pending);
            secondGame.StartSession(1, 0, result => Assert(!result.IsSuccess && result.Retryable, "second account start was not pending"));
            Assert(pending.TryLoad("game-a", "user-1", out _) && pending.TryLoad("game-a", "user-2", out _),
                "pending starts from two accounts were not isolated");

            string pendingFolder = Path.Combine(Application.temporaryCachePath, "sdk-pending-" + Guid.NewGuid().ToString("N"));
            var fileStore = new FilePendingOperationStore(pendingFolder);
            PendingOperation firstDiskOperation = PendingOperation.Create("game-a", "user-1", sessionId, "settle", "{\"moves\":[1]}");
            fileStore.Save(firstDiskOperation);
            Assert(new FilePendingOperationStore(pendingFolder).TryLoad("game-a", "user-1", out PendingOperation loaded) &&
                loaded.IdempotencyKey == firstDiskOperation.IdempotencyKey, "pending operation did not survive a store restart");
            PendingOperation replacement = PendingOperation.Create("game-a", "user-1", sessionId, "settle", "{\"moves\":[2]}");
            fileStore.Save(replacement);
            Assert(fileStore.TryLoad("game-a", "user-1", out loaded) && loaded.IdempotencyKey == replacement.IdempotencyKey, "atomic pending replacement failed");
            Assert(!fileStore.TryLoad("game-a", "user-2", out _), "different account read another account's pending operation");
            fileStore.Remove("game-a", "user-1");
            Assert(!fileStore.TryLoad("game-a", "user-1", out _), "pending operation was not removed");

            game.SyncOfflineProgress(3, result => Assert(result.IsSuccess && result.Data.offlineMaxCompletedLevel == 3, "offline response parse failed"));
            ApiRequest offline = fake.Requests.Last(r => r.Path.EndsWith("offline-progress/sync", StringComparison.Ordinal));
            Assert(offline.BodyJson.Contains("\"operationId\":\"" + offline.IdempotencyKey + "\""), "offline operation ID did not match request key");
            Debug.Log("SDK game data checks passed.");
        }

        private static void Assert(bool condition, string message)
        {
            if (!condition) throw new Exception(message);
        }

        private sealed class FakeTransport : IPlatformTransport
        {
            public readonly List<ApiRequest> Requests = new List<ApiRequest>();
            private readonly string _userId;
            private int _settleCount;
            private int _startCount;

            public FakeTransport(string userId = "user-1") { _userId = userId; }

            public void Send<T>(ApiRequest request, Action<ApiResult<T>> callback)
            {
                Requests.Add(request);
                if (request.Path == "/v1/platform/auth/guest")
                    callback(ApiResult<T>.FromJson("{\"data\":{\"userId\":\"" + _userId + "\",\"guestCredential\":\"guest-secret\",\"accessToken\":\"access-1\",\"refreshToken\":\"refresh-1\",\"expiresInSeconds\":900},\"meta\":{\"requestId\":\"guest\"}}", 201));
                else if (request.Path.EndsWith("/progress", StringComparison.Ordinal))
                    callback(ApiResult<T>.FromJson("{\"data\":{\"userId\":\"user-1\",\"currentLevel\":2,\"progressVersion\":1},\"meta\":{\"requestId\":\"progress\"}}", 200));
                else if (request.Path == "/v1/platform/wallet")
                    callback(ApiResult<T>.FromJson("{\"data\":{\"assets\":[{\"code\":\"material\",\"balance\":\"9007199254740993\",\"version\":\"2\"}]},\"meta\":{\"requestId\":\"wallet\"}}", 200));
                else if (request.Path.Contains("leaderboards"))
                    callback(ApiResult<T>.FromJson("{\"data\":{\"boardId\":\"campaign_progress\",\"seasonId\":\"all_time\",\"entries\":[{\"userId\":\"user-1\",\"score\":\"9007199254740993\",\"rank\":\"1\"}],\"self\":null},\"meta\":{\"requestId\":\"board\"}}", 200));
                else if (request.Path.EndsWith("/settle", StringComparison.Ordinal))
                {
                    if (++_settleCount == 1) callback(ApiResult<T>.NetworkFailure("NETWORK_UNCERTAIN", true));
                    else callback(ApiResult<T>.FromJson("{\"data\":{\"sessionId\":\"008c0571-f68f-4387-9a9d-694704f1d5c1\",\"outcome\":\"passed\",\"currentLevel\":2,\"progressVersion\":2},\"meta\":{\"requestId\":\"settle\"}}", 200));
                }
                else if (request.Path.EndsWith("offline-progress/sync", StringComparison.Ordinal))
                    callback(ApiResult<T>.FromJson("{\"data\":{\"offlineMaxCompletedLevel\":3,\"progressVersion\":2},\"meta\":{\"requestId\":\"offline\"}}", 200));
                else if (request.Path.EndsWith("/start", StringComparison.Ordinal))
                {
                    if (++_startCount == 1) callback(ApiResult<T>.NetworkFailure("NETWORK_UNCERTAIN", true));
                    else callback(ApiResult<T>.FromJson("{\"data\":{\"sessionId\":\"008c0571-f68f-4387-9a9d-694704f1d5c1\",\"levelNumber\":2,\"progressVersion\":2},\"meta\":{\"requestId\":\"start\"}}", 200));
                }
                else throw new Exception("Unexpected route: " + request.Path);
            }
        }
    }
}
