using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Reflection;
using System.Globalization;
using MiniGamePlatform.HotUpdate;
using MiniGamePlatform.SDK.Auth;
using MiniGamePlatform.SDK.GameData;
using MiniGamePlatform.SDK.Network;
using UnityEditor;
using UnityEngine;
using UnityEngine.Networking;

namespace MiniGamePlatform.SDK.EditorChecks
{
    public static class SdkGardenChecks
    {
        public static void RunRegression()
        {
            Run();
            MiniGamePlatform.SDK.Editor.Authoring.ModuleHostBoundaryChecks.RunWithProtectionRegression();
            Debug.Log("Garden SDK full regression passed.");
        }
        [MenuItem("MiniGame Platform/SDK/Run Garden Contract Checks")]
        public static void Run()
        {
            _assertions = 0;
            var fixturePath = Path.Combine(UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(GardenDataClient).Assembly).resolvedPath,
                "Tests~/Garden/garden-local-v1.json");
            var fixture = JsonUtility.FromJson<Fixture>(File.ReadAllText(fixturePath));
            CheckRequestBoundaries(fixture);
            CheckFlows(fixture);
            CheckResponseBoundaries(fixture);
            CheckAccountAndStoreBoundaries(fixture);
            SdkTransportChecks.Run(); SdkAuthChecks.Run(); SdkGameDataChecks.Run();
            Debug.Log("Garden contract checks passed: " + _assertions + " assertions; serialization, headers, auth replay, persistence, account isolation, unverified receipts and legacy SDK regressions.");
        }

        [Serializable] private sealed class Fixture { public GardenStartRequest start; public GardenFactsRequest submit; public GardenSyncRequest sync; }
        private const string Owner = "11111111-1111-4111-8111-111111111111";
        private const string Other = "22222222-2222-4222-8222-222222222222";
        private const string SessionId = "33333333-3333-4333-8333-333333333333";
        private static readonly GameContext Context = new GameContext("garden_local_test", "garden");
        private static int _assertions;
        private static void Check(bool condition, string message) { _assertions++; if (!condition) throw new Exception(message); }
        private static void Reject<T>(Action action) where T : Exception
        { _assertions++; try { action(); } catch (T) { return; } throw new Exception("Expected " + typeof(T).Name); }

        private static PlatformSession Login(Fake transport, string product = "garden_local_test")
        {
            var session = new PlatformSession(transport, new EditorMemoryCredentialStore(), product);
            session.LoginGuest(r => Check(r.IsSuccess, "Guest fixture failed."));
            return session;
        }
        private static void CheckRequestBoundaries(Fixture f)
        {
            string facts = GardenContract.SerializeFacts(f.submit);
            Check(facts.Contains("\"kind\":\"tap\",\"boxId\":2") && !facts.Contains("\"moves\"") && !facts.Contains("\"win\"") &&
                !facts.Contains("\"rewards\""), "Garden used a settlement payload.");
            Check(!facts.Contains("\"boxId\":0") && !facts.Contains("\"deltaSeconds\":0}"), "Fact union emitted fields from the wrong kind.");
            var oldCulture = CultureInfo.CurrentCulture;
            try { CultureInfo.CurrentCulture = CultureInfo.GetCultureInfo("fr-FR"); Check(GardenContract.SerializeFacts(f.submit) == facts, "Fact JSON is locale dependent."); }
            finally { CultureInfo.CurrentCulture = oldCulture; }
            f.submit.facts[1].sequence = 4; Reject<ArgumentException>(() => GardenContract.SerializeFacts(f.submit)); f.submit.facts[1].sequence = 1;
            foreach (double delta in new[] { 0, -1, 1.001, double.NaN, double.PositiveInfinity })
            { f.submit.facts[0].deltaSeconds = delta; Reject<ArgumentException>(() => GardenContract.SerializeFacts(f.submit)); }
            f.submit.facts[0].deltaSeconds = 0.016;
            f.submit.facts[1].boxId = 0; Reject<ArgumentException>(() => GardenContract.SerializeFacts(f.submit)); f.submit.facts[1].boxId = 2;
            f.submit.facts[0].kind = "revive"; Reject<ArgumentException>(() => GardenContract.SerializeFacts(f.submit)); f.submit.facts[0].kind = "advance";
            var originalFacts = f.submit.facts;
            f.submit.facts = new GardenInputFact[4097]; Reject<ArgumentException>(() => GardenContract.SerializeFacts(f.submit));
            f.submit.facts = Array.Empty<GardenInputFact>(); Reject<ArgumentException>(() => GardenContract.SerializeFacts(f.submit)); f.submit.facts = originalFacts;
            f.start.expectedProgressVersion = GardenContract.MaxVersion + 1; Reject<ArgumentException>(() => GardenContract.SerializeStart(f.start));
            f.start.expectedProgressVersion = 1;
            f.start.contractVersion = 2; Reject<ArgumentException>(() => GardenContract.SerializeStart(f.start)); f.start.contractVersion = 1;
            var hash = f.start.moduleManifestSha256;
            f.start.moduleManifestSha256 = hash.ToUpperInvariant(); Reject<ArgumentException>(() => GardenContract.SerializeStart(f.start)); f.start.moduleManifestSha256 = hash;
            string sync = GardenContract.SerializeSync(f.sync);
            Array.Reverse(f.sync.completedLevelIds); Check(GardenContract.SerializeSync(f.sync) == sync, "Milestone ordering changed request semantics."); Array.Reverse(f.sync.completedLevelIds);
            f.sync.saveSchemaVersion = 1; Reject<ArgumentException>(() => GardenContract.SerializeSync(f.sync)); f.sync.saveSchemaVersion = 9;
            var levels = f.sync.completedLevelIds;
            foreach (var invalid in new[] { new[] { "garden.campaign.0" }, new[] { "garden.campaign.301" }, new[] { "garden.campaign.02" },
                new[] { "garden.campaign.2", "garden.campaign.2" }, new[] { "arrow.campaign.2" }, new[] { "garden.campaign.2\n" } })
            { f.sync.completedLevelIds = invalid; Reject<ArgumentException>(() => GardenContract.SerializeSync(f.sync)); }
            f.sync.completedLevelIds = levels;
            Reject<ArgumentException>(() => new ApiRequest("GET", "/v1/games/garden/progress", productId: "a\r\nAuthorization: evil"));
            Check(typeof(GardenFactsResult).GetProperty("IsSuccess") == null && typeof(GardenDataClient).GetMethod("SettleSession") == null,
                "Garden exposes a misleading success or settlement API.");
            Check(HostProfile.ApiVersion >= 3 && HostProfile.Current.SupportsCapability(GardenContract.Capability) &&
                !new HostProfile(2, "android", "", new[] { GardenContract.Capability }).SupportsCapability(GardenContract.Capability), "Garden host capability is not versioned.");
            Debug.Log("Garden request boundary checks passed.");
        }

        private static void CheckFlows(Fixture f)
        {
            var pending = new MemoryPendingOperationStore(); var fake = new Fake(pending, f); var auth = Login(fake);
            var garden = new GardenDataClient(auth, Context, pending);
            garden.EnsureProfile(r => Check(r.IsSuccess && r.Data.verifiedCompletedLevelIds.Length == 0 && !r.Data.HasActiveSession, "Garden profile failed."));
            garden.GetProgress(r => Check(r.IsSuccess && r.Data.progressVersion == 1, "Garden progress failed."));
            garden.GetCapabilities(r => Check(r.IsSuccess && !r.Data.settlementEnabled, "Garden capabilities failed."));
            var facade = new ModulePlatformFacade(auth, Context, pending);
            Check(facade.Garden != null && facade.Game == null && facade.Leaderboard == null && facade.Wallet != null, "Garden exposed Game A or leaderboard facade.");
            using (var lua = new XLua.LuaEnv())
            {
                lua.Global.Set("platform", facade);
                lua.DoString("assert(platform.Game == nil and platform.Leaderboard == nil); " +
                    "platform.Garden:GetProgress(function(r) assert(r.IsSuccess and r.Data.localOnly); garden_seen=true end)");
                Check(lua.Global.Get<bool>("garden_seen"), "Lua Garden progress bridge did not invoke its callback.");
            }
            Reject<ArgumentException>(() => new GardenDataClient(auth, new GameContext("hub", "garden"), pending));
            Reject<ArgumentException>(() => new GardenDataClient(auth, new GameContext("garden_local_test", "game-a"), pending));
            Reject<ArgumentException>(() => garden.StartSession("garden.campaign.3", f.start, _ => { }));

            fake.NextStatus = 0;
            garden.StartSession(GardenContract.TrialLevelId, f.start, r => Check(!r.IsSuccess && r.Retryable, "Uncertain start was accepted."));
            Check(pending.TryLoad("garden", Owner, out var start), "Start was not retained.");
            fake.NextStatus = 401;
            garden.RetryPendingStart(r => Check(r.IsSuccess && !r.Data.authoritativeValidation, "401 start replay failed."));
            var starts = fake.Requests.Where(r => r.Path.EndsWith("/start")).ToArray();
            Check(starts.Length == 3 && starts.All(r => r.IdempotencyKey == start.IdempotencyKey && r.BodyJson == start.BodyJson &&
                r.ProductId == "garden_local_test") && starts.Last().AccessToken == "access-refreshed", "Refresh changed Garden headers, key or body.");
            Check(!pending.TryLoad("garden", Owner, out _), "Confirmed start still pending.");

            fake.NextStatus = 0;
            garden.SubmitFacts(SessionId, f.submit, r => Check(r.Retryable && !r.IsAcceptedUnverified && !r.IsVerifiedWin, "Timeout treated as fact acceptance."));
            garden.RetryPendingFacts(r => Check(r.IsAcceptedUnverified && r.HttpStatus == 202 && r.Receipt.validationStatus == "unverified" &&
                !r.IsVerifiedWin && !r.RewardsGranted && !r.LeaderboardUpdated, "202 was promoted to victory or rewards."));
            Check(!pending.TryLoad("garden", Owner, out _), "Accepted facts were not acknowledged.");
            fake.NextStatus = 0;
            garden.SyncReportedProgress(f.sync, r => Check(r.Retryable, "Uncertain sync was discarded."));
            var hub = new GardenDataClient(auth, new GameContext("hub_local_test", "garden"), pending);
            hub.RetryPendingSync(r => Check(r.IsSuccess && r.Data.sharedRewardsEnabled == false, "Cross-product sync replay failed."));
            var syncs = fake.Requests.Where(r => r.Path.EndsWith("/sync")).ToArray();
            Check(syncs.Length == 2 && syncs[0].BodyJson == syncs[1].BodyJson && syncs.All(r => r.IdempotencyKey == f.sync.operationId) &&
                syncs[1].ProductId == "hub_local_test", "Sync idempotency changed across products.");
            fake.NextStatus = 409; fake.NextJson = Error("PROGRESS_VERSION_CONFLICT", false);
            garden.SyncReportedProgress(f.sync, r => Check(!r.IsSuccess && r.ErrorCode == "PROGRESS_VERSION_CONFLICT" && !r.Retryable, "Conflict was hidden."));
            Check(!pending.TryLoad("garden", Owner, out _), "Definitive conflict did not release pending slot.");

            var transport = new UnityApiTransport("https://example.test", "android", "1.0.0");
            var create = typeof(UnityApiTransport).GetMethod("CreateWebRequest", BindingFlags.Instance | BindingFlags.NonPublic);
            using (var web = (UnityWebRequest)create.Invoke(transport, new object[] { starts.Last() }))
                Check(web.GetRequestHeader("X-Product-Id") == "garden_local_test" && web.GetRequestHeader("Authorization") == "Bearer access-refreshed" &&
                    web.GetRequestHeader("Idempotency-Key") == start.IdempotencyKey && web.GetRequestHeader("X-Platform") == "android", "Wire headers missing.");

            string folder = Path.GetFullPath("Logs/sdk-garden"); Directory.CreateDirectory(folder);
            File.WriteAllText(Path.Combine(folder, "outbound-requests.json"), JsonUtility.ToJson(new Transcript {
                entries = fake.Requests.Where(r => r.Path.StartsWith("/v1/games/garden", StringComparison.Ordinal)).Select(r => new RequestRecord {
                    path = r.Path, method = r.Method, bodyJson = r.BodyJson, idempotencyKey = r.IdempotencyKey, productId = r.ProductId }).ToArray()
            }, true));
            Debug.Log("Garden transport/pending flows passed; outbound contract transcript written without tokens.");
        }

        private static void CheckResponseBoundaries(Fixture f)
        {
            foreach (string response in new[] { "{\"data\":null}", "{\"data\":{}}", Receipt().Replace("unverified", "verified"),
                Receipt().Replace("\"rewardsGranted\":false", "\"rewardsGranted\":true"), Receipt().Replace(SessionId, Other),
                Receipt().Replace("\"receivedFactCount\":3", "\"receivedFactCount\":2"), Receipt().Replace("\"contractVersion\":1", "\"contractVersion\":2") })
            {
                var pending = new MemoryPendingOperationStore(); var fake = new Fake(pending, f); var auth = Login(fake);
                var garden = new GardenDataClient(auth, Context, pending);
                fake.NextStatus = 202; fake.NextJson = response;
                garden.SubmitFacts(SessionId, f.submit, r => Check(!r.IsAcceptedUnverified && !r.IsVerifiedWin && !r.RewardsGranted &&
                    r.Retryable && r.ErrorCode == "GARDEN_CONTRACT_MISMATCH", "Invalid receipt accepted."));
                Check(pending.TryLoad("garden", Owner, out _), "Invalid receipt discarded replay evidence.");
            }
            foreach (int status in new[] { 200, 201 })
            {
                var pending = new MemoryPendingOperationStore(); var fake = new Fake(pending, f); var auth = Login(fake);
                fake.NextStatus = status; fake.NextJson = Receipt();
                new GardenDataClient(auth, Context, pending).SubmitFacts(SessionId, f.submit,
                    r => Check(!r.IsAcceptedUnverified && !r.IsVerifiedWin, "Wrong HTTP status was accepted."));
            }
            Debug.Log("Garden response fail-closed checks passed.");
        }

        private static void CheckAccountAndStoreBoundaries(Fixture f)
        {
            string folder = Path.Combine(Path.GetTempPath(), "SdkGarden-" + Guid.NewGuid().ToString("N"));
            try
            {
                var store = new FilePendingOperationStore(folder); var fake = new Fake(store, f); var auth = Login(fake);
                var garden = new GardenDataClient(auth, Context, store);
                fake.NextStatus = 0;
                garden.SubmitFacts(SessionId, f.submit, _ => { });
                var reopened = new FilePendingOperationStore(folder);
                Check(reopened.TryLoad("garden", Owner, out var before), "Pending facts lost after restart.");
                var otherGame = PendingOperation.Create("game-a", Owner, SessionId, "settle", "{}"); store.Save(otherGame);
                new GardenDataClient(auth, Context, reopened).RetryPendingFacts(r => Check(r.IsAcceptedUnverified, "Disk replay failed."));
                Check(store.TryLoad("game-a", Owner, out _), "Garden cleared another game pending operation.");

                fake.HoldNext = true;
                garden.SubmitFacts(SessionId, f.submit, r => Check(r.ErrorCode == "ACCOUNT_CHANGED" && r.Retryable, "Old account response was consumed."));
                Reject<InvalidOperationException>(() => garden.SubmitFacts(SessionId, f.submit, _ => { }));
                fake.UserId = Other; auth.LoginGuest(_ => { }); fake.Release();
                Check(store.TryLoad("garden", Owner, out _) && !store.TryLoad("garden", Other, out _), "Old pending crossed account boundary.");
                Reject<InvalidOperationException>(() => garden.RetryPendingFacts(_ => { }));
                fake.UserId = Owner; auth.LoginGuest(_ => { }); garden.RetryPendingFacts(_ => { });

                // A login while token refresh is outstanding must not restore the old identity.
                fake.HoldRefresh = true; fake.NextStatus = 401;
                garden.StartSession(GardenContract.TrialLevelId, f.start,
                    r => Check(r.ErrorCode == "ACCOUNT_CHANGED" && r.Retryable, "Stale refresh replayed an old user's Garden write."));
                fake.UserId = Other; auth.LoginGuest(_ => { }); fake.ReleaseRefresh();
                Check(auth.UserId == Other && store.TryLoad("garden", Owner, out _), "Stale refresh replaced the new identity.");

                fake.UserId = Owner; auth.LoginGuest(_ => { }); garden.RetryPendingStart(_ => { });
                fake.NextStatus = 401; fake.FailRefresh = true;
                garden.SubmitFacts(SessionId, f.submit, r => Check(r.ErrorCode == "REFRESH_EXPIRED" && !r.IsAcceptedUnverified, "Auth failure was hidden."));
                Check(store.TryLoad("garden", Owner, out _), "An auth failure discarded a Garden request that has no definitive game receipt.");
                auth.LoginGuest(_ => { }); garden.RetryPendingFacts(_ => { });

                fake.HoldGuest = true;
                auth.ResumeGuest(r => Check(r.ErrorCode == "ACCOUNT_CHANGED" && r.Retryable, "Stale guest recovery replaced a new login."));
                fake.UserId = Other; auth.LoginGuest(_ => { }); fake.ReleaseGuest();
                Check(auth.UserId == Other, "Old guest credential restored a prior account.");
            }
            finally { if (Directory.Exists(folder)) Directory.Delete(folder, true); }
            Debug.Log("Garden durable pending and account-switch checks passed.");
        }

        [Serializable] private sealed class Transcript { public RequestRecord[] entries; }
        [Serializable] private sealed class RequestRecord { public string path, method, bodyJson, idempotencyKey, productId; }
        private static string Error(string code, bool retryable) => "{\"error\":{\"code\":\"" + code + "\",\"retryable\":" + (retryable ? "true" : "false") + "},\"meta\":{\"requestId\":\"test-error\"}}";
        private static string Receipt() => "{\"data\":{\"gameId\":\"garden\",\"sessionId\":\"" + SessionId + "\",\"contractVersion\":1,\"ruleVersion\":1,\"stableLevelId\":\"garden.campaign.2\",\"configVersion\":1,\"localOnly\":true,\"validationStatus\":\"unverified\",\"reason\":\"GARDEN_VALIDATOR_NOT_IMPLEMENTED\",\"receivedFactCount\":3,\"factsSha256\":\"" + new string('c',64) + "\",\"rewardsGranted\":false,\"leaderboardUpdated\":false},\"meta\":{\"requestId\":\"receipt\"}}";

        private sealed class Fake : IPlatformTransport
        {
            public readonly List<ApiRequest> Requests = new List<ApiRequest>();
            private readonly IPendingOperationStore _store;
            private readonly Fixture _fixture;
            public string UserId = Owner, NextJson, LastResponse;
            public int NextStatus = -1;
            public bool HoldNext, HoldRefresh, HoldGuest, FailRefresh;
            public Action Release, ReleaseRefresh, ReleaseGuest;
            public Fake(IPendingOperationStore store, Fixture fixture) { _store = store; _fixture = fixture; }
            private string Identity(string user, bool refresh) => "{\"data\":{\"userId\":\"" + user + "\",\"guestCredential\":\"test-guest\",\"accessToken\":\"" + (refresh ? "access-refreshed" : "access-" + user) + "\",\"refreshToken\":\"refresh-" + user + "\",\"expiresInSeconds\":900},\"meta\":{\"requestId\":\"identity\"}}";
            public void Send<T>(ApiRequest request, Action<ApiResult<T>> callback)
            {
                Requests.Add(request);
                if (request.Path.EndsWith("/auth/guest"))
                {
                    string identity = Identity(UserId, false);
                    if (HoldGuest) { HoldGuest = false; ReleaseGuest = () => callback(ApiResult<T>.FromJson(identity, 201)); }
                    else callback(ApiResult<T>.FromJson(identity, 201));
                    return;
                }
                if (request.Path.EndsWith("/auth/refresh"))
                {
                    if (FailRefresh) { FailRefresh = false; callback(ApiResult<T>.FromJson(Error("REFRESH_EXPIRED", false), 401)); return; }
                    string json = Identity(UserId, true);
                    if (HoldRefresh) { HoldRefresh = false; ReleaseRefresh = () => callback(ApiResult<T>.FromJson(json, 200)); }
                    else callback(ApiResult<T>.FromJson(json, 200));
                    return;
                }
                Check(request.ProductId == "garden_local_test" || request.ProductId == "hub_local_test", "Missing product header.");
                Check(!string.IsNullOrEmpty(request.AccessToken), "Garden request lacks bearer token.");
                if (request.Method == "POST")
                    Check(_store.TryLoad("garden", UserId, out var operation) && operation.BodyJson == request.BodyJson && operation.IdempotencyKey == request.IdempotencyKey,
                        "Request sent before durable pending save.");
                int status = NextStatus >= 0 ? NextStatus : request.Path.EndsWith("/facts") ? 202 : 200;
                string response = NextJson ?? (status == 401 ? Error("TOKEN_EXPIRED", false) : Response(request));
                LastResponse = response;
                NextStatus = -1; NextJson = null;
                void Complete() => callback(status == 0 ? ApiResult<T>.NetworkFailure("NETWORK_UNCERTAIN", true) : ApiResult<T>.FromJson(response, status));
                if (HoldNext) { HoldNext = false; Release = Complete; } else Complete();
            }
            private string Response(ApiRequest request)
            {
                if (request.Path.EndsWith("/facts")) return Receipt();
                object data;
                if (request.Path.EndsWith("/start")) data = new GardenSessionStart { gameId = "garden", sessionId = SessionId,
                    stableLevelId = GardenContract.TrialLevelId, contractVersion = 1, ruleVersion = 1, configVersion = 1, progressVersion = 1,
                    moduleVersion = _fixture.start.moduleVersion, moduleManifestSha256 = _fixture.start.moduleManifestSha256,
                    levelBaselineSha256 = _fixture.start.levelBaselineSha256, expiresAt = "2026-09-29T23:00:00Z", status = "started", localOnly = true };
                else if (request.Path.EndsWith("/capabilities")) data = new GardenCapabilities { gameId = "garden", gameStatus = "active", localOnly = true,
                    contractVersion = 1, ruleVersion = 1, ruleStatus = "capture_only", offlineSaveSchemaVersion = 9, maxFactsPerSubmission = 4096,
                    supportedSessionLevelIds = new[] { GardenContract.TrialLevelId }, supportedFactKinds = new[] { "tap", "advance" }, missingValidationInputs = new[] { "validator" } };
                else data = new GardenProgress { gameId = "garden", userId = UserId, localOnly = true, progressVersion = 1,
                    reportedCompletedLevelIds = Array.Empty<string>(), verifiedCompletedLevelIds = Array.Empty<string>() };
                // JsonUtility emits a null string as empty; the server's nullable UUID is JSON null.
                return "{\"data\":" + JsonUtility.ToJson(data).Replace("\"activeSessionId\":\"\"", "\"activeSessionId\":null") + ",\"meta\":{\"requestId\":\"test\"}}";
            }
        }
    }
}
