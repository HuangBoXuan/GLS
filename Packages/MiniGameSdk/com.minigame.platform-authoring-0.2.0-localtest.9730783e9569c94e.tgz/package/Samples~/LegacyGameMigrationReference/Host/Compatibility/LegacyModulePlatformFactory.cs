using System;
using System.IO;
using MiniGamePlatform.HotUpdate;
using MiniGamePlatform.SDK.Auth;
using MiniGamePlatform.SDK.Contracts;
using MiniGamePlatform.SDK.GameData;

namespace MiniGamePlatform.SDK.Host.Compatibility
{
    // Retains the already-shipped business rules outside the generic Lua runtime.
    public sealed class LegacyModulePlatformFactory : IModulePlatformFactory
    {
        private readonly Func<IPendingOperationStore> _createPending;
        public LegacyModulePlatformFactory(Func<IPendingOperationStore> createPending)
        { _createPending = createPending ?? throw new ArgumentNullException(nameof(createPending)); }

        public ModulePlatformFacade Create(ModuleManifest manifest, ProductContext product, PlatformSession session)
        {
            if (manifest == null) throw new ArgumentNullException(nameof(manifest));
            if (product == null || !product.TryResolveServerGameId(manifest.gameId, out _)) return null;
            if (session == null) throw new InvalidOperationException("A mapped module requires a platform session.");
            var context = product.CreateGameContext(manifest.gameId);
            if (context.GameId == "garden" && (manifest.minHostApiVersion < 3 ||
                Array.IndexOf(manifest.requiredCapabilities ?? Array.Empty<string>(), GardenContract.Capability) < 0))
                throw new InvalidDataException("Garden online modules must declare garden_local_api and host API 3.");
            var pending = _createPending();
            if (pending == null) throw new InvalidOperationException("Pending operation store is unavailable.");
            return new ModulePlatformFacade(session, context, pending);
        }
    }
}
