using MiniGamePlatform.SDK.GameData;
using MiniGamePlatform.SDK.Host.Compatibility;

namespace MiniGamePlatform.HotUpdate
{
    public sealed partial class ModulePlayer
    {
        public ModulePlayer(string source = "hub", string singleGameId = null, IModuleContentKeyProvider keys = null)
            : this(source, singleGameId, keys, new LegacyModulePlatformFactory(() => new FilePendingOperationStore())) { }
    }
}
