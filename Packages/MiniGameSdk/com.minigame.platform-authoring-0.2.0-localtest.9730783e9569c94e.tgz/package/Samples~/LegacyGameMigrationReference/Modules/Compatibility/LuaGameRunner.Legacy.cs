using MiniGamePlatform.SDK.GameData;
using MiniGamePlatform.SDK.Host.Compatibility;

namespace MiniGamePlatform.HotUpdate
{
    public sealed partial class LuaGameRunner
    {
        // Compatibility for existing shells. New shells supply their host factory explicitly.
        public LuaGameRunner(IModuleContentKeyProvider contentKeys = null)
            : this(contentKeys, new LegacyModulePlatformFactory(() => new FilePendingOperationStore())) { }
    }
}
