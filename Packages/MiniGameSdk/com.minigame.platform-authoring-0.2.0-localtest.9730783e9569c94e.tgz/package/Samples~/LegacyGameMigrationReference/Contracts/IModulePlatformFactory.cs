using MiniGamePlatform.HotUpdate;
using MiniGamePlatform.SDK.Auth;
using MiniGamePlatform.SDK.GameData;

namespace MiniGamePlatform.SDK.Contracts
{
    // Host-only composition seam. The facade is a compatibility type, not a new Lua protocol.
    // Create synchronously assembles clients; it must not perform login, network writes or rewards.
    public interface IModulePlatformFactory
    {
        ModulePlatformFacade Create(ModuleManifest manifest, ProductContext product, PlatformSession session);
    }
}
