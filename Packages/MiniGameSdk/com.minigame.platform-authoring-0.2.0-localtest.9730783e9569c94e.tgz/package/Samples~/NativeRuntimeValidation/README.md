# 原生 Unity 组件最小验收

此样例用于专用测试工程，不要复制后直接在正式游戏工程运行构建方法。构建器会生成测试场景、资源和修改测试工程的 Android 构建设置；工程根须有 `.native-sdk-validation`，内容为 `MGP_NATIVE_VALIDATION_ONLY`。

1. 创建 Unity 2022.3.76f1 测试工程，安装同一快照的核心 SDK、共用宿主、开发工具三个固定 tgz 包，并按 Tools~/NativeUguiLocalization.md 固定官方 Localization 1.4.4 tgz（仅写 registry 版本号可能被编辑器最低版本规则覆盖）。安装 Android SDK/NDK/JDK 和 IL2CPP 模块。
2. 将本样例内容复制到 `Assets/NativeValidation`，导入 TMP Essential Resources；创建上述标记文件。
3. Editor：运行 `-batchmode -executeMethod NativeValidationBuild.RunEditor -logFile <日志>`，不加 `-quit`；探针进入 Play Mode 后自行返回 exit 0/1。
4. Android：运行 `-batchmode -quit -buildTarget Android -executeMethod NativeValidationBuild.BuildAndroid -logFile <日志>`，生成 `Builds/native-baseline-arm64.apk`，使用 arm64、IL2CPP、High 托管裁剪和引擎裁剪。
5. 安装到专用测试设备后打开 `com.minigame.sdk.nativevalidation`；读取 logcat 中 `NATIVE_BASELINE_RESULT` 和该应用私有持久目录的 `native-baseline-result.json`。只有 passed=true 且 backend=IL2CPP、pointerBytes=8 的实际设备记录才算 arm64 运行通过。

资源夹是原生 UGUI/TMP/Animator/ParticleSystem/AudioSource Prefab，不删改组件来适配表现桥；Lua 通过 CS 直调。模块经同一 ModulePlayer 在 hub、independent、hub 三轮加载，测试按钮回调、暂停、解绑、退出和重入。另通过通用 LoadAsset 读取 Sprite/Material/音频/AnimatorController/TMP 字体，验证两指按压、Up/Exit/Submit、禁用取消，以及父 ScrollRect 的拖动处理器没有被 relay 截获。触摸输入由探针构造，不能替代设备手势验收。

此 APK 是共用运行层探针，不是实际 Garden 完整游戏、正式双产品 APK，也不验证 CDN、账号或服务端。测试夹通过 StreamingAssets 读取固定模块，不替代生产签名目录。音频使用静音测试片段，当前检查播放配置和暂停状态，不验证听感或设备音频输出。

宿主装配回归同时覆盖两种 C# 入口：hub 使用默认共用服务装配，independent 显式提供 CommonModuleServiceFactory；Lua 与资源相同。验证旧模块兼容时，必须保留旧 manifest/Lua/Bundle 原字节，由专用验证构建入口装入新宿主，不能用重新导出的模块替代该项兼容证据。

NativeExtensionsProbe 另验证 Lua 创建原生 Mesh 并交给 ModuleMeshGraphic、纹理/材质借用、Mask 模板材质、RectMask2D 移出裁剪和返回显示、清空网格、销毁不释放借用资源、静态 bool(Vector2,Camera) Lua 回调，以及精确 Localization 1.4.4 的命名/数字/复数/条件格式。该探针不修改旧模块文件；也不代表游戏全部自定义 UI、语言目录及资源生命周期已完成迁移。

本轮 API 6 样例重新构建 Bundle 并声明 module_owned_resources_v1，不用于证明旧 API 5 Bundle 二进制兼容。测试探针仅在 Editor 或 Development Build 编译；正式包不编译测试身份和模拟广告驱动。退出探针等待 HasPendingExit 完成，不能假定一帧完成回收。

探针用 10 秒实时期限等待退出，避免高帧率下固定帧数提前超时；生产产品应显示等待/错误状态，由宿主继续回收，不能在超时后强行忽略 HasPendingExit 进入下一模块。
