#if UNITY_EDITOR || DEVELOPMENT_BUILD
using MiniGamePlatform.SDK.Host;
using System;
using System.Collections;
using System.IO;
using System.Security.Cryptography;
using MiniGamePlatform.HotUpdate;
using MiniGamePlatform.SDK;
using MiniGamePlatform.SDK.GameData;
using MiniGamePlatform.Components;
using UnityEngine.EventSystems;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Networking;
using UnityEngine.UI;
using TMPro;
using XLua;

public sealed class NativeRuntimeProbe : MonoBehaviour
{
    [Serializable] private sealed class Result { public bool passed; public int assertions; public string backend, platform, error; public int pointerBytes; }
    private int _checks;
    private ModulePlayer _player;
    private string _directory;
    private void Check(bool value, string reason) { _checks++; if (!value) throw new Exception(reason); }
    private static string Hash(byte[] bytes) { using var sha = SHA256.Create(); return BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant(); }

    private IEnumerator Start()
    {
        var result = new Result { platform = Application.platform.ToString(), pointerBytes = IntPtr.Size,
#if ENABLE_IL2CPP
            backend = "IL2CPP"
#else
            backend = "Mono"
#endif
        };
        IEnumerator checks = RunChecks();
        while (true)
        {
            object current;
            try { if (!checks.MoveNext()) { result.passed = true; break; } current = checks.Current; }
            catch (Exception e) { result.error = e.ToString(); Debug.LogException(e); break; }
            yield return current;
        }
        _player?.Dispose();
        result.assertions = _checks;
        string json = JsonUtility.ToJson(result, true);
        File.WriteAllText(Path.Combine(Application.persistentDataPath, "native-baseline-result.json"), json);
        Debug.Log("NATIVE_BASELINE_RESULT " + json);
#if UNITY_EDITOR
        if (Application.isBatchMode) UnityEditor.EditorApplication.Exit(result.passed ? 0 : 1);
#endif
    }

    private IEnumerator RunChecks()
    {
        IEnumerator timing = TimingProbe.Run(Check);
        try { while (timing.MoveNext()) yield return timing.Current; }
        finally { (timing as IDisposable)?.Dispose(); }
        IEnumerator services = HostServicesProbe.Run(Check);
        try { while (services.MoveNext()) yield return services.Current; }
        finally { (services as IDisposable)?.Dispose(); }
        IEnumerator extensions = NativeExtensionsProbe.Run(Check);
        try { while (extensions.MoveNext()) yield return extensions.Current; }
        finally { (extensions as IDisposable)?.Dispose(); }
        Check(DelegateBridge.Gen_Flag, "Static callback path is not enabled.");
        var env = new LuaEnv();
        InvokeNativeEvents(env); env.DoString("native_fn=nil; native_value=nil; collectgarbage('collect')");
        // Let the completed callback stack unwind before checking that no delegate is retained.
        yield return null;
        env.Dispose();
        bool closed = false; try { var state = env.L; } catch (InvalidOperationException) { closed = true; }
        Check(closed, "Native Lua state leaked after Dispose."); env.Dispose();

        _directory = Path.Combine(Application.temporaryCachePath, "native-baseline-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(Path.Combine(_directory, "games/nativecheck"));
        foreach (string name in new[] { "manifest.json", "native.bundle", "games/nativecheck/main.lua" })
        {
            string location = Application.streamingAssetsPath + "/NativeValidation/" + name;
            if (!location.Contains("://")) location = new Uri(location).AbsoluteUri;
            using var request = UnityWebRequest.Get(location);
            yield return request.SendWebRequest();
            Check(request.result == UnityWebRequest.Result.Success, "Fixture read failed: " + name + " " + request.error);
            File.WriteAllBytes(Path.Combine(_directory, name), request.downloadHandler.data);
        }
        string hash = Hash(File.ReadAllBytes(Path.Combine(_directory, "manifest.json")));
        foreach (string shell in new[] { "hub", "independent", "hub" })
        {
            string message = null;
            // Exercise default shell construction and explicit host composition with identical Lua.
            _player = shell == "independent"
                ? new ModulePlayer(shell, "nativecheck", null, CommonModuleServiceFactory.CreateDefault())
                : new ModulePlayer(shell);
            _player.OpenInstalled(_directory, hash, new ProductContext("native_test", "https://example.invalid", "1.0.0", new[] { "nativecheck" }), null, null, s => message = s);
            Check(message == "entered" && _player.State == GameRunState.Running, "Lua native enter failed.");
            _player.Tick();
            yield return null;
            var root = GameObject.Find("NativeRoot");
            Check(root != null, "Native prefab missing.");
            var button = root.transform.Find("ScrollArea/Button").GetComponent<Button>();
            var clickEvent = button.onClick;
            var text = root.transform.Find("Label").GetComponent<TextMeshProUGUI>();
            var animator = root.transform.Find("Actor").GetComponent<Animator>();
            var ps = root.transform.Find("Fx").GetComponent<ParticleSystem>();
            var audio = root.transform.Find("Audio").GetComponent<AudioSource>();
            Check(button.GetComponent<RectTransform>().anchoredPosition == new Vector2(17, 29), "RectTransform direct write failed.");
            Check(root.GetComponent<CanvasGroup>().alpha == .75f && text.text == "native", "Native CanvasGroup/TMP write failed.");
            clickEvent.Invoke(); Check(text.text == "click:1", "Native Button callback failed.");
            Check(button.image.sprite != null && button.image.material != null && text.font != null, "Generic native asset reads failed.");
            var relay = button.GetComponent<ModulePointerRelay>();
            Check(relay != null && ExecuteEvents.GetEventHandler<IDragHandler>(button.gameObject) == button.transform.parent.gameObject,
                "Relay intercepted parent ScrollRect drag.");
            var fingerA = new PointerEventData(EventSystem.current) { pointerId = 11 };
            var fingerB = new PointerEventData(EventSystem.current) { pointerId = 12 };
            relay.OnPointerDown(fingerA); Check(text.text == "down:11", "Pointer Lua callback failed.");
            relay.OnPointerDown(fingerB); relay.OnPointerExit(fingerA); Check(text.text == "exit:11", "Pointer exit callback failed.");
            relay.OnPointerUp(fingerA); Check(text.text == "up:11", "Pointer up callback failed.");
            Check(animator.GetBool("Running") && animator.GetCurrentAnimatorStateInfo(0).IsName("Base Layer.Move"), "Native Animator state failed.");
            Check(ps.isPlaying && audio.clip != null && audio.loop, "Native media configuration failed.");
            int ticks = _player.SuccessfulTicks;
            _player.Pause(); _player.Tick();
            Check(_player.SuccessfulTicks == ticks && !button.interactable && !root.GetComponent<CanvasGroup>().blocksRaycasts, "Pause did not suspend module/input.");
            Check(text.text == "cancel:12", "Disabled relay did not cancel outstanding finger.");
            string pausedText = text.text;
            clickEvent.Invoke(); Check(text.text == pausedText, "Paused callback changed game.");
            Check(animator.speed == 0 && ps.isPaused && !audio.isPlaying, "Native media pause failed.");
            _player.Resume(); _player.Tick();
            relay.OnPointerUp(fingerB); Check(text.text == pausedText, "Stale finger survived pause.");
            relay.OnSubmit(new BaseEventData(EventSystem.current)); Check(text.text == "submit", "Submit Lua callback failed.");
            Check(button.interactable && animator.speed == 1 && ps.isPlaying, "Native media/input resume failed.");
            // Close from a subsequent frame, after the synthetic event invocation stack unwinds.
            yield return null;
            _player.Exit();
            // Disposed userdata can remain conservatively rooted until the host call stack unwinds.
            // A pending environment must be retained, not replaced or force-closed.
            for (double deadline = Time.realtimeSinceStartupAsDouble + 10;
                _player.HasPendingExit && Time.realtimeSinceStartupAsDouble < deadline;) yield return null;
            Check(_player.State == GameRunState.Empty && !_player.HasPendingExit && message == "unbound",
                "Exit or tracked unbind failed: " + message + " " + _player.LastError);
            clickEvent.Invoke(); // Must no longer call Lua, even while the Unity destruction is deferred.
            yield return null;
            Check(root == null, "Module root survived exit.");
            _player.Dispose(); _player = null;
        }
    }

    // Separate stack frame ensures temporary delegate locals are not roots during LuaEnv.Dispose.
    private void InvokeNativeEvents(LuaEnv env)
    {
        env.DoString("function native_fn(v) native_value=v end");
        var evt = new UnityEvent<float>();
        var callback = env.Global.Get<UnityAction<float>>("native_fn");
        evt.AddListener(callback); evt.Invoke(.5f);
        Check(env.Global.Get<float>("native_value") == .5f, "Static float callback failed.");
        evt.RemoveListener(callback); evt.Invoke(.75f);
        Check(env.Global.Get<float>("native_value") == .5f, "Exact delegate removal failed.");
        env.Global.Get<UnityAction<bool>>("native_fn")(true); Check(env.Global.Get<bool>("native_value"), "Static bool callback failed.");
        env.Global.Get<UnityAction<int>>("native_fn")(9); Check(env.Global.Get<int>("native_value") == 9, "Static int callback failed.");
        env.Global.Get<UnityAction<string>>("native_fn")("native"); Check(env.Global.Get<string>("native_value") == "native", "Static string callback failed.");
        env.Global.Get<UnityAction<Vector2>>("native_fn")(new Vector2(3, 4)); Check(env.Global.Get<Vector2>("native_value") == new Vector2(3, 4), "Static Vector2 callback failed.");
    }
    private void OnDestroy() { _player?.Dispose(); }
}

#endif
