#if UNITY_EDITOR || DEVELOPMENT_BUILD
using System;
using System.Collections;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using MiniGamePlatform.HotUpdate;
using MiniGamePlatform.SDK;
using MiniGamePlatform.SDK.Auth;
using MiniGamePlatform.SDK.Contracts;
using MiniGamePlatform.SDK.GameData;
using MiniGamePlatform.SDK.Host;
using MiniGamePlatform.SDK.Network;
using UnityEngine;

public static class HostServicesProbe
{
    private sealed class TestTransport : IPlatformTransport
    {
        public string User = "account-A";
        public void Send<T>(ApiRequest request, Action<ApiResult<T>> callback)
        {
            callback(ApiResult<T>.FromJson("{\"data\":{\"userId\":\"" + User + "\",\"accessToken\":\"local-test\",\"refreshToken\":\"local-test\",\"expiresInSeconds\":3600}}", 200));
        }
    }
    private static string Hash(byte[] bytes)
    { using var sha = SHA256.Create(); return BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant(); }
    public static IEnumerator Run(Action<bool, string> check)
    {
        string root = Path.Combine(Application.temporaryCachePath, "host-services-" + Guid.NewGuid().ToString("N"));
        string luaPath = "games/servicecheck/main.lua";
        Directory.CreateDirectory(Path.Combine(root, "games/servicecheck"));
        var queue = new HostMainThreadQueue(); var driver = new LocalTestAdDriver();
        var store = new AtomicLocalStore(Path.Combine(root, "saves"));
        var factory = new CommonModuleServiceFactory(store, new HostAdBroker(driver, queue));
        var credentials = new EditorMemoryCredentialStore(); // Explicit non-network test identity, never production login.
        credentials.Save(new CredentialState { DeviceId = "probe", UserId = "account-A" });
        var transport = new TestTransport(); var session = new PlatformSession(transport, credentials, "probe");
        var product = new ProductContext("probe", "https://example.invalid", "1.0.0", new[] { "servicecheck", "other" });
        byte[] lua = Encoding.UTF8.GetBytes(@"local host
return {
 enter=function(h)
  host=h
  assert(h.Services.Account.IsAvailable and h.Services.Account.UserId=='account-A')
  h.Services.Storage:Write('progress', 'entered')
  assert(h.Services.Storage:Read('progress')=='entered')
  h.Services.Account:Invalidated('+', function() h:ShowMessage('invalidated') end)
  h.Services.Ads:Show('continue','rewarded',function(json) h:ShowMessage(json) end)
  h:ShowMessage('services-entered')
 end,
 exit=function()
  if host.Services.Storage.IsAvailable then host.Services.Storage:Write('progress','exited') end
  host=nil
 end
}");
        File.WriteAllBytes(Path.Combine(root, luaPath), lua);
        var manifest = new ModuleManifest { formatVersion=1, gameId="servicecheck", version="v1", runtimeType="unity_lua", entry="games.servicecheck.main",
            minHostApiVersion=1, platform="any", unityVersion=Application.unityVersion, requiredCapabilities=new[]{"lua"},
            files=new[]{new ModuleFile {path=luaPath,size=lua.Length,sha256=Hash(lua)}} };
        byte[] json = Encoding.UTF8.GetBytes(JsonUtility.ToJson(manifest)); File.WriteAllBytes(Path.Combine(root, "manifest.json"), json);
        IModuleHostServices old = null;
        ModulePlayer player = null;
        try
        {
            foreach (string shell in new[]{"hub","independent"})
            {
                string message=null;
                player = new ModulePlayer(shell, shell=="independent" ? "servicecheck" : null, null, factory);
                player.OpenInstalled(root,Hash(json),product,session,null,s=>message=s);
                check(message=="services-entered", "Host services did not reach Lua enter.");
                var worker = new Thread(driver.Complete); worker.Start(); worker.Join();
                check(message=="services-entered", "Worker thread invoked Lua.");
                queue.Drain(); check(message.Contains("completed") && message.Contains("\"isTest\":true"), "Test ad callback missing.");
                yield return null;
                player.Exit(); for(double deadline=Time.realtimeSinceStartupAsDouble+10; player.HasPendingExit && Time.realtimeSinceStartupAsDouble<deadline;) yield return null;
                check(!player.HasPendingExit && player.LastError==null, "Service callbacks retained Lua after exit.");
                check(store.Read("account-A","servicecheck","progress")=="exited", "Exit could not save before scope disposal.");
                player.Dispose(); player=null;
            }
            old=factory.CreateServices(manifest,product,session);
            old.Storage.Write("atomic","old");
            var fault = new AtomicLocalStore(Path.Combine(root,"saves"),(a,b)=>{throw new IOException("injected commit failure");});
            bool rejected=false; try { fault.Write("account-A","servicecheck","atomic","bad"); } catch(IOException) { rejected=true; }
            check(rejected && old.Storage.Read("atomic")=="old", "Atomic save failure damaged old data.");
            using(var other=factory.CreateServices(new ModuleManifest {gameId="other"},product,session))
                check(other.Storage.Read("atomic")==null,"Cross-game local data leak.");
            transport.User="account-B"; session.LoginGuest(_=>{});
            using(var b=factory.CreateServices(manifest,product,session)) check(b.Storage.Read("atomic")==null,"Cross-account local data leak.");
            transport.User="account-A"; session.LoginGuest(_=>{});
            check(!old.Storage.IsAvailable,"A-B-A revived old scope.");
            string after=null;
            player=new ModulePlayer("hub",null,null,factory); player.OpenInstalled(root,Hash(json),product,session,null,s=>after=s);
            yield return null;
            player.Exit(); for(double deadline=Time.realtimeSinceStartupAsDouble+10; player.HasPendingExit && Time.realtimeSinceStartupAsDouble<deadline;) yield return null;
            check(!player.HasPendingExit,"Pending ad retained exited Lua.");
            driver.Complete(); queue.Drain(); check(after=="services-entered","Exited Lua received ad callback.");
        }
        finally
        {
            player?.Dispose(); old?.Dispose();
            driver.Cancel(); queue.Drain();
            Directory.Delete(root,true);
        }
    }
}

#endif
