#if UNITY_EDITOR || DEVELOPMENT_BUILD
using System;
using System.Collections;
using MiniGamePlatform.Components;
using UnityEngine;
using UnityEngine.UI;
using XLua;

public static class NativeExtensionsProbe
{
    public static IEnumerator Run(Action<bool, string> check)
    {
        check(MiniGamePlatform.HotUpdate.LocalizationBaseline.IsAvailable, "Exact Localization 1.4.4 baseline not compiled.");
        var env = new LuaEnv();
        var root = new GameObject("NativeExtensionCanvas", typeof(RectTransform), typeof(Canvas));
        root.GetComponent<Canvas>().renderMode = RenderMode.ScreenSpaceOverlay;
        var maskObject = new GameObject("Mask", typeof(RectTransform), typeof(Image), typeof(Mask));
        maskObject.transform.SetParent(root.transform, false);
        maskObject.GetComponent<RectTransform>().sizeDelta = new Vector2(100, 100);
        var clipping = new GameObject("Clip", typeof(RectTransform), typeof(RectMask2D));
        clipping.transform.SetParent(maskObject.transform, false);
        clipping.GetComponent<RectTransform>().sizeDelta = new Vector2(100, 100);
        var child = new GameObject("Mesh", typeof(RectTransform), typeof(ModuleMeshGraphic), typeof(ModuleRaycastFilter));
        child.transform.SetParent(clipping.transform, false);
        var graphic = child.GetComponent<ModuleMeshGraphic>();
        var filter = child.GetComponent<ModuleRaycastFilter>();
        var texture = new Texture2D(1, 1);
        var material = new Material(Shader.Find("UI/Default"));
        Mesh borrowed = null;
        try
        {
            env.Global.Set("graphic", graphic); env.Global.Set("filter", filter);
            env.Global.Set("texture", texture); env.Global.Set("material", material);
            env.DoString(@"
local V3 = CS.UnityEngine.Vector3
mesh = CS.UnityEngine.Mesh()
mesh.vertices = { V3(-10,-10,0), V3(10,-10,0), V3(0,10,0) }
mesh.triangles = {0,1,2}
graphic.Mesh = mesh; graphic.Texture = texture; graphic.material = material
filter.Filter = function(point, camera) return point.x > 0 and camera == nil end
local fmt = CS.UnityEngine.Localization.SmartFormat.Smart.CreateDefaultSmartFormat()
local values = CS.System.Collections.Generic.Dictionary(CS.System.String, CS.System.Object)()
values:Add('name','player'); values:Add('count',2)
assert(values:ContainsKey('name') and values.Count == 2)
local culture = CS.System.Globalization.CultureInfo.GetCultureInfo('en-US')
assert(fmt:Format(culture, '{name}: {count:0}', values) == 'player: 2')
assert(fmt:Format(culture, '{count:plural:one|many}', values) == 'many')
assert(fmt:Format(culture, '{count:cond:>1?more|single}', values) == 'more')
");
            borrowed = graphic.Mesh;
            check(borrowed != null && borrowed.vertexCount == 3, "Lua authored mesh missing.");
            check(graphic.mainTexture == texture && graphic.material == material, "Mesh native resource assignment failed.");
            check(filter.IsRaycastLocationValid(Vector2.one, null) && !filter.IsRaycastLocationValid(Vector2.zero, null), "Static AOT bool(Vector2,Camera) callback failed.");
            filter.enabled = false;
            check(filter.IsRaycastLocationValid(Vector2.zero, null), "Disabled filter interfered with UGUI."); filter.enabled = true;
            yield return null; Canvas.ForceUpdateCanvases();
            check(graphic.canvasRenderer.GetMesh().vertexCount == 3, "UGUI did not render borrowed mesh.");
            var shadow = child.AddComponent<Shadow>();
            yield return null; Canvas.ForceUpdateCanvases();
            check(graphic.canvasRenderer.GetMesh().vertexCount == 6, "Native Shadow mesh modifier was bypassed.");
            shadow.enabled = false;
            check(graphic.materialForRendering != material && graphic.materialForRendering.GetInt("_Stencil") > 0, "Mask stencil material was bypassed.");
            child.GetComponent<RectTransform>().anchoredPosition = new Vector2(300, 0);
            yield return null; Canvas.ForceUpdateCanvases();
            check(graphic.canvasRenderer.cull, "RectMask2D did not cull outside geometry.");
            child.GetComponent<RectTransform>().anchoredPosition = Vector2.zero;
            yield return null; Canvas.ForceUpdateCanvases();
            check(!graphic.canvasRenderer.cull, "RectMask2D did not restore visible geometry.");
            graphic.Mesh = null; Canvas.ForceUpdateCanvases();
            var cleared = graphic.canvasRenderer.GetMesh();
            check(cleared == null || cleared.vertexCount == 0, "Cleared mesh remained visible.");
            env.DoString("filter.Filter=nil; filter=nil; graphic=nil; mesh=nil; texture=nil; material=nil; collectgarbage('collect')");
            UnityEngine.Object.Destroy(root);
            yield return null;
            check(borrowed != null && texture != null && material != null, "UGUI carrier destroyed borrowed resources.");
            env.Dispose(); env = null;
        }
        finally
        {
            // Failure cleanup also releases Lua callbacks before tearing down their environment.
            if (filter != null) filter.Filter = null;
            UnityEngine.Object.Destroy(root); UnityEngine.Object.Destroy(borrowed);
            UnityEngine.Object.Destroy(texture); UnityEngine.Object.Destroy(material);
            if (env != null) { env.DoString("filter=nil; graphic=nil; mesh=nil; texture=nil; material=nil; collectgarbage('collect')"); env.Dispose(); }
        }
    }
}

#endif
