using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using MiniGamePlatform.HotUpdate;
using MiniGamePlatform.SDK.EditorChecks;
using TMPro;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public static class NativeValidationBuild
{
    private const string Root = "Assets/NativeValidation/Fixtures";
    private const string Destination = "Assets/StreamingAssets/NativeValidation";
    private static void Guard()
    {
        if (!File.Exists(".native-sdk-validation") || File.ReadAllText(".native-sdk-validation").Trim() != "MGP_NATIVE_VALIDATION_ONLY")
            throw new InvalidOperationException("Only run this in a dedicated SDK validation project.");
    }
    private static string Hash(byte[] bytes) { using var sha = SHA256.Create(); return BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant(); }
    private static ModuleFile Entry(string relative)
    { byte[] bytes = File.ReadAllBytes(Path.Combine(Destination, relative)); return new ModuleFile { path = relative, size = bytes.Length, sha256 = Hash(bytes) }; }
    private static void DeleteOwnedAsset(string name)
    { string path = Root + "/" + name; if (AssetDatabase.LoadMainAssetAtPath(path) != null) AssetDatabase.DeleteAsset(path); }

    private static void Prepare(BuildTarget target)
    {
        Guard();
        Directory.CreateDirectory(Root); Directory.CreateDirectory(Destination + "/games/nativecheck"); AssetDatabase.Refresh();
        DeleteOwnedAsset("Move.anim"); DeleteOwnedAsset("Actor.controller"); DeleteOwnedAsset("native.prefab");
        var clip = new AnimationClip(); clip.SetCurve("Bone", typeof(Transform), "localPosition.x", AnimationCurve.Linear(0, 0, 1, 1));
        AssetDatabase.CreateAsset(clip, Root + "/Move.anim");
        var controller = AnimatorController.CreateAnimatorControllerAtPath(Root + "/Actor.controller");
        controller.AddParameter("Running", AnimatorControllerParameterType.Bool);
        var state = controller.layers[0].stateMachine.AddState("Move"); state.motion = clip;
        controller.layers[0].stateMachine.defaultState = state;
        using (var wav = new BinaryWriter(File.Create(Root + "/tone.wav")))
        {
            const int samples = 22050;
            wav.Write(System.Text.Encoding.ASCII.GetBytes("RIFF")); wav.Write(36 + samples * 2);
            wav.Write(System.Text.Encoding.ASCII.GetBytes("WAVEfmt ")); wav.Write(16); wav.Write((short)1); wav.Write((short)1);
            wav.Write(samples); wav.Write(samples * 2); wav.Write((short)2); wav.Write((short)16);
            wav.Write(System.Text.Encoding.ASCII.GetBytes("data")); wav.Write(samples * 2);
            for (int i = 0; i < samples; i++) wav.Write((short)(Math.Sin(i * 440 * 2 * Math.PI / samples) * 100));
        }
        AssetDatabase.ImportAsset(Root + "/tone.wav");
        var icon = new Texture2D(2, 2); icon.SetPixels(new[] { Color.white, Color.white, Color.white, Color.white }); icon.Apply();
        File.WriteAllBytes(Root + "/Icon.png", icon.EncodeToPNG()); UnityEngine.Object.DestroyImmediate(icon);
        AssetDatabase.ImportAsset(Root + "/Icon.png");
        var iconImporter = (TextureImporter)AssetImporter.GetAtPath(Root + "/Icon.png");
        iconImporter.textureType = TextureImporterType.Sprite; iconImporter.spriteImportMode = SpriteImportMode.Single; iconImporter.SaveAndReimport();
        DeleteOwnedAsset("UI.mat"); AssetDatabase.CreateAsset(new Material(Shader.Find("UI/Default")), Root + "/UI.mat");
        var root = new GameObject("NativeRoot", typeof(RectTransform), typeof(Canvas), typeof(CanvasGroup), typeof(CanvasScaler), typeof(GraphicRaycaster));
        try
        {
            root.GetComponent<Canvas>().renderMode = RenderMode.ScreenSpaceOverlay;
            var scroll = new GameObject("ScrollArea", typeof(RectTransform), typeof(ScrollRect)); scroll.transform.SetParent(root.transform, false);
            var button = new GameObject("Button", typeof(RectTransform), typeof(Image), typeof(Button)); button.transform.SetParent(scroll.transform, false);
            var label = new GameObject("Label", typeof(RectTransform), typeof(TextMeshProUGUI)); label.transform.SetParent(root.transform, false);
            var font = TMP_Settings.defaultFontAsset;
            if (font == null) throw new InvalidOperationException("Import TMP Essential Resources into this validation project first.");
            label.GetComponent<TextMeshProUGUI>().font = font; label.GetComponent<TextMeshProUGUI>().text = "Authored TMP";
            var actor = new GameObject("Actor", typeof(Animator)); actor.transform.SetParent(root.transform, false);
            new GameObject("Bone").transform.SetParent(actor.transform, false);
            actor.GetComponent<Animator>().runtimeAnimatorController = controller;
            var fx = new GameObject("Fx", typeof(ParticleSystem)); fx.transform.SetParent(root.transform, false);
            var main = fx.GetComponent<ParticleSystem>().main; main.playOnAwake = false;
            fx.GetComponent<ParticleSystem>().Stop();
            var audio = new GameObject("Audio", typeof(AudioSource)); audio.transform.SetParent(root.transform, false);
            audio.GetComponent<AudioSource>().clip = AssetDatabase.LoadAssetAtPath<AudioClip>(Root + "/tone.wav");
            audio.GetComponent<AudioSource>().playOnAwake = false; audio.GetComponent<AudioSource>().mute = true;
            PrefabUtility.SaveAsPrefabAsset(root, Root + "/native.prefab");
        }
        finally { UnityEngine.Object.DestroyImmediate(root); }
        AssetDatabase.SaveAssets();
        string[] caps = { "lua", "assetbundle", "module_owned_resources_v1", NativeLuaBaseline.Capability };
        var inventory = HostComponentInventory.FromCapabilities(caps, new[] { "GUI/Text Shader", "UI/Default", "Particles/Standard Unlit", "Particles/Standard Surface", "Legacy Shaders/Particles/Alpha Blended Premultiply" });
        string fontPath = AssetDatabase.GetAssetPath(TMP_Settings.defaultFontAsset);
        var definition = new ModuleDefinition { minHostApiVersion = 6, requiredCapabilities = caps, assetRoots = new[] {
            Root + "/native.prefab", Root + "/Icon.png", Root + "/UI.mat", Root + "/tone.wav", Root + "/Actor.controller", fontPath } };
        var errors = AssetDependencyValidator.Validate(definition, inventory);
        if (errors.Count != 0) throw new Exception(string.Join("; ", errors.Select(e => e.Code + ":" + e.Message)));
        var bundles = BuildPipeline.BuildAssetBundles(Destination, new[] { new AssetBundleBuild { assetBundleName = "native.bundle", assetNames = definition.assetRoots } }, BuildAssetBundleOptions.ForceRebuildAssetBundle, target);
        if (bundles == null) throw new Exception("Native fixture bundle failed.");
        File.WriteAllText(Destination + "/games/nativecheck/main.lua", File.ReadAllText("Assets/NativeValidation/main.lua.txt")
            .Replace("__FONT_PATH__", fontPath.ToLowerInvariant()), new System.Text.UTF8Encoding(false));
        var manifest = new ModuleManifest { formatVersion = 1, gameId = "nativecheck", version = "v1", runtimeType = "unity_lua",
            entry = "games.nativecheck.main", minHostApiVersion = 6, platform = target == BuildTarget.Android ? "android" : "editor",
            unityVersion = Application.unityVersion, requiredCapabilities = caps,
            files = new[] { Entry("native.bundle"), Entry("games/nativecheck/main.lua") } };
        File.WriteAllText(Destination + "/manifest.json", JsonUtility.ToJson(manifest), new System.Text.UTF8Encoding(false));
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        new GameObject("NativeRuntimeProbe", typeof(NativeRuntimeProbe), typeof(AudioListener));
        new GameObject("NativeEventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
        EditorSceneManager.SaveScene(scene, "Assets/NativeValidation/Validation.unity"); AssetDatabase.Refresh();
    }

    public static void RunEditor()
    {
        Prepare(BuildTarget.StandaloneWindows64);
        EditorApplication.EnterPlaymode(); // Probe exits batchmode with its actual result.
    }

    public static void BuildAndroid()
    {
        Guard();
        PlayerSettings.SetScriptingBackend(BuildTargetGroup.Android, ScriptingImplementation.IL2CPP);
        PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
        PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel23;
        PlayerSettings.SetManagedStrippingLevel(BuildTargetGroup.Android, ManagedStrippingLevel.High);
        PlayerSettings.stripEngineCode = true;
        PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.Android, "com.minigame.sdk.nativevalidation");
        PlayerSettings.SetUseDefaultGraphicsAPIs(BuildTarget.Android, false);
        PlayerSettings.SetGraphicsAPIs(BuildTarget.Android, new[] { UnityEngine.Rendering.GraphicsDeviceType.OpenGLES3 });
        EditorUserBuildSettings.buildAppBundle = false;
        Prepare(BuildTarget.Android);
        Directory.CreateDirectory("Builds");
        var report = ModuleHostKeyBuild.BuildPlayer(new BuildPlayerOptions { scenes = new[] { "Assets/NativeValidation/Validation.unity" },
            target = BuildTarget.Android, locationPathName = "Builds/native-baseline-arm64.apk", options = BuildOptions.Development });
        if (report.summary.result != BuildResult.Succeeded) throw new Exception("Android native baseline build failed: " + report.summary.result);
        Debug.Log("NATIVE_ANDROID_BUILD_SUCCEEDED arm64 IL2CPP high stripping, bytes=" + report.summary.totalSize);
    }
}
