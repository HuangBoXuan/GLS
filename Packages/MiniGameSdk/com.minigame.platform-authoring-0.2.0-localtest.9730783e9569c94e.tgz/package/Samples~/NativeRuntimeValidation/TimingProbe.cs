#if UNITY_EDITOR || DEVELOPMENT_BUILD
using System;
using System.Collections;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using MiniGamePlatform.HotUpdate;
using MiniGamePlatform.SDK;
using UnityEngine;

public static class TimingProbe
{
    private static string Hash(byte[] bytes)
    { using var sha = SHA256.Create(); return BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant(); }
    public static IEnumerator Run(Action<bool, string> check)
    {
        string root = Path.Combine(Application.temporaryCachePath,"timing-"+Guid.NewGuid().ToString("N"));
        string path="games/timing/main.lua";
        Directory.CreateDirectory(Path.Combine(root,"games/timing"));
        byte[] lua=Encoding.UTF8.GetBytes(@"local host, callback; local frames=0; local paused=false
return {
 enter=function(h)
  host=h
  callback=CS.UnityEngine.Camera.CameraCallback(function(camera)
   if camera.name=='TimingProbeCamera' then h:ShowMessage('camera') end
  end)
  if CS.UnityEngine.Camera.onPreCull==nil then CS.UnityEngine.Camera.onPreCull=callback
  else CS.UnityEngine.Camera.onPreCull=CS.UnityEngine.Camera.onPreCull+callback end
 end,
 update=function(dt) frames=frames+1 end,
 late_update=function(dt) assert(frames>0 and not paused); host:ShowMessage('late:'..frames) end,
 pause=function() paused=true end, resume=function() paused=false end,
 exit=function()
  if CS.UnityEngine.Camera.onPreCull~=nil and callback~=nil then
   CS.UnityEngine.Camera.onPreCull=CS.UnityEngine.Camera.onPreCull-callback
  end
  callback=nil; host=nil
 end
}");
        File.WriteAllBytes(Path.Combine(root,path),lua);
        var manifest=new ModuleManifest {formatVersion=1,gameId="timing",version="v1",runtimeType="unity_lua",entry="games.timing.main",
            minHostApiVersion=5,platform="any",unityVersion=Application.unityVersion,
            requiredCapabilities=new[]{"lua","lua_late_update_v1","unity_camera_callback_v1"},
            files=new[]{new ModuleFile {path=path,size=lua.Length,sha256=Hash(lua)}}};
        byte[] json=Encoding.UTF8.GetBytes(JsonUtility.ToJson(manifest)); File.WriteAllBytes(Path.Combine(root,"manifest.json"),json);
        var node=new GameObject("TimingProbeHost"); var host=node.AddComponent<ModulePlayerBehaviour>();
        var cameraNode=new GameObject("TimingProbeCamera"); var camera=cameraNode.AddComponent<Camera>(); camera.enabled=false; camera.cullingMask=0;
        var target=new RenderTexture(16,16,16); camera.targetTexture=target;
        string message=null; Exception failure=null;
        try
        {
            host.Failed+=e=>failure=e;
            host.Initialize("hub",null,new ProductContext("probe","https://example.invalid","1.0.0",new[]{"timing"}),null);
            host.OpenInstalled(root,Hash(json),null,s=>message=s);
            yield return null; yield return null;
            check(failure==null && message!=null && message.StartsWith("late:"),"Behaviour did not drive late_update after update: "+failure);
            host.SetPaused(true); string paused=message;
            yield return null; yield return null;
            check(message==paused && failure==null,"Paused module still ran late_update.");
            camera.Render(); check(message=="camera","Native Camera.onPreCull Lua callback failed.");
            host.SetPaused(false); yield return null; yield return null;
            check(message.StartsWith("late:") && failure==null,"late_update did not resume.");
            host.Exit(); for(double deadline=Time.realtimeSinceStartupAsDouble+10; host.Player.HasPendingExit && Time.realtimeSinceStartupAsDouble<deadline;) yield return null;
            check(!host.Player.HasPendingExit && host.Player.LastError==null,"Camera delegate retained Lua after unsubscribe.");
            message="exited"; camera.Render(); host.Player.LateTick();
            check(message=="exited","Camera or late_update callback remained after exit.");
        }
        finally
        {
            host.Exit(); camera.targetTexture=null;
            UnityEngine.Object.Destroy(node); UnityEngine.Object.Destroy(cameraNode); UnityEngine.Object.Destroy(target);
            Directory.Delete(root,true);
        }
    }
}

#endif
