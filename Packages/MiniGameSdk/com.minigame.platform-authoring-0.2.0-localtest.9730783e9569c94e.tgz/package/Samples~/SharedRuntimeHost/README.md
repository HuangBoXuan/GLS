# 独立包与综合包共用宿主模板

复制本目录到产品壳的 Assets。它是 C# 产品入口，不是可下载小游戏源码。

场景添加 SharedModuleShell，独立包配置 independent=true 和 gameId；综合包配置 independent=false。外层按已有流程获取 ProductContext、PlatformSession、已验证目录与 ModuleReleaseSelection，然后调用 Open。小游戏继续使用同一 manifest、Lua 和 Bundle。

示例不内置服务器地址、密钥、广告参数、未校验URL或试玩奖励。Open 的 selection 必须来自当前有效可信目录；恢复已缓存游戏也需先检查上下架规则，再调用 Player.OpenInstalled。发布检查仍要求相同模块哈希的 Android 双包证据。
