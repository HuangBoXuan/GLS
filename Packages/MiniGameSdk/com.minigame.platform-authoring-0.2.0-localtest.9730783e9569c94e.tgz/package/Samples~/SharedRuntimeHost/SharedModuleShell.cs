using System;
using System.Collections;
using System.IO;
using MiniGamePlatform.HotUpdate;
using MiniGamePlatform.SDK;
using MiniGamePlatform.SDK.Auth;
using MiniGamePlatform.SDK.GameData;
using MiniGamePlatform.SDK.Host;
using UnityEngine;

public sealed class SharedModuleShell : MonoBehaviour
{
    public bool independent = true;
    public string gameId;
    private ModulePlayerBehaviour _player;
    private int _generation;
    private HostMainThreadQueue _serviceQueue;
    private CommonModuleServiceFactory _services;
    public ModulePlayerBehaviour Player => _player;

    // Invoke only after current trusted catalog selection and product login initialization.
    public void Open(ModuleReleaseSelection selection, string catalogBaseUrl, ProductContext product,
        PlatformSession session, string levelId, Action<string> status)
    {
        if (selection == null || selection.Status != ModuleSelectionStatus.Ready) throw new InvalidOperationException("Select a permitted release first.");
        if (product == null || !product.AllowsGame(selection.Release.gameId) ||
            (independent && selection.Release.gameId != gameId)) throw new InvalidOperationException("Game is not allowed by this product.");
        if (_player == null) _player = gameObject.AddComponent<ModulePlayerBehaviour>();
        if (_services == null)
        {
            _serviceQueue = new HostMainThreadQueue();
            // A null driver explicitly means ads are not configured. Reuse this broker across games.
            _services = new CommonModuleServiceFactory(new AtomicLocalStore(Path.Combine(Application.persistentDataPath, "ModuleLocalSaves")),
                new HostAdBroker(null, _serviceQueue));
        }
        int generation = ++_generation;
        StartCoroutine(ReplaceAndInstall(selection, catalogBaseUrl, product, session, levelId, status, generation));
    }

    private IEnumerator ReplaceAndInstall(ModuleReleaseSelection selection, string url, ProductContext product,
        PlatformSession session, string levelId, Action<string> status, int generation)
    {
        _player.Exit();
        while (_player.Player != null && _player.Player.HasPendingExit)
        {
            if (generation != _generation || !isActiveAndEnabled) yield break;
            status?.Invoke("正在释放上一款小游戏资源…");
            yield return null;
        }
        if (generation != _generation || !isActiveAndEnabled) yield break;
        _player.InitializeWithHost(independent ? "independent" : "hub", independent ? gameId : null, product, session, _services);
        yield return Install(selection, url, levelId, status, generation);
    }

    private IEnumerator Install(ModuleReleaseSelection selection, string url, string levelId, Action<string> status, int generation)
    {
        var installer = new ModuleInstaller(Path.Combine(Application.persistentDataPath, "MiniGameModules"));
        yield return installer.Install(selection, url, (manifest, directory) =>
        {
            if (generation != _generation || !isActiveAndEnabled) return;
            try { _player.OpenInstalled(directory, selection.Release.manifestSha256, levelId, status); }
            catch (Exception e) { status?.Invoke(e.Message); }
        }, error => { if (generation == _generation) status?.Invoke(error); });
    }
    // Exit requests cleanup; before destroying this host or switching scenes, the owning shell
    // must wait for Player.Player.HasPendingExit == false. The persistent host drives cleanup;
    // do not call Exit repeatedly or assume one frame always suffices.
    public void Exit() { _generation++; _player?.Exit(); }
    private void Update() { _serviceQueue?.Drain(); }
    private void OnDisable() { _generation++; StopAllCoroutines(); _player?.Exit(); }
}
