local M = {}

function M.enter(host)
    host:SpawnPrefab('sample_partner.bundle', 'assets/partnergame/prefabs/partnerui.prefab')
    host:ShowMessage('PartnerGame UGUI sample')
end

function M.exit()
end

return M
