# PartnerGame：受邀合作方接入样例

本样例面向 Unity 2022.3.76f1、Android、Built-In Render Pipeline、UGUI 和 核心 SDK、共用宿主、开发工具三个 0.2.0 包。它只演示 Lua 入口与可下载 Prefab；不包含账号、广告位、真实结算或 H5 运行时。

固定交付请以配套 `artifact-manifest.json` 的完整 `0.2.0-localtest.*` 版本为准。模块定义中的 `ruleVersion: r1`、`saveSchemaVersion: s1`、`levelMapPath` 是占位字段，样例不使用关卡表；接服务器前必须按游戏注册协议替换（服务端整数规则版本通常填写为 `"1"`），提供实际关卡映射文件并复制到声明的 dataRoot。不要将占位值当成已经注册成功。

下文 `Packages/com.minigame.platform-authoring` 路径适用于 embedded 包。使用 `.tgz` 安装时工具位于 Unity 解析后的包目录，可从 Package Manager 定位，脚本路径需替换为该实际目录；不要为运行脚本再复制一份旧 embedded 包。

在空 Unity 工程引用三个配套 Package 后，执行菜单 `MiniGame Platform/SDK/Import PartnerGame Sample`，样例会复制到 `Assets/PartnerGame`。已有同名目录时导入工具会停止，不覆盖你的文件。随后运行 `MiniGame Platform/SDK/Run Partner Import Checks`。模块定义在 `Assets/PartnerGame/module-definition.json`；它的 `assetRoots` 必须与导入后的 Prefab 路径一致。

构建时先把 Lua/数据复制到独立的源目录，避免把 Prefab、README 或 C# 误放进可下载模块。以下命令在工程根执行，`Unity.exe` 路径按本机安装位置调整：

```powershell
New-Item -ItemType Directory -Force Builds/partner-source/games/sample_partner | Out-Null
Copy-Item Assets/PartnerGame/games/sample_partner/main.lua Builds/partner-source/games/sample_partner/main.lua
& 'D:\Unity2022.3.25\2022.3.76f1\Editor\Unity.exe' -batchmode -nographics `
  -projectPath . -executeMethod MiniGamePlatform.SDK.EditorChecks.AndroidModuleBuilder.BuildFromCommandLine `
  -moduleDefinition Assets/PartnerGame/module-definition.json `
  -moduleSource Builds/partner-source -moduleOutput Builds/partner-output -quit
```

产物位于 `Builds/partner-output/modules/sample_partner/v1`，其中只有 Lua、Android bundle 与 manifest。版本号不可覆盖；修改玩法或资源后递增 `moduleVersion` 并重新构建。预览时先运行模块定义、Lua、资源依赖检查，并在 Android Development Player 中加载；Editor 成功只代表可预览。

提交给平台审核的材料包括 Lua 和资源源码、模块定义、所用 Unity 与 SDK 版本、组件/shader 依赖清单、不可变模块产物及 manifest SHA-256、独立包和综合包的 Android APK/设备日志/门禁报告。两包须使用同一模块清单哈希，完成进入、暂停、恢复、退出、再进入；综合包还需 A→B→A 与下载失败恢复。开发工具包内 `Tools~/VerifyModuleRelease.ps1` 可从工程根调用并生成报告；传入 `-ProjectPath` 可指定其他工程。平台会复现构建、人工审核、登记服务端游戏规则并签署正式目录；合作方不能指定产品广告 SDK 参数、广告位或共有钱包发奖规则。

两包门禁通过后，用 开发工具包内 `Tools~/PrepareModuleDelivery.ps1` 生成标准交付目录。先把供复验的游戏源码放在单独的 `review-source/Assets/PartnerGame`，不要把平台工程、Library 或游戏专属 C# 放进去。以下命令中的证据和 APK 路径替换为本游戏实际文件：

```powershell
& pwsh -NoProfile -File Packages/com.minigame.platform-authoring/Tools~/PrepareModuleDelivery.ps1 `
  -ModulePath Builds/partner-output/modules/sample_partner/v1 `
  -ModuleDefinition Assets/PartnerGame/module-definition.json `
  -SourceDirectory review-source -HostProfiles review/host-profiles.json `
  -GateReport review/gate-report.json `
  -IndependentEvidence review/independent.json -HubEvidence review/hub.json `
  -IndependentApk review/independent.apk -HubApk review/hub.apk `
  -IndependentLog review/independent.log -HubLog review/hub.log `
  -RightsFile review/rights.md -OutputDirectory Builds/partner-delivery
```

输出的 `modules/<gameId>/<version>/` 是独立包和综合包共用的运行模块；`review/<gameId>/<version>/delivery.json` 列出私有审核材料的大小和 SHA-256。工具在本地拒绝缺少资源根、游戏 C#、APK／日志哈希不符和过大的权属说明。后续发行方上传器把这两组文件放入测试对象存储的固定路径；玩家只读取 `modules/`，不读取 `review/`。

`runtimeType` 为将来的 H5/WebView 留有扩展点；当前只支持 `unity_lua`，没有 H5 构建器或运行环境。真实玩法迁移前，先把专属 C# 玩法改为 Lua，或把经过审核的通用组件升级到宿主商店包；可下载模块不能包含专属 C#、DLL 或原生库。

新版 Bundle 模块使用宿主 API 6，并声明 module_owned_resources_v1。调用 Exit 后等待 HasPendingExit=false，再进行下次进入或替换播放器。
