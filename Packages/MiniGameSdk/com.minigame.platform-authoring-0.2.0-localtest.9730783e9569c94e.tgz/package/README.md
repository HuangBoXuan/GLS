# MiniGame 开发与交付工具 0.2.0

Editor 构建、资源依赖检查、发布门禁、CLI 交付与可选样例。安装时同时引用同一套核心 SDK 与宿主包。Editor 程序集不进入 Player；DevelopmentRuntime 中的测试身份/广告只在 Editor 或 Development Build 编译。

- Tools~/HostServiceComposition.md：账号、广告、存档与通用请求的宿主装配。
- Tools~/NativeLuaBaseline.md：原生 Unity、资源所有权与生命周期。
- Tools~/NativeUguiLocalization.md：当前已验证的 UGUI/Localization 扩展。
- Tools~/GameRegistrationAndVersioning.md：后台建档、永久 GameID、模块交付和服务器精确选版的接入顺序。
- Samples~/PartnerGame：模块定义、导入、构建、预览。
- Samples~/SharedRuntimeHost：独立包/综合包共用壳接线。
- Samples~/NativeRuntimeValidation：专用工程 Editor/Android 验收。
- Samples~/LegacyGameMigrationReference：不参与编译的旧业务迁移参考。

本地导出：`python Tools~/ExportLocalTestSdk.py --output <全新目录>`。输出三个不可覆盖 tgz、逐文件哈希清单和 Unity manifest 依赖片段。工具按包内每个文件回读校验；打包成功不表示 Android 运行验收通过。

游戏自有业务/资源仍由开发者交付。门禁校验真实运行兼容性与发布证据，不规定美术风格。测试/正式目录、签名和上下架属于独立发布后台。
