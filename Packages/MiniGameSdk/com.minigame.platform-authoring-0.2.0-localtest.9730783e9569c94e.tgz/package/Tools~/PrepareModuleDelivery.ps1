param(
    [Parameter(Mandatory)][string]$ModulePath,
    [Parameter(Mandatory)][string]$ModuleDefinition,
    [Parameter(Mandatory)][string]$SourceDirectory,
    [Parameter(Mandatory)][string]$HostProfiles,
    [Parameter(Mandatory)][string]$GateReport,
    [Parameter(Mandatory)][string]$IndependentEvidence,
    [Parameter(Mandatory)][string]$HubEvidence,
    [Parameter(Mandatory)][string]$IndependentApk,
    [Parameter(Mandatory)][string]$HubApk,
    [Parameter(Mandatory)][string]$IndependentLog,
    [Parameter(Mandatory)][string]$HubLog,
    [Parameter(Mandatory)][string]$RightsFile,
    [Parameter(Mandatory)][string]$OutputDirectory
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function FullFile([string]$path) {
    return (Resolve-Path -LiteralPath $path -ErrorAction Stop).Path
}

function Hash([string]$path) {
    return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function CheckPath([string]$path) {
    if ([string]::IsNullOrWhiteSpace($path) -or $path.Contains('\') -or $path.Contains(':') -or
        $path.StartsWith('/') -or @($path -split '/' | Where-Object { $_ -eq '' -or $_ -eq '.' -or $_ -eq '..' }).Count -gt 0 -or
        $path -notmatch '^[A-Za-z0-9_./-]+$') {
        throw "Forbidden path: $path"
    }
}

function CheckTree([string]$root, [bool]$source) {
    $allowed = @('.lua', '.meta', '.prefab', '.unity', '.mat', '.png', '.jpg', '.jpeg', '.tga',
        '.asset', '.anim', '.controller', '.fbx', '.wav', '.mp3', '.ogg', '.txt', '.json',
        '.csv', '.spriteatlas', '.rendertexture', '.cubemap', '.physicmaterial', '.physicsmaterial2d')
    foreach ($item in Get-ChildItem -LiteralPath $root -Recurse -Force) {
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw "Linked file is forbidden: $($item.FullName)"
        }
        if (-not $item.PSIsContainer -and $source -and
            [IO.Path]::GetExtension($item.Name).ToLowerInvariant() -notin $allowed) {
            throw "Forbidden source file: $($item.FullName)"
        }
    }
}

function CopyReview([string]$source, [string]$relative, [string]$reviewRoot) {
    $target = Join-Path $reviewRoot ($relative.Replace('/', [IO.Path]::DirectorySeparatorChar))
    [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target)) | Out-Null
    [IO.File]::Copy((FullFile $source), $target, $false)
}

$module = (Resolve-Path -LiteralPath $ModulePath -ErrorAction Stop).Path
$source = (Resolve-Path -LiteralPath $SourceDirectory -ErrorAction Stop).Path
$output = [IO.Path]::GetFullPath($OutputDirectory).TrimEnd([IO.Path]::DirectorySeparatorChar)
foreach ($inputRoot in @($module, $source)) {
    if ($output.Equals($inputRoot, [StringComparison]::OrdinalIgnoreCase) -or
        $output.StartsWith($inputRoot.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar,
            [StringComparison]::OrdinalIgnoreCase)) {
        throw 'Output directory must be outside module and source inputs.'
    }
}
if (Test-Path -LiteralPath $output) { throw "Output already exists: $output" }
CheckTree $module $false
CheckTree $source $true

$definition = Get-Content -LiteralPath (FullFile $ModuleDefinition) -Raw | ConvertFrom-Json
$manifestPath = Join-Path $module 'manifest.json'
$manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
$manifestHash = Hash $manifestPath
$gate = Get-Content -LiteralPath (FullFile $GateReport) -Raw | ConvertFrom-Json
$definitionRuntimeType = if ([string]::IsNullOrEmpty([string]$definition.runtimeType)) { 'unity_lua' } else { [string]$definition.runtimeType }
if ($definition.gameId -cnotmatch '^[a-z][a-z0-9_]{0,63}$' -or
    $definition.moduleVersion -notmatch '^[a-z][a-z0-9_]*$' -or
    $manifest.gameId -ne $definition.gameId -or $manifest.version -ne $definition.moduleVersion -or
    $gate.gameId -ne $definition.gameId -or $gate.moduleVersion -ne $definition.moduleVersion -or
    $gate.moduleManifestSha256 -ne $manifestHash -or $gate.publishable -ne $true) {
    throw 'Definition, manifest or gate report identity/hash mismatch.'
}
if ($manifest.entry -cne $definition.entry -or
    -not ([string]$manifest.entry).StartsWith("games.$($definition.gameId).", [StringComparison]::Ordinal) -or
    $manifest.minHostApiVersion -ne $definition.minHostApiVersion -or
    $manifest.runtimeType -cne $definitionRuntimeType) {
    throw 'Manifest entry or host contract differs from the module definition.'
}
if (-not $manifest.files -or $manifest.files.Count -gt 2048) { throw 'Invalid module file list.' }
$listed = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach ($file in $manifest.files) {
    CheckPath $file.path
    if (-not ($file.path.StartsWith("games/$($definition.gameId)/", [StringComparison]::Ordinal) -and
            $file.path.EndsWith('.lua', [StringComparison]::Ordinal)) -and
        -not $file.path.StartsWith("data/$($definition.gameId)/", [StringComparison]::Ordinal) -and
        -not ($file.path.EndsWith('.bundle', [StringComparison]::Ordinal) -and
            -not $file.path.Contains('/'))) {
        throw "Module file is outside the registered GameID namespace: $($file.path)"
    }
    if (-not $listed.Add([string]$file.path)) { throw "Duplicate module file: $($file.path)" }
    $full = Join-Path $module ($file.path.Replace('/', [IO.Path]::DirectorySeparatorChar))
    if (-not (Test-Path -LiteralPath $full -PathType Leaf) -or
        (Get-Item -LiteralPath $full).Length -ne $file.size -or
        (Hash $full) -ne ([string]$file.sha256).ToLowerInvariant()) {
        throw "Module file hash/size mismatch: $($file.path)"
    }
}
if (-not $listed.Contains(([string]$manifest.entry).Replace('.', '/') + '.lua')) {
    throw 'Manifest Lua entry is missing from the module file list.'
}
$actual = @(Get-ChildItem -LiteralPath $module -File -Recurse | Where-Object { $_.FullName -ne $manifestPath })
if ($actual.Count -ne $listed.Count) { throw 'Module contains undeclared files.' }
foreach ($root in $definition.assetRoots) {
    CheckPath $root
    if (-not $root.StartsWith('Assets/', [StringComparison]::Ordinal) -or
        -not (Test-Path -LiteralPath (Join-Path $source ($root.Replace('/', [IO.Path]::DirectorySeparatorChar))) -PathType Leaf)) {
        throw "Missing source asset root: $root"
    }
}
$assetRoots = @($definition.assetRoots)
if ($assetRoots.Count -eq 0) { throw 'At least one asset root is required.' }
if ((Get-Item -LiteralPath (FullFile $RightsFile)).Length -gt 64KB) {
    throw 'Rights statement is too large.'
}
if ([string]::IsNullOrWhiteSpace((Get-Content -LiteralPath (FullFile $RightsFile) -Raw))) {
    throw 'Rights declaration is required.'
}
foreach ($pair in @(@($IndependentEvidence, $IndependentApk, $IndependentLog),
                     @($HubEvidence, $HubApk, $HubLog))) {
    $evidence = Get-Content -LiteralPath (FullFile $pair[0]) -Raw | ConvertFrom-Json
    if ($evidence.moduleManifestSha256 -ne $manifestHash) { throw 'Evidence manifest hash mismatch.' }
    if ($evidence.apkSha256 -ne (Hash (FullFile $pair[1]))) { throw 'APK hash mismatch.' }
    if ($evidence.deviceLogSha256 -ne (Hash (FullFile $pair[2]))) { throw 'Device log hash mismatch.' }
}

$parent = [IO.Path]::GetDirectoryName($output)
[IO.Directory]::CreateDirectory($parent) | Out-Null
$stage = Join-Path $parent ('.' + [IO.Path]::GetFileName($output) + '.stage-' + [guid]::NewGuid().ToString('N'))
try {
    $gameId = [string]$definition.gameId
    $version = [string]$definition.moduleVersion
    $moduleTarget = Join-Path $stage "modules/$gameId/$version"
    $reviewTarget = Join-Path $stage "review/$gameId/$version"
    [IO.Directory]::CreateDirectory($moduleTarget) | Out-Null
    [IO.Directory]::CreateDirectory($reviewTarget) | Out-Null
    foreach ($item in Get-ChildItem -LiteralPath $module -Force) {
        Copy-Item -LiteralPath $item.FullName -Destination $moduleTarget -Recurse -Force
    }
    [IO.Directory]::CreateDirectory((Join-Path $reviewTarget 'source')) | Out-Null
    Copy-Item -LiteralPath (Join-Path $source 'Assets') -Destination (Join-Path $reviewTarget 'source') -Recurse -Force
    CopyReview $ModuleDefinition 'module-definition.json' $reviewTarget
    CopyReview $HostProfiles 'host-profiles.json' $reviewTarget
    CopyReview $GateReport 'gate-report.json' $reviewTarget
    CopyReview $IndependentEvidence 'evidence/independent.json' $reviewTarget
    CopyReview $HubEvidence 'evidence/hub.json' $reviewTarget
    CopyReview $IndependentApk 'apks/independent.apk' $reviewTarget
    CopyReview $HubApk 'apks/hub.apk' $reviewTarget
    CopyReview $IndependentLog 'logs/independent.log' $reviewTarget
    CopyReview $HubLog 'logs/hub.log' $reviewTarget
    CopyReview $RightsFile 'review/rights.md' $reviewTarget
    $reviewFiles = @(Get-ChildItem -LiteralPath $reviewTarget -File -Recurse | Sort-Object FullName | ForEach-Object {
        $relative = [IO.Path]::GetRelativePath($reviewTarget, $_.FullName).Replace('\', '/')
        [ordered]@{ path = $relative; size = $_.Length; sha256 = (Hash $_.FullName) }
    })
    $delivery = [ordered]@{ formatVersion = 1; gameId = $gameId; moduleVersion = $version;
        manifestSha256 = $manifestHash; reviewFiles = $reviewFiles }
    [IO.File]::WriteAllText((Join-Path $reviewTarget 'delivery.json'),
        ($delivery | ConvertTo-Json -Depth 10), [Text.UTF8Encoding]::new($false))
    [IO.Directory]::Move($stage, $output)
    Write-Output $output
}
finally {
    if (Test-Path -LiteralPath $stage) {
        $resolvedStage = [IO.Path]::GetFullPath($stage)
        if (-not $resolvedStage.StartsWith($parent.TrimEnd([IO.Path]::DirectorySeparatorChar) +
            [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
            throw 'Unsafe staging path; refusing cleanup.'
        }
        Remove-Item -LiteralPath $resolvedStage -Recurse -Force
    }
}
