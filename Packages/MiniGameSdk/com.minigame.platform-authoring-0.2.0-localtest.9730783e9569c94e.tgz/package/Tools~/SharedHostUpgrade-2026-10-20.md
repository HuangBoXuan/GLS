# 平台与 Garden 共用 SDK 升级说明

日期：2026-10-20。用途：内部小游戏 Lua 改造、共用宿主接入和测试。状态：`local-test-only`，本轮不打 APK，不自动修改 Garden 工程或发布 CDN。

## 1. 领取与版本

完整交付：`Builds/InternalOnboarding/lua-sdk-api7-20261020.zip`。解压后从 `START-HERE.md` 开始。

Unity 固定为 **2022.3.76f1**，Lua **5.4.8**，xLua 原生 ABI **105**，Host API **7**。三个 UPM 包的精确版本及 SHA-256 以交付内 `sdk/artifact-manifest.json` 为准，必须整组使用；不能仅凭 `0.2.0` 或 API 7 判断两个快照相同。

| 包 | 职责 | 本次变化 |
| --- | --- | --- |
| `com.minigame.platform-sdk` | 账号、认证请求、广告调度及模块/服务契约 | 保留已完成的统一 GameID 契约；未加入 Garden 游戏业务 |
| `com.minigame.platform-host` | Unity/xLua、下载、资源、生命周期和产品宿主 | 合并平台续传与 Garden 缓存修复、异步资源和渲染优化；更新 Android xLua 原生库 |
| `com.minigame.platform-authoring` | 开发工具、导出、检查及样例 | 纳入共用回归检查、原生 ABI/对齐校验和来源记录 |

相对 10 月 12 日平台候选快照，核心 SDK 业务接口保持不变；宿主与工具有所变化，所以三个分发包一起生成新快照。相对 10 月 10 日旧完整接入包，还包含后续 GameID、渲染批量调用等已有更新。

## 2. 已整合的共用修正

| 来源 | 整合方式与边界 |
| --- | --- |
| 平台下载器 | 保留 Range 断点续传、重试预算、暂停/取消、响应范围检查、完整文件 SHA-256 验证和安装写锁 |
| Garden 安装安全补丁 | 合入接收阶段 1 MiB manifest 限制、损坏缓存修复；下载/校验失败保留原版本，成功后更换目录，重命名失败尝试恢复原版本 |
| 平台页签卡顿修复 | 展示状态只做轻量文件检查；执行/激活仍走完整校验，不把“本地有文件”当作可信执行许可 |
| Garden 资源性能补丁 | 未加密 Bundle 流式校验后从文件加载；加密资源保留认证解密；新增可轮询异步资产请求，退出等待未完成请求后释放 Bundle |
| Garden 渲染性能补丁 | Lua 帧回调减少临时参数分配；直接 UGUI 顶点提交，packed/chunk Mesh 与 Transform 批量接口；保留长度、数值和归属检查 |
| Garden Android Lua 库补丁 | ARM64/ARMv7 使用有来源清单的重建库，保持 Lua/xLua ABI；检查 ELF 对齐、导出符号与依赖。静态通过不等于整包 Android 验收 |
| 平台产品装配 | 保留账号面板样式接入、安装标识复用、日期/时区裁剪保留及 GameID 规则 |

SDK 不包含 Garden 关卡、奖励、商店、排行榜规则和游戏专属 DTO；本轮没有替换各游戏自己的美术、字体、材质或登录业务界面。

## 3. 老工程升级步骤

1. 先保存工程当前状态，包括 `Packages/manifest.json`、`packages-lock.json`、三份 embedded 包和项目自己的补丁清单。记录原 SDK 精确版本，不仅记录 API 号。
2. 关闭或暂停该工程的 Unity 导入操作。把交付 `sdk/` 中四个 `.tgz` 复制到游戏工程 `Packages/MiniGameSdk/`。第四个是固定的 Unity Localization 1.4.4 依赖，不是第四个自研 SDK。
3. 采用 UPM 归档方式时，先把工程 `Packages/com.minigame.platform-sdk`、`...platform-host`、`...platform-authoring` 三个旧 embedded 目录移到工程外备份，避免 embedded 包继续覆盖 manifest 中的归档。不要一边留旧 embedded 包一边以为已升级成功。
4. 将交付 `manifest-dependencies.json` 的 **dependencies 条目合并**到现有 `Packages/manifest.json`，保留游戏其他依赖。相对 `file:MiniGameSdk/...` 以该工程的 `Packages/` 为基准。
5. 打开 Unity 等待导入，核对 Package Manager 中三包为交付清单所列的同一快照版本；检查 `packages-lock.json` 实际解析结果。不要手工拼接旧锁文件里的 hash/version。
6. 已有工程通常不必导入样例。新工程可导入 `sample/PartnerGame.unitypackage`；或复制 `sample/PartnerGame` 连同 `.meta` 到 `Assets/`；或从 UPM Samples 导入。三种方式选一种，避免同 GUID 资源重复。
7. 删除重复运行时前先核对来源：本宿主已携带 xLua 托管代码、Windows/Android 原生插件和 BouncyCastle。不要再把旧 Lua DLL/旧 `.so` 复制到 `Assets/Plugins`；若其他包依赖它们，先统一版本而不是直接删除。
8. 运行工具菜单中的 Shared Host Baseline Checks、Render Batch Checks，并验证自己的场景入口、退出、暂停/恢复、资源释放。根据游戏使用能力验证字体/TMP、动画、物理、音频与资源依赖。
9. 完成宿主升级后再用同套 authoring 重建模块，并使用新的不可变模块版本目录。不得覆盖旧 CDN 的 manifest/Bundle 文件；账号 `userId`、游戏 `gameId` 和本地存档命名空间不应随 SDK 升级改变。

需要回退时，整组恢复原三包及对应 manifest/锁文件/原生库，恢复与该宿主兼容的模块目录选择。新版模块使用了新增宿主方法时，不可继续下发给旧宿主。

## 4. Garden 专项说明

本轮读取的 Garden 工程位于 `MiniGameWorkspace-TapGarden-import/games/TapGarden`，其 `platform-sdk.lock.json` 指向 `c496034de6fd829d` 基线，并叠加本地补丁。实际升级应在 Garden 正在开发的分支进行；本轮没有切换或修改该工程。

- `xlua-android-16kb-20261011`：已纳入共用宿主和 authoring 来源/校验文件，不再重复覆盖。
- `module-installer-safety-20261011`：安全处理已与平台续传实现合并，不能把 Garden 旧整份 `ModuleInstaller.cs` 再覆盖回来。
- `runtime-performance-20261013`：异步加载、UGUI/批量传输、帧回调优化已纳入；游戏侧 Lua 使用优化和具体关卡仍由 Garden 保留。
- 不复制旧 `platform-sdk.lock.json` 作为新包已验收凭据。更新自定义锁文件时，将本次 manifest 的 sourceSetSha256、三包版本和哈希写入；旧 overlay 标记为 absorbed，不继续列为待应用补丁。其他未在上述列表中的本地改动须另行比较。

## 5. 新调用与资源生命周期

`host:BeginLoadAsset(bundlePath, assetName, typeofAsset)` 返回请求对象；在 `update` 中轮询 `IsDone/Progress`，完成后读取 `Asset`。请求 Dispose 只解除调用方引用，不会中断 Unity 原生载入；宿主仍等原生请求结束后释放 Bundle。退出后不能再使用请求、资产或已释放的 host。

`host:CreateGraphicBuffer(graphic)`、`UploadPacked/UploadPackedChunks`、`ApplyPacked/ApplyPackedChunks` 是本基线新增的优化入口。原来的 `Upload(byte[], count)` 和 `Apply(byte[])` 保留。Graphic 必须归属当前模块，禁止把平台 UI 对象交给小游戏持有。

新模块若依赖异步加载，应声明 `unity_async_asset_v1`；依赖直接 Graphic 或 packed/chunk 接口，应声明 `unity_render_batch_packed_v1`，并保留原本的原生/资源/渲染能力声明及 API 7。这些标记用于阻止旧宿主接收不支持的模块；已发布 Garden 旧模块的原方法兼容入口保留。能力声明仍由交付方据实际调用填写，不能只改标记就声称旧平台已支持。

所有 Unity 物件、UI 订阅、计时器、协程和请求必须在模块边界内管理；游戏退出先停止自身回调再释放实例。不要调用全局 `AssetBundle.UnloadAllAssetBundles` 或销毁平台 EventSystem/Camera；加载资源与自行实例化的物件要按宿主作用域契约登记。

## 6. 四方接入约定

| 负责方 | 需要继续完成的事项 |
| --- | --- |
| 游戏客户端 | 升级固定包、迁移 Lua、声明真实能力；接宿主账号和广告服务；保存/结算调用游戏自己的协议；导出同一份供独立包与平台使用的模块 |
| 平台产品壳 | 装配真实服务器地址、产品身份、目录信任配置、账号存储与广告驱动；提供目录/下载/进入/退出 UI；新增原生能力需更新安装包 |
| 服务器 | 共用账号和稳定 userId；每 gameId 的进度/排行、共有钱包、在线结算和幂等；产品注册、展示资格与选版。离线同步不发共有奖励，不更新在线榜 |
| 发布后台/发行 | 管理 gameId、productId、封面/试玩、模块版本、环境、审核与签名目录；使用既定 SVN→CDN 流程交付不可变版本，发布前检查资源可访问和哈希 |

不要在平台内初始化游戏独立包的第二套账号或广告 SDK。广告调用由宿主配置本包的 key/placement，游戏使用本次请求的结果回调决定复活/道具等行为；只有 Completed 才走对应奖励逻辑，取消/失败不冒充完成。本包不包含已上线的商业广告参数、账号密钥、生产 token 或 CDN 签名私钥。

统一服务器不代表自动打通已发布包的游客身份。账号绑定与恢复、服务器版本、后台选版和实际 CDN 上架仍须各方联调；交付 SDK 不会自动部署这些系统。

## 7. 验证范围

最终验证结果见交付内 `validation.json` 与 `evidence/`。本轮目标是源码整合、隔离工程导入编译、定向 Editor 回归、归档成员/整包哈希和 Android 原生库静态校验。没有构建 APK，没有做真机、真实广告、账号跨包、生产服务或真实 CDN 验收，不能将此包标记为正式发布版。
