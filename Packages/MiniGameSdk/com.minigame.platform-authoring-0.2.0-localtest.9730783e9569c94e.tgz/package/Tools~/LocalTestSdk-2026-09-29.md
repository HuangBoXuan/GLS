> 历史版本说明：本文对应拆分前的 0.1.0 实现。新版 0.2.0 请从包 README 和 HostServiceComposition.md 接入；旧 Garden 客户端只保留为非编译迁移参考。

# SDK 本地测试交付与接入边界（2026-09-29）

本次产物用于游戏工程接入验证，不是正式 SDK 版本发布。包含当前 SDK 完整源码、Unity 元文件和第三方依赖；不包含平台 Admin、游戏工程、宿主生成密钥源文件、私有构建配置或 Unity Library。

SDK 已显式声明实际使用的 UGUI、Android JNI、AssetBundle、JSON 序列化、3D 物理和 UnityWebRequest 内置模块依赖；不依赖原平台工程恰好启用了这些模块。

## 1. 固定版本与来源

- 基线提交、实际分支、工作区未提交文件列表、源文件与归档文件 SHA-256 均记录在产物旁的 `artifact-manifest.json`。
- 工作区已有未提交修改，产物来自完整文件快照，不能仅凭基线提交还原。
- 导出工具只将 `package.json` 的版本改为 `0.1.0-localtest.<源文件清单哈希前16位>`，其余文件逐字节保留；版本变换前后均有清单。
- 新产物写入新目录，禁止覆盖已有快照。SHA-256 用于固定引用和比对，不代替可信发行签名。
- 不要在接入后直接修改 SDK 包内文件；修复应回平台工程，重新导出并更新固定依赖。

在平台工程执行（Python 3.12）：

```powershell
python Packages/com.minigame.platform-sdk/Tools~/ExportLocalTestSdk.py --output Builds/SDK/<新的交付目录> --existing-bouncycastle <游戏已有DLL完整路径>
```

导出会检查已有 DLL 哈希，并逐文件读回归档比对。Unity Package Manager 使用“Add package from tarball”选择 `.tgz`。保留 `.tgz`、清单和 SHA 文件供回退；不要依赖浮动的 SDK 源码目录。

## 2. Lua 数据读取契约

模块定义、构建产物清单及目录元数据须声明：

```json
{
  "minHostApiVersion": 2,
  "requiredCapabilities": ["lua", "data_text", "protected_content"],
  "contentEncryption": "wpc1",
  "contentKeyId": "由宿主构建配置供应的公开选择器"
}
```

上面是字段示意。实际 key ID 必须满足既有 ID 格式；资源如包含 AssetBundle，还需声明 `assetbundle` 及实际使用的其他能力。明文模块不填写加密算法和 key ID，也不声明 `protected_content`；声明 `data_text` 和最低 API 2 后即可使用文本接口。

```lua
local M = {}
function M.enter(host)
    local json = host:ReadDataText("data/garden/levels.json")
    -- 解析并检查业务数据；不要使用 io.open 或绕过宿主读取安装目录。
end
return M
```

读取规则：

- 只接受当前模块清单声明的 `data/<当前gameId>/` 下 `.json`、`.csv`、`.txt` 文件，路径和扩展名区分大小写。
- 拒绝跨游戏、绝对路径、反斜杠、`..`、流名称、链接路径、未声明文件、Lua 与 AssetBundle 路径。
- 单文件明文预算 4 MiB，包含可选 UTF-8 BOM；密文读取另有封装余量。先检查存储长度与解压长度预算，再分配相应缓冲区。
- 严格 UTF-8，拒绝非法字节；去掉文件开头的 UTF-8 BOM。返回文本，不负责验证 JSON/CSV 的业务结构。
- 复用 `ModuleContentReader` 的清单哈希、WPC1 认证解密及 `(gameId, version, keyId, path)` 绑定；缺钥、错误钥、篡改均失败，不回退明文。
- 桥接身份与资源域必须一致；桥接或资源域退出后读取失败。临时明文字节清理，返回的托管字符串由运行时管理。
- 同步读取，不做文本缓存；大数据应分文件，避免每帧重复读取。

能力链覆盖注册表、当前宿主、Android 模块构建宿主、模块定义验证、运行时兼容判断和实际桥接。API 1 宿主不能加载要求 API 2 的模块；使用新 API 的独立壳和综合壳都需要先更新宿主。旧模块可继续运行。

## 3. Lua 生命周期失败

`Tick / Pause / Resume` 出错时，Runner 尝试退出并释放 Lua 对象、桥接对象和资源域，将状态重置为 `Empty`，清空游戏 ID 和成功 tick 计数，再抛出 `ModuleRunException`：

| 调用 | Code | Phase |
| --- | --- | --- |
| Tick（Lua update 或 LuaEnv.Tick） | UPDATE_FAILED | update |
| Pause | PAUSE_FAILED | pause |
| Resume | RESUME_FAILED | resume |

退出回调再次报错不会覆盖原始阶段异常；`LastError` 保留本次结构化错误。宿主应捕获并恢复菜单或错误页面。清理后可以重新进入；Editor 非运行模式也会释放桥接创建的场景对象。

## 4. TapGarden 依赖去重与保护构建

TapGarden 和 SDK 的 `BouncyCastle.Cryptography.dll` 已核对为相同二进制：

```text
4367d033a374883ef902419f9c7075a22d852f079828bf49e35b3cd10ca4524b
```

推荐由游戏工程维护者保留原 `Assets/Plugins/BouncyCastle/BouncyCastle.Cryptography.dll` 和原始 `.meta` 的回退记录，使用 Plugin Inspector 可回退地禁用该旧副本的 Editor 与 Player 平台导入，启用 SDK 副本。不能仅关闭 Auto Reference，因为这不能保证程序集不被加载。旧 DLL 文件继续存在，便于旧保护测试通过文件路径读取。综合壳只使用 SDK 副本。

本 SDK 产物完整保留自身 DLL 与 `.meta`，不制作内容不明的删库变体。接入后检查编译器引用与实际加载程序集，确认只有一个有效副本；若旧 SDK/插件另有副本也需盘点。卸载测试 SDK 时先恢复原导入设置。游戏原始工程不由本次导出工具修改。

游戏现有 Android 保护构建门禁继续有效。SDK 的宿主密钥供应必须与原受保护 BuildPlayer 流程接线，不能全局关闭或绕过游戏原有保护回调。两个宿主各自供应所需密钥；模块及 CDN 不携带密钥。既有加密游戏资源需要按模块上下文重新构建，不会因为 key 字节相同就自动兼容。

## 5. 验证入口与未验证范围

```text
MiniGamePlatform.SDK.Editor.Authoring.ModuleHostBoundaryChecks.RunWithProtectionRegression
MiniGamePlatform.EditorChecks.HotUpdateSmokeChecks.Run
```

第一项包含生命周期、明文/密文数据边界和原有六组保护/发布回归，可在 SDK 接入工程运行；第二项依赖平台工程中的 2D/3D 样例。Android xLua ABI 可用 `Tools~/VerifyXLuaAndroidAbis.ps1` 验证哈希、ELF 架构及导出接口。

这些结果不能代替 TapGarden 实际关卡、受保护独立壳/综合壳双 APK、IL2CPP 裁剪、Android 真机与真实服务器/CDN 联调验收。xLua 当前不构成不可信代码安全沙箱；本接口的边界校验不能改变这一点。
