"""Export an immutable local-test set: core SDK, Unity host, developer tools. No publication."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def inventory(files):
    return [{"path": name, "size": len(data), "sha256": sha(data)} for name, data in sorted(files.items())]


def read_tree(root):
    files = {}
    for path in sorted(root.rglob("*")):
        if path.is_symlink() or path.is_junction():
            raise ValueError("Package tree contains a link: " + str(path))
        if not path.is_file() or "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        if path.name.startswith(".env") or path.name.endswith(".module-keys.local.json") or path.name.startswith("MiniGameModuleKeys.cpp"):
            raise ValueError("Private build input is forbidden in artifacts: " + str(path))
        files[path.relative_to(root).as_posix()] = path.read_bytes()
    return files


def write_archive(path, files):
    with path.open("xb") as raw, gzip.GzipFile(filename="", fileobj=raw, mode="wb", mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as tar:
            for name, data in sorted(files.items()):
                member = tarfile.TarInfo("package/" + name)
                member.size, member.mode, member.mtime = len(data), 0o644, 0
                tar.addfile(member, io.BytesIO(data))
    with tarfile.open(path, "r:gz") as tar:
        members = tar.getmembers()
        if len(members) != len(files) or len({item.name for item in members}) != len(files):
            raise RuntimeError("Archive member count differs from source")
        for item in members:
            if not item.isfile() or item.name not in {"package/" + name for name in files}:
                raise RuntimeError("Unexpected archive member")
            if sha(tar.extractfile(item).read()) != sha(files[item.name[8:]]):
                raise RuntimeError("Archive readback failed: " + item.name)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--existing-bouncycastle", type=Path, help="Optional read-only consumer DLL comparison")
    args = parser.parse_args()
    packages = Path(__file__).resolve().parents[2]
    names = ["com.minigame.platform-sdk", "com.minigame.platform-host", "com.minigame.platform-authoring"]
    roots = {name: packages / name for name in names}
    localization_path = packages.parent / "HostDependencies" / "com.unity.localization-1.4.4.tgz"
    provenance_path = packages.parent / "HostDependencies" / "localization-provenance.json"
    output = args.output.resolve()
    if output.exists() or any(output == root or root in output.parents for root in roots.values()):
        raise ValueError("Output must be a new directory outside all package trees; snapshots are never overwritten.")
    sources = {name: read_tree(root) for name, root in roots.items()}
    localization_bytes = localization_path.read_bytes()
    provenance = json.loads(provenance_path.read_text(encoding="utf-8"))
    if (provenance.get("name") != "com.unity.localization" or provenance.get("version") != "1.4.4" or
            provenance.get("sha256") != sha(localization_bytes) or provenance.get("size") != len(localization_bytes)):
        raise ValueError("Pinned Unity Localization 1.4.4 dependency differs from its provenance.")
    with tarfile.open(fileobj=io.BytesIO(localization_bytes), mode="r:gz") as tar:
        descriptor = json.load(tar.extractfile("package/package.json"))
        if descriptor.get("name") != "com.unity.localization" or descriptor.get("version") != "1.4.4":
            raise ValueError("Pinned Unity Localization archive has the wrong package identity.")
    for name in names:
        if "package.json" not in sources[name]:
            raise ValueError("Missing companion package: " + name)
    # One set hash includes all three trees. A host/tool change updates the test set, not the source SDK API version.
    source_hash = sha(json_bytes({"packages": {name: inventory(files) for name, files in sources.items()},
                                 "hostDependencies": {"com.unity.localization": sha(localization_bytes)}}))
    versions = {name: json.loads(files["package.json"])["version"].split("-")[0] + "-localtest." + source_hash[:16]
                for name, files in sources.items()}
    dll_sha = sha(sources[names[1]]["ThirdParty/BouncyCastle/BouncyCastle.Cryptography.dll"])
    if args.existing_bouncycastle and sha(args.existing_bouncycastle.read_bytes()) != dll_sha:
        raise ValueError("Consumer BouncyCastle differs from the host dependency")
    for name, root in roots.items():
        if inventory(read_tree(root)) != inventory(sources[name]):
            raise RuntimeError("Package changed during snapshot: " + name)
    base = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=packages).decode().strip()
    output.mkdir(parents=True)
    records, dependencies, sums = [], {}, []
    for name in names:
        files = dict(sources[name]); package = json.loads(files["package.json"])
        package["version"] = versions[name]
        for dependency in package.get("dependencies", {}):
            if dependency in versions:
                package["dependencies"][dependency] = versions[dependency]
        files["package.json"] = json_bytes(package)
        archive = output / (name + "-" + versions[name] + ".tgz")
        write_archive(archive, files)
        digest = sha(archive.read_bytes())
        records.append({"name": name, "version": versions[name], "file": archive.name, "sha256": digest,
                        "sourceFiles": inventory(sources[name]), "packagedFiles": inventory(files)})
        dependencies[name] = "file:" + archive.as_posix()
        sums.append(digest + "  " + archive.name)
    localization_archive = output / localization_path.name
    with localization_archive.open("xb") as destination:
        destination.write(localization_bytes)
    localization_sha = sha(localization_archive.read_bytes())
    if localization_sha != provenance["sha256"]:
        raise RuntimeError("Pinned Localization archive copy failed readback verification.")
    dependencies["com.unity.localization"] = "file:" + localization_archive.as_posix()
    sums.append(localization_sha + "  " + localization_archive.name)
    manifest = {"formatVersion": 2, "status": "local-test-only", "formalRelease": False,
                "gitBaseCommit": base, "sourceSetSha256": source_hash, "packages": records,
                "hostDependencies": [{"name": "com.unity.localization", "version": "1.4.4",
                                      "file": localization_archive.name, "sha256": localization_sha}],
                "transformations": ["package versions and companion dependency versions pin this exact snapshot set"],
                "verification": "Every archive member was read back and hash checked; runtime evidence is separate."}
    (output / "artifact-manifest.json").write_bytes(json_bytes(manifest))
    (output / "unity-manifest.dependencies.json").write_bytes(json_bytes({"dependencies": dependencies}))
    (output / "SHA256SUMS.txt").write_text("\n".join(sums) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(output), "sourceSetSha256": source_hash,
                      "packages": [{key: record[key] for key in ("name", "version", "file", "sha256")} for record in records]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
