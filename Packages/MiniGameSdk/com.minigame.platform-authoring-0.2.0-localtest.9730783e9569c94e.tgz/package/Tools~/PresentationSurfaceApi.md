# SDK API 5 通用材质与世界视图接口

> 范围说明（2026-09-29）：本文描述已交付 API 5 适配器，保留兼容；不是游戏必须采用的资源标准。材质、颜色、Shader 属性和相机表现由游戏决定，新接入优先使用已验证的 Unity 原生能力。

状态：本地测试接口；固定产物和实际验证范围见交付报告。API 3、API 4 R2 归档保留，不覆盖。

## 1. 契约边界

游戏决定资源内容、材质、颜色、Shader 属性及动画。SDK 只校验类型、兼容性、依赖、对象归属、生命周期与运行预算。当前方法支持范围不是美术规范；尚未实现的 Animator、粒子、更多纹理类型属于能力缺口。小游戏专属 C# 仍须迁为 Lua，不能通过资源包新增宿主组件。

## 2. API 5 新方法

入口仍为 `host.Presentation`。新模块最低 API 5，增加 `presentation_surface`；世界视图另加 `world_view`，既有 `presentation/assetbundle/tmp_text` 按需要保留。

| 方法 | 约定 |
| --- | --- |
| `SetImageMode(int node, string mode, bool preserveAspect)` | Image 专用；mode 只接受 `simple` 或 `sliced`。Sprite 的 border/PPU 必须在资源导出时保留 |
| `SetUvRect(int node, float x, float y, float width, float height)` | RawImage 专用；有限数值，偏移绝对值≤1024，宽高绝对值 0.0001..1024，支持翻转；重复纹理由导出资源的 wrapMode=Repeat 决定 |
| `SetGraphicMaterial(int node, string bundle, string materialAsset)` | Image/RawImage 绑定模块包内 Material，不修改共享材质，不接受任意 Shader 字符串或 URL |
| `ApplyMaterialProperties(string json)` | 世界 Renderer 按材质槽更新游戏 Shader 自己声明的属性；先校验全批，再用 MaterialPropertyBlock 更新，不修改 Material 资产 |
| `CreateWorldView(int uiParent, int pixelWidth, int pixelHeight)` → int | 创建 UGUI RawImage 世界视图；每模块实例最多一个。纹理边长 64..2048，RGBA+24 位深度/模板，单采样；返回视图节点句柄 |
| `GetWorldRoot(int view)` → int | 取得该视图专用世界根句柄；模型使用 CreatePrefab(root,...) 创建 |
| `ConfigureWorldView(int view, string json)` | 设置这个视图自己的相机；不开放 Camera 对象、任意 cullingMask、目标纹理或反射调用 |

视图节点通过 ApplyNodes 设置 UI 尺寸、位置与显隐。自定义合成效果由游戏交付材质并通过 SetGraphicMaterial 绑定。

### 材质批量格式

```json
{"properties":[
  {"node":101,"slot":0,"property":"_Accent","kind":"color","r":0.8,"g":0.3,"b":0.2,"a":1},
  {"node":101,"slot":0,"property":"_Progress","kind":"float","value":0.4},
  {"node":101,"slot":1,"property":"_Progress","kind":"float","value":0.4},
  {"node":101,"slot":1,"property":"_Offset","kind":"float","value":0.1}
]}
```

- 单批 1..512 条，JSON≤256 Ki 字符；同节点/槽/属性重复项拒绝。
- slot 为实际 Renderer 的材质数组索引，0..15；必须存在非空材质和匹配属性。不要把世界容器 ID 当 Renderer ID，先 FindNode 到实际渲染节点。
- `property` 是游戏 Shader 定义的属性名，SDK 不维护 `_Accent`、`_Progress` 或其他游戏专属名称白名单。
- `kind` 支持 float/color/vector/texture，必须与实际 Shader 属性类型匹配。float 使用 value，color 使用 r/g/b/a，vector 使用 x/y/z/w，texture 使用 bundle/asset（当前模块声明包中的 Texture2D）。
- 数值仅检查可表示且有限，不按 SDK 偏好限制颜色到 0..1；允许 Shader 合法使用的 HDR 颜色。Shader Range 的编辑器滑条范围不被平台强行作为游戏运行规则。
- SDK 保留的限制是批次数量、字符串长度、资源归属、对象生命周期和属性类型，不包含颜色方案、参数语义或游戏专属材质数值。

### 相机配置格式

```json
{"orthographic":true,"size":8,"fov":45,"near":0.1,"far":200,
 "x":0,"y":20,"z":-10,"rx":60,"ry":0,"rz":0,
 "r":0,"g":0,"b":0,"a":0}
```

位置/朝向相对专用世界根，角度制欧拉角；UI 尺寸和纹理分辨率分开配置。所有数值必须有限；size 0.001..10000、fov 1..179、near≥0.001、far>near 且≤100000；位置绝对值≤1000000，旋转≤360000，背景 RGBA 0..1。相机 aspect 固定为纹理宽高比，不由 UI 拉伸后的矩形悄悄改变；游戏侧选择匹配比例。

SDK 从 24..31 中租用当前没有场景对象占用的层，已租用层不可重复使用。只让这个视图相机渲染该层；进入时临时从其他现存相机的 cullingMask 移除该位，退出恢复这一位并保留其他位的变化。宿主运行期间不要自行更改已租用层或让新相机渲染它；首期为单活动模块。没有空闲层时明确拒绝创建，不覆盖游戏/宿主的已有层对象。

删除视图或其世界根时连同配对根、相机和目标纹理一起释放；模块退出也释放。视图暂停/隐藏时停止其相机输出，保留最后画面；恢复时继续。世界视图不参与规则运算或世界物理点击，UI 色块仍用 BindTap/PollTap。


## 3. 兼容与使用边界

- 独立壳和综合壳需先安装 API 5 SDK 并重新构建；远程 Lua 不能为 API 4 宿主补 C# 能力。兼容目录拒绝不满足能力的版本。
- 新接口按节点和材质槽写 MaterialPropertyBlock，不修改共享 Material，不替游戏推断哪些属性代表颜色。API 4 tint 保留旧行为；同一 Renderer 不要混用旧 tint 与新槽位接口，材质槽级属性块会优先于 Renderer 级属性块。
- 支持的属性目前为 Shader Properties 声明的 Float/Range、Color、Vector、2D Texture；未在 Properties 声明的 uniform、Integer、Cube/Array Texture、关键字、材质槽替换和 UGUI 动态材质属性尚未提供。UGUI 当前可绑定游戏自己的完整材质。
- 每批先校验全部目标和加载全部纹理，校验失败不修改 Renderer。保留每个槽已有的其他属性。属性名由游戏定义，颜色允许有限 HDR 数值。
- 世界视图目前每模块一个、单活动模块，使用自己的相机和 RenderTexture；不提供物理点击或灯光创建。游戏应按当前宿主光照环境验证 Shader。
- 自带 Shader 通过材质依赖随 Bundle 交付；宿主共享/内置 Shader 仍需保留清单。Android 图形 API、变体、Unity 与管线兼容须由构建和真机验证，不能以依赖存在替代。
- 本批没有新增 Animator、粒子、音频和完整 UGUI Prefab 支持；它们属于后续通用运行能力，不要求游戏永久删除这些内容。

## 4. Lua 调用示例

```lua
-- rendererId 是 CreatePrefab / FindNode 返回的实际 Renderer 节点。
-- 属性名仅作示例；填写自己的 Shader 实际声明。
host.Presentation:ApplyMaterialProperties(string.format(
  [[{"properties":[
    {"node":%d,"slot":0,"property":"_Accent","kind":"color","r":1,"g":0.5,"b":0.2,"a":1},
    {"node":%d,"slot":1,"property":"_Progress","kind":"float","value":0.4}
  ]}]], rendererId, rendererId))
```

参数 `slot` 为从 0 开始的材质索引；不是子节点编号。传入容器或不属于当前模块的句柄将被拒绝。
