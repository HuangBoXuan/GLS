param(
    [Parameter(Mandatory=$true)][string]$ReadElf,
    [string]$NativeRoot,
    [string]$ProvenancePath
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
if (!$NativeRoot) {
    $NativeRoot = Join-Path (Split-Path -Parent (Split-Path -Parent $PSScriptRoot)) 'com.minigame.platform-host/ThirdParty/BallXLua/Plugins/Android'
}
if (!$ProvenancePath) { $ProvenancePath = Join-Path $PSScriptRoot 'XLuaAndroidBuildProvenance.json' }
$provenance = Get-Content -Raw -LiteralPath $ProvenancePath | ConvertFrom-Json
$pins = Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'XLuaAndroidBuildInputs.json') | ConvertFrom-Json
if ($provenance.androidDeviceVerified -ne $false -or $provenance.xluaLibraryVersion -ne 105 -or
    $provenance.sourceInventorySha256 -ne $pins.sourceInventorySha256 -or $provenance.libraries.Count -ne 2) {
    throw 'Unreviewed xLua rebuild provenance.'
}
$objdump = Join-Path (Split-Path -Parent $ReadElf) 'llvm-objdump.exe'
function Hash-Text([string]$value) {
    $hash = [Security.Cryptography.SHA256]::Create()
    try { [BitConverter]::ToString($hash.ComputeHash([Text.Encoding]::UTF8.GetBytes($value))).Replace('-','').ToLowerInvariant() }
    finally { $hash.Dispose() }
}
foreach ($abi in @('arm64-v8a','armeabi-v7a')) {
    $library = Join-Path $NativeRoot "$abi/libxlua.so"
    $record = @($provenance.libraries | Where-Object { $_.abi -eq $abi })
    if ($record.Count -ne 1 -or !(Test-Path -LiteralPath $library) -or
        (Get-FileHash -LiteralPath $library -Algorithm SHA256).Hash -ne $record[0].sha256) {
        throw "Missing or unreviewed xLua native ABI: $abi"
    }
    $header = @(& $ReadElf -h $library)
    if ($LASTEXITCODE -ne 0) { throw "Cannot inspect $abi ELF" }
    $machine = if ($abi -eq 'arm64-v8a') {'AArch64'} else {'ARM'}
    $elfClass = if ($abi -eq 'arm64-v8a') {'ELF64'} else {'ELF32'}
    if (!(($header -join "`n") -match "Class:\s+$elfClass") -or !(($header -join "`n") -match "Machine:\s+$machine\s")) {
        throw "Wrong ELF architecture: $abi"
    }
    & (Join-Path $PSScriptRoot 'VerifyXLuaAndroidElf.ps1') -ReadElf $ReadElf -Library $library
    $symbols = @(& $ReadElf --dyn-syms --wide $library)
    if ($LASTEXITCODE -ne 0) { throw "Cannot inspect $abi exports" }
    $exports = @($symbols | Where-Object { $_ -match '\s+(FUNC|OBJECT|NOTYPE)\s+(GLOBAL|WEAK)\s+DEFAULT\s+\d+\s+\S+' } |
        ForEach-Object { $parts = $_.Trim() -split '\s+'; ($parts[3..5] + $parts[7]) -join ' ' } | Sort-Object)
    if ($exports.Count -ne $pins.baselineExports.$abi.count -or
        (Hash-Text (($exports -join "`n") + "`n")) -ne $pins.baselineExports.$abi.sha256) {
        throw "Original BALL exported ABI changed: $abi"
    }
    $version = @(& $objdump --disassemble-symbols=xlua_get_lib_version $library)
    if ($LASTEXITCODE -ne 0 -or !(($version -join "`n") -match '#105')) { throw "xLua API version changed: $abi" }
    $dynamic = @(& $ReadElf -d $library)
    if ($LASTEXITCODE -ne 0) { throw "Cannot inspect $abi dependencies" }
    $needed = @($dynamic | ForEach-Object { if ($_ -match '\(NEEDED\).*\[(.+)\]') { $Matches[1] } } | Sort-Object)
    if (($needed -join ',') -ne ($pins.baselineNeeded -join ',')) { throw "Native dependencies changed: $abi" }
    Write-Output "PASS: $abi hash, $elfClass, $($exports.Count) original exports, API 105 and native dependencies."
}
Write-Output 'PASS: xLua Android static ABI/alignment verification. APK packaging and device execution remain unverified.'
