# Protected module content — host build contract

Status: integration foundation, **not an Android release certificate**. No production key is supplied by this change.

## Ownership and compatibility

- Standalone and hub hosts must use the same `(gameId, keyId, 32-byte key)` for the same module. Lua never receives the key provider.
- Modules declare `contentEncryption: "wpc1"`, public `contentKeyId`, and required capability `protected_content` together. Plaintext manifests remain supported; older hosts reject the new capability.
- AES-256-GCM reuses TapGarden's WPC1 envelope, additionally binding game, immutable version, key ID and file path through AAD. Original-game encrypted files **cannot simply be copied** into modules; rebuild authorized plaintext sources with the new context.
- All declared files (Lua/data/AssetBundle) are encrypted. Manifest hashes/sizes describe ciphertext. Catalog signature, manifest hash, ciphertext hash and authenticated decryption remain separate checks.
- Native masking is not hardware-backed secrecy or protection against a compromised client. Signing private keys must never enter this ring.

## Local/CI configuration

`MINIGAME_MODULE_KEYS_FILE` points to private JSON outside the Unity project **and module source/output trees**. Hosts requiring protected games should set `MINIGAME_REQUIRE_MODULE_KEYS=1` to reject empty provisioning. Set variables in the build process/job; a running Unity editor does not inherit later OS environment changes.

Input shape (placeholder, deliberately unusable):

```json
{"version":1,"entries":[{"gameId":"garden","keyId":"garden_v1","keyBase64":"<base64 of 32 privately generated random bytes>"}]}
```

Maximum 64 unique pairs. IDs start with a lowercase letter and contain lowercase letters, digits or underscores, at most 64 characters. Zero keys, invalid lengths, duplicates, oversized input and links/junctions fail validation. Do not put keys in command-line arguments, Git, resources, logs or module definitions.

Add to module definition:

```json
"contentEncryption": "wpc1",
"contentKeyId": "garden_v1",
"requiredCapabilities": ["lua", "assetbundle", "protected_content"]
```

Use the normal ModulePackager/AndroidModuleBuilder. Matching key provision is required before encrypted staging; the original source is unchanged. Private input must not be published even when building plaintext modules.

## Host builds and cleanup

- Android IL2CPP preprocessing generates ignored `Assets/Plugins/Android/MiniGameModuleKeys.cpp`, exporting `mgp_module_key`, imported Android-only. Empty provisioning emits a deny-all stub, not stale previous keys.
- Build scripts should use `ModuleHostKeyBuild.BuildPlayer(options)` for finally cleanup. The platform development builder uses this wrapper.
- Postbuild removes source/meta. Editor-idle/restart cleanup handles marker-owned source after interrupted builds, refusing unrelated files. Use ephemeral CI workspaces and remove private build caches after use: Unity's IL2CPP/Bee caches can retain key source or machine code. Source cleanup is **not** a whole-cache secure erase.
- Ship a new key ID in both hosts BEFORE publishing modules requiring it. Preserve old IDs while cached versions remain supported. Capability describes implementation availability, not provision of a particular key; missing keys fail closed at entry.

## Runtime and limits

LuaGameRunner authenticates Lua through ModuleContentReader. ModuleAssetScope authenticates encrypted bundles then calls AssetBundle.LoadFromMemory; plaintext behavior is unchanged. Host config can use ModuleContentReader; a bounded Lua-facing data facade remains integration work. Undeclared/unsafe paths, links, size/hash mismatch, missing keys and authentication failure are rejected without plaintext fallback.

Each protected plaintext file is capped at 64 MiB. Decryption/loading retains ciphertext, plaintext and Unity allocations temporarily; split mobile bundles further and measure memory on target devices.

## Verification and unfinished release gates

Editor entry: `MiniGamePlatform.SDK.EditorChecks.ModuleProtectionChecks.RunRegression` (six suites).

Synthetic temporary-key tests cover authenticated context/nonces/tampering, real packaging and ciphertext installation checks, decrypted xLua execution, plaintext compatibility, private-input locations, generated host source creation/removal, Windows native key selection/decryption and ARMv7/ARM64 object compilation. Other suites cover definition validation, plaintext packaging, signed/trusted catalog and release gating. No production keys or saves are used.

Not yet proven: Android final linkage/stripping and device execution on both ABIs, actual encrypted AssetBundle plus full runner lifecycle, dual-host smoke tests, low-memory behavior, release-backend acceptance, production key provisioning and SDK import into standalone TapGarden. Reconcile to **one** BouncyCastle assembly on import; TapGarden already owns the identical focused DLL. Full gameplay Lua conversion, schema9 account activation and platform ad facade remain separate unfinished gates. No automatic migration/reset or extra SDK initialization is introduced.
