# Unity 宿主批量渲染提交契约 v1

更新时间：2026-10-10。目标：减少小游戏 Lua 每帧逐顶点、逐 Transform 跨语言调用。游戏仍在 Lua 计算玩法、曲线、骨骼姿态、拓扑和数据；宿主只校验并将数据提交给 Unity。此能力属于共用 Unity 宿主，不进入核心 SDK 的账号/广告业务层。

## 启用与生命周期

- 新模块声明 `minHostApiVersion: 7` 和 `requiredCapabilities` 中的 `unity_render_batch_v1`；宿主通过 `HostProfile` 实际能力检测。已有不支持它的安装包不能靠更新 Lua 获得 C# 实现。
- Lua 通过 `host:CreateMeshBuffer(mesh)` 和 `host:CreateTransformBatch()` 创建对象。宿主验证模块能力、GameId 和对象有效性，并把创建的对象纳入本次模块的回收范围。Lua 可以提前 `Dispose()`；模块退出时宿主兜底调用，重复释放安全。
- `host.SupportsRenderBatch` 是只读布尔值，只有**当前安装宿主实际支持**且**当前模块的 `minHostApiVersion`/`requiredCapabilities` 已声明**此能力、桥接尚未释放时才为 true。游戏据此选批量或原有即时提交路径。工厂仍独立严格校验，失败抛错，不能把参数错误当成能力回退。
- 兼容旧宿主的 Lua 判断可写 `if host.SupportsRenderBatch then ... else ... end`；旧二进制没有该属性时值为 `nil`。不要用捕获 `CreateMeshBuffer` 的参数异常来选择旧路径。
- Mesh 与 Transform 均由游戏提供并负责自身生命周期。批量对象只借用它们；`Dispose()` 不销毁、卸载或重置原对象，但会从宿主登记表移除并解除对借用对象的引用。所有方法限创建时的 Unity 主线程。旧宿主/旧模块维持原 Lua 实现，游戏可按能力选择路径。

## `ModuleMeshBuffer`

公开方法：`SetTriangles(int[] triangles)`、`Upload(byte[] vertices, int vertexCount)`、`Clear()`、`Dispose()`。构造由 `host:CreateMeshBuffer(mesh)` 完成；传入一个运行时可读、由游戏单独创建和管理的 `UnityEngine.Mesh`。不得传入 AssetBundle 加载的原始 Mesh、其他模块持有的 Mesh 或共享资源。当前 v1 接口只接收 Mesh 引用，无法可靠区分运行时新建对象和共享资源；它依赖受审核的游戏遵守此规则，不构成不可信代码隔离。后续面向更广泛开发者时应改成宿主创建并登记 Mesh 的工厂。适用于 `ModuleMeshGraphic.Mesh` 等消费同一 Mesh 的 Unity 组件；游戏在提交后按组件要求标记 UI 顶点脏，例如 `ModuleMeshGraphic:SetVerticesDirty()`。

`Upload` 使用紧密排列的小端数据，每顶点 **76 字节**，偏移和格式固定：

| 偏移 | 内容 | 字节 |
| ---: | --- | ---: |
| 0 | position，float32 × 3 | 12 |
| 12 | normal，float32 × 3 | 12 |
| 24 | tangent，float32 × 4 | 16 |
| 40 | color，RGBA uint8 × 4 | 4 |
| 44 | uv0，float32 × 4 | 16 |
| 60 | uv1，float32 × 4 | 16 |

`vertexCount` 范围 0–64999，数组长度必须恰好等于 `vertexCount × 76`。所有使用的 float 必须有限值，且位置范围必须能表示为有限的 Unity Bounds。宿主把字节协议解码到**复用的结构体顶点数组**，一次调用静态泛型 `Mesh.SetVertexBufferData<BatchVertex>` 提交；只在顶点数改变时重设布局及索引。Unity 2022.3 的该 API 的 `count` 参数按顶点元素计数，不能把 `byte[]` 直接当作每顶点 1 字节提交。宿主从 position 计算并设置 Bounds，不把 Unity 的逐顶点 Vector/Color 包装对象暴露给 Lua。

`SetTriangles` 接受长度为 3 的倍数、最多 100 万个 int 的数组，索引均为非负且在最近一次/下一次 `Upload` 的顶点范围内；宿主复制并复用这份拓扑。先设置三角形再首次上传是合法顺序。新数组、顶点或索引不合法时，在修改 Mesh 之前抛错，保留之前有效内容。`Upload(empty, 0)` 和 `Clear()` 都清空 Mesh 几何、保留已设拓扑与借用关系，允许后续重新上传；`Dispose()` 只释放宿主临时缓冲，不销毁借用 Mesh。底层 Unity API 的非参数异常不能保证 GPU 提交事务回滚，因此设备验证必须覆盖这些调用。

## `ModuleTransformBatch`

公开方法：`Bind(Transform target) -> int handle`、`Apply(byte[] records)`、`Clear()`、`Dispose()`。`Bind` 只在对象创建时调用，要求 Transform 是本模块 Root 下的场景对象，或已由本模块 `TrackInstance` 登记的场景对象；同一对象重复绑定返回相同 handle。handle 在本批量对象的 `Clear/Dispose` 前稳定，不跨模块保存。

`Apply` 使用紧密排列的小端记录，每条 **48 字节**；`Bind` 返回从 1 开始的 handle：

| 偏移 | 内容 | 字节 |
| ---: | --- | ---: |
| 0 | handle，int32 | 4 |
| 4 | flags，uint32 | 4 |
| 8 | position，float32 × 3 | 12 |
| 20 | rotation，float32 × 4，顺序 x/y/z/w | 16 |
| 36 | scale，float32 × 3 | 12 |

`flags`：bit 0 更新 position；bit 1 更新 rotation；bit 2 更新 localScale；bit 3 表示 position/rotation 使用世界坐标，否则使用 local 坐标。未设置的字段不读取。允许仅 rotation 或仅 scale 更新；未知 bit 拒绝。空数组是空操作。单次最多 16384 条。宿主先校验整批长度、handle、目标存活/归属、flags、被使用字段的有限值与非零 rotation，再按原顺序提交。**任一记录无效，整批不修改任何 Transform。**目标已被 Unity 销毁时显式报错，游戏应在重建对象后重新绑定，不能静默更新其他模块的对象。`Clear()` 释放绑定及缓存而不销毁 Transform。

## 验证与交付

开发工具需对两种字节协议、非法长度/索引/NaN、失效对象、重复绑定、跨模块目标、退出回收、旧宿主能力拒绝做 EditMode 检查；在隔离 Unity 工程导入固定三包并构建样例模块。随后由接入游戏在 Android ARM64/IL2CPP 真机分别测功能、峰值分配和帧时。固定快照应记录三包 SHA-256 和宿主能力；新宿主交付不能覆盖此前不可变归档。

当前 `ModuleMeshGraphic` 会把 Mesh 数据读回托管内存并通过 UGUI `VertexHelper` 重建顶点。此批量接口减少 Lua→C# 逐点调用，不代表 UGUI 渲染路径已经零拷贝，也不能仅凭编辑器脚本计时推断手机端帧时或 GC 收益。
