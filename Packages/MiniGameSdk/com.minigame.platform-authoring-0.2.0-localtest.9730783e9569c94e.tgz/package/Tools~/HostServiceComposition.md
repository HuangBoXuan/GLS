# 宿主服务装配（API 6）

共用 Unity 宿主创建服务，核心 SDK 接收身份与驱动并提供稳定接口。综合包和独立包共用此装配方式，运行器不识别 Garden 或其他游戏业务。

```csharp
using MiniGamePlatform.HotUpdate;
using MiniGamePlatform.SDK.Host;

var queue = new HostMainThreadQueue();
var factory = new CommonModuleServiceFactory(
    new AtomicLocalStore(saveDirectory),
    new HostAdBroker(nativeAdDriver, queue));
var player = new ModulePlayer("independent", gameId, contentKeys, factory);
player.OpenInstalled(directory, manifestSha256, product, session, levelId, OnStatus);
```

`nativeAdDriver` 由产品接入；null 明确表示广告未配置，不会假装成功。正式 Player 不包含模拟广告驱动。产品可跨游戏复用一个 HostAdBroker，维持原生全屏广告占用；账号切换、退出和迟到回调由 SDK 的服务作用域隔离。

Lua 使用 `host.Services.Account/Storage/Ads/Requests`。`Requests` 只转发当前游戏的认证请求，业务 DTO、奖励、进度与排行规则由游戏和服务端维护。`host.Platform` 和 LegacyModulePlatformFactory 已从编译实现移除，历史源码在 Samples~/LegacyGameMigrationReference，仅供迁移参考。

正常 `player.Tick()` 会泵送服务回调；MonoBehaviour 入口自动接线。手写壳须在 Update / LateUpdate 分别调用 Tick / LateTick。原生广告驱动可在其他线程报告结果，Lua 回调经主线程队列投递。产品仍可在自己的 Update 泵送共享队列，以完成无模块运行时的原生广告关闭。

退出时调用一次 Exit，并等待 HasPendingExit 为 false。共用宿主持久驱动负责异步资源回收；不要在 Lua 正在执行的调用栈内关闭 LuaEnv，不要主动每帧重试 Exit。

产品账号配置、广告商参数、目录 UI 和建筑养成业务均由产品负责。正式账号和原生广告驱动接入、真实服务端联调，不能由本地测试驱动的通过结果替代。
