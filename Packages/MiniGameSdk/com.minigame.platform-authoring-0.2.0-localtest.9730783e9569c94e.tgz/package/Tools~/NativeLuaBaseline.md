# 原生 Unity / xLua 基线 v1

当前共用宿主 API 7，Unity/xLua 实现位于 `com.minigame.platform-host`。核心 SDK 不承载 Unity 表现实现。基础 Bundle 所需最低 API 仍为 6，并至少声明 `lua`、`assetbundle`、`module_owned_resources_v1`；原生 CS 调用另声明 `unity_native_v1`。旧 API 5 模块须按新版工具重新导出，不能只改目录能力字段。2026-10-20 基线的异步资产与 packed/chunk 渲染接口另见 `SharedHostUpgrade-2026-10-20.md`，API 号相同不代表快照能力完全相同。

## 调用方式

小游戏通过 `host:SpawnPrefab(bundlePath, assetName)` 加载模块清单中的原 Prefab，再通过 xLua 的 `CS.UnityEngine`、`CS.UnityEngine.UI`、`CS.TMPro` 操作组件。不需要通过 ModulePresentation 重建 UI、材质、动画、粒子或音频。Lua 侧优先用非泛型 Type 重载，例如 `node:GetComponent(typeof(CS.UnityEngine.UI.Button))`。

此版使用 xLua 的原生反射包装路径及静态回调实现，不宣称已经生成整个 Unity API 的静态 Wrap。Editor 禁用动态委托生成以暴露 AOT 差异；Player 的反射与泛型调用仍须通过 IL2CPP 验证。

## 静态回调范围

`NativeDelegateBridge.cs` 显式引用以下闭合方法，使 IL2CPP 编译它们：

- `UnityAction`，以及一个参数为 bool/int/float/string/Vector2/Vector3/Color/PointerEventData/BaseEventData 的 `UnityAction<T>`。
- `System.Action`，以及 bool/int/float/string/Vector2/Vector3/Color 一个参数的 `Action<T>`。
- 无参数、返回 bool/int/float/string 的 `Func<T>`。

`NativeUnityEventAot.cs` 保留对应 `UnityEvent<T>` 的构造、AddListener、Invoke、RemoveListener 闭合引用。覆盖 Button、Toggle、Slider、Dropdown、InputField、ScrollRect 等常见 UI 事件签名；并不保证任意 ref/out、多参数、接口代理或未声明泛型。TMP 特殊字符验证回调、第三方插件委托等须按实际签名追加和验证，不能仅增加 link.xml 就宣称支持。

## 生命周期

```lua
local U = CS.UnityEngine
local button = root:GetComponent(typeof(U.UI.Button))
local clicked = U.Events.UnityAction(function()
    if paused or root:Equals(nil) then return end
    -- 游戏逻辑
end)
button.onClick:AddListener(clicked)
host:TrackCallback(function()
    if not button:Equals(nil) then button.onClick:RemoveListener(clicked) end
    clicked = nil
end)
```

解绑必须使用订阅时的同一个委托，不能用一个新匿名函数代替。TrackCallback 也可登记其他事件/资源清理操作；模块 exit 回调后、LuaEnv 关闭前执行这些清理。不要在 exit 中提前清空清理闭包仍要使用的引用。

原生组件的播放状态由游戏的 pause/resume/exit 管理：禁用局内交互、保存并恢复动画/粒子/音频状态，不能全局暂停宿主音频或随意更改全局 Time.timeScale。样例展示这一契约，不向 SDK 添加 PlayAudio/SetAnimator 等表现接口。通过 SpawnPrefab 创建的对象归当前模块根节点；自行创建的对象要挂在模块对象下，订阅的外部事件必须登记清理。

LuaEnv.Dispose 现在真正关闭 Lua 状态，并支持重复调用；仍有未解绑的 C# 委托时会报错，不能忽略。LuaGameRunner 保留未关闭的环境以便再次 Exit 重试，并以 EXIT_PENDING 阻止开启新模块，直到旧回调解除并关闭成功。不要在正在执行的 Lua 回调堆栈内销毁其 LuaEnv；通过壳在回调返回后退出。

宿主检查 `ModulePlayer.HasPendingExit`（同样存在于 LuaGameRunner），不能只看 State=Empty。`Exit()` 发起退场；Player 的持久回收驱动等待 Unity 对象销毁，完成后才能替换播放器。外部 Lua 委托仍存活时，VM 退出失败，资源继续保留；自动重试从 0.25 秒退避到最多 2 秒，避免每帧反复完整 GC。业务应修复并解绑残留回调，不要用永久重试掩盖泄漏，也不要每帧主动调用 Exit。

产品壳销毁后回收驱动仍持有待释放对象；正常流程仍应等待 `HasPendingExit=false` 再进入下个模块。EditMode 没有 Player 更新驱动，测试在解绑后显式再次 Exit。成功重试清除退出错误；其他错误可保留，不用 LastError 单独判断释放完成。

## 构建保留与边界

NativeLuaLinkerProcessor 通过 IUnityLinkerProcessor 显式提交包内 Runtime/link.xml，不依赖 Unity 自动扫描 UPM 包。构建日志输出 MGP_NATIVE_LINKER_INPUT，需核对实际 linker 参数。做法依据 [Unity Linker 回调文档](https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Build.IUnityLinkerProcessor.GenerateAdditionalLinkXmlFile.html)。

link.xml 按原生基础程序集保留 Core、UI、UGUI、TMP、Animation、ParticleSystem、Audio、Physics，以及 xLua。`NativeLuaBaseline.RetainedAssemblies` 与这些保留项对应，导出工具按实际程序集中的组件建立清单；没有材质名、颜色、动画事件的表现白名单。代价是这部分托管代码不能被激进裁剪，包体成本应以实际 Android 构建评估。

依赖类型仍必须存在于 Player。资源不能带来新的游戏 C#、StateMachineBehaviour 或原生插件；其他 Unity 模块和第三方组件不在此基线承诺内。材质 Shader、字体图集、渲染管线与 AssetBundle 目标兼容仍由资源构建和真机验收验证。当前 xLua 不构成不可信代码沙箱。

## 原生资源读取与输入转接

```lua
local sprite = host:LoadAsset("ui.bundle", "assets/game/ui/icon.png", typeof(CS.UnityEngine.Sprite))
image.sprite = sprite
```

`host:LoadAsset(bundlePath, assetName, assetType)` 返回 Unity 原生资源，支持按实际类型读取 Sprite、Material、AudioClip、TMP_FontAsset、RuntimeAnimatorController 等 UnityEngine.Object。它与 SpawnPrefab 共用当前模块的 ModuleAssetScope、已声明 Bundle、安装完整性校验、加密内容读取与缓存；不接受任意 CDN 地址或未声明的 Bundle。资源名允许中文和空格，不约束美术命名风格、颜色或材质属性。

返回的是当前资源作用域借用的引用。SpawnPrefab 自动登记实例；自行创建的场景节点应挂在 host.Root 下，或通过 host:TrackInstance(node) 登记。游戏自建的材质、Mesh、纹理等非场景资源由游戏清理，不能销毁借用资产或跨模块缓存它们。模块租用完整 Bundle 集合，相同明文哈希共享租约；完成 VM 退出与实例销毁后，最后租约以 Unload(true) 释放原始资源。GUID/localId、Sprite 多子资源的唯一定位和游戏资源表由游戏构建管理；本接口不实现任意子资源选择器。

`ModulePointerRelay` 是可选的最小 MonoBehaviour 转接器。Lua 可 AddComponent，也可使用包含此组件的 Prefab：

- PointerDown / PointerUp / PointerExit：传原始 PointerEventData，保留 pointerId。
- Submit：传 BaseEventData。
- PointerCanceled：组件禁用或根节点退出时，逐个传尚未释放的 pointerId，并清空按压状态。

只实现 IPointerDown/Up/Exit/Submit；不实现拖动、滚动或点击接口。Button.onClick 仍使用原生事件，父 ScrollRect 保留拖动路由。重复 Down 不产生重复按压；Exit 是离开通知，不等同于取消；游戏按自身规则处理移出/移入表现。暂停应禁用该 relay，恢复再启用，防止旧指针在恢复后继续生效。监听使用同一个 Lua 函数添加/移除，或保存显式委托；通过 TrackCallback 解绑。完整例子见 NativeRuntimeValidation/main.lua.txt。平台不提供按钮动效、动画状态机或配色逻辑。

## 验证工具

- SDK Editor 回归：`MiniGamePlatform.SDK.EditorChecks.SdkNativeLuaChecks.Run`。
- `Samples~/NativeRuntimeValidation` 是独立验证工程样例，含原生 Prefab 构建器、Lua 模块和实际 Play Mode/Android 运行探针。按该样例 README 操作。
- 固定包的哈希、实际执行范围与 Android/设备状态记录在仓库中文交付报告中；源码存在不等于全部平台通过。

## 额外宿主能力

当前宿主已接入固定 Localization 1.4.4；具体 SmartFormatter 与 UGUI 扩展范围见 NativeUguiLocalization.md。使用相应能力的游戏应声明实际依赖并通过 Android 验收。游戏翻译表由游戏交付。

宿主显式声明 unitywebrequestwww 引擎依赖，供迁入 xLua 的旧 StreamingAssets loader 编译；模块主加载仍走清单和内容验证，不推荐游戏绕过此入口。
