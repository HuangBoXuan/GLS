param(
  [Parameter(Mandatory)][string]$ModuleDefinition,
  [Parameter(Mandatory)][string]$ModulePath,
  [Parameter(Mandatory)][string]$HostProfiles,
  [Parameter(Mandatory)][string]$IndependentEvidence,
  [Parameter(Mandatory)][string]$HubEvidence,
  [Parameter(Mandatory)][string]$Report,
  [string]$ProjectPath = (Get-Location).Path,
  [string]$EditorPath = 'D:\Unity2022.3.25\2022.3.76f1\Editor\Unity.exe'
)
$ErrorActionPreference = 'Stop'
foreach ($inputPath in @($ModuleDefinition, $ModulePath, $HostProfiles, $IndependentEvidence, $HubEvidence, $EditorPath)) {
  if (-not (Test-Path -LiteralPath $inputPath)) { throw "Input missing: $inputPath" }
}
$buildTools = Join-Path (Split-Path -Parent $EditorPath) 'Data\PlaybackEngines\AndroidPlayer\SDK\build-tools'
$aapt = Get-ChildItem -LiteralPath $buildTools -Filter aapt.exe -Recurse -ErrorAction Stop | Select-Object -First 1 -ExpandProperty FullName
if (-not $aapt) { throw "Android aapt missing under $buildTools" }
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
foreach ($evidencePath in @($IndependentEvidence, $HubEvidence)) {
  $evidence = Get-Content -LiteralPath $evidencePath -Raw | ConvertFrom-Json
  if (-not (Test-Path -LiteralPath $evidence.apkPath)) { throw "APK missing: $($evidence.apkPath)" }
  $badging = & $aapt dump badging $evidence.apkPath
  if ($LASTEXITCODE -ne 0) { throw "aapt could not inspect $($evidence.apkPath)" }
  $packageLine = $badging | Where-Object { $_ -like 'package:*' } | Select-Object -First 1
  if ($packageLine -notmatch "package: name='([^']+)' versionCode='([^']+)' versionName='([^']+)'" -or
      $Matches[1] -ne $evidence.applicationId -or
      ($Matches[3] + '+' + $Matches[2]) -ne $evidence.androidBuildVersion) {
    throw "APK identity differs from evidence: $($evidence.apkPath)"
  }
  $archive = [IO.Compression.ZipFile]::OpenRead($evidence.apkPath)
  try {
    if (-not $archive.GetEntry('lib/arm64-v8a/libil2cpp.so')) { throw "APK is not arm64 IL2CPP: $($evidence.apkPath)" }
    $catalogEntry = $archive.GetEntry('assets/MiniGames/catalog.json')
    if (-not $catalogEntry) { throw "Product catalog absent from APK: $($evidence.apkPath)" }
    $stream = New-Object IO.StreamReader($catalogEntry.Open())
    try { $catalog = $stream.ReadToEnd() | ConvertFrom-Json }
    finally { $stream.Dispose() }
    if ($catalog.productId -ne $evidence.productId) { throw "APK productId differs from evidence: $($evidence.apkPath)" }
  }
  finally { $archive.Dispose() }
}
$reportFile = [IO.Path]::GetFullPath($Report)
$logFile = [IO.Path]::ChangeExtension($reportFile, '.unity.log')
[IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($reportFile)) | Out-Null
$arguments = @(
  '-batchmode', '-nographics', '-projectPath', ([IO.Path]::GetFullPath($ProjectPath)),
  '-executeMethod', 'MiniGamePlatform.SDK.EditorChecks.ModuleReleaseGate.VerifyFromCommandLine',
  '-modulePath', ([IO.Path]::GetFullPath($ModulePath)),
  '-moduleDefinition', ([IO.Path]::GetFullPath($ModuleDefinition)),
  '-hostProfiles', ([IO.Path]::GetFullPath($HostProfiles)),
  '-independentEvidence', ([IO.Path]::GetFullPath($IndependentEvidence)),
  '-hubEvidence', ([IO.Path]::GetFullPath($HubEvidence)),
  '-gateReport', $reportFile, '-quit', '-logFile', $logFile
)
$process = Start-Process -FilePath $EditorPath -ArgumentList $arguments -WindowStyle Hidden -PassThru
Wait-Process -Id $process.Id -Timeout 300
$process.Refresh()
if ($process.ExitCode -ne 0) { throw "Release gate rejected or Unity failed; see $logFile and $reportFile" }
if (-not (Test-Path -LiteralPath $reportFile)) { throw "Release report missing: $reportFile" }
$gate = Get-Content -LiteralPath $reportFile -Raw | ConvertFrom-Json
if ($gate.publishable -ne $true) { throw "Release gate rejected: $($gate.reasons -join ',')" }
Write-Output "MODULE_GATE_PUBLISHABLE $($gate.gameId) $($gate.moduleManifestSha256)"
