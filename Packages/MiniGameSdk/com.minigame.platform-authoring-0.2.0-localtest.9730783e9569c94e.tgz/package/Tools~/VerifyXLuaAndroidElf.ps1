param(
    [Parameter(Mandatory=$true)][string]$ReadElf,
    [Parameter(Mandatory=$true)][string]$Library,
    [switch]$PassThru
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
if (!(Test-Path -LiteralPath $ReadElf -PathType Leaf)) { throw 'Missing llvm-readelf tool.' }
if (!(Test-Path -LiteralPath $Library -PathType Leaf)) { throw "Missing native library: $Library" }
$headers = @(& $ReadElf -Wl $Library)
if ($LASTEXITCODE -ne 0) { throw "Cannot inspect ELF program headers: $Library" }
$loads = 0
$relro = 0
foreach ($line in $headers) {
    if ($line -notmatch '^\s*(LOAD|GNU_RELRO)\s+(0x[0-9a-fA-F]+)\s+(0x[0-9a-fA-F]+)\s+(0x[0-9a-fA-F]+)\s+(0x[0-9a-fA-F]+)\s+(0x[0-9a-fA-F]+)\s+.+?\s+(0x[0-9a-fA-F]+)\s*$') { continue }
    $type = $Matches[1]
    $offset = [Convert]::ToUInt64($Matches[2].Substring(2),16)
    $address = [Convert]::ToUInt64($Matches[3].Substring(2),16)
    $memorySize = [Convert]::ToUInt64($Matches[6].Substring(2),16)
    $alignment = [Convert]::ToUInt64($Matches[7].Substring(2),16)
    if ($type -eq 'LOAD') {
        $loads++
        if ($alignment -lt 16384 -or ($alignment -band ($alignment-1)) -ne 0 -or
            ($offset % 16384) -ne ($address % 16384)) {
            throw "16KB LOAD alignment failed in ${Library}: $line"
        }
    } else {
        $relro++
        $end = $address + $memorySize
        if (($end % 16384) -ne 0) {
            throw ('16KB GNU_RELRO alignment failed in {0}: VirtAddr+MemSiz=0x{1:X}, remainder=0x{2:X}' -f $Library,$end,($end % 16384))
        }
    }
}
if ($loads -eq 0) { throw "No LOAD segments found in $Library" }
if ($relro -eq 0) { throw "xLua RELRO protection is missing in $Library" }
if ($PassThru) { [pscustomobject]@{ library=$Library; loadSegments=$loads; relroSegments=$relro; pageSize=16384 } }
else { Write-Output "PASS: $Library ($loads LOAD and $relro GNU_RELRO segments aligned for 16KB)." }
