# SDK 旧表现桥兼容接口（API 4）

> 2026-09-29：仅记录已交付接口的实际行为，不是新游戏接入标准。下文的组件白名单、居中布局、颜色字段和节点预算只约束此旧适配器，不约束 Unity 原生资源。新游戏不应为适配旧桥拆 UI、去掉 Animator 或烘焙颜色/动画。

本文用于游戏 Lua 接线。目标是在独立壳与综合壳中，通过同一套受控接口显示色块、花朵、虫体及关卡文字，并把点击交给 Lua 规则层。这里不运行 Garden 原 C# 玩法，不结算云奖励，也不改变 API 3 服务端协议。

本文先于实现落地；实际验证与固定包地址见后续交付报告。API 3 归档保持不变。

## 1. 入口、声明和职责

入口为 `host.Presentation`，类型 `MiniGamePlatform.HotUpdate.ModulePresentation`。模块必须声明 `minHostApiVersion: 4` 和 `presentation` 能力；使用 TMP 另加 `tmp_text`，使用资源包另加 `assetbundle`。原有 `lua`、在线 `garden_local_api`、`data_text`、加密能力按实际需求保留。

所有创建方法返回正整数节点句柄。句柄只在当前运行实例有效；0 仅表示创建时使用该类型默认根节点。不能跨模块、跨退出或跨实例复用。API 不返回 GameObject、Transform、Component 或任意反射调用入口。旧 xLua 本身仍不是不可信代码沙箱。

SDK 负责资源实例、UGUI 点击和显示更新；Lua 负责关卡规则、输入顺序、骨骼/身体轨迹计算及胜负。显示帧不能替代确定性模拟 tick。SDK 不生成 tap/advance 网络事实。

## 2. 精确接口

以下参数按位置传入，Lua 用 `:` 调用。所有方法必须在 Unity 主线程调用。

| 方法 | 含义 |
| --- | --- |
| `int CreateGroup(bool ui, int parent)` | 创建空容器；UI 与世界节点不能混合父子类型 |
| `int CreateImage(int parent)` | 创建 UGUI Image，默认白色，可无图片显示色块 |
| `int CreateRawImage(int parent)` | 创建 UGUI RawImage |
| `int CreateText(int parent, string text, int fontSize)` | 创建 UGUI Text；使用宿主内置字体，中文字体覆盖不保证 |
| `int CreateTmpText(int parent, string bundle, string fontAsset, string text, int fontSize)` | 创建 TextMeshProUGUI；显式传入模块包内 TMP_FontAsset，不依赖游戏原 Resources 路径 |
| `void SetText(int node, string text)` | 设置 Text 或 TMP 的文字；按纯文本显示 |
| `void SetImage(int node, string bundle, string asset)` | Image 读取 Sprite；RawImage 读取 Texture2D；不能传任意磁盘路径或 URL |
| `int CreatePrefab(int parent, string bundle, string asset)` | 创建世界模型，只接受下述纯表现组件白名单 |
| `int FindNode(int parent, string relativePath)` | 取得世界 Prefab 子节点句柄；逐段唯一名字路径，不支持 `..`、绝对路径或同名歧义；找不到抛错 |
| `void ApplyNodes(string json)` | 批量设置姿态、UI 矩形、颜色、显隐；先检查全批，再应用 |
| `void BindTap(int node, int logicalId)` | 给 Image/RawImage 设置逻辑点击 ID，必须大于 0；重绑替换旧绑定 |
| `void UnbindTap(int node)` | 清除绑定；旧队列项不再交付 |
| `int PollTap()` | 按到达顺序取一个有效逻辑 ID；无输入返回 0 |
| `void DestroyNode(int node)` | 删除节点及子树；句柄、绑定与未消费点击同时失效 |

UI 使用居中锚点和居中 pivot，参考分辨率 1080×1920，CanvasScaler 按宽高各 0.5 匹配；位置/尺寸均为画布单位。Canvas 使用 Overlay、sortingOrder=100；宿主需要给退出/暂停浮层安排更高层级或在暂停时屏蔽输入。文本默认不拦截点击。

世界节点使用局部坐标、角度制欧拉角。首版不创建/修改相机、灯光或全局渲染设置；宿主 C# 根据游戏入口布置相机与光照，使模块根节点可见。没有世界射线命中 API：首批可交互对象使用 UGUI Image/RawImage，世界花朵和虫体用于显示。

## 3. 批量更新格式

```json
{"nodes":[
  {"id":123,"pose":true,"x":0,"y":100,"z":0,"rx":0,"ry":0,"rz":0,"sx":1,"sy":1,"sz":1,
   "rect":true,"width":120,"height":120,
   "tint":true,"r":1,"g":0.3,"b":0.2,"a":1,
   "visibility":true,"active":true}
]}
```

`pose/rect/tint/visibility` 为更新开关；未开启的组不改变原值。开启 pose 时须传全套位置、旋转、缩放（缩放不能为零）；开启 tint 须传 RGBA。rect 仅用于 UI；tint 仅作用于当前节点上的 Graphic 或 Renderer，给容器着色需逐个更新具体子节点。Renderer 使用 MaterialPropertyBlock 的 `_Color` 和 `_BaseColor`，不复制材质、不开放任意 Shader 参数。SpriteRenderer 直接更新颜色。

单批 1..512 项（空批次也拒绝），JSON 最多 256 Ki 字符；重复 ID、无效/已删除/外部 ID、错误节点类型、非有限数字或超限数值会拒绝整个批次。最多 4096 个节点，Prefab 的所有子节点计入预算；文字最多 2048 字符；字号 1..256；UI 宽高 0..16384；位置绝对值不超过 1,000,000，旋转不超过 360,000，缩放绝对值 0.0001..1000，颜色 0..1。此处的全批校验不承诺对 Unity 内部异常做事务回滚。

## 4. 点击与生命周期

使用 Unity EventSystem 的正常 UI 遮挡顺序。宿主已有可用 EventSystem 时复用；没有时创建由本实例持有的 EventSystem + StandaloneInputModule，退出只销毁自己创建的实例。宿主应保持单活动模块、使用兼容的 UGUI 输入配置；本桥不改变项目 Input System 设置。

点击队列最多 128 项，满时拒收新的点击并累计 `DroppedTapCount`，不能当作完整输入记录；游戏侧应监测该计数并终止需要完整输入证据的录制。暂停、退出、取消绑定、删除或隐藏节点时，尚未交付的相应点击失效。暂停前按下、恢复后松开的手势不交付；不保留 Lua 回调代理。

`LuaGameRunner.Pause/Resume/Exit` 自动控制表现输入；退出销毁 UI/世界对象并清空队列。Lua 不需要自己处理 Unity 事件解绑。退出后调用桥抛 `ObjectDisposedException`。原生壳不要在退出后继续使用旧句柄。

## 5. 资源交付与现有 Garden 的具体差距

资源从当前模块清单声明的 `.bundle` 加载；Editor 与 Android 使用各自目标构建，不能用 Android 包证明 Editor 预览通过。游戏侧导出步骤仍应通过已有模块构建门禁。

世界 Prefab 首批运行时白名单：Transform、MeshFilter、MeshRenderer、SkinnedMeshRenderer、SpriteRenderer。实例化前检查整棵树，含 Missing Script、Animator、Collider、Camera、Light、任意 MonoBehaviour 的原包都会拒绝。蒙皮可保留骨骼 Transform，通过 FindNode/ApplyNodes 更新姿态；自动动画状态机、动画事件、粒子、材质弯曲/裁剪参数另行设计，不能宣称已复现。

原先为了这个旧桥要求 Garden 去掉 Animator、拆分 UGUI、烘焙动画或材质的迁移建议已撤销。应保留原资源，修复通用加载与桥接缺口；游戏专属 C# 逻辑迁移 Lua 的边界仍有效。SDK 不规定游戏 Shader 名称、颜色、材质槽的美术语义。

## 6. Lua 接线最小例子

```lua
local p, block
return {
  enter = function(host)
    p = host.Presentation
    block = p:CreateImage(0)
    p:ApplyNodes('{"nodes":[{"id":' .. block .. ',"rect":true,"width":160,"height":160,"tint":true,"r":0.2,"g":0.7,"b":0.3,"a":1}]}')
    p:BindTap(block, 17)
  end,
  update = function(dt)
    while true do
      local boxId = p:PollTap()
      if boxId == 0 then break end
      -- 在这里交给游戏 Lua 规则层，并记录真正接受的输入顺序。
    end
  end,
  exit = function() p = nil end
}
```

本批验收目标为 Editor 创建/更新/点击/退出边界、实际 xLua 调用和独立安装包导入。Android/IL2CPP/AOT、双壳真机与真实 Garden 资源运行必须单独验证。

## 7. 宿主准备和预览入口

- SDK 显式依赖 Unity UGUI 与 TextMeshPro 3.0.7。使用 TMP 前，宿主须导入 TMP Essential Resources（Unity 的 `Window > TextMeshPro > Import TMP Essential Resources`），再把相关设置与 Shader 纳入宿主构建。SDK 不静默覆盖项目现有 TMP Settings；缺少设置时给出明确错误。
- 每个 SetImage/CreatePrefab/CreateTmpText 所读 bundle 应包含其必要依赖；本批没有增加任意外部 bundle 依赖的隐式下载器。
- 建议在空白场景进入 Play Mode 后执行 `MiniGame Platform > SDK > Open Presentation Preview (Play Mode)`，在 Game 视图点击三个色块；Close Preview 或退出 Play Mode 会清理演示对象。此演示是通用 UGUI 验证，不是 Garden 真实美术预览，不读存档、不连接服务器。
- 检查入口：`MiniGamePlatform.SDK.EditorChecks.SdkPresentationChecks.RunRegression`。TMP 资源另用 `RunTmpAssets` 在导入 TMP Essential Resources 的验证工程运行。
- `MiniGamePlatform.SDK.EditorChecks.SdkPresentationPreview.Capture` 需要图形设备（不加 `-nographics`），输出 `Logs/sdk-presentation/preview.png` 并检查真实 GraphicRaycaster 命中到点击队列的链路。
- 实际 Play Mode 冒烟入口为 "MiniGamePlatform.SDK.EditorChecks.SdkPresentationPlayChecks.Run"；批处理不能加 -quit，由检查在完成后退出。该入口只用于独立验证工程，不作为修改现有场景层级的工具。
