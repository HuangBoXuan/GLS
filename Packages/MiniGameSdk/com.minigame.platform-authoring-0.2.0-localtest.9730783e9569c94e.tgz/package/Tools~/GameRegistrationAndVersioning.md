# 小游戏建档、模块构建与选版接入

适用：内部小游戏和受邀合作方的 Unity 2022.3.76f1 / Android / `unity_lua` 模块。本文说明开发者怎样把同一游戏模块交给独立包和综合包；建档、交付、发布分别是不同操作。本地工具可验证构建契约，但不能代替真实 CDN、服务器和 Android 设备验收。

## 三个标识只各管一件事

| 标识 | 填写位置 | 含义 |
| --- | --- | --- |
| `gameId` | 后台游戏档案、`module-definition.json`、Lua 目录、manifest、签名目录和服务器游戏记录 | 游戏永久身份。新建时用 `^[a-z][a-z0-9_]{0,63}$`，例如 `garden`；同一游戏的独立包与综合包必须相同。不要把包名或版本写进 ID。 |
| `productId` | 每个宿主包的 `trusted-catalog.json`、产品签名目录、服务器选版请求 | 安装包/产品身份。独立包与综合包各有自己的值；**共享模块不写入 productId**，从而可以原样复用。 |
| `moduleVersion` | `module-definition.json`，构建后对应 manifest `version` | 不可覆盖的游戏模块版本，例如 `v1`、`v2`。不同于宿主 APK 版本和 SDK 包版本。 |

SDK/宿主兼容性由模块定义的 `minHostApiVersion`、`requiredCapabilities`、构建平台和实际 Unity 版本表达，写入 manifest 与产品签名目录。核心 SDK、宿主和 Authoring 三个 UPM 包必须取同一固定基线；不要在游戏工程单独升级其中一个包。产品的广告参数、API 地址和信任公钥配置在宿主包，不放入小游戏模块。

既有服务器样例可能使用 `game-a` 这样的旧路由；SDK 的数据接口保留读取这类 ID 的兼容性。**新游戏建档和可下载模块**只用上表的新规则。

## 开发者从建档到交付

1. 先确认该游戏的永久 `gameId`。如果是已有游戏（例如 `garden`），沿用现有 ID。在发布后台「版本发布 → 游戏与热更版本」创建或查看游戏档案，记录审核人确认的 ID。档案创建只登记游戏身份，不会自动注册玩法规则、开通 CDN 或上架。
2. 在游戏工程导入发行方给出的同一组三个 UPM `.tgz`，按 [PartnerGame 样例](../Samples~/PartnerGame/README.md)设置 `module-definition.json`。`gameId`、`luaRoot=games/<gameId>`、`entry=games.<gameId>.*`、数据根、资源根、宿主 API 和能力都必须对应真实游戏。游戏专属 C# 不进入可下载模块。
3. 用 `MiniGamePlatform.SDK.EditorChecks.AndroidModuleBuilder.BuildFromCommandLine` 生成 Android 模块；命令见样例。产物为 `modules/<gameId>/<moduleVersion>/manifest.json`、Lua/数据和 Android Bundle。构建器会拒绝定义、入口或资源命名空间不一致的输入。修改模块时新建 `moduleVersion`，不要覆盖已输出版本。
4. 运行 `MiniGame Platform/SDK/Run Module Definition Checks`、`Run Module Packager Checks`，并按样例执行 `Tools~/VerifyModuleRelease.ps1` 完成独立包和综合包的 Android 双包门禁。两包必须使用**相同 manifest SHA-256**。再运行 `Tools~/PrepareModuleDelivery.ps1` 输出 `modules/`（玩家可下载内容）和 `review/`（审核材料）。该工具再次核对定义、manifest、门禁报告、入口、文件命名空间和 APK/日志哈希。
5. 将标准交付导入**测试环境**后台；可以按后台受控存储路径导入，也可以上传约定 ZIP。审核人执行接入检查及复验。游戏服务器还需登记该 `gameId` 的账号/存档与结算规则；后台“服务器可见”仅表示清单中找到 ID，不能证明在线结算已接通。
6. 测试发布需要后台执行模式、签名目录、测试 CDN 和服务器快照同步均已启用。当前 `managementOnly=true` 的后台只管理档案，不能完成实际发布。正式环境在测试验收后单独晋级相同哈希的模块并签发对应产品目录。

## 宿主如何按产品选版

每个产品包维护自己的 `productId`、包名、默认入口、可访问游戏和 `trusted-catalog.json`。发行方签署的目录必须属于该 `productId`。正式构建要求 `useServerVersionSelection=true`；客户端对选定游戏发送 `POST /v1/platform/module-selection`，携带 `productId`、`gameId`、真实平台/客户端/Unity/宿主 API 版本、能力及安装 ID。该接口不需要后台管理账号，客户端不能调用 `GET /api/games` 或携带审核人的 CSRF/服务令牌。

服务器返回 `ready` 时，宿主核对响应的产品和游戏，验证完整签名目录，再按指定的 `gameId + version + manifestSha256` 精确选择、下载和逐文件校验；**不能从 CDN 自选最高版本**。`fallback` 只在本次决定明确给出、已安装、仍在已验签目录中开放且兼容时使用。`blocked`、`host_update_required`、无效签名/哈希或策略倒退直接拒绝；网络临时故障仅按上次同作用域的已验证本地决定受限启动，不能下载新版本。首次无历史策略且返回严格的 `UNPUBLISHED` 时，才允许使用完整校验的包内版。详见[服务器选版契约](../../../docs/architecture/server-assigned-module-selection-2026-10-08.md)。

平台目录只负责发现“有哪些游戏”；启用、默认版、灰度版、下架和紧急封禁由后台策略及服务器决定；`modules/<gameId>/` 下有几个资源版本不等于玩家能启动几个版本。账号 `userId` 跨包共享；游戏进度及专属资产按 `gameId` 隔离。共有奖励和排行由服务器核实的有效在线对局写入，离线同步不发奖。

## 两个模块版本的验收顺序

1. 在本地分别构建 `v1` 和 `v2`，确认 manifest 哈希不同、旧目录保持原样。Editor 执行 `MiniGame Platform/SDK/Run Module Selection Checks` 和 `Run Server Version Decision Checks`，核对精确版本、错误哈希、禁用、宿主不兼容与临时断网规则。这是契约测试，不代表真实 CDN 联调。
2. 测试环境先审核/发布 `v1` 为默认版，核对后台快照同步成功后，分别用独立包与综合包查询并进入 `v1`，记录 `productId`、服务器 `selectionRevision`、模块 manifest 哈希和设备日志。
3. 再审核/发布 `v2`，仅给指定产品或灰度安装分桶选 `v2`；未命中的仍应得到服务器指定的 `v1`。两个产品可以有不同选版，但下载到的同版本模块哈希应相同。
4. 人为制造下载中断、文件哈希错误、服务器明确 `blocked` / `host_update_required`、允许的 `fallback` 和临时 5xx，逐项核对客户端提示、已安装版本保存与是否允许受限启动。完成回退后再次进入并检查存档未丢失、资源被正确回收。

实际测试/正式 CDN 地址、第三个产品的正式 `productId` 和版本数据由发行方配置；本文不预设它们已经存在或已发布。
