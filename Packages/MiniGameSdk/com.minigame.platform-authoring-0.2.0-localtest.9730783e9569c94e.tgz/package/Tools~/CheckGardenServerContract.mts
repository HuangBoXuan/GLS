// Read-only schema verification. Does not initialize Fastify, connect to a DB or call HTTP.
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { resolve, join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';

const [serverDirectory, transcriptPath] = process.argv.slice(2);
if (!serverDirectory || !transcriptPath) throw new Error('Usage: tsx CheckGardenServerContract.mts <server-root> <outbound-requests.json>');
const root = resolve(serverDirectory);
const requireServer = createRequire(join(root, 'package.json'));
const { Value } = requireServer('@sinclair/typebox/value');
const contractFile = join(root, 'apps/game-a-api/src/garden-contract.ts');
const contract = await import(pathToFileURL(contractFile).href);
const transcript = JSON.parse(readFileSync(transcriptPath, 'utf8'));
let requests = 0;
let mutations = 0;
for (const entry of transcript.entries) {
    const headers = { authorization: 'Bearer synthetic-contract-test', 'x-platform': 'android',
        'x-client-version': '1.0.0', 'x-product-id': entry.productId };
    if (entry.idempotencyKey) headers['idempotency-key'] = entry.idempotencyKey;
    if (!Value.Check(entry.method === 'POST' ? contract.GardenActionHeaders : contract.GardenHeaders, headers))
        throw new Error('SDK emitted invalid Garden headers for ' + entry.path);
    let schema;
    if (entry.path.endsWith('/start')) schema = contract.GardenStartBody;
    else if (entry.path.endsWith('/facts')) schema = contract.GardenFactsBody;
    else if (entry.path.endsWith('/sync')) schema = contract.GardenSyncBody;
    if (schema) {
        const body = JSON.parse(entry.bodyJson);
        if (!Value.Check(schema, body)) throw new Error('SDK body failed server schema: ' + entry.path);
        if (entry.path.endsWith('/sync') && body.operationId !== entry.idempotencyKey)
            throw new Error('Sync operation ID does not match header');
        for (const field of ['moves', 'win', 'rewards']) {
            if (Value.Check(schema, { ...body, [field]: [] })) throw new Error('Server schema accepted forbidden ' + field);
            mutations++;
        }
    }
    requests++;
}
if (requests < 6) throw new Error('Insufficient Garden request evidence');
console.log(JSON.stringify({ status: 'passed', requests, rejectedForbiddenFieldMutations: mutations,
    contractSha256: createHash('sha256').update(readFileSync(contractFile)).digest('hex'),
    transcriptSha256: createHash('sha256').update(readFileSync(transcriptPath)).digest('hex'),
    scope: 'read-only executable schema; no HTTP, migration or deployment' }));
