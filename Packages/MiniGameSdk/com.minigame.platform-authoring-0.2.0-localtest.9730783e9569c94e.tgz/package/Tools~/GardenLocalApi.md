> 历史版本说明：本文对应拆分前的 0.1.0 实现。新版 0.2.0 请从包 README 和 HostServiceComposition.md 接入；旧 Garden 客户端只保留为非编译迁移参考。

# Garden 本地契约 SDK 接入说明

日期：2026-09-29。本批是对已验证 `0.1.0-localtest.9c0abb961346a956` 的独立增量；旧 `-r2` 归档不覆盖。最终新归档的文件清单、哈希和本机验证结果见交付目录。

## 1. 契约来源和可用范围

按服务器当前本地契约实现，未连接或部署运行中的服务器：

| 来源 | SHA-256 |
| --- | --- |
| `D:/Project/MiniGameServer/apps/game-a-api/src/garden-contract.ts` | `0ea384c8af1e2a7fcfa95fcc866e3db47df30505cd9682701ea848d9f975b606` |
| `D:/Project/MiniGameServer/docs/garden-local-contract.md` | `d14c0a490ede2a6c586e79e26e32bf43fec4a07a68950cd5c47f7e5eb9c2655f` |
| `D:/Project/MiniGameServer/docs/fixtures/garden-local-v1.json` | `1fc3d7025f2b5ab0fe0192f454eef060525edbdfb80bc4593f97210fc3d97c9d` |

SDK 内保留同一合成 fixture 的只读副本 `Tests~/Garden/garden-local-v1.json`。其中哈希是占位值，不是实际关卡、回放、胜利或审核证据。

当前仅支持 `gameId=garden`、`garden_local_test / hub_local_test` 两个产品标签；服务端须运行 development/test 并完成对应本地配置，正式环境没有这些接口。productId 是来源标签，不代表可信产品认证，也不让两个游客自动合并。

本契约没有权威校验、结算、奖励或排行榜能力。已在线登录、开局成功、上传收妥、进度同步完成，均不代表游戏已验证通关。

## 2. 接口入口

新增 `GardenDataClient` 和专属 DTO，保留 Game A 原 DTO：

| SDK 方法 | HTTP | 返回 |
| --- | --- | --- |
| GetCapabilities | GET `/v1/games/garden/capabilities` | `ApiResult<GardenCapabilities>` |
| EnsureProfile | PUT `/v1/games/garden/profile`，无请求体 | `ApiResult<GardenProgress>` |
| GetProgress | GET `/v1/games/garden/progress` | `ApiResult<GardenProgress>` |
| StartSession | POST `/v1/games/garden/levels/garden.campaign.2/start` | `ApiResult<GardenSessionStart>` |
| SubmitFacts | POST `/v1/games/garden/sessions/{uuid}/facts` | `GardenFactsResult` |
| SyncReportedProgress | POST `/v1/games/garden/offline-progress/sync` | `ApiResult<GardenProgress>` |
| RetryPendingStart / RetryPendingFacts / RetryPendingSync | 使用已落盘原请求 | 对应类型 |

`GardenFactsResult` 特意没有 `IsSuccess` 或 `outcome`。只有 HTTP 202 且回执符合当前 session、关卡、事实数量及 capture-only 契约，`IsAcceptedUnverified` 才为 true。`IsVerifiedWin`、`RewardsGranted`、`LeaderboardUpdated` 始终为 false；错误回执不向调用方提供可用 Receipt。

`ApiResult<GardenSessionStart>.IsSuccess` 仅表示会话建立。进度响应中的 `reportedCompletedLevelIds` 仅为客户端申报集合，`verifiedCompletedLevelIds` 必须为空，不能据此生成权威解锁、首通奖励或排名。

Garden 的模块入口为 `host.Platform.Garden`；`host.Platform.Game` 和 `host.Platform.Leaderboard` 对 Garden 返回 null，避免误走 Game A 的 `int[] moves` 或未实现排行。`Wallet` 仍是平台共有钱包的读取入口，不会被 facts 回执更新。本 SDK 没有新增 Garden settle 方法。

## 3. 宿主和初始化

新 Lua 在线能力登记为 `garden_local_api`，最低宿主 API 3。模块定义、发布清单与真实宿主能力保持一致；API 2 旧宿主必须先更新，不能只改目录版本号。只使用原 `ReadDataText` 的模块仍可声明最低 API 2。

```json
{
  "minHostApiVersion": 3,
  "requiredCapabilities": ["lua", "data_text", "garden_local_api", "protected_content"]
}
```

上例只示意能力，保护字段、key ID、AssetBundle 等声明仍按模块实际需求补齐。若 Runner 将模块映射到服务端 garden，而模块未声明新能力，则拒绝该在线接入；纯离线模块不建立平台 facade 时不受此限制。

宿主 C# 使用已有 `PlatformSession` 完成登录，再初始化：

```csharp
var garden = new GardenDataClient(
    session,
    new GameContext("garden_local_test", "garden"),
    new FilePendingOperationStore());

garden.EnsureProfile(result => {
    if (!result.IsSuccess) { /* 按错误码展示或恢复登录 */ return; }
    // result.Data.progressVersion 用于下次请求；不是可自行递增的本地版本。
});
```

UnityApiTransport 继续发送平台、客户端版本和 Bearer 头，新增请求级 `X-Product-Id`。授权刷新与重放保留产品头、原始请求体和幂等键。拒绝非法产品头字符。

## 4. 请求构造和边界

- `GardenStartRequest`：contractVersion/ruleVersion 固定 1；expectedProgressVersion 来自 profile/progress；moduleVersion 为实际模块版本，两个 SHA-256 使用实际发布清单和基线。只接受试验关 `garden.campaign.2`。
- `GardenFactsRequest`：完整保留受支持事实；`GardenInputFact.Tap(sequence, boxId)` 或 `Advance(sequence, deltaSeconds)`。sequence 从 0 连续，1..4096 项；boxId 为正 int32；deltaSeconds 有限且 `0 < delta <= 1`。不能丢输入、合帧、截断或把其它输入伪装成这两类。
- SDK 自行按 fact 类型序列化，只输出 tap 的 boxId 或 advance 的 deltaSeconds，不会因共用 C# 对象而多发另一类型字段。浮点格式与系统语言无关。
- `GardenSyncRequest`：contractVersion=1，saveSchemaVersion=9，operationId 为 8..128 位合法幂等键，expectedProgressVersion 为最近服务端版本，completedLevelIds 仅接收 `garden.campaign.1`..`300` 的显式稳定 ID，最多 300 项且不重复。
- 同步会排序一份 ID 副本以固定请求，不改调用方数组；不推导历史 index、不迁移旧币/道具/钱包、不自动合并账号。游戏侧继续负责 schema 9 原档备份和稳定映射提取。
- 数字版本保留为 long，并限制在服务端安全整数范围；请求体上限 1 MiB。
- 服务端 JSON null 的 activeSessionId 在 Unity 中可能表现为空字符串，用 `GardenProgress.HasActiveSession` 判断，不用 null 判断。

请求请通过客户端方法提交，不要直接用 JsonUtility 序列化 `GardenInputFact[]` 后绕过适配器发送。

## 5. 幂等、错误与账号切换

复用既有 `IPendingOperationStore`。独立包与综合包各自使用本机持久化存储，按 `garden + userId` 隔离；同账号重新进入同一本机宿主仍能读取待发操作。不会跨设备共享本地队列。

三种写操作发送前保存 key、完整 body 和指纹。start/facts 自动生成 key；sync 使用 operationId 作为 header key。每个账号/game 的已有待发操作未解决时，拒绝提交不同操作或改动后的正文。重试必须使用相同 key 和正文，不能因超时生成新 key。

- 网络不确定、畸形回执或契约不匹配：保留待发记录，返回 retryable 或契约错误。不会把格式错误当成已完成。
- 登录/刷新失败：没有 Garden 最终回执，记录仍保留；先恢复登录，再显式重试，不按自动网络重试盲循环。
- `PROGRESS_VERSION_CONFLICT`：保留错误码作为确定失败，释放该待发槽。调用方重新读取服务端申报集合，按业务规则合并，再生成新的 operationId/expectedProgressVersion。SDK 不自动覆盖服务端进度。
- 正常 facts 202 回执：解除待发状态，仅显示“输入已收妥，尚未验证”，不推进游戏完成或资产到账。
- 账号切换：禁止旧请求在新身份下发送；旧响应返回 `ACCOUNT_CHANGED`，保留旧账号记录。旧 token 刷新或游客恢复回调不能覆盖新登录态。
- 延迟回调只有在存储中仍是同一个 key 和请求指纹时才删除记录，不删除替换操作。

服务端幂等保留期为 24 小时，超期后的回执恢复能力按服务端契约处理；SDK 不承诺原回执无限期可重放。回放返回的是原回执，不是当前最新进度快照，必要时再调用 GetProgress。

## 6. 验证与限制

Editor 检查入口：

```text
MiniGamePlatform.SDK.EditorChecks.SdkGardenChecks.Run
MiniGamePlatform.SDK.EditorChecks.SdkGardenChecks.RunRegression
```

前者验证 Garden 输入、输出、Lua callback、网络头、刷新、持久化、账号切换，并运行既有传输/账号/Game A 回归。后者额外运行宿主边界与原有六组保护回归；其中可信目录测试需平台的 `Assets/StreamingAssets/MiniGames` 样例。

测试会把使用合成数据的实际出站 body 写入 `Logs/sdk-garden/outbound-requests.json`，不包含 token。可在服务器已安装本地依赖的前提下，只读校验现有 TypeBox schema：

```powershell
node D:/Project/MiniGameServer/node_modules/tsx/dist/cli.mjs Packages/com.minigame.platform-sdk/Tools~/CheckGardenServerContract.mts D:/Project/MiniGameServer Logs/sdk-garden/outbound-requests.json
```

该命令不启动服务、不调用 HTTP、不连接数据库、不执行迁移。当前运行中的旧 API 不作为本批验收对象。

尚需真实服务器部署后的联调、真实第 2 关输入回放、独立壳/综合壳 Android 真机与 IL2CPP 验证。Editor Lua callback 通过不等同于裁剪后真机通过。模块退出期间的异步回调和 UI 恢复应随真实游戏宿主接线验收。

## 7. 第 2 关表现桥候选缺口（本批未开发）

本批只盘点平台现有桥接与服务器契约，未全量审查实际第 2 关 Prefab/场景。现有桥只有基本 Prefab 生成、示例 2D/3D 展示、文本读取及回调登记；以下需由游戏侧给出实际依赖清单后确定最小扩展：

1. 点击/触摸命中到稳定 boxId 的输入路由，遮挡与 UI 屏蔽规则，以及退出时统一解绑。
2. 关卡实体、路径/身体轨迹、槽位的表现更新，动态对象复用和回收；不能将影响模拟的可见性或槽位就绪变化藏在表现层。
3. UGUI 关卡状态、暂停/恢复和错误返回界面；表现动画与确定性 simulation tick 的职责分开。
4. 实际 Prefab 所用组件/Shader 的宿主保留清单；现有白名单不代表已支持任意 Animator、LineRenderer、SkinnedMeshRenderer 等组件。
5. 调参后的初始状态、随机来源和真实输入顺序。当前 tap/advance 不能表达的可见性、道具、复活和广告资格，应先扩展客户端与服务端契约，不能绕过或静默丢弃。

这些是后续接入检查项，不是本包已经具备的第 2 关完整运行能力。
