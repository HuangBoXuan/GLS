# Android xLua local 16KB rebuild

The original ABI pair comes from the internal BALL package `com.yoozoo.managers.xlua@0.1.9-preview`. Its ARM64 library had LOAD alignment 0x4000, but GNU_RELRO ended at 0xE2000 (16KB remainder 0x2000). The old source CMake only supplied max-page-size. [Android's current guidance](https://developer.android.com/guide/practices/page-sizes#compile-16-kb-alignment) requires both max-page-size and common-page-size for NDK r27 and lower, and checks `(VirtAddr + MemSiz) % 0x4000` for RELRO.

Both libraries were recompiled from the existing BALL `BuildXLua/build` source, commit `dfb3f75defb0593bc00f628d83d41513577733d6`. The source tree was read-only. `XLuaAndroidBuildInputs.json` pins the 156 reviewed source inputs and each original ABI's full defined GLOBAL/WEAK DEFAULT export fingerprint. `XLuaAndroidBuildProvenance.json` records the actual compiler/build settings and output hashes. No original license was changed.

- NDK r23b (`23.1.7779620`), Clang/LLD 12.0.8; CMake 3.31.6; Ninja 1.11.1.
- Lua 5.4.8, `LUA54_OBFUSCATE=ON`, xLua native API 105, Android API 21, `c++_static`, RelWithDebInfo; existing LuaSocket, FFI, protobuf and rapidjson retained.
- `ANDROID_USE_LEGACY_TOOLCHAIN_FILE=ON` explicitly retains the original NDK defaults and all exports with newer CMake. The newer default toolchain omitted an internal rapidjson weak export during the first validation; that candidate was rejected and never installed.
- Link flags: `-Wl,--build-id=sha1 -Wl,--rosegment -Wl,-z,max-page-size=16384 -Wl,-z,common-page-size=16384`. Explicit rosegment preserves the original separation of read-only and executable LOAD segments despite the legacy NDK default.
- ARM64 SHA256: `817e9bb507241b7fa102c6b78f2a327b5b131bae4cde098bd40f9bcb29c4e0b2`; 915 unchanged exports; 4 aligned LOADs and 1 aligned GNU_RELRO.
- ARMv7 SHA256: `93f11ac952eba761c3928849e01acb0f1ff954bd538604d73bc7a412927802b5`; 920 unchanged exports; 4 aligned LOADs and 1 aligned GNU_RELRO.
- Native dependencies remain exactly `libc.so`, `libdl.so`, `libm.so`. Source/build path prefix maps make independent fresh build directories produce identical `.so` hashes. Debug files stay in ignored `Builds` directories.

From the TapGarden project directory, use the following commands (the source and tools are external build prerequisites; a checkout of the consumer SDK does not itself include the internal BALL native sources):

```powershell
python -m pip install --target Builds/XLuaBuildTools cmake==3.31.6 ninja==1.11.1.3
./Tools/RuleTests/Rebuild-XLuaAndroid.ps1 -SourceRoot E:/BALL/ballclient/BuildXLua/build -NdkRoot D:/Unity2022.3.25/2022.3.76f1/Editor/Data/PlaybackEngines/AndroidPlayer/NDK -CMake ./Builds/XLuaBuildTools/cmake/data/bin/cmake.exe -Ninja (Join-Path (Get-Location) Builds/XLuaBuildTools/bin/ninja.exe) -OutputDirectory (Join-Path (Get-Location) Builds/XLuaAndroid16KB-new)
./Tools/RuleTests/Install-XLuaAndroidOverlay.ps1 -BuildDirectory ./Builds/XLuaAndroid16KB-new -ReadElf D:/Unity2022.3.25/2022.3.76f1/Editor/Data/PlaybackEngines/AndroidPlayer/NDK/toolchains/llvm/prebuilt/windows-x86_64/bin/llvm-readelf.exe
./Packages/com.minigame.platform-authoring/Tools~/VerifyXLuaAndroidAbis.ps1 -ReadElf D:/Unity2022.3.25/2022.3.76f1/Editor/Data/PlaybackEngines/AndroidPlayer/NDK/toolchains/llvm/prebuilt/windows-x86_64/bin/llvm-readelf.exe
./Tools/RuleTests/check-sdk-git-roundtrip.ps1
```

The installer verifies both staged ABIs before replacing the current project's two Android binaries and backs up the prior binaries and SDK metadata under `Builds/XLuaRollback`. Unity plugin `.meta` files are retained. The original delivery version, `sourceFiles`, source-set identity and archive hashes still describe the original immutable SDK delivery. The installed file hashes and a separate `localOverrides`/`installedSnapshotSha256` identify this consumer-local patch. It is not a newly published SDK artifact; a later full SDK delivery should be exported by the platform project and imported with `Import-SplitSdk.ps1` (the API5 `Import-FixedSdk.ps1` cannot import this API7 layout).

Static verification is not an Android run. No APK/AAB was built for this change, so APK ZIP alignment and final dependency packaging are unverified. Android 16KB device validation still needs `adb shell getconf PAGE_SIZE` = 16384, Lua startup, managed callbacks, modules, gameplay and memory checks. `androidDeviceVerified` remains false. Existing third-party source emits its original compiler warnings (Lua tmpnam, protobuf macro, FFI casts/alignment and rapidjson diagnostics); those sources were not modified.
