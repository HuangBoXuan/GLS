> 0.2.0：这些通用服务属于核心 SDK；测试广告驱动只属于开发支持。游戏业务通过本游戏范围 Requests 传递，装配方式见 HostServiceComposition.md。

# 共用宿主服务接入

SDK 契约位于 `Runtime/Contracts/IModuleHostServices.cs`，实现位于 `Runtime/Host`。本阶段仍在一个物理包内交付，代码职责已经分层，后续可独立拆包。小游戏通过 `host.Services` 使用稳定接口；旧工厂没有装配时该属性为空。不能仅凭 SDK 版本推断账号和广告已经配置。

## 宿主接线

综合包与独立包使用同样的装配。一个产品宿主创建并持有一套 `HostMainThreadQueue`、`HostAdBroker`、`AtomicLocalStore` 和 `CommonModulePlatformFactory`，将工厂交给 `ModulePlayer` 或 `ModulePlayerBehaviour.InitializeWithHost`。每帧在 Unity 主线程调用队列 `Drain()`，不能为每个游戏各建一个广告 broker，否则失去跨游戏全屏互斥。会话操作及服务调用也在主线程进行。

可运行参考是 `Samples~/SharedRuntimeHost/SharedModuleShell.cs`；平台自身 `HotUpdateDemo` 也使用相同接线。两者默认广告驱动为空，明确报告广告不可用。测试驱动只供 Editor／Development Player 显式装配，不能用于正式包。真实广告驱动由宿主后续接入，负责把 `(gameId, placement, format)` 映射到发行方真实广告配置。

存档根目录由宿主配置。测试／正式环境必须用不同根目录；替换整个 PlatformSession 对象前，宿主须退出原模块，再用新会话重入。后台线程的网络适配器必须先把会话回调调度回主线程。

## Lua 用法

```lua
local services = host.Services
assert(services ~= nil and services.Account.IsAvailable)
local userId = services.Account.UserId -- 不包含任何凭据
local previous = services.Storage:Read('progress') -- 不存在时为 nil
services.Storage:Write('progress', '{"level":12}')
-- services.Storage:Delete('progress')

local onInvalidated = function()
    -- 旧句柄已经不可用，由游戏停止相关操作，由宿主安排重入。
end
services.Account:Invalidated('+', onInvalidated)

if services.Ads.IsAvailable then
    local requestId = services.Ads:Show('continue', 'rewarded', function(json)
        -- JSON 字段：requestId、status、isTest、error。
        -- completed 不是服务器奖励证明，不能直接增加共有钱包。
    end)
end
```

存档的 key/value 为字符串，JSON 和版本迁移由游戏管理。账号／gameId 由宿主绑定，游戏不传其他账号或磁盘路径。账号、gameId、key 组成无歧义的元组，联合 SHA256 后形成一个文件名，避免叠加两层长哈希路径。空 key、空值、失效句柄或 I/O 故障抛出异常，可用 Lua `pcall` 捕获；不存在的文件返回 nil，文件存在但读失败会报错，不能把所有读取异常都当作“新玩家”。

同账号同游戏重入能读取本设备存档。本地文件不会跨 Android 应用沙箱共享，也不代表云端已同步；跨包进度共享仍走服务器。原子保存采用同目录临时文件、Flush 和替换，提交失败保留旧值；它不保证设备断电后的目录元数据持久化，也不支持绕过宿主的多进程并发写入。

成功显式登录、绑定或退出会使旧服务句柄失效，A→B→A 不会复活旧句柄。正常 token 刷新及其同账号凭据恢复保留身份代次。模块退出时清除账号事件与广告 Lua 回调，Lua exit 可以在服务销毁前做最后一次存档。游戏提前订阅／解绑账号事件可用相同函数的 `Invalidated('-', onInvalidated)`。

广告类型首期支持 `rewarded`、`interstitial`。`IsAvailable` 只表示已配置驱动且当前账号可用，不保证广告已加载。结果为 `completed/canceled/failed/not_ready/busy`，主线程异步投递，单请求最多一次；请求发生后退出或换账号不会投递旧回调。原生广告尚未关闭时，全屏占用继续保持。宿主驱动必须在真实关闭后报终态；不得仅因奖励回调到达就释放占用，也不得在已打开广告后抛出异常而不管理关闭。

## 可选时序与相机事件

模块声明 `lua_late_update_v1` 可用 `late_update(dt)`；最低 host API 5。ModulePlayerBehaviour 自动由 Unity LateUpdate 调用，手工宿主在自己的 LateUpdate 调用 `player.LateTick()`。暂停／退出不调用该生命周期，异常会退出并报告 `LATE_UPDATE_FAILED`。旧模块无需新增该函数。

声明 `unity_camera_callback_v1` 可使用静态 AOT 签名 `Camera.CameraCallback`。相机事件属于 Unity 全局事件，游戏负责保存同一个委托，并在 exit 中解绑；暂停是否屏蔽回调由游戏判断。宿主不会自动接管游戏创建的 CommandBuffer、Material 或相机事件。常规 Animator 更新完成后的调整可放 late_update；自定义 Animator 手动更新的顺序仍由游戏管理。

```lua
local callback = CS.UnityEngine.Camera.CameraCallback(function(camera)
    -- 按游戏相机和暂停状态筛选。
end)
if CS.UnityEngine.Camera.onPreCull == nil then
    CS.UnityEngine.Camera.onPreCull = callback
else
    CS.UnityEngine.Camera.onPreCull = CS.UnityEngine.Camera.onPreCull + callback
end
-- exit 中使用同一委托：
CS.UnityEngine.Camera.onPreCull = CS.UnityEngine.Camera.onPreCull - callback
callback = nil
```

这些接口面向可信、经审核的 Lua 模块；xLua 的 CS 访问不是安全沙箱。
