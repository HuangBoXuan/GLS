# UGUI 通用转接与 Localization 宿主基线

本批新增的是 Unity/Lua 运行底座能力。游戏仍定义自己的顶点、形状、颜色、材质、纹理与翻译内容；这里不提供游戏表现算法。旧 R4 与第一阶段宿主装配包不具备这些新能力，使用前必须更新宿主应用。

## 能力声明

新模块按实际使用增加 `requiredCapabilities`，`minHostApiVersion` 仍为 5：

- `unity_ugui_mesh_v1`：`MiniGamePlatform.Components.ModuleMeshGraphic`。
- `unity_ugui_raycast_v1`：`MiniGamePlatform.Components.ModuleRaycastFilter`，静态 xLua `Func<Vector2, Camera, bool>`。
- `unity_localization_1_4_4`：Localization 1.4.4 原生依赖与 SmartFormatter 命名参数基线。

旧模块无需添加这些声明，继续按原接口运行；不能把它们合并解释成旧 `unity_native_v1` 已经具备的能力。

## Mesh Graphic

```lua
local graphic = object:GetComponent(typeof(CS.MiniGamePlatform.Components.ModuleMeshGraphic))
graphic.Mesh = gameMesh
graphic.Texture = gameTexture
graphic.material = gameMaterial
-- 游戏原地修改同一个 Mesh 后，主动标记需要重建。
graphic:SetVerticesDirty()
```

组件继承 MaskableGraphic，通过原生 VertexHelper 填充几何；保留 Graphic 网格修改器、Mask 模板材质和 RectMask2D 裁剪。网格坐标为 Graphic 局部坐标，颜色为网格顶点色乘 Graphic.color，缺少顶点色按白色处理；UV0–3、法线、切线按网格数据传递，Canvas 的附加通道仍由游戏按 Shader 需求设置。

游戏的 RectTransform 应包含实际网格范围；UGUI 的射线初筛与 RectMask2D 粗剔除依据 RectTransform，不依据 Mesh.bounds。默认启用 VertexHelper 重建路径，原生 Shadow 等 IMeshModifier 继续参与渲染。

技术边界沿用 UGUI：CPU 可读网格、单个三角形 submesh、少于 65000 个顶点、每个 Graphic 一个材质。多材质请使用多个 Graphic；不能静默丢弃其他 submesh。Shadow 等后续网格修改器扩增后的顶点数也要满足 UGUI 限制。这些是原生渲染接口限制，不是美术规则。

Mesh/Texture/Material 均为借用引用，组件不会替游戏销毁资源。赋 `Mesh=nil` 清空几何；调用方在退出时解除引用并释放自己动态创建的资源。材质要支持所需的 UGUI 遮罩/裁剪协议；不改写自定义 Shader、不强制颜色或样式。

## 射线筛选

```lua
local filter = object:GetComponent(typeof(CS.MiniGamePlatform.Components.ModuleRaycastFilter))
filter.Filter = function(screenPoint, eventCamera)
    return gameHitTest(screenPoint, eventCamera)
end
-- 退出时解除 Lua 回调；不要等 LuaEnv 已关闭才清理。
filter.Filter = nil
```

UGUI 通过 ICanvasRaycastFilter 取得同步 bool 结果。无回调或组件禁用时不额外阻挡，仍由其他原生过滤器判断；回调抛异常时记录错误并拒绝本次射线。暂停禁用不会删除回调，销毁会清除引用。模块仍须主动解绑，跨帧销毁遵守 HasPendingExit，不能强行关闭仍被引用的 Lua 环境。

## Localization 安装与边界

当前 Unity 2022.3.76f1 安装的内置 registry 规则把 Localization 的最低版本设为 1.5.2；只写 `"com.unity.localization": "1.4.4"` 仍会被提升。宿主采用 Unity 官方原始 `com.unity.localization-1.4.4.tgz` 固定依赖，交付目录另附这个原封不动的包及来源/哈希，不修改 Unity 安装。

将该 tgz 放到工程根 `HostDependencies/`，在 `Packages/manifest.json` 中声明 `"com.unity.localization": "file:../HostDependencies/com.unity.localization-1.4.4.tgz"`，并保留各工程自己的依赖锁文件。SDK 的 registry 依赖声明只提供传递依赖，不能代替本轮精确版本固定。编译时按实际安装版本决定是否声明本基线；其他版本不能冒充本批验证结果。后续升级到 1.5.2 或其他版本应作为单独的宿主兼容验证。

Lua 直接使用 Unity 的 `Smart.CreateDefaultSmartFormat()` 和 `Dictionary<string, object>`，没有另加字符串格式化业务接口。提供闭合泛型 AOT 引用及 UnityLinker 保留。调用形如 `fmt:Format(culture, '{name}: {count:0}', values)`，由 xLua 收集可变参数，不要额外包一层 object[]。支持具体样例中的数字、复数与条件格式；不承诺任意反射对象或任意泛型在 AOT 下均可用。

本批不会自动注册各游戏的 Addressables 目录、切换全局 LocalizationSettings 或替游戏卸载翻译表。完整语言切换和资源目录生命周期仍需游戏与宿主联调；SmartFormatter 测试不能代表这些业务流程已验收。任意游戏专属 C# formatter/source 也不能作为资源下载到旧宿主执行，应迁为游戏 Lua 或另行审查通用原生能力。

版本宏采用 Unity Assembly Definition 的 Version Defines；区间与精确版本语义参见 [Unity 官方说明](https://docs.unity.cn/Manual/ScriptCompilationAssemblyDefinitionFiles.html)。
