using System;

namespace MiniGamePlatform.SDK.Auth
{
    // Editor-only behavior: a new process has a new store. Never use for a release player.
    public sealed class EditorMemoryCredentialStore : ICredentialStore
    {
        private CredentialState _state;

        public void Save(CredentialState state)
        {
            _state = state == null ? throw new ArgumentNullException(nameof(state)) : state.Copy();
        }

        public bool TryLoad(out CredentialState state)
        {
            state = _state?.Copy();
            return state != null;
        }

        public void Clear() { _state = null; }
    }
}
