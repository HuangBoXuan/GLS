#if UNITY_EDITOR_WIN
using System;
using System.IO;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using UnityEngine;

namespace MiniGamePlatform.SDK.Auth
{
    /// <summary>Windows Editor credentials protected for the current OS user; never compiled into a player.</summary>
    public sealed class WindowsEditorCredentialStore : ICredentialStore
    {
        [StructLayout(LayoutKind.Sequential)]
        private struct DataBlob
        {
            public int Length;
            public IntPtr Data;
        }

        [DllImport("crypt32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool CryptProtectData(ref DataBlob input, string description, IntPtr entropy,
            IntPtr reserved, IntPtr prompt, int flags, out DataBlob output);

        [DllImport("crypt32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool CryptUnprotectData(ref DataBlob input, IntPtr description, IntPtr entropy,
            IntPtr reserved, IntPtr prompt, int flags, out DataBlob output);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr LocalFree(IntPtr memory);

        private const int UiForbidden = 0x1;
        private readonly string _path;

        public WindowsEditorCredentialStore(string path)
        {
            if (string.IsNullOrWhiteSpace(path) || !Path.IsPathRooted(path))
                throw new ArgumentException("An absolute credential path is required.", nameof(path));
            _path = Path.GetFullPath(path);
        }

        public static string DefaultPath(string productId, string apiBaseUrl)
        {
            if (string.IsNullOrWhiteSpace(productId) || string.IsNullOrWhiteSpace(apiBaseUrl))
                throw new ArgumentException("Product and API origin are required for credential isolation.");
            string scope = Path.GetFullPath(Path.Combine(Application.dataPath, "..")) + "\n" +
                productId + "\n" + apiBaseUrl.TrimEnd('/');
            byte[] digest;
            using (var sha = SHA256.Create()) digest = sha.ComputeHash(Encoding.UTF8.GetBytes(scope));
            string name = BitConverter.ToString(digest).Replace("-", "").ToLowerInvariant() + ".bin";
            return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "MiniGamePlatform", "EditorCredentials", name);
        }

        public void Save(CredentialState state)
        {
            if (state == null) throw new ArgumentNullException(nameof(state));
            string directory = Path.GetDirectoryName(_path);
            Directory.CreateDirectory(directory);
            byte[] plaintext = Encoding.UTF8.GetBytes(JsonUtility.ToJson(state));
            byte[] ciphertext;
            try { ciphertext = Protect(plaintext, false); }
            finally { Array.Clear(plaintext, 0, plaintext.Length); }
            string temporary = _path + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                File.WriteAllBytes(temporary, ciphertext);
                if (File.Exists(_path)) File.Replace(temporary, _path, null);
                else File.Move(temporary, _path);
            }
            finally
            {
                Array.Clear(ciphertext, 0, ciphertext.Length);
                if (File.Exists(temporary)) File.Delete(temporary);
            }
        }

        public bool TryLoad(out CredentialState state)
        {
            state = null;
            if (!File.Exists(_path)) return false;
            byte[] plaintext = null;
            try
            {
                plaintext = Protect(File.ReadAllBytes(_path), true);
                CredentialState loaded = JsonUtility.FromJson<CredentialState>(Encoding.UTF8.GetString(plaintext));
                if (loaded == null || string.IsNullOrWhiteSpace(loaded.DeviceId))
                    throw new InvalidDataException("Stored credential state is incomplete.");
                state = loaded;
                return true;
            }
            catch (Exception error) when (error is CryptographicException || error is ArgumentException ||
                error is InvalidDataException)
            {
                throw new InvalidOperationException("Encrypted Editor credentials could not be restored.", error);
            }
            finally { if (plaintext != null) Array.Clear(plaintext, 0, plaintext.Length); }
        }

        public void Clear()
        {
            if (File.Exists(_path)) File.Delete(_path);
        }

        private static byte[] Protect(byte[] bytes, bool decrypt)
        {
            if (bytes == null || bytes.Length == 0)
                throw new CryptographicException("Credential payload is empty.");
            var input = new DataBlob { Length = bytes.Length, Data = Marshal.AllocHGlobal(bytes.Length) };
            DataBlob output = default(DataBlob);
            try
            {
                Marshal.Copy(bytes, 0, input.Data, bytes.Length);
                bool succeeded = decrypt
                    ? CryptUnprotectData(ref input, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero,
                        UiForbidden, out output)
                    : CryptProtectData(ref input, null, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero,
                        UiForbidden, out output);
                if (!succeeded)
                    throw new CryptographicException("Windows credential protection failed.",
                        new Win32Exception(Marshal.GetLastWin32Error()));
                if (output.Length <= 0 || output.Data == IntPtr.Zero)
                    throw new CryptographicException("Windows credential protection returned empty data.");
                byte[] result = new byte[output.Length];
                Marshal.Copy(output.Data, result, 0, result.Length);
                return result;
            }
            finally
            {
                Marshal.Copy(new byte[bytes.Length], 0, input.Data, bytes.Length);
                Marshal.FreeHGlobal(input.Data);
                if (output.Data != IntPtr.Zero)
                {
                    if (output.Length > 0)
                        Marshal.Copy(new byte[output.Length], 0, output.Data, output.Length);
                    LocalFree(output.Data);
                }
            }
        }
    }
}
#endif
