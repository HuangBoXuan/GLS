using System;
using UnityEngine;
namespace MiniGamePlatform.SDK.Host
{
    public sealed class LocalTestAdDriver : IHostAdDriver
    {
        private Action<string, string> _terminal;
        public bool IsTest => true;
        public bool Ready { get; set; } = true;
        public LocalTestAdDriver()
        {
            if (!Application.isEditor && !Debug.isDebugBuild)
                throw new InvalidOperationException("Local test ads require an Editor or development player.");
        }
        public bool IsReady(string gameId, string placement, string format) => Ready && _terminal == null;
        public void Show(string requestId, string gameId, string placement, string format, Action<string, string> terminal)
        {
            if (_terminal != null) throw new InvalidOperationException("Test fullscreen already open.");
            _terminal = terminal;
        }
        public void Complete() { Finish("completed", null); }
        public void Cancel() { Finish("canceled", null); }
        public void Fail(string error) { Finish("failed", error); }
        private void Finish(string status, string error)
        { var callback = _terminal; _terminal = null; callback?.Invoke(status, error); }
    }
}
