# Focused Bouncy Castle binary

Same focused AES-GCM/Ed25519 binary used by TapGarden; not the general-purpose upstream assembly.

- Upstream version: 2.7.0, netstandard2.0, MIT (LICENSE.md).
- Focused DLL SHA256: `4367d033a374883ef902419f9c7075a22d852f079828bf49e35b3cd10ca4524b`.
- Original NuGet SHA256: `f091ffccab4d03993e660bace277659a79dee0972f54d7f1f4bd46d680966241`.
- Algorithms are upstream; this is a locally trimmed, not upstream signed, distribution.

When importing this SDK into an existing project that already includes BouncyCastle.Cryptography.dll, keep exactly one compatible assembly. TapGarden currently still uses its existing DLL; SDK import must reconcile the duplicate (do not ship both). No SDK dependency upgrade is implied.

ModuleProtectedEnvelope reuses the existing WPC1 authenticated envelope implementation. Module AAD additionally binds game/version/keyId/path. This does not make old native-key resources directly loadable as a platform module; rebuild content under the new context.
