using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.Scripting;

namespace XLua
{
    // Explicit closed method references compile these signatures for IL2CPP.
    // This is a callback binding baseline, not a replacement for Unity components.
    [Preserve]
    public partial class DelegateBridge
    {
        static DelegateBridge() { Gen_Flag = true; }

        [Preserve]
        public override Delegate GetDelegateByType(Type type)
        {
            if (type == typeof(UnityAction)) return new UnityAction(Action);
            if (type == typeof(Camera.CameraCallback)) return new Camera.CameraCallback(Action<Camera>);
            if (type == typeof(UnityAction<bool>)) return new UnityAction<bool>(Action<bool>);
            if (type == typeof(UnityAction<int>)) return new UnityAction<int>(Action<int>);
            if (type == typeof(UnityAction<float>)) return new UnityAction<float>(Action<float>);
            if (type == typeof(UnityAction<string>)) return new UnityAction<string>(Action<string>);
            if (type == typeof(UnityAction<Vector2>)) return new UnityAction<Vector2>(Action<Vector2>);
            if (type == typeof(UnityAction<Vector3>)) return new UnityAction<Vector3>(Action<Vector3>);
            if (type == typeof(UnityAction<Color>)) return new UnityAction<Color>(Action<Color>);
            if (type == typeof(UnityAction<PointerEventData>)) return new UnityAction<PointerEventData>(Action<PointerEventData>);
            if (type == typeof(UnityAction<BaseEventData>)) return new UnityAction<BaseEventData>(Action<BaseEventData>);
            if (type == typeof(System.Action)) return new System.Action(Action);
            if (type == typeof(Action<bool>)) return new Action<bool>(Action<bool>);
            if (type == typeof(Action<int>)) return new Action<int>(Action<int>);
            if (type == typeof(Action<float>)) return new Action<float>(Action<float>);
            if (type == typeof(Action<string>)) return new Action<string>(Action<string>);
            if (type == typeof(Action<Vector2>)) return new Action<Vector2>(Action<Vector2>);
            if (type == typeof(Action<Vector3>)) return new Action<Vector3>(Action<Vector3>);
            if (type == typeof(Action<Color>)) return new Action<Color>(Action<Color>);
            if (type == typeof(Func<bool>)) return new Func<bool>(Func<bool>);
            if (type == typeof(Func<int>)) return new Func<int>(Func<int>);
            if (type == typeof(Func<float>)) return new Func<float>(Func<float>);
            if (type == typeof(Func<string>)) return new Func<string>(Func<string>);
            if (type == typeof(Func<Vector2, Camera, bool>)) return new Func<Vector2, Camera, bool>(Func<Vector2, Camera, bool>);
            return null;
        }
    }
}
