/*
 * Lua->C# 跨语言调用频率计数器（dev 工具）
 * 全程常开、低开销：在 Utils.RegisterFunc 注册时给每个 LuaCSFunction 包一层计数 trampoline，
 * 运行期每次调用只多一次「按索引自增」。IL2CPP 安全：trampoline 是 static + [MonoPInvokeCallback]，
 * 真实函数存托管 List、由 trampoline 按 upvalue 索引取回调用（仿 XLua FixCSFunction 手法），
 * 永不对闭包做 Marshal.GetFunctionPointerForDelegate。
 * 由 XLUA_CALL_COUNTER 编译符号控制；不定义时全部为空壳，对正式包零影响。
 */
using System.Collections.Generic;

#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLuaBase.lua_CSFunction;
#endif

namespace XLua
{
    public static class LuaCSCallCounter
    {
        // 计数总开关（运行期可切）。定义 XLUA_CALL_COUNTER 即 dev 专用，默认常开以统计整局；
        // 需暂停用 lua_cs_enable {"on":false}
        public static bool Enabled = true;

#if XLUA_CALL_COUNTER
        // ── gen wrap 路径（占 ~90%）：注册时分配索引，运行期 trampoline 按索引自增，零字典查找 ──
        private static readonly List<LuaCSFunction> s_originals = new List<LuaCSFunction>(1024);
        private static readonly List<string> s_labels = new List<string>(1024);
        private static int[] s_counters = new int[1024];

        // ── 反射 / 委托路径（低频）：字符串键聚合 ──
        private static readonly Dictionary<string, int[]> s_named = new Dictionary<string, int[]>(64);

        // 注册时调用（主线程、启动期/懒注册），返回该条目索引
        internal static int RegisterEntry(string label, LuaCSFunction original)
        {
            int idx = s_originals.Count;
            s_originals.Add(original);
            s_labels.Add(label);
            if (idx >= s_counters.Length)
            {
                int[] bigger = new int[s_counters.Length * 2];
                System.Array.Copy(s_counters, bigger, s_counters.Length);
                s_counters = bigger;
            }
            return idx;
        }

        // 静态 trampoline：IL2CPP 反向 P/Invoke 要求 static + [MonoPInvokeCallback]
        [MonoPInvokeCallback(typeof(LuaCSFunction))]
        private static int Trampoline(RealStatePtr L)
        {
            int idx = LuaAPI.xlua_tointeger(L, LuaAPI.xlua_upvalueindex(1));
            if (Enabled && (uint)idx < (uint)s_counters.Length)
            {
                s_counters[idx]++;
            }
            return s_originals[idx](L);
        }

        // 复用同一个 trampoline delegate（Marshal 只生成一个固定函数指针，靠 upvalue 索引区分）
        internal static readonly LuaCSFunction TrampolineDelegate = new LuaCSFunction(Trampoline);

        // 反射/委托路径计数（StaticLuaCallbacks.FixCSFunction / DelegateCall 调用）
        internal static void CountNamed(string label)
        {
            if (!Enabled) return;
            int[] slot;
            if (!s_named.TryGetValue(label, out slot))
            {
                slot = new int[1];
                s_named[label] = slot;
            }
            slot[0]++;
        }

        public static string DumpTop(int topN)
        {
            var all = new List<KeyValuePair<string, int>>(s_originals.Count + s_named.Count);
            for (int i = 0; i < s_originals.Count; i++)
            {
                if (s_counters[i] > 0)
                {
                    all.Add(new KeyValuePair<string, int>(s_labels[i], s_counters[i]));
                }
            }
            foreach (var kv in s_named)
            {
                if (kv.Value[0] > 0)
                {
                    all.Add(new KeyValuePair<string, int>(kv.Key, kv.Value[0]));
                }
            }
            all.Sort((a, b) => b.Value.CompareTo(a.Value));

            long total = 0;
            for (int i = 0; i < all.Count; i++) total += all[i].Value;

            var sb = new System.Text.StringBuilder(8192);
            sb.AppendLine("=== Lua->C# 调用频率 Top" + topN + "  唯一=" + all.Count + "  总次数=" + total + " ===");
            int n = topN < all.Count ? topN : all.Count;
            for (int i = 0; i < n; i++)
            {
                sb.AppendLine(string.Format("{0,10}  {1}", all[i].Value, all[i].Key));
            }
            return sb.ToString();
        }

        public static void ResetCounters()
        {
            System.Array.Clear(s_counters, 0, s_counters.Length);
            foreach (var kv in s_named) kv.Value[0] = 0;
        }
#else
        // 空壳：未定义 XLUA_CALL_COUNTER 时供 FileSignal 命令编译通过
        public static string DumpTop(int topN) { return "未启用（需定义 XLUA_CALL_COUNTER 编译符号）"; }
        public static void ResetCounters() { }
#endif
    }
}
