using System;

namespace XLua
{
    // Replaces BALL's ResourceManagerV2 buffer so its Lua runtime can be used alone.
    public sealed class ModuleLuaBuffer
    {
        public byte[] Bytes { get; private set; }
        public int Length { get; private set; }

        public ModuleLuaBuffer(int initialCapacity)
        {
            Bytes = new byte[Math.Max(initialCapacity, 1)];
        }

        public void Copy(byte[] source)
        {
            if (source == null)
            {
                throw new ArgumentNullException(nameof(source));
            }

            if (Bytes.Length < source.Length)
            {
                Bytes = new byte[source.Length];
            }

            Buffer.BlockCopy(source, 0, Bytes, 0, source.Length);
            Length = source.Length;
        }
    }
}
