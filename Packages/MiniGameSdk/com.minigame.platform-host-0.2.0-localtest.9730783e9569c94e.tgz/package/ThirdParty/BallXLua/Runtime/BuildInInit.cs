using XLuaBase;

namespace XLua.LuaDLL
{
    public partial class Lua
    {
        public static int luaopen_rapidjson(System.IntPtr L)
        {
            return XLuaBase.Lua.luaopen_rapidjson(L);
        }

        [MonoPInvokeCallback(typeof(lua_CSFunction))]
        public static int LoadRapidJson(System.IntPtr L)
        {
            return luaopen_rapidjson(L);
        }
        
        public static int luaopen_lpeg(System.IntPtr L)
        {
            return XLuaBase.Lua.luaopen_lpeg(L);
        }

        [MonoPInvokeCallback(typeof(lua_CSFunction))]
        public static int LoadLpeg(System.IntPtr L)
        {
            return luaopen_lpeg(L);
        }
        
        
        [MonoPInvokeCallback(typeof(lua_CSFunction))]
        public static int LoadLuaProfobuf(System.IntPtr L)
        {
            return XLuaBase.Lua.luaopen_pb(L);
        }
        //是LuaProfobufBuffer的Buffer访问库
        [MonoPInvokeCallback(typeof(lua_CSFunction))]
        public static int LoadLuaProfobufBuffer(System.IntPtr L)
        {
            return  XLuaBase.Lua.luaopen_pb_buffer(L);
        }
    }
}
