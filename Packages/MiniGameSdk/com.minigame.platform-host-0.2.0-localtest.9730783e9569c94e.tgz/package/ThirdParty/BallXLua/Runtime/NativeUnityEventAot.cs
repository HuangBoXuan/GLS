using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.Scripting;

namespace XLua
{
    [Preserve]
    internal static class NativeUnityEventAot
    {
        // Linker-preserved static references compile generic UnityEvent method bodies.
        // Never called during gameplay. Unknown signatures remain outside this baseline.
        [Preserve]
        private static void ClosedSignatures()
        {
            Keep(new UnityEvent<bool>(), default(bool));
            Keep(new UnityEvent<int>(), default(int));
            Keep(new UnityEvent<float>(), default(float));
            Keep(new UnityEvent<string>(), default(string));
            Keep(new UnityEvent<Vector2>(), default(Vector2));
            Keep(new UnityEvent<Vector3>(), default(Vector3));
            Keep(new UnityEvent<Color>(), default(Color));
            Keep(new UnityEvent<PointerEventData>(), default(PointerEventData));
            Keep(new UnityEvent<BaseEventData>(), default(BaseEventData));
        }
        private static void Keep<T>(UnityEvent<T> evt, T value)
        {
            UnityAction<T> callback = Ignore;
            evt.AddListener(callback); evt.Invoke(value); evt.RemoveListener(callback);
        }
        private static void Ignore<T>(T value) { }
    }
}
