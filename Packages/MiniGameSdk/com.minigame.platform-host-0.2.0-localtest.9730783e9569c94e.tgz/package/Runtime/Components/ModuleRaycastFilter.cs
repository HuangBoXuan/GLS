using System;
using UnityEngine;
using UnityEngine.Scripting;

namespace MiniGamePlatform.Components
{
    [Preserve, DisallowMultipleComponent]
    [UnityEngine.Scripting.APIUpdating.MovedFrom(true, null, "MiniGamePlatform.SDK", null)]
    public sealed class ModuleRaycastFilter : MonoBehaviour, ICanvasRaycastFilter
    {
        public Func<Vector2, Camera, bool> Filter { get; set; }
        public bool IsRaycastLocationValid(Vector2 screenPoint, Camera eventCamera)
        {
            if (!isActiveAndEnabled || Filter == null) return true;
            try { return Filter(screenPoint, eventCamera); }
            catch (Exception exception) { Debug.LogException(exception, this); return false; }
        }
        private void OnDestroy() { Filter = null; }
    }
}
