using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace MiniGamePlatform.Components
{
    public class AutoRotate : MonoBehaviour
    {
        [SerializeField][Header("旋转轴")]public RotateAxis rotateAxis = RotateAxis.Y;
        [SerializeField][Header("旋转速度（度/秒）")]public float rotateSpeed = 45;
        public enum RotateAxis
        {
            X,
            Y,
            Z
        }

        private Vector3 _rotateAxisVector;

        private void Start()
        {
            InitAxis();
        }

        void Update()
        {
#if UNITY_EDITOR
            InitAxis();
#endif
            this.transform.Rotate(_rotateAxisVector * Time.deltaTime);
        }

        private void InitAxis()
        {
            int x = rotateAxis == RotateAxis.X ? 1 : 0;
            int y = rotateAxis == RotateAxis.Y ? 1 : 0;
            int z = rotateAxis == RotateAxis.Z ? 1 : 0;
            _rotateAxisVector = new Vector3(x, y, z) * rotateSpeed;
        }
    }
}
