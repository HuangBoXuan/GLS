using UnityEngine;

namespace MiniGamePlatform.Components
{
    // Adapted from BALL CameraUtils: explicit camera/canvas, no RootCanvas singleton.
    public static class CameraUtils
    {
        public static bool WorldToCanvas(Camera worldCamera, Camera uiCamera, RectTransform canvas, Vector3 worldPosition, out Vector2 localPoint)
        {
            localPoint = Vector2.zero;
            if (worldCamera == null || canvas == null) return false;
            Vector3 screen = worldCamera.WorldToScreenPoint(worldPosition);
            if (screen.z < 0) return false;
            return RectTransformUtility.ScreenPointToLocalPointInRectangle(canvas, screen, uiCamera, out localPoint);
        }
    }
}
