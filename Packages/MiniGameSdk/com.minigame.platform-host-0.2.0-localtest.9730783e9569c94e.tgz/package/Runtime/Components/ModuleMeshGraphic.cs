using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Scripting;
using UnityEngine.UI;

namespace MiniGamePlatform.Components
{
    // Geometry and borrowed resource ownership belong to the game. UGUI owns rendering.
    [Preserve, DisallowMultipleComponent, RequireComponent(typeof(CanvasRenderer))]
    [UnityEngine.Scripting.APIUpdating.MovedFrom(true, null, "MiniGamePlatform.SDK", null)]
    public sealed class ModuleMeshGraphic : MaskableGraphic
    {
        public ModuleMeshGraphic() { useLegacyMeshGeneration = false; }
        [SerializeField] private Mesh _mesh;
        [SerializeField] private Texture _texture;
        private HotUpdate.ModuleMeshBuffer _buffer;
        private readonly List<Vector3> _vertices = new List<Vector3>();
        private readonly List<Vector3> _normals = new List<Vector3>();
        private readonly List<Vector4> _tangents = new List<Vector4>();
        private readonly List<Color32> _colors = new List<Color32>();
        private readonly List<Vector4>[] _uvs = { new List<Vector4>(), new List<Vector4>(), new List<Vector4>(), new List<Vector4>() };
        private readonly List<int> _triangles = new List<int>();

        public Mesh Mesh
        {
            get => _mesh;
            set { Validate(value); _buffer = null; _mesh = value; SetVerticesDirty(); }
        }
        // Borrow the host-owned validated CPU buffer. No Mesh upload/readback is
        // needed for dynamic UGUI geometry; Lua still supplies every vertex.
        internal void SetBuffer(HotUpdate.ModuleMeshBuffer buffer)
        {
            _mesh = null; _buffer = buffer; SetVerticesDirty();
        }
        internal void ClearBuffer(HotUpdate.ModuleMeshBuffer buffer)
        {
            if (!ReferenceEquals(_buffer, buffer)) return;
            _buffer = null; SetVerticesDirty();
        }
        public Texture Texture
        {
            get => _texture;
            set { if (_texture == value) return; _texture = value; SetMaterialDirty(); }
        }
        public override Texture mainTexture => _texture != null ? _texture : material != null && material.mainTexture != null ? material.mainTexture : s_WhiteTexture;

        private static void Validate(Mesh value)
        {
            if (value == null) return;
            if (!value.isReadable) throw new ArgumentException("UGUI mesh must be CPU readable.");
            if (value.vertexCount >= 65000) throw new ArgumentException("UGUI VertexHelper requires fewer than 65000 vertices.");
            if (value.subMeshCount > 1 || (value.subMeshCount == 1 && value.GetTopology(0) != MeshTopology.Triangles))
                throw new ArgumentException("One Graphic requires one triangle submesh and one material.");
        }
        protected override void OnPopulateMesh(VertexHelper vh)
        {
            vh.Clear();
            if (_buffer != null) { _buffer.PopulateGraphic(vh, color); return; }
            Validate(_mesh);
            if (_mesh == null || _mesh.vertexCount == 0 || _mesh.subMeshCount == 0) return;
            _mesh.GetVertices(_vertices); _mesh.GetNormals(_normals); _mesh.GetTangents(_tangents); _mesh.GetColors(_colors);
            for (int channel = 0; channel < 4; channel++) _mesh.GetUVs(channel, _uvs[channel]);
            _mesh.GetTriangles(_triangles, 0);
            for (int i = 0; i < _vertices.Count; i++)
            {
                var vertex = UIVertex.simpleVert;
                vertex.position = _vertices[i];
                vertex.color = (_colors.Count == 0 ? Color.white : (Color)_colors[i]) * color;
                vertex.normal = _normals.Count == 0 ? Vector3.back : _normals[i];
                vertex.tangent = _tangents.Count == 0 ? new Vector4(1, 0, 0, -1) : _tangents[i];
                vertex.uv0 = Uv(0, i); vertex.uv1 = Uv(1, i); vertex.uv2 = Uv(2, i); vertex.uv3 = Uv(3, i);
                vh.AddVert(vertex);
            }
            for (int i = 0; i < _triangles.Count; i += 3) vh.AddTriangle(_triangles[i], _triangles[i + 1], _triangles[i + 2]);
        }
        private Vector4 Uv(int channel, int vertex) => _uvs[channel].Count == 0 ? Vector4.zero : _uvs[channel][vertex];
        protected override void OnDestroy()
        {
            _mesh = null; _texture = null; _buffer = null;
            base.OnDestroy();
        }
    }
}
