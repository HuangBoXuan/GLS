using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.Scripting;

namespace MiniGamePlatform.Components
{
    // Intentionally no drag/scroll/click interfaces: preserve parent ScrollRect routing.
    [Preserve, DisallowMultipleComponent]
    [UnityEngine.Scripting.APIUpdating.MovedFrom(true, null, "MiniGamePlatform.SDK", null)]
    public sealed class ModulePointerRelay : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IPointerExitHandler, ISubmitHandler
    {
        public UnityEvent<PointerEventData> PointerDown { get; } = new UnityEvent<PointerEventData>();
        public UnityEvent<PointerEventData> PointerUp { get; } = new UnityEvent<PointerEventData>();
        public UnityEvent<PointerEventData> PointerExit { get; } = new UnityEvent<PointerEventData>();
        public UnityEvent<BaseEventData> Submit { get; } = new UnityEvent<BaseEventData>();
        public UnityEvent<int> PointerCanceled { get; } = new UnityEvent<int>();
        private readonly HashSet<int> _pressed = new HashSet<int>();

        public void OnPointerDown(PointerEventData data)
        { if (isActiveAndEnabled && data != null && _pressed.Add(data.pointerId)) PointerDown.Invoke(data); }
        public void OnPointerUp(PointerEventData data)
        { if (isActiveAndEnabled && data != null && _pressed.Remove(data.pointerId)) PointerUp.Invoke(data); }
        public void OnPointerExit(PointerEventData data)
        { if (isActiveAndEnabled && data != null) PointerExit.Invoke(data); }
        public void OnSubmit(BaseEventData data)
        { if (isActiveAndEnabled && data != null) Submit.Invoke(data); }

        private void OnDisable()
        {
            var pending = new List<int>(_pressed); _pressed.Clear();
            foreach (int id in pending)
            {
                try { PointerCanceled.Invoke(id); }
                catch (System.Exception exception) { Debug.LogException(exception); }
            }
        }
        private void OnDestroy()
        {
            PointerDown.RemoveAllListeners(); PointerUp.RemoveAllListeners(); PointerExit.RemoveAllListeners();
            Submit.RemoveAllListeners(); PointerCanceled.RemoveAllListeners();
        }
    }
}
