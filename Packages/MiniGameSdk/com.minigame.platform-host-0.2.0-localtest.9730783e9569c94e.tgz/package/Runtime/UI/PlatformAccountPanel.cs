using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace MiniGamePlatform.Host.UI
{
    /// <summary>Reusable UGUI account presentation. Product shells own the session and requests.</summary>
    public sealed class PlatformAccountPanel : MonoBehaviour
    {
        public enum Page { Hidden, Login, Bind, Account, ConfirmSwitch }

        private static readonly Color Ink = new Color(0.08f, 0.16f, 0.23f);
        private static readonly Color Surface = new Color(0.11f, 0.20f, 0.28f);
        private static readonly Color Mint = new Color(0.43f, 0.86f, 0.76f);
        private static readonly Color Cream = new Color(0.96f, 0.97f, 0.93f);
        private static readonly Color Muted = new Color(0.68f, 0.76f, 0.78f);

        private Font _font;
        private RectTransform _card;
        private CanvasGroup _controls;
        private Text _title, _description, _accountLabel, _identity, _message;
        private InputField _accountInput, _passwordInput, _confirmInput;
        private Button _primary, _secondary, _close;
        private Text _primaryLabel, _secondaryLabel;
        private GameObject _form, _confirmRow;
        private string _userId, _accountName;
        private bool _isBound, _busy, _canContinueGuest, _canRetry;
        private Color _messageColor = Muted, _errorColor = new Color(1f, .75f, .56f);

        public Page CurrentPage { get; private set; } = Page.Hidden;
        public bool Busy => _busy;
        public InputField AccountInput => _accountInput;
        public InputField PasswordInput => _passwordInput;
        public InputField ConfirmInput => _confirmInput;
        public Button PrimaryButton => _primary;
        public Button SecondaryButton => _secondary;

        public event Action<string, string> LoginRequested;
        public event Action<string, string> BindRequested;
        public event Action ContinueGuestRequested;
        public event Action RetryRequested;
        public event Action CloseRequested;

        public static PlatformAccountPanel Create(Transform canvas, Font font)
        {
            if (canvas == null) throw new ArgumentNullException(nameof(canvas));
            if (font == null) throw new ArgumentNullException(nameof(font));
            GameObject root = new GameObject("Platform Account", typeof(RectTransform), typeof(Image), typeof(PlatformAccountPanel));
            RectTransform rect = (RectTransform)root.transform;
            rect.SetParent(canvas, false);
            rect.anchorMin = Vector2.zero; rect.anchorMax = Vector2.one;
            rect.offsetMin = Vector2.zero; rect.offsetMax = Vector2.zero;
            root.GetComponent<Image>().color = new Color(Ink.r, Ink.g, Ink.b, .94f);
            PlatformAccountPanel view = root.GetComponent<PlatformAccountPanel>();
            view._font = font;
            view.Build();
            root.SetActive(false);
            return view;
        }

        public void ShowLogin(string message = null, bool canContinueGuest = true, bool canRetry = false, string existingUserId = null)
        {
            _canContinueGuest = canContinueGuest;
            _canRetry = canRetry;
            _userId = existingUserId;
            _accountInput.text = string.Empty;
            ClearPasswords();
            Show(Page.Login, message);
        }

        public void ShowBind(string message = null)
        {
            _accountInput.text = string.Empty;
            ClearPasswords();
            Show(Page.Bind, message);
        }

        public void ShowAccount(string userId, string accountName, bool isBound, string message = null)
        {
            _userId = userId;
            _accountName = accountName;
            _isBound = isBound;
            ClearPasswords();
            Show(Page.Account, message);
        }

        public void ShowError(string message)
        {
            _message.text = message ?? string.Empty;
            _message.color = _errorColor;
        }

        public void SetBusy(bool busy)
        {
            _busy = busy;
            if (_controls == null) return;
            _controls.interactable = !busy;
            _controls.blocksRaycasts = !busy;
        }

        public void Hide()
        {
            ClearPasswords();
            SetBusy(false);
            CurrentPage = Page.Hidden;
            gameObject.SetActive(false);
            if (EventSystem.current != null) EventSystem.current.SetSelectedGameObject(null);
        }

        private void Show(Page page, string message)
        {
            CurrentPage = page;
            gameObject.SetActive(true);
            transform.SetAsLastSibling();
            if (EventSystem.current != null) EventSystem.current.SetSelectedGameObject(null);
            SetBusy(false);
            _message.text = message ?? string.Empty;
            _message.color = _messageColor;
            _form.SetActive(page == Page.Login || page == Page.Bind);
            _confirmRow.SetActive(page == Page.Bind);
            _identity.gameObject.SetActive(page == Page.Account || page == Page.ConfirmSwitch);
            _primary.gameObject.SetActive(page != Page.Account || !_isBound);
            _secondary.gameObject.SetActive(true);
            _close.gameObject.SetActive(true);
            switch (page)
            {
                case Page.Login:
                    _title.text = "回到你的游戏";
                    _description.text = "登录已绑定的账号，继续原来的进度。";
                    _primaryLabel.text = "登录账号";
                    _secondaryLabel.text = _canContinueGuest ? "继续游客体验" : _canRetry ? "重试自动登录" : "返回账号信息";
                    break;
                case Page.Bind:
                    _title.text = "保存当前进度";
                    _description.text = "设置账号和密码后，可在其他安装包登录同一进度。";
                    _primaryLabel.text = "绑定当前账号";
                    _secondaryLabel.text = "返回账号信息";
                    break;
                case Page.Account:
                    _title.text = "我的账号";
                    _description.text = _isBound ? "已绑定，可用账号和密码找回进度。" : "当前是游客账号，绑定后可找回进度。";
                    _identity.text = (_isBound ? "账号：" + _accountName : "游客账号") + "\n用户 ID：" + (_userId ?? "—");
                    _primaryLabel.text = "绑定账号";
                    _secondaryLabel.text = "切换账号";
                    break;
                case Page.ConfirmSwitch:
                    _title.text = "切换到其他账号？";
                    _description.text = "当前进度不会并入目标账号。未绑定的游客进度在本机凭据丢失后可能无法找回。";
                    _identity.text = "将登录：" + _accountInput.text.Trim();
                    _primaryLabel.text = "确认切换";
                    _secondaryLabel.text = "返回登录";
                    break;
            }
        }

        private void Build()
        {
            _card = Rect("Account Card", transform, new Vector2(920, 1320), Vector2.zero);
            _card.gameObject.AddComponent<Image>().color = Surface;
            _controls = _card.gameObject.AddComponent<CanvasGroup>();
            Text mark = Label("Mark", _card, "●  我的小游戏", 31, Mint, new Vector2(-300, 565), new Vector2(275, 55), TextAnchor.MiddleLeft);
            mark.supportRichText = false;
            _title = Label("Title", _card, string.Empty, 59, Cream, new Vector2(0, 460), new Vector2(690, 90), TextAnchor.MiddleLeft);
            _description = Label("Description", _card, string.Empty, 28, Muted, new Vector2(0, 350), new Vector2(700, 130), TextAnchor.UpperLeft);
            _identity = Label("Identity", _card, string.Empty, 31, Cream, new Vector2(0, 125), new Vector2(700, 165), TextAnchor.MiddleLeft);
            _message = Label("Message", _card, string.Empty, 27, Muted, new Vector2(0, -345), new Vector2(730, 125), TextAnchor.MiddleCenter);

            _form = Rect("Credentials", _card, new Vector2(800, 610), new Vector2(0, 15)).gameObject;
            Label("Account Label", _form.transform, "账号（邮箱格式）", 27, Muted, new Vector2(-230, 205), new Vector2(330, 45), TextAnchor.MiddleLeft);
            _accountInput = Input("Account", _form.transform, new Vector2(0, 135), "例如 name@example.com", InputField.ContentType.EmailAddress);
            Label("Password Label", _form.transform, "密码", 27, Muted, new Vector2(-340, 35), new Vector2(110, 45), TextAnchor.MiddleLeft);
            _passwordInput = Input("Password", _form.transform, new Vector2(0, -35), "输入密码", InputField.ContentType.Password);
            _confirmRow = Rect("Confirm Row", _form.transform, new Vector2(800, 165), new Vector2(0, -190)).gameObject;
            Label("Confirm Label", _confirmRow.transform, "确认密码", 27, Muted, new Vector2(-310, 58), new Vector2(170, 45), TextAnchor.MiddleLeft);
            _confirmInput = Input("Confirm Password", _confirmRow.transform, new Vector2(0, -16), "再次输入密码", InputField.ContentType.Password);

            _primary = ActionButton("Primary", _card, new Vector2(0, -465), Mint, Ink, out _primaryLabel);
            _secondary = ActionButton("Secondary", _card, new Vector2(0, -575), new Color(.22f, .34f, .42f), Cream, out _secondaryLabel);
            _close = ActionButton("Close", _card, new Vector2(350, 555), Surface, Muted, out Text closeLabel, new Vector2(72, 72));
            closeLabel.text = "×";
            _primary.onClick.AddListener(PrimaryClicked);
            _secondary.onClick.AddListener(SecondaryClicked);
            _close.onClick.AddListener(() => { if (!_busy) CloseRequested?.Invoke(); });
        }

        private void PrimaryClicked()
        {
            if (_busy) return;
            switch (CurrentPage)
            {
                case Page.Login:
                    if (string.IsNullOrEmpty(_accountInput.text) || string.IsNullOrEmpty(_passwordInput.text))
                    { ShowError("请输入账号和密码。"); return; }
                    if (!string.IsNullOrEmpty(_userId)) Show(Page.ConfirmSwitch, null);
                    else SubmitLogin();
                    break;
                case Page.ConfirmSwitch: SubmitLogin(); break;
                case Page.Bind:
                    if (string.IsNullOrEmpty(_accountInput.text) || string.IsNullOrEmpty(_passwordInput.text))
                    { ShowError("请输入账号和密码。"); return; }
                    if (_passwordInput.text != _confirmInput.text)
                    { ShowError("两次输入的密码不一致。"); return; }
                    string account = _accountInput.text, password = _passwordInput.text;
                    ClearPasswords();
                    BindRequested?.Invoke(account, password);
                    break;
                case Page.Account: ShowBind(); break;
            }
        }

        private void SubmitLogin()
        {
            string account = _accountInput.text, password = _passwordInput.text;
            ClearPasswords();
            LoginRequested?.Invoke(account, password);
        }

        private void SecondaryClicked()
        {
            if (_busy) return;
            switch (CurrentPage)
            {
                case Page.Login:
                    if (_canContinueGuest) ContinueGuestRequested?.Invoke();
                    else if (_canRetry) RetryRequested?.Invoke();
                    else ShowAccount(_userId, _accountName, _isBound);
                    break;
                case Page.Bind: ShowAccount(_userId, _accountName, _isBound); break;
                case Page.Account: ShowLogin(null, false, false, _userId); break;
                case Page.ConfirmSwitch: ClearPasswords(); ShowLogin(null, false, false, _userId); break;
            }
        }

        private void ClearPasswords()
        {
            if (_passwordInput != null) _passwordInput.text = string.Empty;
            if (_confirmInput != null) _confirmInput.text = string.Empty;
        }

        // The product supplies appearance; credentials still never enter its Lua module.
        public void ApplyAppearance(Font font, Sprite panelSprite, Sprite buttonSprite,
            Color surface, Color ink, Color accent, Color muted)
        {
            if (font != null) _font = font;
            _messageColor = muted;
            _errorColor = new Color(.68f, .22f, .15f);
            GetComponent<Image>().color = new Color(ink.r, ink.g, ink.b, .65f);
            Image card = _card.GetComponent<Image>();
            card.color = surface; card.sprite = panelSprite; card.type = Image.Type.Sliced;
            foreach (Text text in GetComponentsInChildren<Text>(true))
            { text.font = _font; text.fontStyle = FontStyle.Bold; text.color = ink; }
            _description.color = muted; _message.color = muted;
            foreach (var input in new[] { _accountInput, _passwordInput, _confirmInput })
            {
                input.GetComponent<Image>().color = Color.white;
                input.textComponent.color = ink;
                input.placeholder.color = muted;
            }
            var primary = _primary.GetComponent<Image>();
            primary.sprite = buttonSprite; primary.type = Image.Type.Sliced;
            primary.color = buttonSprite != null ? Color.white : accent;
            _primaryLabel.color = Color.white;
            _secondary.GetComponent<Image>().color = new Color(.88f, .93f, .86f);
            _close.GetComponent<Image>().color = surface;
        }

        private void LateUpdate()
        {
            if (_card == null || Screen.width <= 0 || Screen.height <= 0) return;
            Rect viewport = ((RectTransform)transform).rect;
            if (viewport.width <= 0 || viewport.height <= 0) return;
            float pixelsToUi = viewport.height / Screen.height;
            Rect safe = Screen.safeArea;
            float bottom = safe.yMin * pixelsToUi;
            float top = (Screen.height - safe.yMax) * pixelsToUi;
            if (TouchScreenKeyboard.visible)
                bottom = Mathf.Max(bottom, TouchScreenKeyboard.area.height * pixelsToUi);
            float availableHeight = viewport.height - top - bottom;
            float scale = Mathf.Min(1f, (viewport.width - 48f) / 920f, (availableHeight - 48f) / 1320f);
            _card.localScale = Vector3.one * Mathf.Clamp(scale, .25f, 1f);
            _card.anchoredPosition = new Vector2(0, (bottom - top) * .5f);
        }

        private static RectTransform Rect(string name, Transform parent, Vector2 size, Vector2 position)
        {
            GameObject node = new GameObject(name, typeof(RectTransform));
            RectTransform rect = (RectTransform)node.transform;
            rect.SetParent(parent, false);
            rect.anchorMin = rect.anchorMax = new Vector2(.5f, .5f);
            rect.sizeDelta = size; rect.anchoredPosition = position;
            return rect;
        }

        private Text Label(string name, Transform parent, string value, int fontSize, Color color, Vector2 position, Vector2 size, TextAnchor anchor)
        {
            RectTransform rect = Rect(name, parent, size, position);
            Text label = rect.gameObject.AddComponent<Text>();
            label.font = _font; label.fontSize = fontSize; label.color = color;
            label.alignment = anchor; label.text = value; label.supportRichText = false;
            return label;
        }

        private InputField Input(string name, Transform parent, Vector2 position, string hint, InputField.ContentType type)
        {
            RectTransform rect = Rect(name, parent, new Vector2(720, 90), position);
            rect.gameObject.AddComponent<Image>().color = Cream;
            InputField input = rect.gameObject.AddComponent<InputField>();
            Text value = Label("Value", rect, string.Empty, 30, Ink, Vector2.zero, new Vector2(660, 75), TextAnchor.MiddleLeft);
            Text placeholder = Label("Placeholder", rect, hint, 27, new Color(.45f, .50f, .53f), Vector2.zero, new Vector2(660, 75), TextAnchor.MiddleLeft);
            input.textComponent = value; input.placeholder = placeholder;
            input.contentType = type;
            input.characterLimit = type == InputField.ContentType.EmailAddress ? 254 : 128;
            return input;
        }

        private Button ActionButton(string name, Transform parent, Vector2 position, Color background, Color foreground,
            out Text label, Vector2? size = null)
        {
            RectTransform rect = Rect(name, parent, size ?? new Vector2(720, 88), position);
            rect.gameObject.AddComponent<Image>().color = background;
            Button button = rect.gameObject.AddComponent<Button>();
            label = Label("Label", rect, name, 31, foreground, Vector2.zero, rect.sizeDelta, TextAnchor.MiddleCenter);
            return button;
        }
    }
}
