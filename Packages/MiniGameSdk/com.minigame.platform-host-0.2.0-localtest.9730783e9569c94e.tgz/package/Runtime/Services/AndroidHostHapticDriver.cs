using System;
using UnityEngine;

namespace MiniGamePlatform.SDK.Host
{
    // Optional product-shell implementation. No game-specific cue names or
    // Java class supplied by a downloadable module are required.
    public sealed class AndroidHostHapticDriver : IHostHapticDriver
    {
        public bool Play(int cue)
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            if (cue <= 0) return false;
            try
            {
                long duration = cue == 1 ? 20L : cue == 2 ? 35L : cue == 3 ? 55L : cue == 4 ? 80L : 110L;
                using (var unity = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
                using (var activity = unity.GetStatic<AndroidJavaObject>("currentActivity"))
                using (var vibrator = activity.Call<AndroidJavaObject>("getSystemService", "vibrator"))
                {
                    if (vibrator == null || !vibrator.Call<bool>("hasVibrator")) return false;
                    using (var version = new AndroidJavaClass("android.os.Build$VERSION"))
                    {
                        if (version.GetStatic<int>("SDK_INT") >= 26)
                        {
                            using (var effectClass = new AndroidJavaClass("android.os.VibrationEffect"))
                            using (var effect = effectClass.CallStatic<AndroidJavaObject>("createOneShot", duration, -1))
                                vibrator.Call("vibrate", effect);
                        }
                        else vibrator.Call("vibrate", duration);
                    }
                    return true;
                }
            }
            catch (Exception e) { Debug.LogWarning("Haptic playback unavailable: " + e.GetType().Name); return false; }
#else
            return false;
#endif
        }

        public bool Cancel()
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            try
            {
                using (var unity = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
                using (var activity = unity.GetStatic<AndroidJavaObject>("currentActivity"))
                using (var vibrator = activity.Call<AndroidJavaObject>("getSystemService", "vibrator"))
                {
                    if (vibrator == null) return false;
                    vibrator.Call("cancel"); return true;
                }
            }
            catch (Exception e) { Debug.LogWarning("Haptic cancel unavailable: " + e.GetType().Name); return false; }
#else
            return false;
#endif
        }
    }
}
