using System;
using UnityEngine;

namespace MiniGamePlatform.SDK.Host
{
    // Product configuration supplies actual documents and CMP. Blank settings
    // remain unavailable; a terms page is not a substitute for consent options.
    public sealed class HostLegalPrivacyDriver : IHostPrivacyDriver
    {
        private string _privacy, _agreement, _deletion;
        private Func<Action<bool>, bool> _options;

        private static string ValidUrl(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return null;
            if (!Uri.TryCreate(value, UriKind.Absolute, out Uri parsed) || parsed.Scheme != Uri.UriSchemeHttps ||
                parsed.UserInfo.Length > 0) throw new ArgumentException("Legal document URL must use HTTPS without embedded credentials.");
            return parsed.AbsoluteUri;
        }
        public void Configure(string privacyUrl, string agreementUrl, string dataDeletionUrl,
            Func<Action<bool>, bool> showPrivacyOptions = null)
        {
            string privacy = ValidUrl(privacyUrl), agreement = ValidUrl(agreementUrl), deletion = ValidUrl(dataDeletionUrl);
            _privacy = privacy; _agreement = agreement; _deletion = deletion; _options = showPrivacyOptions;
        }
        public bool OpenDocument(string document)
        {
            string url = document == "privacy" ? _privacy : document == "agreement" ? _agreement :
                document == "data_deletion" ? _deletion : null;
            if (url == null) return false;
            Application.OpenURL(url); return true;
        }
        public bool ShowOptions(Action<bool> completion)
        {
            if (_options == null || completion == null) return false;
            return _options(completion);
        }
    }
}
