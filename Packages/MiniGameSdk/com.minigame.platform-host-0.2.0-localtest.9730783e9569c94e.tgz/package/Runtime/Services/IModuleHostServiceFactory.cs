using MiniGamePlatform.HotUpdate;
using MiniGamePlatform.SDK;
using MiniGamePlatform.SDK.Auth;
namespace MiniGamePlatform.SDK.Contracts
{
    // Host composition API: a game sees only IModuleHostServices, never this factory or session.
    public interface IModuleHostServiceFactory
    {
        IModuleHostServices CreateServices(ModuleManifest manifest, ProductContext product, PlatformSession session);
    }
}
