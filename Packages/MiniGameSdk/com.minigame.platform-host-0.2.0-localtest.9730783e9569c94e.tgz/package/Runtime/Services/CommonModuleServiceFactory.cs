using System;
using MiniGamePlatform.HotUpdate;
using MiniGamePlatform.SDK.Auth;
using MiniGamePlatform.SDK.Contracts;
using UnityEngine;

namespace MiniGamePlatform.SDK.Host
{
    public sealed class CommonModuleServiceFactory : IModuleHostServiceFactory
    {
        private readonly AtomicLocalStore _storage;
        private readonly HostAdBroker _ads;
        private readonly HostNativeCoordinator _native;
        public CommonModuleServiceFactory(AtomicLocalStore storage, HostAdBroker ads, HostNativeCoordinator native = null)
        {
            _storage = storage ?? throw new ArgumentNullException(nameof(storage));
            _ads = ads ?? throw new ArgumentNullException(nameof(ads));
            _native = native ?? new HostNativeCoordinator(ads);
        }
        public static CommonModuleServiceFactory CreateDefault() => new CommonModuleServiceFactory(
            new AtomicLocalStore(System.IO.Path.Combine(Application.persistentDataPath, "MiniGamePlatform", "Saves")),
            new HostAdBroker(null, new HostMainThreadQueue()));
        public IModuleHostServices CreateServices(ModuleManifest manifest, ProductContext product, PlatformSession session)
        {
            if (manifest == null || string.IsNullOrWhiteSpace(manifest.gameId)) throw new ArgumentException("Game identity is required.");
            if (product != null && !product.AllowsGame(manifest.gameId)) throw new InvalidOperationException("Game is not allowed by product.");
            string serverGameId = null;
            product?.TryResolveServerGameId(manifest.gameId, out serverGameId);
            return new ModuleHostServices(session, manifest.gameId, _storage, _ads, product?.ProductId,
                serverGameId, _native.CreateScope());
        }
    }
}
