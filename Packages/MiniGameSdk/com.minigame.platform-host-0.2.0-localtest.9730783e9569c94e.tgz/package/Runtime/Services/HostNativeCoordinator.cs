using System;
using MiniGamePlatform.SDK.Contracts;
using MiniGamePlatform.SDK.Host;
using UnityEngine;

namespace MiniGamePlatform.SDK.Host
{
    // Product-owned adapters. A missing adapter is unavailable, never a simulated success.
    public interface IHostBannerDriver
    {
        bool IsReady { get; }
        // All rectangles are actual physical screen pixels reported by the native ad surface.
        bool TryGetGeometry(out Rect screen, out Rect safe, out Rect banner, out float density);
        bool Show(string placement);
        void Hide();
    }
    public interface IHostPrivacyDriver
    {
        bool OpenDocument(string document);
        bool ShowOptions(Action<bool> completion);
    }
    public interface IHostHapticDriver
    {
        bool Play(int cue);
        bool Cancel();
    }
    // Put a MonoBehaviour implementing this on the authored product-shell object
    // before HotUpdateDemo.Awake. The default demo has no ad or Banner driver.
    public interface IHostNativeAdapterProvider
    {
        IHostAdDriver Ads { get; }
        IHostBannerDriver Banner { get; }
        IHostPrivacyDriver Privacy { get; }
        IHostHapticDriver Haptics { get; }
    }

    // One instance per product shell. Multiple module scopes share the same
    // physical banner and fullscreen gate, but only the active scope owns a lease.
    public sealed class HostNativeCoordinator
    {
        [Serializable] private sealed class BannerContext
        {
            public bool enabled, ready, trusted, editorPreview, readOnly, runOwned;
            public Rect screen, safe, banner;
            public float density;
        }

        private readonly HostAdBroker _ads;
        private readonly IHostBannerDriver _banner;
        private readonly IHostPrivacyDriver _privacy;
        private readonly IHostHapticDriver _haptics;
        private readonly Func<bool> _requestExit;
        private NativeScope _owner;
        private int _nextRun, _run;
        private bool _homeWanted, _gameplayWanted, _obscured, _suppressed, _visible;
        private bool _applicationPaused, _privacyOpen;
        private string _visiblePlacement;

        public HostNativeCoordinator(HostAdBroker ads, IHostBannerDriver banner = null,
            IHostPrivacyDriver privacy = null, IHostHapticDriver haptics = null,
            Func<bool> requestExit = null)
        {
            _ads = ads ?? throw new ArgumentNullException(nameof(ads));
            _banner = banner; _privacy = privacy; _haptics = haptics; _requestExit = requestExit;
            _ads.FullscreenChanged += Reconcile;
        }
        public IModuleNativeFeatures CreateScope()
        {
            _ads.MainThread.RequireMainThread();
            return new NativeScope(this);
        }
        public void SetApplicationPaused(bool paused)
        {
            _ads.MainThread.RequireMainThread();
            _applicationPaused = paused; Reconcile();
        }
        private bool Owns(NativeScope scope) => scope != null && !scope.IsDisposed && ReferenceEquals(_owner, scope);
        private bool Acquire(NativeScope scope)
        {
            if (scope == null || scope.IsDisposed || (_owner != null && !ReferenceEquals(_owner, scope))) return false;
            _owner = scope; return true;
        }
        private static bool Finite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);
        private static bool Inside(Rect inner, Rect outer) => inner.xMin >= outer.xMin && inner.yMin >= outer.yMin &&
            inner.xMax <= outer.xMax && inner.yMax <= outer.yMax;
        private bool TryGeometry(out Rect screen, out Rect safe, out Rect banner, out float density)
        {
            screen = safe = banner = default; density = 0;
            if (_banner == null) return false;
            try
            {
                if (!_banner.TryGetGeometry(out screen, out safe, out banner, out density)) return false;
                return Finite(density) && density > 0 && screen.width > 0 && screen.height > 0 &&
                    safe.width > 0 && safe.height > 0 && banner.width > 0 && banner.height > 0 &&
                    Finite(screen.xMin) && Finite(screen.yMin) && Finite(screen.xMax) && Finite(screen.yMax) &&
                    Finite(safe.xMin) && Finite(safe.yMin) && Finite(safe.xMax) && Finite(safe.yMax) &&
                    Finite(banner.xMin) && Finite(banner.yMin) && Finite(banner.xMax) && Finite(banner.yMax) &&
                    Inside(safe, screen) && Inside(banner, screen);
            }
            catch (Exception e) { Debug.LogWarning("Banner geometry unavailable: " + e.GetType().Name); return false; }
        }
        private bool BannerReady()
        {
            try { return _banner != null && _banner.IsReady; }
            catch (Exception e) { Debug.LogWarning("Banner readiness unavailable: " + e.GetType().Name); return false; }
        }
        private void Hide()
        {
            if (!_visible) return;
            _visible = false; _visiblePlacement = null;
            try { _banner?.Hide(); } catch (Exception e) { Debug.LogWarning("Banner hide failed: " + e.GetType().Name); }
        }
        private void Reconcile()
        {
            _ads.MainThread.RequireMainThread();
            string placement = _owner == null || _owner.IsDisposed ? null :
                _run > 0 && _gameplayWanted && !_obscured && !_suppressed ? "gameplay" :
                _run == 0 && _homeWanted ? "home" : null;
            if (placement == null || _applicationPaused || _privacyOpen || _ads.IsFullscreenShowing || !BannerReady() ||
                !TryGeometry(out _, out _, out _, out _)) { Hide(); return; }
            if (_visible && _visiblePlacement == placement) return;
            Hide();
            try
            {
                _visible = _banner.Show(placement);
                _visiblePlacement = _visible ? placement : null;
            }
            catch (Exception e) { Debug.LogWarning("Banner show failed: " + e.GetType().Name); }
        }
        private string Context(NativeScope scope)
        {
            _ads.MainThread.RequireMainThread();
            bool trusted = TryGeometry(out Rect screen, out Rect safe, out Rect banner, out float density);
            return JsonUtility.ToJson(new BannerContext
            {
                enabled = _banner != null, ready = BannerReady() && !_ads.IsFullscreenShowing,
                trusted = trusted, editorPreview = false, readOnly = false,
                runOwned = Owns(scope) && _run > 0,
                screen = screen, safe = safe, banner = banner, density = density
            });
        }
        private float Top(NativeScope scope)
        {
            _ads.MainThread.RequireMainThread();
            return Owns(scope) && _visible && TryGeometry(out _, out _, out Rect banner, out _)
                ? banner.yMax : 0;
        }
        private void SetHome(NativeScope scope, bool visible)
        {
            _ads.MainThread.RequireMainThread();
            if (!Acquire(scope)) return;
            _run = 0; _gameplayWanted = false; _obscured = false; _suppressed = false;
            _homeWanted = visible; Reconcile();
        }
        private int BeginGameplay(NativeScope scope, bool eligible)
        {
            _ads.MainThread.RequireMainThread();
            if (!Acquire(scope)) return 0;
            _homeWanted = false; _run = 0; _gameplayWanted = false; _obscured = false; _suppressed = false;
            Hide();
            if (!eligible || !BannerReady() || !TryGeometry(out _, out _, out _, out _)) return 0;
            _run = ++_nextRun;
            if (_run <= 0) _run = _nextRun = 1;
            return _run;
        }
        private bool Viable(NativeScope scope, int run) => Owns(scope) && run > 0 && _run == run &&
            !_suppressed && BannerReady() && TryGeometry(out _, out _, out _, out _);
        private bool ShowGameplay(NativeScope scope, int run)
        {
            _ads.MainThread.RequireMainThread();
            if (!Viable(scope, run)) return false;
            _gameplayWanted = true; Reconcile();
            return _visible;
        }
        private void Overlay(NativeScope scope, int run, bool obscured)
        {
            _ads.MainThread.RequireMainThread();
            if (!Owns(scope) || _run != run || run <= 0) return;
            _obscured = obscured; Reconcile();
        }
        private void Suppress(NativeScope scope, int run)
        {
            _ads.MainThread.RequireMainThread();
            if (!Owns(scope) || _run != run || run <= 0) return;
            _suppressed = true; _gameplayWanted = false; Reconcile();
        }
        private void End(NativeScope scope, int run)
        {
            _ads.MainThread.RequireMainThread();
            if (!Owns(scope) || _run != run || run <= 0) return;
            _run = 0; _gameplayWanted = false; _obscured = false; _suppressed = false;
            Reconcile();
        }
        private void Release(NativeScope scope)
        {
            _ads.MainThread.RequireMainThread();
            if (!ReferenceEquals(_owner, scope)) return;
            _owner = null; _run = 0; _homeWanted = _gameplayWanted = _obscured = _suppressed = _privacyOpen = false;
            Hide();
        }

        private sealed class NativeScope : IModuleNativeFeatures, IModuleServicePump
        {
            private readonly HostNativeCoordinator _host;
            private bool _disposed, _hapticOwned;
            public bool IsDisposed => _disposed;
            public NativeScope(HostNativeCoordinator host) { _host = host; }
            public float BannerTopPixels => _disposed ? 0 : _host.Top(this);
            public string GetBannerContext() => _disposed ? null : _host.Context(this);
            public void SetHomeBanner(bool visible) { if (!_disposed) _host.SetHome(this, visible); }
            public int BeginGameplayBanner(bool eligible) => _disposed ? 0 : _host.BeginGameplay(this, eligible);
            public bool ShowGameplayBanner(int runId) => !_disposed && _host.ShowGameplay(this, runId);
            public bool IsGameplayBannerViable(int runId) => !_disposed && _host.Viable(this, runId);
            public void SetGameplayBannerOverlay(int runId, bool obscured) { if (!_disposed) _host.Overlay(this, runId, obscured); }
            public void SuppressGameplayBanner(int runId) { if (!_disposed) _host.Suppress(this, runId); }
            public void EndGameplayBanner(int runId) { if (!_disposed) _host.End(this, runId); }
            public bool IsFullscreenShowing() => !_disposed && _host._ads.IsFullscreenShowing;
            public bool OpenLegalDocument(string document)
            {
                if (_disposed || _host._privacy == null ||
                    (document != "privacy" && document != "agreement" && document != "data_deletion")) return false;
                try { return _host._privacy.OpenDocument(document); }
                catch (Exception e) { Debug.LogWarning("Legal document unavailable: " + e.GetType().Name); return false; }
            }
            public bool ShowPrivacyOptions(Action<bool> completion)
            {
                if (_disposed || _host._privacy == null || completion == null || !_host.Acquire(this) ||
                    _host._privacyOpen) return false;
                _host._privacyOpen = true; _host.Reconcile();
                try
                {
                    bool started = _host._privacy.ShowOptions(ok => _host._ads.MainThread.Post(() =>
                    {
                        if (_disposed) return;
                        _host._privacyOpen = false; _host.Reconcile(); completion(ok);
                    }));
                    if (!started) { _host._privacyOpen = false; _host.Reconcile(); }
                    return started;
                }
                catch (Exception e)
                {
                    _host._privacyOpen = false; _host.Reconcile();
                    Debug.LogWarning("Privacy options unavailable: " + e.GetType().Name); return false;
                }
            }
            public bool PlayHaptic(int cue)
            {
                if (_disposed || _host._haptics == null) return false;
                try { _hapticOwned = _host._haptics.Play(cue); return _hapticOwned; }
                catch (Exception e) { Debug.LogWarning("Haptic playback unavailable: " + e.GetType().Name); return false; }
            }
            public bool CancelHaptic()
            {
                if (_disposed || _host._haptics == null || !_hapticOwned) return false;
                _hapticOwned = false;
                try { return _host._haptics.Cancel(); }
                catch (Exception e) { Debug.LogWarning("Haptic cancel unavailable: " + e.GetType().Name); return false; }
            }
            public bool RequestExit()
            {
                if (_disposed || _host._requestExit == null) return false;
                try { return _host._requestExit(); }
                catch (Exception e) { Debug.LogWarning("Module exit unavailable: " + e.GetType().Name); return false; }
            }
            public void Pump() { if (!_disposed) _host.Reconcile(); }
            public void Dispose()
            {
                _host._ads.MainThread.RequireMainThread();
                if (_disposed) return;
                if (_hapticOwned) CancelHaptic();
                _disposed = true; _host.Release(this);
            }
        }
    }
}
