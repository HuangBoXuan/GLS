using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using MiniGamePlatform.HotUpdate;
using MiniGamePlatform.SDK.GameData;
using MiniGamePlatform.SDK.Network;

namespace MiniGamePlatform.SDK
{
    public sealed class ProductContext
    {
        private static readonly Regex ModuleId = new Regex("^[a-z][a-z0-9_]{0,63}$", RegexOptions.CultureInvariant);
        private static readonly Regex Version = new Regex("^[0-9]+\\.[0-9]+\\.[0-9]+$", RegexOptions.CultureInvariant);
        private readonly HashSet<string> _allowedGameIds = new HashSet<string>(StringComparer.Ordinal);
        private readonly HashSet<string> _locallyDisabled = new HashSet<string>(StringComparer.Ordinal);
        private readonly HashSet<string> _trustedServerIds = new HashSet<string>(StringComparer.Ordinal);
        private readonly Dictionary<string, string> _serverGameIds = new Dictionary<string, string>(StringComparer.Ordinal);

        public string ProductId { get; }
        public string ApiBaseUrl { get; }
        public string ClientVersion { get; }

        public ProductContext(string productId, string apiBaseUrl, string clientVersion, IEnumerable<string> allowedGameIds,
            IReadOnlyDictionary<string, string> serverGameIds = null, IEnumerable<string> locallyDisabledGameIds = null)
        {
            if (string.IsNullOrWhiteSpace(productId)) throw new ArgumentException("Product ID is required.", nameof(productId));
            if (!Version.IsMatch(clientVersion ?? string.Empty)) throw new ArgumentException("Client version must be major.minor.patch.", nameof(clientVersion));
            if (allowedGameIds == null) throw new ArgumentNullException(nameof(allowedGameIds));
            // Constructor validates HTTPS in release and loopback-only HTTP in development.
            new UnityApiTransport(apiBaseUrl, clientVersion: clientVersion);
            ProductId = productId;
            ApiBaseUrl = apiBaseUrl;
            ClientVersion = clientVersion;
            foreach (string gameId in allowedGameIds)
            {
                if (string.IsNullOrEmpty(gameId) || !ModuleId.IsMatch(gameId) || !_allowedGameIds.Add(gameId))
                    throw new ArgumentException("Invalid or duplicate module game ID.", nameof(allowedGameIds));
            }
            if (locallyDisabledGameIds != null)
                foreach (string gameId in locallyDisabledGameIds)
                    if (!ModuleId.IsMatch(gameId ?? ""))
                        throw new ArgumentException("Invalid locally disabled game ID.", nameof(locallyDisabledGameIds));
                    else _locallyDisabled.Add(gameId);
            if (serverGameIds == null) return;
            foreach (KeyValuePair<string, string> pair in serverGameIds)
            {
                if (!_allowedGameIds.Contains(pair.Key)) throw new ArgumentException("Server game mapping is not allowed by this product.", nameof(serverGameIds));
                new GameContext(productId, pair.Value);
                _serverGameIds.Add(pair.Key, pair.Value);
            }
        }

        public bool AllowsGame(string moduleGameId)
        {
            return moduleGameId != null && !_locallyDisabled.Contains(moduleGameId) &&
                _allowedGameIds.Contains(moduleGameId);
        }

        public bool IsLocallyDisabled(string moduleGameId)
        {
            return moduleGameId != null && _locallyDisabled.Contains(moduleGameId);
        }

        public void ApplyVerifiedCatalog(VerifiedProductCatalog catalog)
        {
            if (catalog == null || catalog.ProductId != ProductId)
                throw new InvalidOperationException("Verified catalog belongs to another product.");
            _allowedGameIds.Clear();
            _trustedServerIds.Clear();
            foreach (ModuleRelease release in catalog.Releases)
            {
                if (!release.enabled || _locallyDisabled.Contains(release.gameId)) continue;
                _allowedGameIds.Add(release.gameId);
                if (!catalog.IsBuiltinFallback && !release.gameId.StartsWith("sample", StringComparison.Ordinal))
                    _trustedServerIds.Add(release.gameId);
            }
        }

        public bool TryResolveServerGameId(string moduleGameId, out string serverGameId)
        {
            serverGameId = null;
            if (!AllowsGame(moduleGameId)) return false;
            if (_serverGameIds.TryGetValue(moduleGameId, out serverGameId)) return true;
            if (!_trustedServerIds.Contains(moduleGameId)) return false;
            serverGameId = moduleGameId;
            return true;
        }

        public GameContext CreateGameContext(string moduleGameId)
        {
            if (!TryResolveServerGameId(moduleGameId, out string serverGameId))
                throw new InvalidOperationException("Module has no registered server game mapping.");
            return new GameContext(ProductId, serverGameId);
        }
    }
}
