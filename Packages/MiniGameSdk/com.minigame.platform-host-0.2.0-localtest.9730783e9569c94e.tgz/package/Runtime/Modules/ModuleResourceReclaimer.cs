using System.Collections.Generic;
using UnityEngine;

namespace MiniGamePlatform.HotUpdate
{
    // A host-owned driver survives destruction of the product shell/module scene.
    // It only completes pending scoped releases; it never performs a global Unity unload.
    internal sealed class ModuleResourceReclaimer : MonoBehaviour
    {
        private static ModuleResourceReclaimer _instance;
        private readonly List<ModuleAssetScope> _pending = new List<ModuleAssetScope>();
        private readonly List<LuaGameRunner> _exits = new List<LuaGameRunner>();
        private static ModuleResourceReclaimer EnsureDriver()
        {
            if (_instance == null)
            {
                var node = new GameObject("MiniGame Resource Reclaimer");
                DontDestroyOnLoad(node);
                _instance = node.AddComponent<ModuleResourceReclaimer>();
            }
            return _instance;
        }
        internal static void Schedule(ModuleAssetScope scope)
        {
            var driver = EnsureDriver();
            if (!driver._pending.Contains(scope)) driver._pending.Add(scope);
        }
        internal static void ScheduleExit(LuaGameRunner runner)
        {
            var driver = EnsureDriver();
            if (!driver._exits.Contains(runner)) driver._exits.Add(runner);
        }
        private void Update()
        {
            for (int i = _exits.Count - 1; i >= 0; i--)
            {
                // A caller may already have completed exit and opened the next module.
                if (_exits[i].HasPendingExit) _exits[i].AdvancePendingExit();
                if (!_exits[i].HasPendingExit) _exits.RemoveAt(i);
            }
            for (int i = _pending.Count - 1; i >= 0; i--)
                if (_pending[i].TryCompleteRelease()) _pending.RemoveAt(i);
            if (_pending.Count != 0 || _exits.Count != 0) return;
            _instance = null;
            Destroy(gameObject);
        }
    }
}
