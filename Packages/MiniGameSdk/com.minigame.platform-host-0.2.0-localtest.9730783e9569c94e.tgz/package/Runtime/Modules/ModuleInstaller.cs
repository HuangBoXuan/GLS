using System;
using System.Collections;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using UnityEngine;
using UnityEngine.Networking;

namespace MiniGamePlatform.HotUpdate
{
    public sealed class ModuleInstaller
    {
        private readonly string _root;
        private readonly HostProfile _host;

        public ModuleInstaller(string root, HostProfile host = null)
        {
            _root = root;
            _host = host ?? HostProfile.Current;
        }

        public string GetInstalledPath(ModuleManifest manifest)
        {
            return Path.Combine(_root, manifest.gameId, manifest.version);
        }

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        public IEnumerator Install(string manifestUrl, Action<ModuleManifest, string> completed, Action<string> failed,
            Action<float> progress = null, ModuleInstallCancellation cancellation = null)
        {
            return InstallInternal(manifestUrl, null, completed, failed, progress, cancellation);
        }

        public IEnumerator Install(ModuleRelease release, string catalogBaseUrl, Action<ModuleManifest, string> completed, Action<string> failed)
#else
        private IEnumerator Install(ModuleRelease release, string catalogBaseUrl, Action<ModuleManifest, string> completed, Action<string> failed)
#endif
        {
            if (release == null || !Uri.TryCreate(catalogBaseUrl, UriKind.Absolute, out Uri baseUri))
            {
                failed("Invalid module release or catalog URL.");
                return Empty();
            }
            string url = new Uri(baseUri, release.manifestPath).AbsoluteUri;
            return InstallInternal(url, release, completed, failed, null);
        }

        public IEnumerator Install(ModuleReleaseSelection selection, string catalogBaseUrl,
            Action<ModuleManifest, string> completed, Action<string> failed, Action<float> progress = null,
            ModuleInstallCancellation cancellation = null)
        {
            if (selection == null || selection.Status != ModuleSelectionStatus.Ready ||
                !Uri.TryCreate(catalogBaseUrl, UriKind.Absolute, out Uri url) ||
                (url.Scheme != Uri.UriSchemeHttps &&
                 !(selection.IsBuiltinFallback &&
                   (url.Scheme == Uri.UriSchemeFile || url.Scheme == "jar"))))
            {
                failed("Trusted module installation requires a selected release and HTTPS catalog base URL.");
                return Empty();
            }
            string manifestUrl = new Uri(url, selection.PinnedRelease.manifestPath).AbsoluteUri;
            return InstallInternal(manifestUrl, selection.PinnedRelease, completed, failed, progress, cancellation);
        }

        private static IEnumerator Empty() { yield break; }

        private IEnumerator InstallInternal(string manifestUrl, ModuleRelease release,
            Action<ModuleManifest, string> completed, Action<string> failed, Action<float> progress,
            ModuleInstallCancellation cancellation = null)
        {
            cancellation = cancellation ?? new ModuleInstallCancellation();
            if (cancellation.IsCancellationRequested) yield break;
            if (!Uri.TryCreate(manifestUrl, UriKind.Absolute, out Uri uri) ||
                (uri.Scheme != Uri.UriSchemeHttp && uri.Scheme != Uri.UriSchemeHttps && uri.Scheme != Uri.UriSchemeFile && uri.Scheme != "jar"))
            {
                failed("Manifest URL must be http(s), file, or Android StreamingAssets jar URI.");
                yield break;
            }

            string json;
            byte[] manifestBytes = null;
            int manifestRetries = 0;
            while (manifestBytes == null)
            {
                while (cancellation.IsPaused && !cancellation.IsCancellationRequested) yield return null;
                if (cancellation.IsCancellationRequested) yield break;
                long status;
                string error;
                int pauseVersion = cancellation.PauseVersion;
                using (var output = new MemoryStream())
                using (var receiver = new BoundedManifestDownload(output))
                using (var request = new UnityWebRequest(manifestUrl, "GET", receiver, null))
                using (cancellation.Track(request))
                {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
                    DevelopmentLoopbackCertificatePin.Configure(request, uri);
#endif
                    request.timeout = 30;
                    request.disposeDownloadHandlerOnDispose = false;
                    UnityWebRequestAsyncOperation operation = request.SendWebRequest();
                    while (!operation.isDone) {
                        if (cancellation.IsCancellationRequested) yield break;
                        if (receiver.Failure != null) {
                            request.Abort(); failed("Module manifest exceeds 1 MiB."); yield break;
                        }
                        progress?.Invoke(.05f * request.downloadProgress); yield return null;
                    }
                    if (cancellation.IsCancellationRequested) yield break;
                    if (pauseVersion != cancellation.PauseVersion) continue;
                    if (receiver.Failure != null) { failed(receiver.Failure); yield break; }
                    if (request.result == UnityWebRequest.Result.Success) { manifestBytes = output.ToArray(); break; }
                    status = request.responseCode; error = request.error;
                }
                Debug.LogWarning("[ModuleDownload] manifest http=" + status + " error=" + error);
                if (!ModuleFileDownload.Retryable(status) || manifestRetries >= 3)
                { failed("HTTP " + status + " manifest.json: " + error); yield break; }
                cancellation.Phase = "版本请求中断，正在重试…";
                yield return ModuleFileDownload.Backoff(++manifestRetries, cancellation);
            }
            if (manifestBytes.Length > 1024 * 1024)
            {
                failed("Module manifest exceeds 1 MiB.");
                yield break;
            }
            if (release != null && !HashMatches(release.manifestSha256, manifestBytes))
            {
                failed("Manifest differs from pinned product catalog.");
                yield break;
            }
            json = Encoding.UTF8.GetString(manifestBytes);

            ModuleManifest manifest;
            try { manifest = ModuleManifest.Parse(json); }
            catch (Exception exception) { failed(exception.Message); yield break; }
            if (release != null && (manifest.gameId != release.gameId || manifest.version != release.version))
            {
                failed("Manifest identity differs from product catalog.");
                yield break;
            }
            if (!_host.Supports(manifest, out string incompatibility))
            {
                failed(incompatibility);
                yield break;
            }

            string finalPath = GetInstalledPath(manifest);
            if (Directory.Exists(finalPath))
            {
                if (IsValid(manifest, finalPath, manifestBytes))
                {
                    progress?.Invoke(1f);
                    completed(manifest, finalPath);
                    yield break;
                }
                // Cache damage is repairable. Keep installed bytes until the pinned
                // replacement is fully verified; cancellation leaves them untouched.
            }

            ModuleDownloadWorkspace workspace;
            try
            {
                workspace = new ModuleDownloadWorkspace(finalPath, manifestBytes);
            }
            catch (Exception exception) { failed(exception.Message); yield break; }

            using (workspace)
            {
                string baseUrl = manifestUrl.Substring(0, manifestUrl.LastIndexOf('/') + 1);
                long totalSize = 0;
                foreach (ModuleFile file in manifest.files) totalSize += file.size;
                long completedSize = 0;
                int fileIndex = 0;
                foreach (ModuleFile file in manifest.files)
                {
                    if (cancellation.IsCancellationRequested) yield break;
                    cancellation.Phase = "正在下载游戏内容…";
                    string downloadUrl = baseUrl + string.Join("/", Array.ConvertAll(file.path.Split('/'), Uri.EscapeDataString));
                    string transferError = null;
                    string target = Path.Combine(workspace.Content, file.path.Replace('/', Path.DirectorySeparatorChar));
                    yield return ModuleFileDownload.Fetch(downloadUrl, file, target, workspace.PartialPath(fileIndex++), cancellation,
                        bytes => progress?.Invoke(.05f + .85f * (totalSize <= 0 ? 0 : (completedSize + bytes) / (float)totalSize)),
                        error => transferError = error);
                    if (cancellation.IsCancellationRequested) yield break;
                    if (transferError != null) { failed(transferError); yield break; }
                    completedSize += file.size;
                }

                cancellation.Phase = "正在安装游戏…";
                progress?.Invoke(.96f);
                yield return null;
                if (cancellation.IsCancellationRequested) yield break;
                try
                {
                    workspace.Publish(finalPath, manifestBytes);
                }
                catch (Exception exception)
                {
                    failed(exception.Message);
                    yield break;
                }
                cancellation.Phase = "准备完成";
                progress?.Invoke(1f);
                completed(manifest, finalPath);
            }
        }

        public static bool Matches(ModuleFile file, byte[] bytes)
        {
            if (bytes == null || bytes.LongLength != file.size) return false;
            return HashMatches(file.sha256, bytes);
        }

        public static bool HashMatches(string expected, byte[] bytes)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] digest = sha.ComputeHash(bytes);
                return BitConverter.ToString(digest).Replace("-", "").Equals(expected, StringComparison.OrdinalIgnoreCase);
            }
        }

        public static bool IsValid(ModuleManifest manifest, string directory)
        {
            foreach (ModuleFile file in manifest.files)
            {
                string path = Path.Combine(directory, file.path.Replace('/', Path.DirectorySeparatorChar));
                if (!FileMatches(file, path)) return false;
            }
            return true;
        }

        // UI hint only. Never use this to authorize execution or mark an installation healthy.
        // Stat the files without reading/hash-scanning the entire module on the Unity main thread.
        public static bool HasFilesForDisplay(ModuleManifest manifest, string directory)
        {
            if (manifest?.files == null || string.IsNullOrEmpty(directory)) return false;
            try
            {
                foreach (ModuleFile file in manifest.files)
                {
                    var info = new FileInfo(Path.Combine(directory, file.path.Replace('/', Path.DirectorySeparatorChar)));
                    if (!info.Exists || info.Length != file.size) return false;
                }
                return true;
            }
            catch (Exception error) when (error is IOException || error is UnauthorizedAccessException)
            { return false; }
        }

        internal static bool FileMatches(ModuleFile file, string path)
        {
            try
            {
                using (var stream = File.OpenRead(path))
                using (var sha = SHA256.Create())
                    return stream.Length == file.size && BitConverter.ToString(sha.ComputeHash(stream)).Replace("-", "").Equals(file.sha256, StringComparison.OrdinalIgnoreCase);
            }
            catch (IOException) { return false; }
            catch (UnauthorizedAccessException) { return false; }
        }

        public static bool IsValid(ModuleManifest manifest, string directory, byte[] expectedManifestBytes)
        {
            if (expectedManifestBytes == null || !IsValid(manifest, directory)) return false;
            string path = Path.Combine(directory, "manifest.json");
            if (!File.Exists(path) || new FileInfo(path).Length != expectedManifestBytes.Length) return false;
            byte[] installedBytes = File.ReadAllBytes(path);
            if (installedBytes.Length != expectedManifestBytes.Length) return false;
            for (int i = 0; i < installedBytes.Length; i++)
                if (installedBytes[i] != expectedManifestBytes[i]) return false;
            return true;
        }

        // Enforce the bound inside the receiver, before MemoryStream grows. Polling
        // downloadedBytes once a frame cannot bound a fast/chunked response.
        private sealed class BoundedManifestDownload : DownloadHandlerScript
        {
            private const int Limit = 1024 * 1024;
            private readonly Stream _output;
            private long _received;
            public string Failure { get; private set; }
            public BoundedManifestDownload(Stream output) : base(new byte[65536]) { _output = output; }
            protected override void ReceiveContentLengthHeader(ulong length)
            { if (length > Limit) Failure = "Module manifest exceeds 1 MiB."; }
            protected override bool ReceiveData(byte[] data, int count)
            {
                if (Failure != null) return false;
                if (count < 0 || count > Limit - _received)
                { Failure = "Module manifest exceeds 1 MiB."; return false; }
                try { _output.Write(data, 0, count); _received += count; return true; }
                catch (Exception e) { Failure = e.Message; return false; }
            }
        }
    }
}
