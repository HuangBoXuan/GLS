using System.Collections.Generic;
using UnityEngine.Localization.SmartFormat;
using UnityEngine.Scripting;

namespace MiniGamePlatform.HotUpdate
{
    public static class LocalizationBaseline
    {
        public const string Capability = "unity_localization_1_4_4";
#if MGP_LOCALIZATION_1_4_4
        public static bool IsAvailable => true;
#else
        public static bool IsAvailable => false;
#endif
        public static IReadOnlyList<string> RetainedAssemblies { get; } = System.Array.AsReadOnly(new[] {
            "Unity.Localization", "Unity.Addressables", "Unity.ResourceManager"
        });
        // Explicit native generic bodies used by Lua named SmartFormat arguments.
        // No global locale, Addressables catalog or gameplay initialization is performed here.
        [Preserve]
        private static void ClosedSignatures()
        {
            var values = new Dictionary<string, object>();
            values.Add("count", 2); values["name"] = "player";
            values.TryGetValue("name", out object value); values.ContainsKey("count");
            Smart.CreateDefaultSmartFormat().Format("{name}: {count}", new object[] { values });
            foreach (KeyValuePair<string, object> pair in values) { _ = pair.Key; _ = pair.Value; }
            values.Remove("name"); values.Clear();
        }
    }
}
