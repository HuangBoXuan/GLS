using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using UnityEngine;

namespace MiniGamePlatform.HotUpdate
{
    public static class CatalogSignatureVerifier
    {
        public const int MaxEnvelopeBytes = 512 * 1024;
        public const int MaxPayloadBytes = 256 * 1024;

        public static VerifiedProductCatalog Verify(byte[] envelopeBytes, CatalogTrustKey key, string expectedProductId)
        {
            if (key == null) throw new ArgumentNullException(nameof(key));
            if (envelopeBytes == null || envelopeBytes.Length == 0 || envelopeBytes.Length > MaxEnvelopeBytes)
                throw new InvalidDataException("Signed catalog envelope size is invalid.");
            SignedCatalogEnvelope envelope;
            try
            {
                envelope = JsonUtility.FromJson<SignedCatalogEnvelope>(new UTF8Encoding(false, true).GetString(envelopeBytes));
            }
            catch (Exception exception) { throw new InvalidDataException("Signed catalog envelope is invalid.", exception); }
            if (envelope == null || envelope.keyId != key.KeyId ||
                string.IsNullOrEmpty(envelope.payloadBase64) ||
                envelope.payloadBase64.Length > ((MaxPayloadBytes + 2) / 3) * 4 + 4 ||
                string.IsNullOrEmpty(envelope.signatureBase64) || envelope.signatureBase64.Length > 1024)
                throw new InvalidDataException("Signed catalog envelope fields are invalid.");
            byte[] payload;
            byte[] signature;
            try
            {
                payload = Convert.FromBase64String(envelope.payloadBase64);
                signature = Convert.FromBase64String(envelope.signatureBase64);
            }
            catch (FormatException exception) { throw new InvalidDataException("Signed catalog Base64 is invalid.", exception); }
            if (payload.Length == 0 || payload.Length > MaxPayloadBytes || signature.Length == 0)
                throw new InvalidDataException("Signed catalog content size is invalid.");
            bool valid;
            try
            {
                using (RSA rsa = RSA.Create())
                {
                    rsa.ImportParameters(key.PublicParameters());
                    valid = rsa.VerifyData(payload, signature, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
                }
            }
            catch (CryptographicException exception) { throw new InvalidDataException("Catalog signature verification failed.", exception); }
            if (!valid) throw new InvalidDataException("Catalog signature verification failed.");
            ProductModuleCatalog catalog;
            try { catalog = ProductModuleCatalog.ParseV2(new UTF8Encoding(false, true).GetString(payload)); }
            catch (Exception exception) when (!(exception is InvalidDataException))
            {
                throw new InvalidDataException("Signed catalog payload is invalid.", exception);
            }
            if (catalog.productId != expectedProductId)
                throw new InvalidDataException("Signed catalog belongs to another product.");
            return VerifiedProductCatalog.FromSigned(payload, catalog);
        }
    }
}
