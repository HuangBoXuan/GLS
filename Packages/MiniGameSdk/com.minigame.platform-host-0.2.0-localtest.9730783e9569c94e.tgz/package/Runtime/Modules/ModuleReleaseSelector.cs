using System;
using System.Collections.Generic;
using MiniGamePlatform.SDK;

namespace MiniGamePlatform.HotUpdate
{
    public enum ModuleSelectionStatus { Ready, NotListed, Disabled, NeedsHostUpdate }

    public sealed class ModuleReleaseSelection
    {
        private readonly ModuleRelease _release;
        public ModuleSelectionStatus Status { get; }
        public string GameId { get; }
        public string Reason { get; }
        public bool IsBuiltinFallback { get; }
        public ModuleRelease Release => _release == null ? null : Copy(_release);
        internal ModuleRelease PinnedRelease => _release;

        internal ModuleReleaseSelection(ModuleSelectionStatus status, string gameId, ModuleRelease release,
            string reason, bool builtinFallback)
        {
            Status = status;
            GameId = gameId;
            _release = release == null ? null : Copy(release);
            Reason = reason;
            IsBuiltinFallback = builtinFallback;
        }

        private static ModuleRelease Copy(ModuleRelease value)
        {
            return new ModuleRelease { gameId = value.gameId, version = value.version,
                manifestPath = value.manifestPath, manifestSha256 = value.manifestSha256,
                runtimeType = value.runtimeType, minHostApiVersion = value.minHostApiVersion,
                requiredCapabilities = value.requiredCapabilities == null ? null :
                    (string[])value.requiredCapabilities.Clone(), platform = value.platform,
                unityVersion = value.unityVersion, enabled = value.enabled,
                fallbackVersion = value.fallbackVersion };
        }
    }

    public static class ModuleReleaseSelector
    {
        public static ModuleReleaseSelection Select(VerifiedProductCatalog catalog, HostProfile host,
            ProductContext product, string gameId)
        {
            if (catalog == null) throw new ArgumentNullException(nameof(catalog));
            if (host == null) throw new ArgumentNullException(nameof(host));
            if (product == null) throw new ArgumentNullException(nameof(product));
            if (catalog.ProductId != product.ProductId)
                throw new InvalidOperationException("Catalog belongs to another product.");
            var matches = new List<ModuleRelease>();
            foreach (ModuleRelease release in catalog.Releases)
                if (release.gameId == gameId) matches.Add(release);
            if (matches.Count == 0)
                return new ModuleReleaseSelection(ModuleSelectionStatus.NotListed, gameId, null, "GAME_NOT_LISTED",
                    catalog.IsBuiltinFallback);
            if (product.IsLocallyDisabled(gameId) || !product.AllowsGame(gameId))
                return new ModuleReleaseSelection(ModuleSelectionStatus.Disabled, gameId, null, "GAME_DISABLED",
                    catalog.IsBuiltinFallback);
            matches.Sort((left, right) => CompareVersion(right.version, left.version));
            foreach (ModuleRelease release in matches)
            {
                if (!release.enabled || !Compatible(release, host)) continue;
                return new ModuleReleaseSelection(ModuleSelectionStatus.Ready, gameId, release, null,
                    catalog.IsBuiltinFallback);
            }
            return new ModuleReleaseSelection(ModuleSelectionStatus.NeedsHostUpdate, gameId, null,
                "NO_COMPATIBLE_RELEASE", catalog.IsBuiltinFallback);
        }

        public static ModuleReleaseSelection SelectFallback(VerifiedProductCatalog catalog, HostProfile host,
            ProductContext product, ModuleReleaseSelection failed,
            Func<ModuleRelease, bool> isInstalled)
        {
            if (failed == null || failed.Status != ModuleSelectionStatus.Ready || isInstalled == null)
                throw new ArgumentException("A selected release and installed-version check are required.");
            string version = failed.PinnedRelease.fallbackVersion;
            var visited = new HashSet<string>(StringComparer.Ordinal);
            while (!string.IsNullOrEmpty(version) && visited.Add(version))
            {
                foreach (ModuleRelease release in catalog.Releases)
                {
                    if (release.gameId != failed.GameId || release.version != version) continue;
                    if (catalog.ProductId == product.ProductId && product.AllowsGame(failed.GameId) &&
                        release.enabled && Compatible(release, host) && isInstalled(release))
                        return new ModuleReleaseSelection(ModuleSelectionStatus.Ready, failed.GameId, release, "FALLBACK",
                            catalog.IsBuiltinFallback);
                    version = release.fallbackVersion;
                    break;
                }
            }
            return new ModuleReleaseSelection(ModuleSelectionStatus.NeedsHostUpdate, failed.GameId, null,
                "NO_INSTALLED_FALLBACK", catalog.IsBuiltinFallback);
        }

        public static ModuleReleaseSelection SelectInstalled(VerifiedProductCatalog catalog, HostProfile host,
            ProductContext product, string gameId, string version, string manifestSha256)
        {
            ModuleReleaseSelection selected = Select(catalog, host, product, gameId);
            if (selected.Status != ModuleSelectionStatus.Ready) return selected;
            if (Matches(selected.PinnedRelease, version, manifestSha256)) return selected;
            ModuleReleaseSelection fallback = SelectFallback(catalog, host, product, selected,
                release => Matches(release, version, manifestSha256));
            return fallback.Status == ModuleSelectionStatus.Ready ? fallback :
                new ModuleReleaseSelection(ModuleSelectionStatus.NotListed, gameId, null,
                    "INSTALLED_RELEASE_NOT_AUTHORIZED", catalog.IsBuiltinFallback);
        }

        // A server assignment must name an exact release in the signed product catalog.
        // The legacy Select/SelectInstalled methods intentionally retain their highest/fallback behavior.
        public static ModuleReleaseSelection SelectExact(VerifiedProductCatalog catalog, HostProfile host,
            ProductContext product, string gameId, string version, string manifestSha256)
        {
            if (catalog == null) throw new ArgumentNullException(nameof(catalog));
            if (host == null) throw new ArgumentNullException(nameof(host));
            if (product == null) throw new ArgumentNullException(nameof(product));
            if (catalog.ProductId != product.ProductId)
                throw new InvalidOperationException("Catalog belongs to another product.");
            if (catalog.IsBuiltinFallback)
                return new ModuleReleaseSelection(ModuleSelectionStatus.NotListed, gameId, null,
                    "SIGNED_CATALOG_REQUIRED", true);

            bool gameListed = false;
            foreach (ModuleRelease release in catalog.Releases)
            {
                if (release.gameId != gameId) continue;
                gameListed = true;
                if (release.version != version) continue;
                if (!Matches(release, version, manifestSha256))
                    return new ModuleReleaseSelection(ModuleSelectionStatus.NotListed, gameId, null,
                        "ASSIGNED_MANIFEST_HASH_MISMATCH", false);
                if (product.IsLocallyDisabled(gameId) || !product.AllowsGame(gameId) || !release.enabled)
                    return new ModuleReleaseSelection(ModuleSelectionStatus.Disabled, gameId, null,
                        "GAME_OR_RELEASE_DISABLED", false);
                if (!Compatible(release, host))
                    return new ModuleReleaseSelection(ModuleSelectionStatus.NeedsHostUpdate, gameId, null,
                        "ASSIGNED_RELEASE_INCOMPATIBLE", false);
                return new ModuleReleaseSelection(ModuleSelectionStatus.Ready, gameId, release, null, false);
            }
            return new ModuleReleaseSelection(ModuleSelectionStatus.NotListed, gameId, null,
                gameListed ? "ASSIGNED_RELEASE_NOT_LISTED" : "GAME_NOT_LISTED", false);
        }

        private static bool Matches(ModuleRelease release, string version, string manifestSha256)
        {
            return release.version == version && string.Equals(release.manifestSha256, manifestSha256,
                StringComparison.OrdinalIgnoreCase);
        }

        private static bool Compatible(ModuleRelease release, HostProfile host)
        {
            if (Array.IndexOf(release.requiredCapabilities, "assetbundle") >= 0 &&
                !host.SupportsBundleOwnership(release.minHostApiVersion, release.requiredCapabilities)) return false;
            if (release.runtimeType != "unity_lua" || release.minHostApiVersion > host.Version ||
                (release.platform != "any" && release.platform != host.Platform) ||
                (!string.IsNullOrEmpty(release.unityVersion) && release.unityVersion != host.UnityVersion)) return false;
            foreach (string capability in release.requiredCapabilities)
                if (!HostCapabilityRegistry.Contains(capability, release.minHostApiVersion) ||
                    !host.SupportsCapability(capability)) return false;
            return true;
        }

        private static int CompareVersion(string left, string right)
        {
            if (left != null && right != null && left.StartsWith("v", StringComparison.Ordinal) &&
                right.StartsWith("v", StringComparison.Ordinal) &&
                long.TryParse(left.Substring(1), out long leftNumber) &&
                long.TryParse(right.Substring(1), out long rightNumber))
                return leftNumber.CompareTo(rightNumber);
            return string.CompareOrdinal(left, right);
        }
    }
}
