using System;
using System.Collections;
using System.IO;
using UnityEngine.Networking;

namespace MiniGamePlatform.HotUpdate
{
    public enum CatalogLoadSource { Remote, VerifiedCache, BuiltinFallback }

    public sealed class CatalogLoadResult
    {
        public VerifiedProductCatalog Catalog { get; }
        public CatalogLoadSource Source { get; }
        public string Diagnostic { get; }

        public CatalogLoadResult(VerifiedProductCatalog catalog, CatalogLoadSource source, string diagnostic)
        {
            Catalog = catalog;
            Source = source;
            Diagnostic = diagnostic;
        }
    }

    public interface ITrustedCatalogTransport
    {
        IEnumerator Fetch(Uri url, Action<byte[], string> done);
    }

    public sealed class TrustedCatalogSource
    {
        private readonly string _productId;
        private readonly Uri _configuredUrl;
        private readonly CatalogTrustKey _key;
        private readonly CatalogCache _cache;
        private readonly VerifiedProductCatalog _builtin;
        private readonly ITrustedCatalogTransport _transport;

        public TrustedCatalogSource(string productId, Uri configuredUrl, CatalogTrustKey key,
            CatalogCache cache, byte[] builtinPayload, ITrustedCatalogTransport transport = null)
        {
            if (configuredUrl == null || configuredUrl.Scheme != Uri.UriSchemeHttps ||
                !string.IsNullOrEmpty(configuredUrl.UserInfo) || !string.IsNullOrEmpty(configuredUrl.Fragment))
                throw new InvalidDataException("Trusted catalog endpoint must be a configured HTTPS URL.");
            _builtin = CatalogCache.LoadBuiltin(builtinPayload, productId);
            _productId = productId;
            _configuredUrl = configuredUrl;
            _key = key ?? throw new ArgumentNullException(nameof(key));
            _cache = cache ?? throw new ArgumentNullException(nameof(cache));
            _transport = transport ?? new UnityCatalogTransport();
        }

        public IEnumerator Load(string productId, Uri httpsUrl, CatalogTrustKey key, Action<CatalogLoadResult> done)
        {
            if (productId != _productId || httpsUrl == null ||
                httpsUrl.AbsoluteUri != _configuredUrl.AbsoluteUri || !ReferenceEquals(key, _key))
                throw new InvalidDataException("Catalog load does not match product trust configuration.");
            if (done == null) throw new ArgumentNullException(nameof(done));
            byte[] response = null;
            string error = null;
            yield return _transport.Fetch(_configuredUrl, (bytes, failure) => { response = bytes; error = failure; });
            if (response != null)
            {
                try
                {
                    VerifiedProductCatalog fresh = _cache.ReplaceVerified(response);
                    done(new CatalogLoadResult(fresh, CatalogLoadSource.Remote, null));
                    yield break;
                }
                catch (Exception exception) when (exception is InvalidDataException || exception is IOException ||
                                                   exception is UnauthorizedAccessException)
                { error = exception.Message; }
            }
            if (_cache.TryRead(out VerifiedProductCatalog cached))
                done(new CatalogLoadResult(cached, CatalogLoadSource.VerifiedCache, error ?? "REMOTE_UNAVAILABLE"));
            else done(new CatalogLoadResult(_builtin, CatalogLoadSource.BuiltinFallback, error ?? "REMOTE_UNAVAILABLE"));
        }

        private sealed class UnityCatalogTransport : ITrustedCatalogTransport
        {
            public IEnumerator Fetch(Uri url, Action<byte[], string> done)
            {
                using (var request = new UnityWebRequest(url.AbsoluteUri, "GET",
                    new BoundedDownloadHandler(), null))
                {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
                    DevelopmentLoopbackCertificatePin.Configure(request, url);
#endif
                    request.timeout = 15;
                    yield return request.SendWebRequest();
                    if (request.result != UnityWebRequest.Result.Success)
                        done(null, request.error);
                    else done(request.downloadHandler.data, null);
                }
            }
        }

        private sealed class BoundedDownloadHandler : DownloadHandlerScript
        {
            private readonly MemoryStream _bytes = new MemoryStream();
            public BoundedDownloadHandler() : base(new byte[16 * 1024]) { }
            protected override bool ReceiveData(byte[] data, int dataLength)
            {
                if (data == null || dataLength < 0 ||
                    _bytes.Length + dataLength > CatalogSignatureVerifier.MaxEnvelopeBytes) return false;
                _bytes.Write(data, 0, dataLength);
                return true;
            }
            protected override byte[] GetData() { return _bytes.ToArray(); }
        }
    }
}
