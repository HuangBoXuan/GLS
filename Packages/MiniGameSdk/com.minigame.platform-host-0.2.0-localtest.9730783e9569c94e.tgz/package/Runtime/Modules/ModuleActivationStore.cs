using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using UnityEngine;

namespace MiniGamePlatform.HotUpdate
{
    public sealed class ModuleActivation
    {
        public string gameId { get; }
        public string version { get; }
        public string directory { get; }
        public string manifestSha256 { get; }

        internal ModuleActivation(string gameIdValue, string versionValue, string directoryValue, string hashValue)
        {
            gameId = gameIdValue;
            version = versionValue;
            directory = directoryValue;
            manifestSha256 = hashValue;
        }
    }

    public sealed class ModuleActivationStore
    {
        [Serializable] private sealed class Entry
        {
            public string gameId;
            public string version;
            public string directory;
            public string manifestSha256;
        }

        [Serializable] private sealed class State
        {
            public Entry current;
            public Entry previous;
        }

        private static readonly Regex GameId = new Regex("^[a-z][a-z0-9_]{0,63}$", RegexOptions.CultureInvariant);
        private readonly string _root;

        public ModuleActivationStore(string root)
        {
            _root = !string.IsNullOrWhiteSpace(root) ? root : throw new ArgumentException("Activation root is required.");
        }

        public ModuleActivation Current(string gameId)
        {
            return ToValidActivation(Read(gameId).current);
        }

        public ModuleActivation Previous(string gameId)
        {
            return ToValidActivation(Read(gameId).previous);
        }

        // Advisory page state; Current/Previous and LuaGameRunner retain full integrity checks.
        public ModuleActivation CurrentForDisplay(string gameId) => ToActivation(Read(gameId).current, false);
        public ModuleActivation PreviousForDisplay(string gameId) => ToActivation(Read(gameId).previous, false);

        public IReadOnlyList<string> KnownGameIdsForDisplay() => KnownGameIds(false);

        public IReadOnlyList<string> KnownGameIds() => KnownGameIds(true);

        private IReadOnlyList<string> KnownGameIds(bool verifyContents)
        {
            var result = new List<string>();
            try
            {
                if (!Directory.Exists(_root)) return result;
                foreach (string path in Directory.EnumerateFiles(_root, "*.json", SearchOption.TopDirectoryOnly))
                {
                    string gameId = Path.GetFileNameWithoutExtension(path);
                    if (!GameId.IsMatch(gameId)) continue;
                    State state = Read(gameId);
                    if (ToActivation(state.current, verifyContents) != null || ToActivation(state.previous, verifyContents) != null)
                        result.Add(gameId);
                }
            }
            catch (Exception exception) when (exception is IOException || exception is UnauthorizedAccessException)
            { return Array.Empty<string>(); }
            result.Sort(StringComparer.Ordinal);
            return result;
        }

        public void MarkHealthy(ModuleReleaseSelection selection, ModuleManifest manifest, string directory,
            LuaGameRunner runner)
        {
            if (selection == null || selection.Status != ModuleSelectionStatus.Ready || manifest == null ||
                runner == null || runner.State != GameRunState.Running ||
                runner.CurrentGameId != manifest.gameId || runner.SuccessfulTicks < 1 ||
                selection.PinnedRelease.gameId != manifest.gameId ||
                selection.PinnedRelease.version != manifest.version ||
                string.IsNullOrWhiteSpace(directory))
                throw new InvalidOperationException("Module must enter successfully before activation.");
            var entry = new Entry { gameId = manifest.gameId, version = manifest.version,
                directory = Path.GetFullPath(directory), manifestSha256 = selection.PinnedRelease.manifestSha256 };
            if (ToValidActivation(entry) == null)
                throw new InvalidDataException("Healthy module does not match the signed catalog and installed files.");
            State state = Read(manifest.gameId);
            if (state.current != null && state.current.version != manifest.version &&
                ToValidActivation(state.current) != null) state.previous = state.current;
            state.current = entry;
            Save(manifest.gameId, state);
        }

        public ModuleActivation Rollback(string gameId)
        {
            State state = Read(gameId);
            ModuleActivation previous = ToValidActivation(state.previous);
            if (previous == null) return null;
            Entry old = state.current;
            state.current = state.previous;
            state.previous = ToValidActivation(old) == null ? null : old;
            Save(gameId, state);
            return previous;
        }

        private State Read(string gameId)
        {
            string path = PathFor(gameId);
            foreach (string candidate in new[] { path, path + ".backup" })
            {
                if (!File.Exists(candidate)) continue;
                try
                {
                    if (new FileInfo(candidate).Length > 64 * 1024) continue;
                    State state = JsonUtility.FromJson<State>(File.ReadAllText(candidate));
                    if (state != null && (state.current != null || state.previous != null)) return state;
                }
                catch (Exception exception) when (exception is IOException || exception is ArgumentException) { }
            }
            return new State();
        }

        private void Save(string gameId, State state)
        {
            Directory.CreateDirectory(_root);
            string target = PathFor(gameId);
            string stage = target + ".stage";
            File.WriteAllText(stage, JsonUtility.ToJson(state));
            if (File.Exists(target))
            {
                try { File.Replace(stage, target, target + ".backup"); }
                catch (PlatformNotSupportedException)
                {
                    string backup = target + ".backup";
                    if (File.Exists(backup)) File.Delete(backup);
                    File.Move(target, backup);
                    File.Move(stage, target);
                }
            }
            else File.Move(stage, target);
        }

        private string PathFor(string gameId)
        {
            if (!GameId.IsMatch(gameId ?? "")) throw new ArgumentException("Invalid activation game ID.");
            return Path.Combine(_root, gameId + ".json");
        }

        private static ModuleActivation ToValidActivation(Entry entry) => ToActivation(entry, true);

        private static ModuleActivation ToActivation(Entry entry, bool verifyContents)
        {
            if (entry == null || !GameId.IsMatch(entry.gameId ?? "") ||
                string.IsNullOrEmpty(entry.version) || string.IsNullOrEmpty(entry.directory) ||
                string.IsNullOrEmpty(entry.manifestSha256)) return null;
            try
            {
                string manifestPath = Path.Combine(entry.directory, "manifest.json");
                if (!File.Exists(manifestPath) || new FileInfo(manifestPath).Length > 1024 * 1024) return null;
                byte[] bytes = File.ReadAllBytes(manifestPath);
                if (!ModuleInstaller.HashMatches(entry.manifestSha256, bytes)) return null;
                ModuleManifest manifest = ModuleManifest.Parse(System.Text.Encoding.UTF8.GetString(bytes));
                if (manifest.gameId != entry.gameId || manifest.version != entry.version) return null;
                if (verifyContents ? !ModuleInstaller.IsValid(manifest, entry.directory) :
                    !ModuleInstaller.HasFilesForDisplay(manifest, entry.directory)) return null;
                return new ModuleActivation(entry.gameId, entry.version, entry.directory, entry.manifestSha256);
            }
            catch (Exception exception) when (exception is IOException || exception is UnauthorizedAccessException ||
                                               exception is InvalidDataException || exception is ArgumentException)
            { return null; }
        }
    }
}
