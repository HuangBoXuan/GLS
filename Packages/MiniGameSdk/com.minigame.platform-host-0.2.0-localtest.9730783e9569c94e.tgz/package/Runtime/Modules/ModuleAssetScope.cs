using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine;

namespace MiniGamePlatform.HotUpdate
{
    public sealed class ModuleAssetScope : IDisposable
    {
        public const int MaxDataTextBytes = 4 * 1024 * 1024;
        private static readonly UTF8Encoding StrictUtf8 = new UTF8Encoding(false, true);
        private readonly ModuleManifest _manifest;
        private readonly string _directory;
        private readonly ModuleContentReader _content;
        private readonly Dictionary<string, ModuleBundleRegistry.Lease> _bundles = new Dictionary<string, ModuleBundleRegistry.Lease>();
        private readonly List<GameObject> _instances = new List<GameObject>();
        private readonly List<int> _instanceIds = new List<int>();
        private readonly List<AssetBundleRequest> _pendingLoads = new List<AssetBundleRequest>();
        private static readonly Dictionary<int, ModuleAssetScope> InstanceOwners = new Dictionary<int, ModuleAssetScope>();
        private readonly int _thread = System.Threading.Thread.CurrentThread.ManagedThreadId;
        private bool _bundlesAcquired;
        private bool _disposed;
        public bool IsReleaseComplete { get; private set; }
        public Exception ReleaseError { get; private set; }
        internal string GameId => _manifest.gameId;

        private void RequireThread()
        {
            if (System.Threading.Thread.CurrentThread.ManagedThreadId != _thread)
                throw new InvalidOperationException("Resource scopes must be used on their owning Unity thread.");
        }

        // Only scene instances may be transferred. Original prefab/assets are borrowed, never owned instances.
        public void TrackInstance(GameObject instance)
        {
            RequireThread();
            if (_disposed) throw new ObjectDisposedException(nameof(ModuleAssetScope));
            if (instance == null || !instance.scene.IsValid()) throw new ArgumentException("A live scene instance is required.");
            int id = instance.GetInstanceID();
            if (InstanceOwners.TryGetValue(id, out var owner))
            {
                if (ReferenceEquals(owner, this)) return;
                throw new InvalidOperationException("Instance already belongs to another module scope.");
            }
            InstanceOwners.Add(id, this); _instanceIds.Add(id); _instances.Add(instance);
        }

        internal void RequireCapability(string capability, int api)
        {
            if (_disposed) throw new ObjectDisposedException(nameof(ModuleAssetScope));
            if (_manifest.minHostApiVersion < api || Array.IndexOf(_manifest.requiredCapabilities ?? Array.Empty<string>(), capability) < 0)
                throw new InvalidDataException("Module must declare " + capability + " and host API " + api + ".");
        }

        internal bool SupportsCapability(string capability, int api)
        {
            RequireThread();
            return !_disposed && _manifest.minHostApiVersion >= api &&
                Array.IndexOf(_manifest.requiredCapabilities ?? Array.Empty<string>(), capability) >= 0 &&
                HostProfile.Current.SupportsCapability(capability);
        }

        internal bool OwnsSceneTransform(Transform target)
        {
            RequireThread();
            if (_disposed || target == null || !target.gameObject.scene.IsValid()) return false;
            for (Transform current = target; current != null; current = current.parent)
                if (InstanceOwners.TryGetValue(current.gameObject.GetInstanceID(), out ModuleAssetScope owner))
                    return ReferenceEquals(owner, this);
            return false;
        }

        internal T LoadPresentationAsset<T>(string bundlePath, string assetName) where T : UnityEngine.Object
        {
            RequireCapability("presentation", 4);
            RequireCapability("assetbundle", 1);
            if (string.IsNullOrEmpty(assetName) || assetName.Length > 512 || assetName.Contains("\\") || assetName.StartsWith("/") || assetName.Contains("..") || assetName.Contains(":"))
                throw new InvalidDataException("Invalid presentation asset name.");
            T asset = GetBundle(bundlePath).LoadAsset<T>(assetName);
            if (asset == null) throw new InvalidDataException("Presentation asset not found or wrong type: " + assetName);
            return asset;
        }

        internal UnityEngine.Object LoadAsset(string bundlePath, string assetName, Type assetType)
        {
            RequireCapability("assetbundle", 1);
            ValidateAssetAddress(assetName, assetType);
            UnityEngine.Object asset = GetBundle(bundlePath).LoadAsset(assetName, assetType);
            if (asset == null) throw new InvalidDataException("Asset not found or wrong type: " + assetName);
            return asset;
        }

        internal ModuleAssetRequest BeginLoadAsset(string bundlePath, string assetName, Type assetType)
        {
            RequireActive();
            RequireCapability("assetbundle", 1);
            ValidateAssetAddress(assetName, assetType);
            for (int i = _pendingLoads.Count - 1; i >= 0; i--)
                if (_pendingLoads[i].isDone) _pendingLoads.RemoveAt(i);
            // Bundle acquisition retains the existing verified lease contract.
            // Once acquired, individual Unity asset loads can yield to rendering.
            AssetBundleRequest request = GetBundle(bundlePath).LoadAssetAsync(assetName, assetType);
            _pendingLoads.Add(request);
            return new ModuleAssetRequest(this, request, assetName);
        }

        internal void RequireActive()
        {
            RequireThread();
            if (_disposed) throw new ObjectDisposedException(nameof(ModuleAssetScope));
        }

        private static void ValidateAssetAddress(string assetName, Type assetType)
        {
            if (assetType == null) throw new ArgumentNullException(nameof(assetType));
            if (!typeof(UnityEngine.Object).IsAssignableFrom(assetType) || assetType.ContainsGenericParameters)
                throw new ArgumentException("Asset type must be a concrete UnityEngine.Object type.", nameof(assetType));
            // Asset names may contain spaces and non-ASCII characters. They are addresses inside
            // the selected bundle, never filesystem paths. Reject traversal/control syntax only.
            if (string.IsNullOrWhiteSpace(assetName) || assetName.Length > 512 || assetName.StartsWith("/", StringComparison.Ordinal) ||
                assetName.Contains("\\") || assetName.Contains(":")) throw new InvalidDataException("Invalid asset address.");
            foreach (char character in assetName)
                if (char.IsControl(character)) throw new InvalidDataException("Invalid asset address.");
            foreach (string segment in assetName.Split('/'))
                if (segment.Length == 0 || segment == "." || segment == "..") throw new InvalidDataException("Invalid asset address.");
        }

        public string ReadDataText(string relativePath)
        {
            if (_disposed) throw new ObjectDisposedException(nameof(ModuleAssetScope));
            if (_manifest.minHostApiVersion < 2 ||
                Array.IndexOf(_manifest.requiredCapabilities ?? Array.Empty<string>(), "data_text") < 0)
                throw new InvalidDataException("ReadDataText requires data_text and host API 2.");
            if (!ModuleManifest.IsAllowedModuleFile(_manifest.gameId, relativePath) ||
                !relativePath.StartsWith("data/" + _manifest.gameId + "/", StringComparison.Ordinal))
                throw new InvalidDataException("Invalid game data path.");
            byte[] bytes = _content.ReadDataBytes(relativePath, MaxDataTextBytes);
            try
            {
                // Optional UTF-8 BOM is not part of the returned JSON/CSV/text payload.
                int offset = bytes.Length >= 3 && bytes[0] == 0xef && bytes[1] == 0xbb && bytes[2] == 0xbf ? 3 : 0;
                return StrictUtf8.GetString(bytes, offset, bytes.Length - offset);
            }
            finally { Array.Clear(bytes, 0, bytes.Length); }
        }

        public ModuleAssetScope(ModuleManifest manifest, string directory, IModuleContentKeyProvider keys = null)
        {
            _manifest = manifest;
            _directory = directory;
            _content = new ModuleContentReader(manifest, directory, keys);
        }

        public GameObject InstantiatePrefab(string bundlePath, string assetName, Transform parent)
        {
            AssetBundle bundle = GetBundle(bundlePath);
            GameObject prefab = bundle.LoadAsset<GameObject>(assetName);
            if (prefab == null) throw new InvalidDataException("Prefab not found: " + assetName);
            GameObject instance = UnityEngine.Object.Instantiate(prefab, parent, false);
            TrackInstance(instance);
            foreach (Component component in instance.GetComponentsInChildren<Component>(true))
            {
                if (component != null) continue;
                DestroyInstance(instance);
                throw new InvalidDataException("Prefab contains a missing component: " + assetName);
            }
            return instance;
        }

        private AssetBundle GetBundle(string bundlePath)
        {
            RequireThread();
            if (_disposed) throw new ObjectDisposedException(nameof(ModuleAssetScope));
            if (!ModuleManifest.IsSafeRelativePath(bundlePath) || !bundlePath.EndsWith(".bundle", StringComparison.Ordinal))
                throw new InvalidDataException("Invalid bundle path.");
            bool declared = false;
            foreach (ModuleFile file in _manifest.files)
            {
                if (file.path == bundlePath) { declared = true; break; }
            }
            if (!declared) throw new InvalidDataException("Bundle is not declared in module manifest.");
            if (!_bundlesAcquired)
            {
                try
                {
                    foreach (ModuleFile file in _manifest.files)
                    {
                        if (!file.path.EndsWith(".bundle", StringComparison.Ordinal)) continue;
                        if (!ModuleContentProtection.ValidateDeclaration(_manifest))
                        {
                            using (var verified = _content.OpenVerifiedPlainFile(file.path))
                                _bundles.Add(file.path, ModuleBundleRegistry.Acquire(verified, () => AssetBundle.LoadFromFile(verified.Path)));
                            continue;
                        }
                        // Read verifies the declared hash, file length, protection and safe path before sharing.
                        byte[] plain = _content.Read(file.path);
                        try
                        {
                            var lease = ModuleBundleRegistry.Acquire(plain, () => AssetBundle.LoadFromMemory(plain));
                            _bundles.Add(file.path, lease);
                        }
                        finally { Array.Clear(plain, 0, plain.Length); }
                    }
                    _bundlesAcquired = true;
                }
                catch
                {
                    foreach (var lease in _bundles.Values) lease.Dispose();
                    _bundles.Clear();
                    throw;
                }
            }
            return _bundles[bundlePath].Bundle;
        }

        public void Dispose()
        {
            RequireThread();
            if (!_disposed)
            {
                _disposed = true;
                foreach (var instance in _instances) DestroyInstance(instance);
            }
            if (!TryCompleteRelease() && Application.isPlaying) ModuleResourceReclaimer.Schedule(this);
        }

        public bool TryCompleteRelease()
        {
            RequireThread();
            if (IsReleaseComplete) return true;
            if (!_disposed) return false;
            // Unity asset requests cannot be cancelled. Keep verified bundle
            // leases until all work completes, even after a Lua request is detached.
            foreach (var request in _pendingLoads) if (!request.isDone) return false;
            foreach (var instance in _instances) if (instance != null) return false;
            try { foreach (var lease in _bundles.Values) lease.Dispose(); }
            catch (Exception exception) { ReleaseError = exception; return false; }
            foreach (int id in _instanceIds) InstanceOwners.Remove(id);
            _instanceIds.Clear(); _instances.Clear();
            _bundles.Clear();
            _pendingLoads.Clear();
            ReleaseError = null;
            IsReleaseComplete = true;
            return true;
        }

        private static void DestroyInstance(GameObject instance)
        {
            if (instance == null) return;
            instance.SetActive(false);
#if UNITY_EDITOR
            if (!Application.isPlaying) { UnityEngine.Object.DestroyImmediate(instance); return; }
#endif
            UnityEngine.Object.Destroy(instance);
        }
    }

    [UnityEngine.Scripting.Preserve]
    public sealed class ModuleAssetRequest : IDisposable
    {
        private readonly ModuleAssetScope _scope;
        private readonly string _address;
        private AssetBundleRequest _request;
        internal ModuleAssetRequest(ModuleAssetScope scope, AssetBundleRequest request, string address)
        { _scope = scope; _request = request; _address = address; }
        private AssetBundleRequest Request
        {
            get
            {
                _scope.RequireActive();
                return _request ?? throw new ObjectDisposedException(nameof(ModuleAssetRequest));
            }
        }
        [UnityEngine.Scripting.Preserve] public bool IsDone => Request.isDone;
        [UnityEngine.Scripting.Preserve] public float Progress => Request.progress;
        [UnityEngine.Scripting.Preserve] public UnityEngine.Object Asset
        {
            get
            {
                var request = Request;
                if (!request.isDone) throw new InvalidOperationException("Asset request has not completed.");
                return request.asset != null ? request.asset : throw new InvalidDataException("Asset not found or wrong type: " + _address);
            }
        }
        // Detaches the consumer, not the native work; its scope owns the release barrier.
        [UnityEngine.Scripting.Preserve] public void Dispose() { _request = null; }
    }
}
