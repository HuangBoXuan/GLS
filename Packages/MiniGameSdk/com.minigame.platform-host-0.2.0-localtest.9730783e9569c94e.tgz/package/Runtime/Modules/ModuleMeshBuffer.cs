using System;
using System.Runtime.InteropServices;
using System.Threading;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Scripting;

namespace MiniGamePlatform.HotUpdate
{
    [Preserve]
    public sealed class ModuleMeshBuffer : IDisposable
    {
        public const int VertexStride = 76;
        private const int MaxVertices = 64999;
        private const int MaxTriangleIndices = 1000000;
        private static readonly VertexAttributeDescriptor[] Layout = {
            new VertexAttributeDescriptor(VertexAttribute.Position, VertexAttributeFormat.Float32, 3),
            new VertexAttributeDescriptor(VertexAttribute.Normal, VertexAttributeFormat.Float32, 3),
            new VertexAttributeDescriptor(VertexAttribute.Tangent, VertexAttributeFormat.Float32, 4),
            new VertexAttributeDescriptor(VertexAttribute.Color, VertexAttributeFormat.UNorm8, 4),
            new VertexAttributeDescriptor(VertexAttribute.TexCoord0, VertexAttributeFormat.Float32, 4),
            new VertexAttributeDescriptor(VertexAttribute.TexCoord1, VertexAttributeFormat.Float32, 4)
        };

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct BatchVertex
        {
            public Vector3 position;
            public Vector3 normal;
            public Vector4 tangent;
            public Color32 color;
            public Vector4 uv0;
            public Vector4 uv1;
        }

        private Mesh _mesh;
        private Components.ModuleMeshGraphic _graphic;
        private readonly ModuleAssetScope _graphicScope;
        private Action<IDisposable> _onDispose;
        private readonly int _threadId;
        private BatchVertex[] _vertices = Array.Empty<BatchVertex>();
        private BatchVertex[] _pendingVertices = Array.Empty<BatchVertex>();
        private int[] _triangles = Array.Empty<int>();
        private int _vertexCount;
        private bool _configured;
        private bool _disposed;
        private byte[] _packedBytes = Array.Empty<byte>();
        private static readonly XLuaBase.lua_CSFunction PackedUpload = UploadFromLua;
        [Preserve] public XLuaBase.lua_CSFunction UploadPacked => PackedUpload;
        private static readonly XLuaBase.lua_CSFunction ChunkUpload = UploadChunksFromLua;
        [Preserve] public XLuaBase.lua_CSFunction UploadPackedChunks => ChunkUpload;

        [XLua.MonoPInvokeCallback(typeof(XLuaBase.lua_CSFunction))]
        private static int UploadChunksFromLua(IntPtr state)
        {
            try
            {
                var buffer = XLua.ObjectTranslatorPool.Instance.Find(state).GetObject(state, 1, typeof(ModuleMeshBuffer)) as ModuleMeshBuffer;
                if (buffer == null) throw new ArgumentException("Mesh buffer receiver required.");
                buffer.RequireUsable();
                if (XLua.LuaDLL.Lua.lua_gettop(state) != 4 ||
                    XLua.LuaDLL.Lua.lua_type(state, 2) != XLua.LuaTypes.LUA_TTABLE ||
                    XLua.LuaDLL.Lua.lua_type(state, 3) != XLua.LuaTypes.LUA_TNUMBER ||
                    XLua.LuaDLL.Lua.lua_type(state, 4) != XLua.LuaTypes.LUA_TNUMBER)
                    throw new ArgumentException("Mesh chunk upload requires a table and bounded integer counts.");
                double requested = XLua.LuaDLL.Lua.lua_tonumber(state, 3), vertices = XLua.LuaDLL.Lua.lua_tonumber(state, 4);
                if (double.IsNaN(requested) || requested < 0 || requested > MaxVertices || requested != Math.Floor(requested) ||
                    double.IsNaN(vertices) || vertices < 0 || vertices > MaxVertices || vertices != Math.Floor(vertices))
                    throw new ArgumentException("Mesh chunk upload requires a table and bounded integer counts.");
                int count = (int)requested, length = 0, expected = (int)vertices * VertexStride;
                // Validate the complete raw table before storage grows or accepted
                // geometry changes. Lua keeps every chunk rooted for this call.
                for (int i = 1; i <= count; i++)
                {
                    XLua.LuaDLL.Lua.xlua_rawgeti(state, 2, i);
                    try
                    {
                        if (XLua.LuaDLL.Lua.lua_type(state, -1) != XLua.LuaTypes.LUA_TSTRING)
                            throw new ArgumentException("Binary string payload required.");
                        XLua.LuaDLL.Lua.lua_tolstring(state, -1, out IntPtr nativeLength);
                        long size = nativeLength.ToInt64();
                        if (size < 0 || size % VertexStride != 0 || size > expected - length)
                            throw new ArgumentException("Invalid packed payload length.");
                        length += (int)size;
                    }
                    finally { XLua.LuaDLL.Lua.lua_pop(state, 1); }
                }
                if (length != expected) throw new ArgumentException("Invalid packed payload length.");
                if (buffer._packedBytes.Length < length)
                    buffer._packedBytes = new byte[Math.Min(MaxVertices * VertexStride, Math.Max(length, Math.Max(256, buffer._packedBytes.Length * 2)))];
                int offset = 0;
                for (int i = 1; i <= count; i++)
                {
                    XLua.LuaDLL.Lua.xlua_rawgeti(state, 2, i);
                    try
                    {
                        IntPtr pointer = XLua.LuaDLL.Lua.lua_tolstring(state, -1, out IntPtr nativeLength);
                        int size = (int)nativeLength.ToInt64();
                        if (size > 0) Marshal.Copy(pointer, buffer._packedBytes, offset, size);
                        offset += size;
                    }
                    finally { XLua.LuaDLL.Lua.lua_pop(state, 1); }
                }
                buffer.UploadCore(buffer._packedBytes, length, (int)vertices);
                return 0;
            }
            catch (Exception error) { return XLua.LuaDLL.Lua.luaL_error(state, error.Message); }
        }

        [XLua.MonoPInvokeCallback(typeof(XLuaBase.lua_CSFunction))]
        private static int UploadFromLua(IntPtr state)
        {
            try
            {
                var buffer = XLua.ObjectTranslatorPool.Instance.Find(state).GetObject(state, 1, typeof(ModuleMeshBuffer)) as ModuleMeshBuffer;
                if (buffer == null) throw new ArgumentException("Mesh buffer receiver required.");
                buffer.RequireUsable();
                if (XLua.LuaDLL.Lua.lua_gettop(state) != 3 || XLua.LuaDLL.Lua.lua_type(state, 3) != XLua.LuaTypes.LUA_TNUMBER)
                    throw new ArgumentException("Packed upload requires payload and vertex count.");
                double count = XLua.LuaDLL.Lua.lua_tonumber(state, 3);
                if (double.IsNaN(count) || count < 0 || count > MaxVertices || count != Math.Floor(count))
                    throw new ArgumentOutOfRangeException("vertexCount");
                int length = ModulePackedPayload.Copy(state, 2, ref buffer._packedBytes, MaxVertices * VertexStride, (int)count * VertexStride);
                buffer.UploadCore(buffer._packedBytes, length, (int)count);
                return 0;
            }
            catch (Exception error) { return XLua.LuaDLL.Lua.luaL_error(state, error.Message); }
        }

        internal ModuleMeshBuffer(Mesh borrowedMesh, Action<IDisposable> onDispose)
        {
            if (borrowedMesh == null) throw new ArgumentNullException(nameof(borrowedMesh));
            if (!borrowedMesh.isReadable) throw new ArgumentException("A CPU-readable runtime Mesh is required.", nameof(borrowedMesh));
            if (!BitConverter.IsLittleEndian) throw new PlatformNotSupportedException("The render batch ABI requires little-endian data.");
            if (Marshal.SizeOf<BatchVertex>() != VertexStride) throw new InvalidOperationException("Render vertex layout differs from the byte ABI.");
            _mesh = borrowedMesh;
            _onDispose = onDispose;
            _threadId = Thread.CurrentThread.ManagedThreadId;
            _mesh.MarkDynamic();
        }

        internal ModuleMeshBuffer(Components.ModuleMeshGraphic graphic, ModuleAssetScope scope, Action<IDisposable> onDispose)
        {
            if (graphic == null) throw new ArgumentNullException(nameof(graphic));
            if (scope == null || !scope.OwnsSceneTransform(graphic.transform))
                throw new InvalidOperationException("Graphic must belong to the current module.");
            if (!BitConverter.IsLittleEndian) throw new PlatformNotSupportedException("The render batch ABI requires little-endian data.");
            _graphic = graphic; _graphicScope = scope; _onDispose = onDispose;
            _threadId = Thread.CurrentThread.ManagedThreadId;
        }

        [Preserve]
        public void SetTriangles(int[] triangles)
        {
            RequireUsable();
            if (triangles == null || triangles.Length % 3 != 0 || triangles.Length > MaxTriangleIndices)
                throw new ArgumentException("Triangle array must contain bounded complete triples.", nameof(triangles));
            for (int i = 0; i < triangles.Length; i++)
                if (triangles[i] < 0 || (_configured && triangles[i] >= _vertexCount))
                    throw new ArgumentOutOfRangeException(nameof(triangles), "Triangle index is outside the vertex range.");
            var copy = new int[triangles.Length];
            Array.Copy(triangles, copy, copy.Length);
            if (_configured && _mesh != null) _mesh.SetTriangles(copy, 0, false);
            _triangles = copy;
            if (_configured && _graphic != null) _graphic.SetBuffer(this);
        }

        [Preserve]
        public void Upload(byte[] data, int vertexCount)
        {
            UploadCore(data, data == null ? -1 : data.Length, vertexCount);
        }

        private void UploadCore(byte[] data, int length, int vertexCount)
        {
            RequireUsable();
            if (vertexCount < 0 || vertexCount > MaxVertices)
                throw new ArgumentOutOfRangeException(nameof(vertexCount));
            if (data == null || length != vertexCount * VertexStride)
                throw new ArgumentException("Vertex payload length does not match the 76-byte ABI.", nameof(data));
            if (vertexCount == 0)
            {
                Clear();
                return;
            }
            foreach (int index in _triangles)
                if (index >= vertexCount)
                    throw new ArgumentOutOfRangeException(nameof(vertexCount), "Triangle index is outside the new vertex range.");

            // The Graphic can still render the last accepted payload after a
            // rejected upload. Decode into a separate buffer, publish atomically.
            var target = _graphicScope != null ? _pendingVertices : _vertices;
            if (target.Length < vertexCount) target = new BatchVertex[vertexCount];
            Vector3 minimum = Vector3.zero, maximum = Vector3.zero;
            for (int i = 0; i < vertexCount; i++)
            {
                int offset = i * VertexStride;
                var vertex = new BatchVertex {
                    position = ReadVector3(data, offset),
                    normal = ReadVector3(data, offset + 12),
                    tangent = ReadVector4(data, offset + 24),
                    color = new Color32(data[offset + 40], data[offset + 41], data[offset + 42], data[offset + 43]),
                    uv0 = ReadVector4(data, offset + 44),
                    uv1 = ReadVector4(data, offset + 60)
                };
                target[i] = vertex;
                if (i == 0) minimum = maximum = vertex.position;
                else { minimum = Vector3.Min(minimum, vertex.position); maximum = Vector3.Max(maximum, vertex.position); }
            }

            var bounds = new Bounds(
                new Vector3(Midpoint(minimum.x, maximum.x), Midpoint(minimum.y, maximum.y),
                    Midpoint(minimum.z, maximum.z)),
                new Vector3(Extent(minimum.x, maximum.x), Extent(minimum.y, maximum.y),
                    Extent(minimum.z, maximum.z)));
            bool resize = !_configured || _vertexCount != vertexCount;
            if (_graphicScope != null) _pendingVertices = _vertices;
            _vertices = target;
            if (_mesh != null)
            {
                if (resize) _mesh.SetVertexBufferParams(vertexCount, Layout);
                _mesh.SetVertexBufferData<BatchVertex>(_vertices, 0, 0, vertexCount, 0,
                    MeshUpdateFlags.DontRecalculateBounds);
                if (resize) _mesh.SetTriangles(_triangles, 0, false);
                _mesh.bounds = bounds;
            }
            _vertexCount = vertexCount;
            _configured = true;
            if (_graphic != null) _graphic.SetBuffer(this);
        }

        internal void PopulateGraphic(UnityEngine.UI.VertexHelper helper, Color tint)
        {
            if (_disposed || !_configured) return;
            for (int i = 0; i < _vertexCount; i++)
            {
                var source = _vertices[i];
                var vertex = UnityEngine.UIVertex.simpleVert;
                vertex.position = source.position; vertex.normal = source.normal; vertex.tangent = source.tangent;
                vertex.color = (Color)source.color * tint; vertex.uv0 = source.uv0; vertex.uv1 = source.uv1;
                helper.AddVert(vertex);
            }
            for (int i = 0; i < _triangles.Length; i += 3)
                helper.AddTriangle(_triangles[i], _triangles[i + 1], _triangles[i + 2]);
        }

        [Preserve]
        public void Clear()
        {
            RequireUsable();
            if (_mesh != null) _mesh.Clear();
            _vertexCount = 0;
            _configured = false;
            if (_graphic != null) _graphic.SetBuffer(this);
        }

        [Preserve]
        public void Dispose()
        {
            if (_disposed) return;
            RequireThread();
            _disposed = true;
            _vertices = Array.Empty<BatchVertex>();
            _pendingVertices = Array.Empty<BatchVertex>();
            _packedBytes = Array.Empty<byte>();
            _triangles = Array.Empty<int>();
            _mesh = null;
            if (_graphic != null) _graphic.ClearBuffer(this);
            _graphic = null;
            Action<IDisposable> onDispose = _onDispose;
            _onDispose = null;
            onDispose?.Invoke(this);
        }

        private static float Midpoint(float minimum, float maximum) =>
            (float)(((double)minimum + maximum) * 0.5d);

        private static float Extent(float minimum, float maximum)
        {
            double size = (double)maximum - minimum;
            if (size > float.MaxValue)
                throw new ArgumentOutOfRangeException("data", "Mesh bounds exceed the supported float range.");
            return (float)size;
        }

        private static Vector3 ReadVector3(byte[] data, int offset) =>
            new Vector3(ReadFloat(data, offset), ReadFloat(data, offset + 4), ReadFloat(data, offset + 8));

        private static Vector4 ReadVector4(byte[] data, int offset) =>
            new Vector4(ReadFloat(data, offset), ReadFloat(data, offset + 4),
                ReadFloat(data, offset + 8), ReadFloat(data, offset + 12));

        private static float ReadFloat(byte[] data, int offset)
        {
            float value = BitConverter.ToSingle(data, offset);
            if (float.IsNaN(value) || float.IsInfinity(value))
                throw new ArgumentException("Render payload contains a non-finite float.", nameof(data));
            return value;
        }

        private void RequireUsable()
        {
            RequireThread();
            if (_disposed) throw new ObjectDisposedException(nameof(ModuleMeshBuffer));
            if (_graphicScope != null)
            {
                if (_graphic == null || !_graphicScope.OwnsSceneTransform(_graphic.transform))
                    throw new InvalidOperationException("Bound Graphic is no longer a live object owned by this module.");
            }
            else if (_mesh == null) throw new InvalidOperationException("Borrowed Mesh was destroyed.");
        }

        private void RequireThread()
        {
            if (Thread.CurrentThread.ManagedThreadId != _threadId)
                throw new InvalidOperationException("Render batches must be used on their owning Unity thread.");
        }
    }

    // Read a Lua string only while its callback stack roots it. No pointer escapes
    // to Lua or survives the call; malformed/oversized input cannot grow storage.
    internal static class ModulePackedPayload
    {
        internal static int Copy(IntPtr state, int index, ref byte[] storage, int maximum, int expected = -1, int stride = 1)
        {
            if (XLua.LuaDLL.Lua.lua_type(state, index) != XLua.LuaTypes.LUA_TSTRING)
                throw new ArgumentException("Binary string payload required.");
            IntPtr pointer = XLua.LuaDLL.Lua.lua_tolstring(state, index, out IntPtr nativeLength);
            long size = nativeLength.ToInt64();
            if (size < 0 || size > maximum || size % stride != 0 || (expected >= 0 && size != expected))
                throw new ArgumentException("Invalid packed payload length.");
            int length = (int)size;
            if (storage.Length < length) storage = new byte[Math.Min(maximum, Math.Max(length, Math.Max(256, storage.Length * 2)))];
            if (length > 0) Marshal.Copy(pointer, storage, 0, length);
            return length;
        }
    }
}
