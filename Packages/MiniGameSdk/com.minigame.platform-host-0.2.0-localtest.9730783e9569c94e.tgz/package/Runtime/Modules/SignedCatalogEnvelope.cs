using System;

namespace MiniGamePlatform.HotUpdate
{
    [Serializable]
    public sealed class SignedCatalogEnvelope
    {
        public string keyId;
        public string payloadBase64;
        public string signatureBase64;
    }
}
