using System;
using MiniGamePlatform.SDK;
using MiniGamePlatform.SDK.Auth;
using MiniGamePlatform.SDK.Contracts;
using MiniGamePlatform.SDK.Host;
using UnityEngine;

namespace MiniGamePlatform.HotUpdate
{
    // Product shell component; never ship this component in a downloadable game prefab.
    [DisallowMultipleComponent]
    [UnityEngine.Scripting.APIUpdating.MovedFrom(true, null, "MiniGamePlatform.SDK", null)]
    public sealed class ModulePlayerBehaviour : MonoBehaviour
    {
        private ModulePlayer _player;
        private ProductContext _product;
        private PlatformSession _session;
        private bool _manualPause, _applicationPause;
        public event Action<Exception> Failed;
        public ModulePlayer Player => _player;

        public void Initialize(string source, string singleGameId, ProductContext product, PlatformSession session,
            IModuleContentKeyProvider keys = null)
        {
            InitializeWithHost(source, singleGameId, product, session,
                CommonModuleServiceFactory.CreateDefault(), keys);
        }

        public void InitializeWithHost(string source, string singleGameId, ProductContext product, PlatformSession session,
            IModuleHostServiceFactory serviceFactory, IModuleContentKeyProvider keys = null)
        {
            if (product == null) throw new ArgumentNullException(nameof(product));
            var player = new ModulePlayer(source, singleGameId, keys, serviceFactory);
            _player?.Exit();
            if (_player != null && _player.HasPendingExit)
                throw new InvalidOperationException("Complete the previous player's pending Exit before reinitializing the host.");
            _player = player; _product = product; _session = session; _manualPause = false;
        }
        public void OpenInstalled(string directory, string manifestSha256, string levelId, Action<string> status)
        {
            if (_player == null) throw new InvalidOperationException("Initialize the product shell first.");
            _player.OpenInstalled(directory, manifestSha256, _product, _session, levelId, status); ReconcilePause();
        }
        public void SetPaused(bool paused) { _manualPause = paused; ReconcilePause(); }
        public void Exit() { _player?.Exit(); }
        private void ReconcilePause()
        { if (_manualPause || _applicationPause || !isActiveAndEnabled) _player?.Pause(); else _player?.Resume(); }
        private void OnApplicationPause(bool paused) { _applicationPause = paused; ReconcilePause(); }
        private void OnEnable() => ReconcilePause();
        private void OnDisable() => ReconcilePause();
        private void Update()
        {
            try { _player?.Tick(); }
            catch (Exception e) { _player?.Exit(); Debug.LogException(e); Failed?.Invoke(e); }
        }
        private void LateUpdate()
        {
            try { _player?.LateTick(); }
            catch (Exception e) { _player?.Exit(); Debug.LogException(e); Failed?.Invoke(e); }
        }
        private void OnDestroy()
        {
            _player?.Exit();
            if (_player != null && _player.HasPendingExit)
            {
                // The shell must finish Exit before destroying its host. Preserve the reference
                // for an owner still holding this component; do not silently discard a live VM.
                if (_player.LastError != null)
                    Debug.LogWarning("Module host destroyed with a pending Lua exit. Release external callbacks; the shared host retains and retries cleanup.");
            }
            else _player = null;
            Failed = null;
        }
    }
}
