using System;
using System.Collections.Generic;
using System.Text;

namespace MiniGamePlatform.HotUpdate
{
    public sealed class VerifiedProductCatalog
    {
        private readonly byte[] _payload;
        private readonly bool _builtinFallback;
        public string ProductId { get; }
        public int CatalogVersion { get; }
        public bool IsBuiltinFallback => _builtinFallback;

        private VerifiedProductCatalog(byte[] payload, ProductModuleCatalog parsed, bool builtinFallback)
        {
            _payload = (byte[])payload.Clone();
            ProductId = parsed.productId;
            CatalogVersion = parsed.catalogVersion;
            _builtinFallback = builtinFallback;
        }

        internal static VerifiedProductCatalog FromSigned(byte[] payload, ProductModuleCatalog parsed)
        {
            return new VerifiedProductCatalog(payload, parsed, false);
        }

        internal static VerifiedProductCatalog FromBuiltin(byte[] payload, ProductModuleCatalog parsed)
        {
            return new VerifiedProductCatalog(payload, parsed, true);
        }

        public IReadOnlyList<ModuleRelease> Releases
        {
            get
            {
                string json = new UTF8Encoding(false, true).GetString(_payload);
                return _builtinFallback ? ProductModuleCatalog.Parse(json).releases :
                    ProductModuleCatalog.ParseV2(json).releases;
            }
        }

        public byte[] PayloadBytes() { return (byte[])_payload.Clone(); }
    }
}
