using System;
using System.Collections.Generic;
using MiniGamePlatform.SDK.Contracts;
using UnityEngine;

namespace MiniGamePlatform.HotUpdate
{
    // Stable services/resources bridge; legacy presentation and demos are isolated in Compatibility.
    public sealed partial class GameHostBridge : IDisposable
    {
        private readonly Action<string> _status;
        private readonly GameObject _root;
        private readonly ModuleAssetScope _assets;
        private readonly ModuleEventScope _events = new ModuleEventScope();
        private readonly List<IDisposable> _renderBatches = new List<IDisposable>();
        private bool _disposed;
        public string CurrentGameId { get; }
        public MiniGamePlatform.SDK.Contracts.IModuleHostServices Services { get; }
        public ModuleLaunchContext Launch { get; }
        public int ActiveCallbackCount => _events.ActiveCount;
        public bool SupportsRenderBatch => !_disposed && _assets != null &&
            CurrentGameId == _assets.GameId && _assets.SupportsCapability("unity_render_batch_v1", 7);

        public GameHostBridge(Action<string> status, ModuleAssetScope assets)
            : this(status, assets, null, null) { }

        public GameHostBridge(Action<string> status, ModuleAssetScope assets, string currentGameId, IModuleHostServices services)
            : this(status, assets, currentGameId, services, new ModuleLaunchContext("legacy", null, "")) { }

        public GameHostBridge(Action<string> status, ModuleAssetScope assets, string currentGameId,
            IModuleHostServices services, ModuleLaunchContext launch)
        {
            _status = status;
            _assets = assets;
            CurrentGameId = currentGameId;
            Services = services;
            Launch = launch ?? throw new ArgumentNullException(nameof(launch));
            _root = new GameObject("MiniGame Module Root");
            _assets?.TrackInstance(_root);
            InitializeCompatibility();
        }

        public void ShowMessage(string message) { _status?.Invoke(message); }

        [UnityEngine.Scripting.Preserve]
        public string ReadDataText(string relativePath)
        {
            if (_disposed) throw new ObjectDisposedException(nameof(GameHostBridge));
            if (_assets == null) throw new InvalidOperationException("Module data scope is unavailable.");
            if (CurrentGameId != _assets.GameId)
                throw new InvalidOperationException("Module bridge identity differs from its data scope.");
            return _assets.ReadDataText(relativePath);
        }

        public void TrackCallback(Action cancel) { _events.Track(cancel); }

        public Transform Root
        {
            get { if (_disposed) throw new ObjectDisposedException(nameof(GameHostBridge)); return _root.transform; }
        }

        // Register native instances created outside Root so the module exit barrier owns their destruction.
        public void TrackInstance(GameObject instance)
        {
            if (_disposed) throw new ObjectDisposedException(nameof(GameHostBridge));
            if (_assets == null || CurrentGameId != _assets.GameId) throw new InvalidOperationException("Module resource scope unavailable.");
            _assets.TrackInstance(instance);
        }

        [UnityEngine.Scripting.Preserve]
        public UnityEngine.Object LoadAsset(string bundlePath, string assetName, Type assetType)
        {
            if (_disposed) throw new ObjectDisposedException(nameof(GameHostBridge));
            if (_assets == null || CurrentGameId != _assets.GameId)
                throw new InvalidOperationException("Native asset scope is unavailable or mismatched.");
            _assets.RequireCapability(NativeLuaBaseline.Capability, 5);
            return _assets.LoadAsset(bundlePath, assetName, assetType);
        }

        [UnityEngine.Scripting.Preserve]
        public ModuleAssetRequest BeginLoadAsset(string bundlePath, string assetName, Type assetType)
        {
            if (_disposed) throw new ObjectDisposedException(nameof(GameHostBridge));
            if (_assets == null || CurrentGameId != _assets.GameId)
                throw new InvalidOperationException("Native asset scope is unavailable or mismatched.");
            _assets.RequireCapability(NativeLuaBaseline.Capability, 5);
            return _assets.BeginLoadAsset(bundlePath, assetName, assetType);
        }

        public GameObject SpawnPrefab(string bundlePath, string assetName)
        {
            if (_disposed) throw new ObjectDisposedException(nameof(GameHostBridge));
            if (_assets == null || CurrentGameId != _assets.GameId) throw new InvalidOperationException("Module resource scope unavailable.");
            return _assets.InstantiatePrefab(bundlePath, assetName, _root.transform);
        }

        [UnityEngine.Scripting.Preserve]
        public ModuleMeshBuffer CreateMeshBuffer(Mesh borrowedMesh)
        {
            RequireRenderBatch();
            var buffer = new ModuleMeshBuffer(borrowedMesh, UnregisterRenderBatch);
            _renderBatches.Add(buffer);
            return buffer;
        }

        [UnityEngine.Scripting.Preserve]
        public ModuleMeshBuffer CreateGraphicBuffer(Components.ModuleMeshGraphic graphic)
        {
            RequireRenderBatch();
            _assets.RequireCapability("unity_ugui_mesh_v1", 5);
            var buffer = new ModuleMeshBuffer(graphic, _assets, UnregisterRenderBatch);
            _renderBatches.Add(buffer);
            return buffer;
        }

        [UnityEngine.Scripting.Preserve]
        public ModuleTransformBatch CreateTransformBatch()
        {
            RequireRenderBatch();
            var batch = new ModuleTransformBatch(_assets, UnregisterRenderBatch);
            _renderBatches.Add(batch);
            return batch;
        }

        private void RequireRenderBatch()
        {
            if (_disposed) throw new ObjectDisposedException(nameof(GameHostBridge));
            if (!SupportsRenderBatch)
                throw new InvalidOperationException("Current module or host does not support unity_render_batch_v1.");
        }

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            // Disable native components while Lua is still alive, before deferred destruction.
            if (_root != null) _root.SetActive(false);
            while (_renderBatches.Count > 0)
                _renderBatches[_renderBatches.Count - 1].Dispose();
            DisposeCompatibility();
            _events.Dispose();
            DestroyOwned(_root);

        }

        private void UnregisterRenderBatch(IDisposable batch) { _renderBatches.Remove(batch); }

        private static void DestroyOwned(UnityEngine.Object value)
        {
            if (value == null) return;
#if UNITY_EDITOR
            if (!Application.isPlaying) { UnityEngine.Object.DestroyImmediate(value); return; }
#endif
            UnityEngine.Object.Destroy(value);
        }
    }
}
