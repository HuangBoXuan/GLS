#if UNITY_EDITOR || DEVELOPMENT_BUILD
using System;
using System.Security.Cryptography;
using UnityEngine.Networking;

namespace MiniGamePlatform.HotUpdate
{
    // Local Android HTTPS integration checks only. This class is absent from release builds.
    public static class DevelopmentLoopbackCertificatePin
    {
        public static string Sha256Hex { get; set; }

        public static void Configure(UnityWebRequest request, Uri url)
        {
            if (request == null || url == null || string.IsNullOrEmpty(Sha256Hex) ||
                !url.IsLoopback || url.Scheme != Uri.UriSchemeHttps) return;
            request.certificateHandler = new ExactCertificateHandler(Sha256Hex);
        }

        private sealed class ExactCertificateHandler : CertificateHandler
        {
            private readonly string _expected;
            public ExactCertificateHandler(string expected) { _expected = expected.ToLowerInvariant(); }

            protected override bool ValidateCertificate(byte[] certificateData)
            {
                if (certificateData == null) return false;
                using (SHA256 sha = SHA256.Create())
                {
                    string actual = BitConverter.ToString(sha.ComputeHash(certificateData))
                        .Replace("-", "").ToLowerInvariant();
                    return actual == _expected;
                }
            }
        }
    }
}
#endif
