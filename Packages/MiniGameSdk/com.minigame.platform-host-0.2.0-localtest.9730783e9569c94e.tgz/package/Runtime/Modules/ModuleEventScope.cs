using System;
using System.Collections.Generic;
using UnityEngine;

namespace MiniGamePlatform.HotUpdate
{
    public sealed class ModuleEventScope : IDisposable
    {
        private readonly List<Action> _cancellations = new List<Action>();
        private bool _disposed;
        public int ActiveCount => _cancellations.Count;

        public void Track(Action cancel)
        {
            if (cancel == null) throw new ArgumentNullException(nameof(cancel));
            if (_disposed) throw new ObjectDisposedException(nameof(ModuleEventScope));
            _cancellations.Add(cancel);
        }

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            for (int i = _cancellations.Count - 1; i >= 0; i--)
            {
                try { _cancellations[i](); }
                catch (Exception exception) { Debug.LogWarning("Module callback cancellation failed: " + exception.Message); }
            }
            _cancellations.Clear();
        }
    }
}
