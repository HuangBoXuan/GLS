using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using UnityEngine;

namespace MiniGamePlatform.HotUpdate
{
    // All access is on Unity's main thread. A scope leases the complete declared bundle set.
    // Identical verified plaintext shares a bundle even when stored in different module directories.
    internal static class ModuleBundleRegistry
    {
        internal sealed class Lease : IDisposable
        {
            private readonly Entry _entry;
            private bool _released;
            internal Lease(Entry entry) { _entry = entry; }
            public AssetBundle Bundle => !_released ? _entry.Bundle : throw new ObjectDisposedException(nameof(Lease));
            public void Dispose()
            {
                if (_released) return;
                if (_entry.Users == 1)
                {
                    // Mark the lease released only after Unity accepted the unload, so failure is retryable.
                    if (_entry.Bundle != null) _entry.Bundle.Unload(true);
                    Entries.Remove(_entry.Hash);
                }
                _entry.Users--;
                _released = true;
            }
        }
        internal sealed class Entry
        {
            public string Hash;
            public AssetBundle Bundle;
            public int Users;
        }
        private static readonly Dictionary<string, Entry> Entries = new Dictionary<string, Entry>(StringComparer.Ordinal);
        internal static Lease Acquire(byte[] verifiedPlaintext, Func<AssetBundle> load)
        {
            string hash;
            using (var sha = SHA256.Create())
                hash = BitConverter.ToString(sha.ComputeHash(verifiedPlaintext)).Replace("-", "");
            return AcquireVerifiedHash(hash, load);
        }
        internal static Lease Acquire(ModuleContentReader.VerifiedPlainFile verified, Func<AssetBundle> load)
        {
            return AcquireVerifiedHash(verified.Hash, load);
        }
        private static Lease AcquireVerifiedHash(string hash, Func<AssetBundle> load)
        {
            if (!Entries.TryGetValue(hash, out Entry entry))
            {
                AssetBundle bundle = load();
                if (bundle == null) throw new InvalidOperationException("Cannot load module bundle; check platform or a conflicting external bundle owner.");
                entry = new Entry { Hash = hash, Bundle = bundle };
                Entries.Add(hash, entry);
            }
            if (entry.Bundle == null) throw new InvalidOperationException("Module bundle was unloaded outside its owning host.");
            entry.Users++;
            return new Lease(entry);
        }
    }
}
