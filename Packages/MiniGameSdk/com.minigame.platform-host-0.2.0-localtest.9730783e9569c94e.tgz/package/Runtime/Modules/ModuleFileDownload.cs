using System;
using System.Collections;
using System.Globalization;
using System.IO;
using System.Text.RegularExpressions;
using UnityEngine;
using UnityEngine.Networking;

namespace MiniGamePlatform.HotUpdate
{
    // Host implementation: bounded disk-backed transfers; modules still see the same loading contract.
    internal static class ModuleFileDownload
    {
        private const long ChunkBytes = 4 * 1024 * 1024;
        private const int MaxRetries = 3;

        internal static bool Retryable(long status) => status == 0 || status == 408 || status == 429 || status >= 500 && status <= 599;
        internal static IEnumerator Backoff(int retry, ModuleInstallCancellation cancellation)
        {
            double end = Time.realtimeSinceStartupAsDouble + Math.Pow(2, retry - 1);
            while (!cancellation.IsCancellationRequested && (cancellation.IsPaused || Time.realtimeSinceStartupAsDouble < end))
                yield return null;
        }

        internal static IEnumerator Fetch(string url, ModuleFile file, string target, string partial,
            ModuleInstallCancellation cancellation, Action<long> progress, Action<string> failed)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(target));
            Directory.CreateDirectory(Path.GetDirectoryName(partial));
            if (ModuleInstaller.FileMatches(file, target)) { progress(file.size); yield break; }
            if (File.Exists(target)) File.Delete(target);
            if (Length(partial) > file.size) File.Delete(partial);
            if (file.size == 0 && !File.Exists(partial)) File.WriteAllBytes(partial, Array.Empty<byte>());
            int retries = 0;
            bool resetRange = false;
            bool http = new Uri(url).Scheme.StartsWith("http", StringComparison.Ordinal);
            while (!cancellation.IsCancellationRequested)
            {
                while (cancellation.IsPaused && !cancellation.IsCancellationRequested) yield return null;
                if (cancellation.IsCancellationRequested) yield break;
                long offset = Length(partial);
                if (File.Exists(partial) && offset == file.size)
                {
                    cancellation.Phase = "正在校验游戏内容…";
                    yield return null;
                    if (cancellation.IsCancellationRequested) yield break;
                    if (!ModuleInstaller.FileMatches(file, partial))
                    {
                        File.Delete(partial);
                        failed("HASH_MISMATCH " + file.path); yield break;
                    }
                    File.Move(partial, target);
                    progress(file.size);
                    yield break;
                }

                long end = Math.Min(file.size - 1, offset + ChunkBytes - 1);
                string responsePath = partial + ".response";
                if (File.Exists(responsePath)) File.Delete(responsePath); // Only this locked workspace owns it.
                var request = new UnityWebRequest(url, UnityWebRequest.kHttpVerbGET);
                request.downloadHandler = new DownloadHandlerFile(responsePath) { removeFileOnAbort = false };
                request.timeout = (int)Math.Min(900L, 120L + (file.size - offset) / (128 * 1024));
                if (http)
                {
                    request.SetRequestHeader("Range", "bytes=" + offset + "-" + end);
                    request.SetRequestHeader("Accept-Encoding", "identity");
                }
#if UNITY_EDITOR || DEVELOPMENT_BUILD
                DevelopmentLoopbackCertificatePin.Configure(request, new Uri(url));
#endif
                int pauseVersion = cancellation.PauseVersion;
                long status = 0;
                string error = null, protocolError = null;
                bool success = false, stalled = false;
                double started = Time.realtimeSinceStartupAsDouble, lastProgress = started, lastLog = started;
                ulong received = 0;
                using (cancellation.Track(request))
                {
                    try
                    {
                        Debug.Log("[ModuleDownload] begin file=" + file.path + " offset=" + offset + " end=" + end);
                        var operation = request.SendWebRequest();
                        while (!operation.isDone)
                        {
                            if (cancellation.IsCancellationRequested || cancellation.IsPaused) { request.Abort(); break; }
                            if (request.downloadedBytes != received) { received = request.downloadedBytes; lastProgress = Time.realtimeSinceStartupAsDouble; }
                            long responseLimit = request.responseCode == 206 ? end - offset + 1 : file.size;
                            if (received > (ulong)responseLimit) { protocolError = "RESPONSE_TOO_LARGE"; request.Abort(); break; }
                            if (Time.realtimeSinceStartupAsDouble - lastProgress > 45) { stalled = true; request.Abort(); break; }
                            long current = Math.Min(file.size, (request.responseCode == 200 ? 0 : offset) + (long)received);
                            cancellation.Phase = "正在下载 " + Path.GetFileName(file.path) + "（" +
                                (current / 1048576d).ToString("F1") + "/" + (file.size / 1048576d).ToString("F1") + " MB）";
                            progress(current);
                            if (Time.realtimeSinceStartupAsDouble - lastLog >= 5)
                            {
                                lastLog = Time.realtimeSinceStartupAsDouble;
                                Debug.Log("[ModuleDownload] progress file=" + file.path + " received=" + current + "/" + file.size +
                                    " segmentBytes=" + received + " seconds=" + (lastLog - started).ToString("F1"));
                            }
                            yield return null;
                        }
                        status = request.responseCode;
                        success = request.result == UnityWebRequest.Result.Success;
                        error = stalled ? "NO_PROGRESS_TIMEOUT" : request.error;
                    }
                    finally
                    {
                        // This also runs when a coroutine is disposed on cancel/disable. Flush before retaining the prefix.
                        if (!request.isDone) request.Abort();
                        status = request.responseCode;
                        string range = request.GetResponseHeader("Content-Range");
                        string encoding = request.GetResponseHeader("Content-Encoding");
                        string length = request.GetResponseHeader("Content-Length");
                        request.Dispose();
                        try
                        {
                            if (protocolError == null && File.Exists(responsePath))
                                protocolError = RetainResponse(partial, responsePath, file.size, offset, end, status, range, length, encoding, http);
                        }
                        catch (Exception e) when (e is IOException || e is UnauthorizedAccessException)
                        { protocolError = "DISK_WRITE_FAILED: " + e.Message; }
                        finally {
                            try { if (File.Exists(responsePath)) File.Delete(responsePath); }
                            catch (Exception e) when (e is IOException || e is UnauthorizedAccessException)
                            { Debug.LogWarning("Download fragment cleanup: " + e.Message); }
                        }
                        Debug.Log("[ModuleDownload] end file=" + file.path + " http=" + status + " saved=" + Length(partial) +
                            "/" + file.size + " seconds=" + (Time.realtimeSinceStartupAsDouble - started).ToString("F2") +
                            " error=" + (protocolError ?? error ?? "none"));
                    }
                }
                if (cancellation.IsCancellationRequested) yield break;
                if (protocolError != null) { failed(protocolError + " " + file.path); yield break; }
                if (cancellation.PauseVersion != pauseVersion) continue; // Explicit pause does not spend retry budget.
                if (Length(partial) == file.size) continue; // Full hash, not transport success, decides acceptance.
                if (status == 416 && offset > 0 && !resetRange)
                {
                    File.Delete(partial); resetRange = true; continue;
                }
                if (success)
                {
                    if (Length(partial) <= offset) { failed("NO_DOWNLOAD_PROGRESS " + file.path); yield break; }
                    retries = 0;
                    continue;
                }
                if (!(Retryable(status) || status == 200 || status == 206) || retries >= MaxRetries)
                {
                    failed("HTTP " + status + " " + file.path + ": " + error); yield break;
                }
                retries++;
                cancellation.Phase = "连接中断，保留进度重试（" + retries + "/" + MaxRetries + "）…";
                Debug.LogWarning("[ModuleDownload] retry=" + retries + " http=" + status + " file=" + file.path + " error=" + error);
                yield return Backoff(retries, cancellation);
            }
        }

        private static string RetainResponse(string partial, string response, long expected, long offset, long requestedEnd,
            long status, string contentRange, string contentLength, string encoding, bool http)
        {
            long bytes = Length(response);
            if (status != 200 && status != 206 && !(status == 0 && !http)) return null;
            if (!string.IsNullOrEmpty(encoding) && !string.Equals(encoding, "identity", StringComparison.OrdinalIgnoreCase))
                return "UNSUPPORTED_CONTENT_ENCODING";
            if (status == 206)
            {
                Match match = Regex.Match(contentRange ?? "", @"^bytes (\d+)-(\d+)/(\d+)$", RegexOptions.CultureInvariant);
                if (!match.Success || !long.TryParse(match.Groups[1].Value, out long start) ||
                    !long.TryParse(match.Groups[2].Value, out long end) || !long.TryParse(match.Groups[3].Value, out long total) ||
                    start != offset || total != expected || end < start || end > requestedEnd || end >= expected ||
                    bytes > end - start + 1 || Length(partial) != offset)
                    return "INVALID_CONTENT_RANGE";
                if (bytes == 0) return null;
                using (var destination = new FileStream(partial, FileMode.Append, FileAccess.Write, FileShare.None))
                using (var source = File.OpenRead(response)) source.CopyTo(destination, 65536);
            }
            else
            {
                // A CDN may ignore Range and return 200. Replace the prefix; never append an entire object to it.
                if (bytes > expected || http && !string.IsNullOrEmpty(contentLength) &&
                    (!long.TryParse(contentLength, NumberStyles.None, CultureInfo.InvariantCulture, out long declared) || declared != expected))
                    return "INVALID_CONTENT_LENGTH";
                if (bytes == 0) return null;
                if (File.Exists(partial)) File.Delete(partial);
                File.Move(response, partial);
            }
            return null;
        }

        private static long Length(string path) => File.Exists(path) ? new FileInfo(path).Length : 0;
    }
}
