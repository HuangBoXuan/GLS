using System;
using System.IO;
using UnityEngine;
using MiniGamePlatform.SDK;
using MiniGamePlatform.SDK.Auth;
using MiniGamePlatform.SDK.Host;
using MiniGamePlatform.SDK.Contracts;
using XLua;

namespace MiniGamePlatform.HotUpdate
{

    public sealed partial class LuaGameRunner : IModuleRuntime
    {
        private LuaEnv _environment;
        private LuaTable _module;
        private LuaFunction _update;
        private LuaFunction _lateUpdate;
        private LuaFunction _pause;
        private LuaFunction _resume;
        private LuaFunction _exit;
        private GameHostBridge _bridge;
        private ModuleAssetScope _assets;
        private IModuleHostServices _services;
        private double _nextAutomaticExitRetryAt;
        private double _exitRetryDelay = 0.25;
        private readonly IModuleContentKeyProvider _contentKeys;
        private readonly IModuleHostServiceFactory _serviceFactory;
        public LuaGameRunner(IModuleContentKeyProvider contentKeys = null)
            : this(contentKeys, CommonModuleServiceFactory.CreateDefault()) { }

        public LuaGameRunner(IModuleContentKeyProvider contentKeys, IModuleHostServiceFactory serviceFactory)
        {
            _contentKeys = contentKeys;
            _serviceFactory = serviceFactory ?? throw new ArgumentNullException(nameof(serviceFactory));
        }
        public GameRunState State { get; private set; }
        public bool HasPendingExit => State == GameRunState.Empty &&
            (_environment != null || (_assets != null && !_assets.IsReleaseComplete));
        public ModuleRunException LastError { get; private set; }
        public string CurrentGameId { get; private set; }
        public int SuccessfulTicks { get; private set; }

        public void Enter(ModuleManifest manifest, string directory, Action<string> status)
        {
            Enter(manifest, directory, status, null, null);
        }

        public void Enter(ModuleManifest manifest, string directory, Action<string> status, ProductContext product, PlatformSession session)
        {
            Enter(manifest, directory, status, product, session,
                new ModuleLaunchContext("legacy", null, manifest?.version ?? ""));
        }

        public void Enter(ModuleManifest manifest, string directory, Action<string> status,
            ProductContext product, PlatformSession session, ModuleLaunchContext launch)
        {
            Exit();
            if (HasPendingExit)
                throw new ModuleRunException("EXIT_PENDING", "exit", (Exception)LastError ??
                    new InvalidOperationException("Previous Lua callbacks and owned resources must finish releasing before another module can enter."));
            LastError = null;
            if (manifest == null) throw new ArgumentNullException(nameof(manifest));
            if (launch == null) throw new ArgumentNullException(nameof(launch));
            if (launch.ModuleVersion != manifest.version)
                throw new InvalidDataException("Launch module version differs from manifest.");
            if (product != null && !product.AllowsGame(manifest.gameId))
                throw new InvalidDataException("Module is not allowed by this product.");
            if (!HostProfile.Current.Supports(manifest, out string incompatibility))
                throw new InvalidDataException(incompatibility);
            if (!ModuleInstaller.IsValid(manifest, directory))
                throw new InvalidDataException("Installed module failed verification.");

            try
            {
                var content = new ModuleContentReader(manifest, directory, _contentKeys);
                _assets = new ModuleAssetScope(manifest, directory, _contentKeys);
                _services = _serviceFactory.CreateServices(manifest, product, session);
                _bridge = new GameHostBridge(status, _assets, manifest.gameId, _services, launch);
                _environment = new LuaEnv();
                string prefix = "games." + manifest.gameId + ".";
                _environment.AddLoader((ref string name, ModuleLuaBuffer buffer) =>
                {
                    if (!name.StartsWith(prefix, StringComparison.Ordinal)) return false;
                    string relative = name.Replace('.', '/') + ".lua";
                    if (!ModuleManifest.IsSafeRelativePath(relative)) return false;
                    string path = Path.Combine(directory, relative.Replace('/', Path.DirectorySeparatorChar));
                    if (!File.Exists(path)) return false;
                    var plain = content.Read(relative);
                    try { buffer.Copy(plain); }
                    finally { Array.Clear(plain, 0, plain.Length); }
                    return true;
                });
                object[] result = _environment.DoString("return require('" + manifest.entry + "')", manifest.entry);
                _module = result.Length > 0 ? result[0] as LuaTable : null;
                if (_module == null) throw new InvalidDataException("Lua entry must return a table.");
                _update = _module.Get<LuaFunction>("update");
                _lateUpdate = _module.Get<LuaFunction>("late_update");
                _pause = _module.Get<LuaFunction>("pause");
                _resume = _module.Get<LuaFunction>("resume");
                _exit = _module.Get<LuaFunction>("exit");
                using (LuaFunction enter = _module.Get<LuaFunction>("enter"))
                {
                    if (enter == null) throw new InvalidDataException("Lua entry must define enter(host).");
                    enter.Call(_bridge);
                }
                State = GameRunState.Running;
                CurrentGameId = manifest.gameId;
            }
            catch (Exception exception)
            {
                Exit();
                LastError = new ModuleRunException("ENTER_FAILED", "enter", exception);
                throw LastError;
            }
        }

        public void Tick()
        {
            // Pending exits belong to the persistent host driver, not both player Update and driver Update.
            if (State == GameRunState.Empty) return;
            try
            {
                (_services as IModuleServicePump)?.Pump();
                _environment?.Tick();
                if (State == GameRunState.Running)
                {
                    _update?.Action<float>(Time.deltaTime);
                    SuccessfulTicks++;
                }
            }
            catch (Exception exception) { throw FailAndExit("UPDATE_FAILED", "update", exception); }
        }

        public void Pause()
        {
            if (State != GameRunState.Running) return;
            try
            {
                _bridge?.SetPresentationPaused(true);
                _pause?.Call();
                State = GameRunState.Paused;
            }
            catch (Exception exception) { throw FailAndExit("PAUSE_FAILED", "pause", exception); }
        }

        public void LateTick()
        {
            if (State != GameRunState.Running) return;
            try { _lateUpdate?.Action<float>(Time.deltaTime); }
            catch (Exception exception) { throw FailAndExit("LATE_UPDATE_FAILED", "late_update", exception); }
        }

        public void Resume()
        {
            if (State != GameRunState.Paused) return;
            try
            {
                _resume?.Call();
                _bridge?.SetPresentationPaused(false);
                State = GameRunState.Running;
            }
            catch (Exception exception) { throw FailAndExit("RESUME_FAILED", "resume", exception); }
        }

        private ModuleRunException FailAndExit(string code, string phase, Exception cause)
        {
            Exit();
            // Keep the primary failure even when the Lua exit callback also fails.
            LastError = new ModuleRunException(code, phase, cause);
            return LastError;
        }

        public void Exit()
        {
            _bridge?.SetPresentationPaused(true);
            State = GameRunState.Empty;
            CurrentGameId = null;
            SuccessfulTicks = 0;
            Exception failure = null;
            try
            {
                if (_module != null) _exit?.Call();
            }
            catch (Exception exception) { failure = exception; }
            TryDispose(_exit, ref failure); _exit = null;
            TryDispose(_resume, ref failure); _resume = null;
            TryDispose(_pause, ref failure); _pause = null;
            TryDispose(_update, ref failure); _update = null;
            TryDispose(_lateUpdate, ref failure); _lateUpdate = null;
            TryDispose(_module, ref failure); _module = null;
            // Cancel native events while their Lua callbacks can still execute.
            TryDispose(_bridge, ref failure); _bridge = null;
            TryDispose(_services, ref failure); _services = null;
            if (_environment != null)
            {
                try
                {
                    _environment.Dispose(); _environment = null;
                    _nextAutomaticExitRetryAt = 0; _exitRetryDelay = 0.25;
                }
                catch (Exception exception)
                {
                    // XLua disposal collects managed and Lua objects before checking external delegates.
                    // A leaked external callback must not cause blocking full collections every frame.
                    _nextAutomaticExitRetryAt = Time.realtimeSinceStartupAsDouble + _exitRetryDelay;
                    _exitRetryDelay = Math.Min(2.0, _exitRetryDelay * 2.0);
                    if (failure == null) failure = exception;
                }
            }
            // A live Lua VM may still reference bundle assets. Keep the whole scope until VM disposal succeeds.
            if (_environment == null && _assets != null)
            {
                TryDispose(_assets, ref failure);
                if (_assets.ReleaseError != null && failure == null) failure = _assets.ReleaseError;
                if (_assets.IsReleaseComplete) _assets = null;
            }
            if (failure != null)
                LastError = new ModuleRunException("LUA_EXIT_FAILED", "exit", failure);
            else if (!HasPendingExit && LastError?.Code == "LUA_EXIT_FAILED") LastError = null;
            if (HasPendingExit && Application.isPlaying) ModuleResourceReclaimer.ScheduleExit(this);
        }

        internal void AdvancePendingExit()
        {
            if (!HasPendingExit) return;
            if (_environment != null && Time.realtimeSinceStartupAsDouble < _nextAutomaticExitRetryAt) return;
            Exit();
        }

        private static void TryDispose(IDisposable resource, ref Exception failure)
        {
            try { resource?.Dispose(); }
            catch (Exception exception)
            {
                if (failure == null) failure = exception;
            }
        }

        public void Dispose() { Exit(); }
    }
}
