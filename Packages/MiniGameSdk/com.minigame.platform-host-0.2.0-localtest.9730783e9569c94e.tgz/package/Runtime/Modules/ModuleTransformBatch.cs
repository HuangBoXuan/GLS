using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Threading;
using UnityEngine;
using UnityEngine.Scripting;

namespace MiniGamePlatform.HotUpdate
{
    [Preserve]
    public sealed class ModuleTransformBatch : IDisposable
    {
        public const int RecordStride = 48;
        public const int PositionFlag = 1;
        public const int RotationFlag = 2;
        public const int ScaleFlag = 4;
        public const int WorldSpaceFlag = 8;
        private const int MaxRecords = 16384;
        private ModuleAssetScope _assets;
        private Action<IDisposable> _onDispose;
        private readonly int _threadId;
        private readonly List<Transform> _targets = new List<Transform>();
        private readonly Dictionary<int, int> _handles = new Dictionary<int, int>();
        private Record[] _records = Array.Empty<Record>();
        private bool _disposed;
        private byte[] _packedBytes = Array.Empty<byte>();
        private static readonly XLuaBase.lua_CSFunction PackedApply = ApplyFromLua;
        [Preserve] public XLuaBase.lua_CSFunction ApplyPacked => PackedApply;
        private static readonly XLuaBase.lua_CSFunction ChunkApply = ApplyChunksFromLua;
        [Preserve] public XLuaBase.lua_CSFunction ApplyPackedChunks => ChunkApply;

        [XLua.MonoPInvokeCallback(typeof(XLuaBase.lua_CSFunction))]
        private static int ApplyChunksFromLua(IntPtr state)
        {
            try
            {
                var batch = XLua.ObjectTranslatorPool.Instance.Find(state).GetObject(state, 1, typeof(ModuleTransformBatch)) as ModuleTransformBatch;
                if (batch == null) throw new ArgumentException("Transform batch receiver required.");
                batch.RequireUsable();
                if (XLua.LuaDLL.Lua.lua_gettop(state) != 3 ||
                    XLua.LuaDLL.Lua.lua_type(state, 2) != XLua.LuaTypes.LUA_TTABLE ||
                    XLua.LuaDLL.Lua.lua_type(state, 3) != XLua.LuaTypes.LUA_TNUMBER)
                    throw new ArgumentException("Chunk upload requires a table and bounded integer count.");
                double requested = XLua.LuaDLL.Lua.lua_tonumber(state, 3);
                if (double.IsNaN(requested) || requested < 0 || requested > MaxRecords || requested != Math.Floor(requested))
                    throw new ArgumentException("Chunk upload requires a table and bounded integer count.");
                int count = (int)requested, length = 0;
                // Validate all lengths before allocating. Raw reads never invoke
                // Lua metamethods, and the table roots every string for this call.
                for (int i = 1; i <= count; i++)
                {
                    XLua.LuaDLL.Lua.xlua_rawgeti(state, 2, i);
                    try
                    {
                        if (XLua.LuaDLL.Lua.lua_type(state, -1) != XLua.LuaTypes.LUA_TSTRING)
                            throw new ArgumentException("Binary string payload required.");
                        XLua.LuaDLL.Lua.lua_tolstring(state, -1, out IntPtr nativeLength);
                        long size = nativeLength.ToInt64();
                        if (size < 0 || size % RecordStride != 0 || size > MaxRecords * RecordStride - length)
                            throw new ArgumentException("Invalid packed payload length.");
                        length += (int)size;
                    }
                    finally { XLua.LuaDLL.Lua.lua_pop(state, 1); }
                }
                if (batch._packedBytes.Length < length)
                    batch._packedBytes = new byte[Math.Min(MaxRecords * RecordStride, Math.Max(length, Math.Max(256, batch._packedBytes.Length * 2)))];
                int offset = 0;
                for (int i = 1; i <= count; i++)
                {
                    XLua.LuaDLL.Lua.xlua_rawgeti(state, 2, i);
                    try
                    {
                        IntPtr pointer = XLua.LuaDLL.Lua.lua_tolstring(state, -1, out IntPtr nativeLength);
                        int size = (int)nativeLength.ToInt64();
                        if (size > 0) Marshal.Copy(pointer, batch._packedBytes, offset, size);
                        offset += size;
                    }
                    finally { XLua.LuaDLL.Lua.lua_pop(state, 1); }
                }
                // Includes finite values, ownership and handle validation of ALL
                // records before the first native write, as in the old ABI.
                batch.ApplyCore(batch._packedBytes, length);
                return 0;
            }
            catch (Exception error) { return XLua.LuaDLL.Lua.luaL_error(state, error.Message); }
        }

        [XLua.MonoPInvokeCallback(typeof(XLuaBase.lua_CSFunction))]
        private static int ApplyFromLua(IntPtr state)
        {
            try
            {
                var batch = XLua.ObjectTranslatorPool.Instance.Find(state).GetObject(state, 1, typeof(ModuleTransformBatch)) as ModuleTransformBatch;
                if (batch == null) throw new ArgumentException("Transform batch receiver required.");
                batch.RequireUsable();
                if (XLua.LuaDLL.Lua.lua_gettop(state) != 2) throw new ArgumentException("Packed apply requires one payload.");
                int length = ModulePackedPayload.Copy(state, 2, ref batch._packedBytes, MaxRecords * RecordStride, stride: RecordStride);
                batch.ApplyCore(batch._packedBytes, length);
                return 0;
            }
            catch (Exception error) { return XLua.LuaDLL.Lua.luaL_error(state, error.Message); }
        }

        private struct Record
        {
            public Transform target;
            public int flags;
            public Vector3 position;
            public Quaternion rotation;
            public Vector3 scale;
        }

        internal ModuleTransformBatch(ModuleAssetScope assets, Action<IDisposable> onDispose)
        {
            _assets = assets ?? throw new ArgumentNullException(nameof(assets));
            _onDispose = onDispose;
            if (!BitConverter.IsLittleEndian) throw new PlatformNotSupportedException("The render batch ABI requires little-endian data.");
            _threadId = Thread.CurrentThread.ManagedThreadId;
        }

        [Preserve]
        public int Bind(Transform target)
        {
            RequireUsable();
            if (!_assets.OwnsSceneTransform(target))
                throw new ArgumentException("Transform must be a live scene object owned by this module.", nameof(target));
            int id = target.GetInstanceID();
            if (_handles.TryGetValue(id, out int handle))
            {
                if (ReferenceEquals(_targets[handle - 1], target)) return handle;
                _handles.Remove(id);
            }
            handle = _targets.Count + 1;
            _targets.Add(target);
            _handles.Add(id, handle);
            return handle;
        }

        [Preserve]
        public void Apply(byte[] data)
        {
            ApplyCore(data, data == null ? -1 : data.Length);
        }

        private void ApplyCore(byte[] data, int length)
        {
            RequireUsable();
            if (data == null || length % RecordStride != 0 || length / RecordStride > MaxRecords)
                throw new ArgumentException("Transform payload must contain bounded 48-byte records.", nameof(data));
            int count = length / RecordStride;
            if (_records.Length < count) _records = new Record[count];
            for (int i = 0; i < count; i++)
            {
                int offset = i * RecordStride;
                int handle = BitConverter.ToInt32(data, offset);
                int flags = BitConverter.ToInt32(data, offset + 4);
                if (handle <= 0 || handle > _targets.Count) throw new ArgumentOutOfRangeException(nameof(data), "Unknown Transform handle.");
                if ((flags & ~15) != 0 || ((flags & WorldSpaceFlag) != 0 && (flags & (PositionFlag | RotationFlag)) == 0))
                    throw new ArgumentException("Invalid Transform update flags.", nameof(data));
                Transform target = _targets[handle - 1];
                if (!_assets.OwnsSceneTransform(target))
                    throw new InvalidOperationException("Bound Transform is no longer a live object owned by this module.");
                var record = new Record { target = target, flags = flags };
                if ((flags & PositionFlag) != 0) record.position = ReadVector3(data, offset + 8);
                if ((flags & RotationFlag) != 0)
                {
                    Vector4 q = ReadVector4(data, offset + 20);
                    if (q.sqrMagnitude < 1e-12f) throw new ArgumentException("Rotation must be nonzero.", nameof(data));
                    record.rotation = new Quaternion(q.x, q.y, q.z, q.w);
                }
                if ((flags & ScaleFlag) != 0) record.scale = ReadVector3(data, offset + 36);
                _records[i] = record;
            }

            for (int i = 0; i < count; i++)
            {
                Record record = _records[i];
                bool world = (record.flags & WorldSpaceFlag) != 0;
                bool pose = (record.flags & (PositionFlag | RotationFlag)) == (PositionFlag | RotationFlag);
                if (pose)
                {
                    if (world) record.target.SetPositionAndRotation(record.position, record.rotation);
                    else record.target.SetLocalPositionAndRotation(record.position, record.rotation);
                }
                else if ((record.flags & PositionFlag) != 0)
                {
                    if (world) record.target.position = record.position;
                    else record.target.localPosition = record.position;
                }
                if (!pose && (record.flags & RotationFlag) != 0)
                {
                    if (world) record.target.rotation = record.rotation;
                    else record.target.localRotation = record.rotation;
                }
                if ((record.flags & ScaleFlag) != 0) record.target.localScale = record.scale;
            }
        }

        [Preserve]
        public void Clear()
        {
            RequireUsable();
            _targets.Clear();
            _handles.Clear();
            _records = Array.Empty<Record>();
            _packedBytes = Array.Empty<byte>();
        }

        [Preserve]
        public void Dispose()
        {
            if (_disposed) return;
            RequireThread();
            _disposed = true;
            _targets.Clear();
            _handles.Clear();
            _records = Array.Empty<Record>();
            _packedBytes = Array.Empty<byte>();
            _assets = null;
            Action<IDisposable> onDispose = _onDispose;
            _onDispose = null;
            onDispose?.Invoke(this);
        }

        private static Vector3 ReadVector3(byte[] data, int offset) =>
            new Vector3(ReadFloat(data, offset), ReadFloat(data, offset + 4), ReadFloat(data, offset + 8));

        private static Vector4 ReadVector4(byte[] data, int offset) =>
            new Vector4(ReadFloat(data, offset), ReadFloat(data, offset + 4),
                ReadFloat(data, offset + 8), ReadFloat(data, offset + 12));

        private static float ReadFloat(byte[] data, int offset)
        {
            float value = BitConverter.ToSingle(data, offset);
            if (float.IsNaN(value) || float.IsInfinity(value))
                throw new ArgumentException("Transform payload contains a non-finite float.", nameof(data));
            return value;
        }

        private void RequireUsable()
        {
            RequireThread();
            if (_disposed) throw new ObjectDisposedException(nameof(ModuleTransformBatch));
        }

        private void RequireThread()
        {
            if (Thread.CurrentThread.ManagedThreadId != _threadId)
                throw new InvalidOperationException("Render batches must be used on their owning Unity thread.");
        }
    }
}
