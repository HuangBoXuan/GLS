using System;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace MiniGamePlatform.HotUpdate
{
    public sealed class CatalogCache
    {
        private readonly string _root;
        private readonly string _productId;
        private readonly CatalogTrustKey _key;
        private struct HighestState
        {
            public int Version;
            public string PayloadSha256;
        }
        public string EnvelopePath => Path.Combine(_root, "catalog.signed.json");
        private string HighestPath => Path.Combine(_root, "highest-version.txt");

        public CatalogCache(string root, string productId, CatalogTrustKey key)
        {
            if (string.IsNullOrWhiteSpace(root) || string.IsNullOrWhiteSpace(productId) || key == null)
                throw new ArgumentException("Catalog cache requires a root, product and trust key.");
            _root = root;
            _productId = productId;
            _key = key;
        }

        public bool TryRead(out VerifiedProductCatalog catalog)
        {
            catalog = null;
            HighestState highest = ReadHighest();
            foreach (string path in new[] { EnvelopePath, EnvelopePath + ".backup" })
            {
                if (!File.Exists(path)) continue;
                try
                {
                    long length = new FileInfo(path).Length;
                    if (length == 0 || length > CatalogSignatureVerifier.MaxEnvelopeBytes) continue;
                    var candidate = CatalogSignatureVerifier.Verify(File.ReadAllBytes(path), _key, _productId);
                    if (candidate.CatalogVersion < highest.Version ||
                        (candidate.CatalogVersion == highest.Version && highest.PayloadSha256 != null &&
                         !string.Equals(Hash(candidate.PayloadBytes()), highest.PayloadSha256,
                             StringComparison.OrdinalIgnoreCase))) continue;
                    catalog = candidate;
                    return true;
                }
                catch (Exception exception) when (exception is IOException || exception is UnauthorizedAccessException ||
                                               exception is InvalidDataException) { }
            }
            return false;
        }

        public int HighestAcceptedVersion()
        {
            return ReadHighest().Version;
        }

        private HighestState ReadHighest()
        {
            if (!File.Exists(HighestPath)) return new HighestState();
            try
            {
                string[] parts = File.ReadAllText(HighestPath, Encoding.ASCII).Trim().Split('\n');
                if (!int.TryParse(parts[0].Trim(), NumberStyles.None, CultureInfo.InvariantCulture,
                        out int version) || version <= 0 || parts.Length > 2)
                    return new HighestState { Version = int.MaxValue };
                string hash = parts.Length == 2 ? parts[1].Trim() : null;
                if (hash != null && (hash.Length != 64 || !IsHex(hash)))
                    return new HighestState { Version = int.MaxValue };
                return new HighestState { Version = version, PayloadSha256 = hash };
            }
            catch (IOException) { return new HighestState { Version = int.MaxValue }; }
            catch (UnauthorizedAccessException) { return new HighestState { Version = int.MaxValue }; }
        }

        public VerifiedProductCatalog ReplaceVerified(byte[] envelopeBytes)
        {
            VerifiedProductCatalog candidate = CatalogSignatureVerifier.Verify(envelopeBytes, _key, _productId);
            HighestState persisted = ReadHighest();
            int persistedHighest = persisted.Version;
            bool hasAccepted = TryRead(out VerifiedProductCatalog accepted);
            int highest = hasAccepted ? Math.Max(persistedHighest, accepted.CatalogVersion) : persistedHighest;
            if (candidate.CatalogVersion < highest)
                throw new InvalidDataException("Signed catalog version is older than the accepted version.");
            if (candidate.CatalogVersion == persistedHighest &&
                (persisted.PayloadSha256 == null && !hasAccepted ||
                 persisted.PayloadSha256 != null &&
                 !string.Equals(Hash(candidate.PayloadBytes()), persisted.PayloadSha256,
                     StringComparison.OrdinalIgnoreCase)))
                throw new InvalidDataException("Signed catalog version was reused after the cache was lost.");
            if (candidate.CatalogVersion == highest && hasAccepted &&
                !SameBytes(candidate.PayloadBytes(), accepted.PayloadBytes()))
                throw new InvalidDataException("Signed catalog version was reused for different content.");
            if (hasAccepted)
                foreach (ModuleRelease newer in candidate.Releases)
                    foreach (ModuleRelease older in accepted.Releases)
                        if (newer.gameId == older.gameId && newer.version == older.version &&
                            (!string.Equals(newer.manifestSha256, older.manifestSha256,
                                StringComparison.OrdinalIgnoreCase) ||
                             newer.runtimeType != older.runtimeType || newer.platform != older.platform ||
                             newer.unityVersion != older.unityVersion ||
                             newer.minHostApiVersion != older.minHostApiVersion ||
                             !SameCapabilities(newer.requiredCapabilities, older.requiredCapabilities)))
                            throw new InvalidDataException("Immutable module release changed across catalogs.");
            Directory.CreateDirectory(_root);
            // Persist the version and payload fingerprint first. A crash before the envelope swap
            // may require an online repair, but cannot admit different bytes under that version.
            if (candidate.CatalogVersion > persistedHighest || persisted.PayloadSha256 == null)
            {
                string highestStage = HighestPath + ".stage";
                File.WriteAllText(highestStage, candidate.CatalogVersion.ToString(CultureInfo.InvariantCulture) +
                    "\n" + Hash(candidate.PayloadBytes()), Encoding.ASCII);
                AtomicReplace(highestStage, HighestPath);
            }
            string stage = EnvelopePath + ".stage";
            File.WriteAllBytes(stage, envelopeBytes);
            AtomicReplace(stage, EnvelopePath);
            return candidate;
        }

        public static VerifiedProductCatalog LoadBuiltin(byte[] payload, string productId)
        {
            if (payload == null) throw new InvalidDataException("Bundled catalog is missing.");
            ProductModuleCatalog parsed = ProductModuleCatalog.Parse(new UTF8Encoding(false, true).GetString(payload));
            if (parsed.productId != productId) throw new InvalidDataException("Bundled catalog belongs to another product.");
            return VerifiedProductCatalog.FromBuiltin(payload, parsed);
        }

        private static void AtomicReplace(string stage, string target)
        {
            if (!File.Exists(target)) { File.Move(stage, target); return; }
            string backup = target + ".backup";
            try { File.Replace(stage, target, backup); }
            catch (PlatformNotSupportedException)
            {
                if (File.Exists(backup)) File.Delete(backup);
                File.Move(target, backup);
                File.Move(stage, target);
            }
        }

        private static bool SameBytes(byte[] left, byte[] right)
        {
            if (left.Length != right.Length) return false;
            for (int i = 0; i < left.Length; i++) if (left[i] != right[i]) return false;
            return true;
        }

        private static string Hash(byte[] bytes)
        {
            using (SHA256 sha = SHA256.Create())
                return BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant();
        }

        private static bool IsHex(string value)
        {
            foreach (char character in value)
                if (!Uri.IsHexDigit(character)) return false;
            return true;
        }

        private static bool SameCapabilities(string[] left, string[] right)
        {
            if (left.Length != right.Length) return false;
            foreach (string item in left)
                if (Array.IndexOf(right, item) < 0) return false;
            return true;
        }
    }
}
