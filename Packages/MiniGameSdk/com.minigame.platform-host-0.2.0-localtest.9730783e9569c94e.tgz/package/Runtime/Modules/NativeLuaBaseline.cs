using System.Collections.Generic;

namespace MiniGamePlatform.HotUpdate
{
    public static class NativeLuaBaseline
    {
        // Separate capability because already-shipped API 5 players lack these bindings.
        public const string Capability = "unity_native_v1";
        public static IReadOnlyList<string> RetainedAssemblies { get; } = System.Array.AsReadOnly(new[] {
            "UnityEngine.CoreModule", "UnityEngine.UIModule", "UnityEngine.UI", "Unity.TextMeshPro",
            "UnityEngine.AnimationModule", "UnityEngine.ParticleSystemModule", "UnityEngine.AudioModule",
            "UnityEngine.PhysicsModule"
        });
    }
}
