using System;
using System.IO;
using System.Security.Cryptography;
using System.Text.RegularExpressions;

namespace MiniGamePlatform.HotUpdate
{
    public sealed class CatalogTrustKey
    {
        private static readonly Regex Identifier = new Regex("^[a-z][a-z0-9_]*$", RegexOptions.CultureInvariant);
        public string KeyId { get; }
        private readonly byte[] _modulus;
        private readonly byte[] _exponent;

        public CatalogTrustKey(string keyId, string modulusBase64, string exponentBase64)
        {
            if (!Identifier.IsMatch(keyId ?? "")) throw new InvalidDataException("Invalid catalog key ID.");
            try
            {
                _modulus = Convert.FromBase64String(modulusBase64 ?? "");
                _exponent = Convert.FromBase64String(exponentBase64 ?? "");
            }
            catch (FormatException exception) { throw new InvalidDataException("Invalid catalog public key.", exception); }
            if (_modulus.Length < 256 || _modulus.Length > 512 || _exponent.Length == 0 || _exponent.Length > 8)
                throw new InvalidDataException("Unsupported catalog RSA key size.");
            KeyId = keyId;
        }

        public RSAParameters PublicParameters()
        {
            return new RSAParameters { Modulus = (byte[])_modulus.Clone(), Exponent = (byte[])_exponent.Clone() };
        }
    }
}
