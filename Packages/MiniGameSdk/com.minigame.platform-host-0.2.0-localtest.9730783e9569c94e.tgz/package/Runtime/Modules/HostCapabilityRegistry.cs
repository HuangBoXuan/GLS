using System;
using System.Collections.Generic;

namespace MiniGamePlatform.HotUpdate
{
    public sealed class HostCapabilityDefinition
    {
        public string Name { get; }
        public int MinimumApiVersion { get; }
        public IReadOnlyList<string> RetainedComponentTypes { get; }

        public HostCapabilityDefinition(string name, int minimumApiVersion, params string[] retainedComponentTypes)
        {
            Name = name;
            MinimumApiVersion = minimumApiVersion;
            RetainedComponentTypes = retainedComponentTypes ?? Array.Empty<string>();
        }
    }

    public static class HostCapabilityRegistry
    {
        private static readonly Dictionary<string, HostCapabilityDefinition> Definitions =
            new Dictionary<string, HostCapabilityDefinition>(StringComparer.Ordinal)
            {
                { "lua", new HostCapabilityDefinition("lua", 1) },
                { "lua_late_update_v1", new HostCapabilityDefinition("lua_late_update_v1", 5) },
                { "host_native_contract_v1", new HostCapabilityDefinition("host_native_contract_v1", 7) },
                { "unity_render_batch_v1", new HostCapabilityDefinition("unity_render_batch_v1", 7) },
                { "unity_render_batch_packed_v1", new HostCapabilityDefinition("unity_render_batch_packed_v1", 7) },
                { "unity_async_asset_v1", new HostCapabilityDefinition("unity_async_asset_v1", 7) },
                { "unity_camera_callback_v1", new HostCapabilityDefinition("unity_camera_callback_v1", 5) },
                { "ugui", new HostCapabilityDefinition("ugui", 1,
                    "UnityEngine.Canvas", "UnityEngine.RectTransform", "UnityEngine.UI.Text", "UnityEngine.UI.CanvasScaler") },
                { "sprite2d", new HostCapabilityDefinition("sprite2d", 1, "UnityEngine.SpriteRenderer") },
                { "mesh3d", new HostCapabilityDefinition("mesh3d", 1,
                    "UnityEngine.MeshRenderer", "UnityEngine.MeshFilter", "UnityEngine.BoxCollider") },
                { "assetbundle", new HostCapabilityDefinition("assetbundle", 1) },
                { "protected_content", new HostCapabilityDefinition("protected_content", 1) },
                { "data_text", new HostCapabilityDefinition("data_text", 2) },
                { "module_owned_resources_v1", new HostCapabilityDefinition("module_owned_resources_v1", 6) },
                { "presentation", new HostCapabilityDefinition("presentation", 4,
                    "UnityEngine.Canvas", "UnityEngine.RectTransform", "UnityEngine.CanvasRenderer",
                    "UnityEngine.UI.Image", "UnityEngine.UI.RawImage", "UnityEngine.UI.Text", "UnityEngine.UI.CanvasScaler",
                    "UnityEngine.UI.GraphicRaycaster", "UnityEngine.MeshFilter", "UnityEngine.MeshRenderer",
                    "UnityEngine.SkinnedMeshRenderer", "UnityEngine.SpriteRenderer") },
                { "tmp_text", new HostCapabilityDefinition("tmp_text", 4, "TMPro.TextMeshProUGUI", "TMPro.TMP_SubMeshUI") },
                { "presentation_surface", new HostCapabilityDefinition("presentation_surface", 5) },
                { "world_view", new HostCapabilityDefinition("world_view", 5) },
                { "unity_ugui_mesh_v1", new HostCapabilityDefinition("unity_ugui_mesh_v1", 5, "MiniGamePlatform.Components.ModuleMeshGraphic") },
                { LocalizationBaseline.Capability, new HostCapabilityDefinition(LocalizationBaseline.Capability, 5) },
                { "unity_ugui_raycast_v1", new HostCapabilityDefinition("unity_ugui_raycast_v1", 5, "MiniGamePlatform.Components.ModuleRaycastFilter") },
                { NativeLuaBaseline.Capability, new HostCapabilityDefinition(NativeLuaBaseline.Capability, 5,
                    "MiniGamePlatform.Components.ModulePointerRelay") }
            };

        public static bool Contains(string capability, int hostApiVersion)
        {
            return capability != null && Definitions.TryGetValue(capability, out HostCapabilityDefinition definition) &&
                definition.MinimumApiVersion <= hostApiVersion;
        }

        public static bool TryGet(string capability, out HostCapabilityDefinition definition)
        {
            return Definitions.TryGetValue(capability ?? "", out definition);
        }
    }
}
