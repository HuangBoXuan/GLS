using System;
using System.IO;
using System.Security.Cryptography;

namespace MiniGamePlatform.HotUpdate
{
    internal sealed class ModuleDownloadWorkspace : IDisposable
    {
        private readonly FileStream _lease;
        private readonly string _root;
        internal readonly string Content;
        internal readonly string Partials;

        internal ModuleDownloadWorkspace(string finalPath, byte[] manifestBytes)
        {
            string parent = Path.GetDirectoryName(Path.GetFullPath(finalPath));
            Directory.CreateDirectory(parent);
            // Shared across manifest revisions too: two installs must never publish the same version concurrently.
            _lease = new FileStream(finalPath + ".download.lock", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
            try
            {
                _root = Path.Combine(parent, ".downloads", Path.GetFileName(finalPath) + "-" + Hash(manifestBytes));
                Content = Path.Combine(_root, "content");
                Partials = Path.Combine(_root, "parts");
                Directory.CreateDirectory(Content);
                Directory.CreateDirectory(Partials);
            }
            catch { _lease.Dispose(); throw; }
        }

        // The full manifest hash already fixes file order. Numeric names avoid doubling path length on Windows.
        internal string PartialPath(int fileIndex) => Path.Combine(Partials, fileIndex.ToString("D4") + ".part");
        internal void Publish(string finalPath, byte[] manifestBytes)
        {
            File.WriteAllBytes(Path.Combine(Content, "manifest.json"), manifestBytes);
            // Under the per-version writer lease. Never remove old bytes before
            // all replacement files pass verification. A failed rename restores them.
            string backup = finalPath + ".repair-" + Guid.NewGuid().ToString("N");
            if (Directory.Exists(finalPath))
            {
                Directory.Move(finalPath, backup);
                try { Directory.Move(Content, finalPath); }
                catch
                {
                    if (!Directory.Exists(finalPath)) Directory.Move(backup, finalPath);
                    throw;
                }
            }
            else Directory.Move(Content, finalPath);
            DeleteScratch(backup);
            // Root was derived exclusively from the validated module identity and SHA-256, beneath its game folder.
            DeleteScratch(_root);
        }
        private static void DeleteScratch(string path)
        {
            try { if (Directory.Exists(path)) Directory.Delete(path, true); }
            catch (IOException e) { UnityEngine.Debug.LogWarning("Module partial cleanup: " + e.Message); }
            catch (UnauthorizedAccessException e) { UnityEngine.Debug.LogWarning("Module partial cleanup: " + e.Message); }
        }
        public void Dispose() => _lease.Dispose(); // Cancel/failure releases the writer, retaining verified files and prefixes.
        private static string Hash(byte[] data)
        {
            using (var sha = SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(data)).Replace("-", "").ToLowerInvariant();
        }
    }
}
