using System;
using System.IO;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using UnityEngine;

namespace MiniGamePlatform.HotUpdate
{
    [Serializable]
    public sealed class ModuleRelease
    {
        public string gameId;
        public string version;
        public string manifestPath;
        public string manifestSha256;
        public string runtimeType;
        public int minHostApiVersion;
        public string[] requiredCapabilities;
        public string platform;
        public string unityVersion;
        public bool enabled;
        public string fallbackVersion;
    }

    [Serializable]
    public sealed class ProductModuleCatalog
    {
        public int formatVersion;
        public int catalogVersion;
        public string productId;
        public ModuleRelease[] releases;

        private static readonly Regex Identifier = new Regex("^[a-z][a-z0-9_]*$", RegexOptions.CultureInvariant);
        private static readonly Regex GameId = new Regex("^[a-z][a-z0-9_]{0,63}$", RegexOptions.CultureInvariant);
        private static readonly Regex Hash = new Regex("^[a-fA-F0-9]{64}$", RegexOptions.CultureInvariant);

        public static ProductModuleCatalog Parse(string json)
        {
            ProductModuleCatalog catalog = JsonUtility.FromJson<ProductModuleCatalog>(json);
            if (catalog == null || catalog.formatVersion > 1 || catalog.catalogVersion < 1 ||
                !Identifier.IsMatch(catalog.productId ?? "") ||
                catalog.releases == null || catalog.releases.Length == 0)
                throw new InvalidDataException("Invalid product module catalog.");
            for (int i = 0; i < catalog.releases.Length; i++)
            {
                ModuleRelease release = catalog.releases[i];
                if (release == null || !GameId.IsMatch(release.gameId ?? "") ||
                    !Identifier.IsMatch(release.version ?? "") ||
                    release.manifestPath != release.gameId + "/" + release.version + "/manifest.json" ||
                    !Hash.IsMatch(release.manifestSha256 ?? ""))
                    throw new InvalidDataException("Invalid module release in catalog.");
                for (int j = 0; j < i; j++)
                    if (catalog.releases[j].gameId == release.gameId)
                        throw new InvalidDataException("Duplicate game in product catalog.");
            }
            return catalog;
        }

        public static ProductModuleCatalog ParseV2(string json)
        {
            ProductModuleCatalog catalog;
            try { catalog = JsonUtility.FromJson<ProductModuleCatalog>(json); }
            catch (Exception exception) { throw new InvalidDataException("Invalid signed catalog JSON.", exception); }
            if (catalog == null || catalog.formatVersion != 2 || catalog.catalogVersion < 1 ||
                !Identifier.IsMatch(catalog.productId ?? "") || catalog.releases == null ||
                catalog.releases.Length == 0 || catalog.releases.Length > 256)
                throw new InvalidDataException("Invalid signed catalog header.");
            var identities = new HashSet<string>(StringComparer.Ordinal);
            foreach (ModuleRelease release in catalog.releases)
            {
                if (release == null || !GameId.IsMatch(release.gameId ?? "") ||
                    !Identifier.IsMatch(release.version ?? "") ||
                    !Identifier.IsMatch(release.runtimeType ?? "") ||
                    release.manifestPath != release.gameId + "/" + release.version + "/manifest.json" ||
                    !Hash.IsMatch(release.manifestSha256 ?? "") || release.minHostApiVersion < 1 ||
                    release.requiredCapabilities == null || release.requiredCapabilities.Length == 0 ||
                    (release.platform != "android" && release.platform != "any") ||
                    release.unityVersion == null ||
                    (release.runtimeType == "unity_lua" &&
                     release.requiredCapabilities != null && Array.IndexOf(release.requiredCapabilities, "assetbundle") >= 0 &&
                     release.unityVersion.Length == 0) ||
                    !identities.Add(release.gameId + "/" + release.version))
                    throw new InvalidDataException("Invalid or duplicate signed catalog release.");
                var capabilities = new HashSet<string>(StringComparer.Ordinal);
                foreach (string capability in release.requiredCapabilities)
                    if (!Identifier.IsMatch(capability ?? "") || !capabilities.Add(capability))
                        throw new InvalidDataException("Invalid signed catalog capability.");
            }
            foreach (ModuleRelease release in catalog.releases)
            {
                if (string.IsNullOrEmpty(release.fallbackVersion)) continue;
                bool found = false;
                foreach (ModuleRelease candidate in catalog.releases)
                    if (candidate.gameId == release.gameId && candidate.version == release.fallbackVersion &&
                        candidate.version != release.version && candidate.enabled) found = true;
                if (!found) throw new InvalidDataException("Invalid signed catalog fallback pointer.");
                var visited = new HashSet<string>(StringComparer.Ordinal) { release.version };
                ModuleRelease cursor = release;
                while (!string.IsNullOrEmpty(cursor.fallbackVersion))
                {
                    if (!visited.Add(cursor.fallbackVersion))
                        throw new InvalidDataException("Cyclic signed catalog fallback pointer.");
                    ModuleRelease next = null;
                    foreach (ModuleRelease candidate in catalog.releases)
                        if (candidate.gameId == release.gameId && candidate.version == cursor.fallbackVersion) next = candidate;
                    if (next == null || !next.enabled)
                        throw new InvalidDataException("Invalid signed catalog fallback pointer.");
                    cursor = next;
                }
            }
            return catalog;
        }

        public ModuleRelease Find(string gameId)
        {
            foreach (ModuleRelease release in releases)
                if (release.gameId == gameId) return release;
            return null;
        }
    }
}
