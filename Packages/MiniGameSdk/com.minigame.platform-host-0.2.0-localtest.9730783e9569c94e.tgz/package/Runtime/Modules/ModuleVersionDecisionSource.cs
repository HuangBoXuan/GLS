using System;
using System.Collections;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using MiniGamePlatform.SDK;
using UnityEngine;
using UnityEngine.Networking;

namespace MiniGamePlatform.HotUpdate
{
    [Serializable] public sealed class ModuleVersionQuery
    {
        public string productId, gameId, platform, clientVersion, unityVersion, installationId;
        public int hostApiVersion;
        public string[] capabilities;
    }

    [Serializable] public sealed class ModuleVersionReference
    {
        public string gameId, version, manifestSha256;
    }

    [Serializable] public sealed class ModuleVersionDecision
    {
        public string productId, gameId, status, reason, moduleBaseUrl;
        public long selectionRevision;
        public int catalogVersion, maxAgeSeconds;
        public ModuleVersionReference selected, fallback;
        public SignedCatalogEnvelope catalogEnvelope;
    }

    [Serializable] public sealed class ModuleVersionResponse
    {
        public ModuleVersionDecision data;
    }

    public sealed class ModuleVersionReply
    {
        public byte[] Bytes;
        public long HttpStatus;
        public bool TransportUnavailable;
    }

    public interface IModuleVersionTransport
    {
        IEnumerator Query(Uri endpoint, ModuleVersionQuery query, Action<ModuleVersionReply> done);
    }

    // The version query is anonymous. Account tokens and game-specific logic stay outside this layer.
    public sealed class ModuleVersionTransport : IModuleVersionTransport
    {
        public IEnumerator Query(Uri endpoint, ModuleVersionQuery query, Action<ModuleVersionReply> done)
        {
            using (var request = new UnityWebRequest(endpoint, "POST"))
            using (var body = new UploadHandlerRaw(Encoding.UTF8.GetBytes(JsonUtility.ToJson(query))))
            using (var download = new BoundedDownload())
            {
                request.uploadHandler = body;
                request.downloadHandler = download;
                request.disposeUploadHandlerOnDispose = false;
                request.disposeDownloadHandlerOnDispose = false;
                request.SetRequestHeader("Content-Type", "application/json");
                request.timeout = 15;
                request.redirectLimit = 0;
                yield return request.SendWebRequest();
                done(ToReply(request.responseCode, request.result, download.Overflow, download.Bytes));
            }
        }

        internal static ModuleVersionReply ToReply(long status, UnityWebRequest.Result result,
            bool overflow, byte[] bytes)
        {
            // A truncated valid JSON prefix must never count as a successful HTTP 200 response.
            return new ModuleVersionReply { HttpStatus = status,
                Bytes = result == UnityWebRequest.Result.Success && !overflow ? bytes : null,
                TransportUnavailable = status <= 0 && !overflow && result == UnityWebRequest.Result.ConnectionError };
        }

        private sealed class BoundedDownload : DownloadHandlerScript
        {
            private readonly MemoryStream _bytes = new MemoryStream();
            public bool Overflow { get; private set; }
            public byte[] Bytes => _bytes.ToArray();

            public BoundedDownload() : base(new byte[16384]) { }

            protected override bool ReceiveData(byte[] data, int length)
            {
                if (length < 0 || _bytes.Length + length > ModuleVersionDecisionSource.MaxResponseBytes)
                { Overflow = true; return false; }
                if (data != null && length > 0) _bytes.Write(data, 0, length);
                return true;
            }

            protected override void ReceiveContentLengthHeader(ulong length)
            {
                if (length > ModuleVersionDecisionSource.MaxResponseBytes) Overflow = true;
            }
        }
    }

    // HTTPS authenticates the server policy; the complete catalog is separately RSA verified.
    // An outage can reuse a verified decision for local startup, never for a new download.
    public sealed class ModuleVersionDecisionSource
    {
        public const int MaxResponseBytes = CatalogSignatureVerifier.MaxEnvelopeBytes + 32768;
        private static readonly Regex GameIdPattern = new Regex("^[a-z][a-z0-9_]{0,63}$", RegexOptions.CultureInvariant);

        [Serializable] private sealed class Record
        {
            public long revision, acceptedUtcTicks;
            public string fingerprint;
            public bool ready;
            public ModuleVersionDecision decision;
        }

        private readonly ModuleVersionQuery _query;
        private readonly Uri _endpoint;
        private readonly string _path;
        private readonly CatalogCache _catalogs;
        private readonly CatalogTrustKey _key;
        private readonly HostProfile _host;
        private readonly ProductContext _product;
        private readonly IModuleVersionTransport _transport;
        private readonly Func<DateTime> _clock;
        private Record _current;

        public ModuleVersionDecision Decision { get; private set; }
        public VerifiedProductCatalog Catalog { get; private set; }
        public ModuleReleaseSelection Selected { get; private set; }
        public ModuleReleaseSelection Fallback { get; private set; }
        public bool Offline { get; private set; }
        public bool MayUseBundled { get; private set; }
        public bool IsAuthorized => _current != null && _current.ready && (Offline || Fresh(_current));
        public bool CanDownload => IsAuthorized && !Offline;

        public ModuleVersionDecisionSource(string gameId, string root, HostProfile host,
            ProductContext product, CatalogTrustKey key, IModuleVersionTransport transport = null,
            Func<DateTime> utcNow = null)
        {
            if (!GameIdPattern.IsMatch(gameId ?? "")) throw new ArgumentException("Invalid game ID.", nameof(gameId));
            if (string.IsNullOrWhiteSpace(root)) throw new ArgumentException("Cache root is required.", nameof(root));
            _host = host ?? throw new ArgumentNullException(nameof(host));
            _product = product ?? throw new ArgumentNullException(nameof(product));
            _key = key ?? throw new ArgumentNullException(nameof(key));
            _transport = transport ?? new ModuleVersionTransport();
            _clock = utcNow ?? (() => DateTime.UtcNow);
            RequireHttps(product.ApiBaseUrl);
            Uri origin = new Uri(product.ApiBaseUrl.TrimEnd('/') + "/");
            if (origin.AbsolutePath != "/" || !string.IsNullOrEmpty(origin.Query))
                throw new InvalidDataException("Version API base must be an HTTPS origin.");
            _endpoint = new Uri(origin, "v1/platform/module-selection");
            Directory.CreateDirectory(root);
            _query = new ModuleVersionQuery { productId = product.ProductId, gameId = gameId,
                platform = host.Platform, clientVersion = product.ClientVersion,
                hostApiVersion = host.Version, unityVersion = host.UnityVersion,
                capabilities = host.GetSupportedCapabilities(),
                installationId = GetOrCreateInstallationId(root) };
            RSAParameters publicKey = key.PublicParameters();
            string scope = Hash(Encoding.UTF8.GetBytes(_endpoint.AbsoluteUri + "\n" +
                JsonUtility.ToJson(_query) + "\n" + key.KeyId + "\n" +
                Convert.ToBase64String(publicKey.Modulus) + "\n" + Convert.ToBase64String(publicKey.Exponent)));
            string directory = Path.Combine(root, "selections", scope);
            Directory.CreateDirectory(directory);
            _path = Path.Combine(directory, "decision.json");
            _catalogs = new CatalogCache(Path.Combine(root, "catalog"), product.ProductId, key);
        }

        public IEnumerator Load(Action<string> failed)
        {
            _current = null; Decision = null; Catalog = null; Selected = null; Fallback = null;
            Offline = false; MayUseBundled = false;
            ModuleVersionReply reply = null;
            yield return _transport.Query(_endpoint, _query, value => reply = value);
            string problem = null;
            try
            {
                Record previous = Read();
                if (reply != null && ((reply.TransportUnavailable && reply.HttpStatus <= 0) ||
                    reply.HttpStatus == 408 || reply.HttpStatus == 429 ||
                    reply.HttpStatus >= 500 && reply.HttpStatus <= 599))
                {
                    UseVerifiedLocal(previous);
                }
                else
                {
                    // Invalidate a previous ready decision before processing a non-transient reply.
                    var barrier = new Record { revision = previous?.revision ?? 0,
                        fingerprint = previous?.fingerprint };
                    Write(barrier);
                    if (reply == null || reply.HttpStatus != 200)
                        throw new InvalidDataException("VERSION_QUERY_REJECTED");
                    if (reply.Bytes == null || reply.Bytes.Length == 0 || reply.Bytes.Length > MaxResponseBytes)
                        throw new InvalidDataException("VERSION_RESPONSE_SIZE_INVALID");
                    var response = JsonUtility.FromJson<ModuleVersionResponse>(
                        new UTF8Encoding(false, true).GetString(reply.Bytes));
                    ModuleVersionDecision decision = response?.data;
                    if (decision == null || decision.productId != _query.productId ||
                        decision.gameId != _query.gameId || decision.selectionRevision < 0 ||
                        decision.catalogVersion < 0 ||
                        (decision.status != "ready" && decision.status != "blocked" &&
                         decision.status != "host_update_required"))
                        throw new InvalidDataException("VERSION_RESPONSE_INVALID");
                    string fingerprint = Fingerprint(decision);
                    if (decision.selectionRevision < barrier.revision ||
                        decision.selectionRevision == barrier.revision && barrier.fingerprint != null &&
                        barrier.fingerprint != fingerprint)
                        throw new InvalidDataException("VERSION_POLICY_REPLAY_OR_MUTATION");
                    barrier.revision = decision.selectionRevision;
                    barrier.fingerprint = fingerprint;
                    Write(barrier);
                    if (previous == null && _catalogs.HighestAcceptedVersion() == 0 &&
                        IsInitialUnpublished(decision))
                    {
                        File.Delete(_path);
                        MayUseBundled = true;
                        Offline = true;
                    }
                    else
                    {
                        if (decision.status != "ready")
                            throw new InvalidDataException("VERSION_" + decision.status.ToUpperInvariant());
                        ValidateReady(decision);
                        _current = new Record { revision = decision.selectionRevision,
                            fingerprint = fingerprint, ready = true, acceptedUtcTicks = _clock().Ticks,
                            decision = decision };
                        Write(_current);
                    }
                }
            }
            catch (Exception exception) when (exception is InvalidDataException || exception is IOException ||
                exception is UnauthorizedAccessException || exception is ArgumentException ||
                exception is FormatException || exception is CryptographicException)
            {
                _current = null; Selected = null; Fallback = null; MayUseBundled = false;
                problem = "Version selection failed: " + exception.Message;
            }
            if (problem != null) failed?.Invoke(problem);
        }

        private void UseVerifiedLocal(Record previous)
        {
            if (previous == null)
            {
                if (_catalogs.HighestAcceptedVersion() != 0)
                    throw new InvalidDataException("VERIFIED_CATALOG_RECOVERY_REQUIRED");
                MayUseBundled = true;
                Offline = true;
                return;
            }
            if (!previous.ready) throw new InvalidDataException("VERSION_POLICY_BLOCKS_LOCAL");
            if (previous.decision == null || previous.fingerprint != Fingerprint(previous.decision) ||
                previous.acceptedUtcTicks <= 0 || _clock().Ticks < previous.acceptedUtcTicks)
                throw new InvalidDataException("VERSION_CACHE_CORRUPT_OR_CLOCK_ROLLBACK");
            ValidateReady(previous.decision);
            _current = previous;
            Offline = true;
        }

        private static bool IsInitialUnpublished(ModuleVersionDecision decision)
        {
            return decision.status == "blocked" && decision.reason == "UNPUBLISHED" &&
                decision.selectionRevision == 0 && decision.catalogVersion == 0 &&
                decision.maxAgeSeconds == 0 && string.IsNullOrEmpty(decision.moduleBaseUrl) &&
                EmptyReference(decision.selected) && EmptyReference(decision.fallback) &&
                (decision.catalogEnvelope == null ||
                 string.IsNullOrEmpty(decision.catalogEnvelope.keyId) &&
                 string.IsNullOrEmpty(decision.catalogEnvelope.payloadBase64) &&
                 string.IsNullOrEmpty(decision.catalogEnvelope.signatureBase64));
        }

        private static bool EmptyReference(ModuleVersionReference value) => value == null ||
            string.IsNullOrEmpty(value.gameId) && string.IsNullOrEmpty(value.version) &&
            string.IsNullOrEmpty(value.manifestSha256);

        private void ValidateReady(ModuleVersionDecision decision)
        {
            if (decision.productId != _query.productId || decision.gameId != _query.gameId ||
                decision.status != "ready" || decision.selectionRevision <= 0 ||
                decision.maxAgeSeconds <= 0 || decision.maxAgeSeconds > 3600 ||
                decision.catalogVersion <= 0 || decision.catalogEnvelope == null)
                throw new InvalidDataException("VERSION_READY_INVALID");
            RequireHttps(decision.moduleBaseUrl);
            var moduleUri = new Uri(decision.moduleBaseUrl);
            if (!decision.moduleBaseUrl.EndsWith("/", StringComparison.Ordinal) ||
                !string.IsNullOrEmpty(moduleUri.Query))
                throw new InvalidDataException("VERSION_MODULE_ROOT_INVALID");
            byte[] envelope = Encoding.UTF8.GetBytes(JsonUtility.ToJson(decision.catalogEnvelope));
            VerifiedProductCatalog verified = CatalogSignatureVerifier.Verify(envelope, _key, _product.ProductId);
            if (verified.CatalogVersion != decision.catalogVersion)
                throw new InvalidDataException("VERSION_CATALOG_MISMATCH");
            _catalogs.ReplaceVerified(envelope);
            _product.ApplyVerifiedCatalog(verified);
            ModuleReleaseSelection selected = Exact(verified, decision.selected);
            ModuleReleaseSelection fallback = EmptyReference(decision.fallback) ? null :
                Exact(verified, decision.fallback);
            if (fallback != null && fallback.Release.version == selected.Release.version)
                throw new InvalidDataException("VERSION_FALLBACK_SELF");
            Catalog = verified;
            Selected = selected;
            Fallback = fallback;
            Decision = decision;
        }

        private ModuleReleaseSelection Exact(VerifiedProductCatalog catalog, ModuleVersionReference reference)
        {
            if (reference == null || reference.gameId != _query.gameId)
                throw new InvalidDataException("VERSION_REFERENCE_INVALID");
            ModuleReleaseSelection result = ModuleReleaseSelector.SelectExact(catalog, _host, _product,
                reference.gameId, reference.version, reference.manifestSha256);
            if (result.Status != ModuleSelectionStatus.Ready) throw new InvalidDataException(result.Reason);
            return result;
        }

        private bool Fresh(Record record)
        {
            long now = _clock().Ticks;
            return record.decision != null && record.decision.maxAgeSeconds > 0 &&
                record.decision.maxAgeSeconds <= 3600 && record.acceptedUtcTicks > 0 &&
                now >= record.acceptedUtcTicks &&
                now - record.acceptedUtcTicks <= TimeSpan.FromSeconds(record.decision.maxAgeSeconds).Ticks;
        }

        private Record Read()
        {
            if (!File.Exists(_path)) return null;
            if (new FileInfo(_path).Length > MaxResponseBytes * 2)
                throw new InvalidDataException("VERSION_CACHE_CORRUPT");
            Record record = JsonUtility.FromJson<Record>(File.ReadAllText(_path));
            if (record == null || record.revision < 0 ||
                record.ready && (record.decision == null || record.revision != record.decision.selectionRevision))
                throw new InvalidDataException("VERSION_CACHE_CORRUPT");
            return record;
        }

        private void Write(Record record) => AtomicWrite(_path, JsonUtility.ToJson(record));
        private static string Fingerprint(ModuleVersionDecision value) =>
            Hash(Encoding.UTF8.GetBytes(JsonUtility.ToJson(value)));

        private static string Hash(byte[] bytes)
        {
            using (var sha = SHA256.Create())
                return BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant();
        }

        public static string GetOrCreateInstallationId(string root)
        {
            if (string.IsNullOrWhiteSpace(root)) throw new ArgumentException("Installation root is required.", nameof(root));
            Directory.CreateDirectory(root);
            string path = Path.Combine(root, "installation-id.txt");
            if (File.Exists(path))
            {
                string value = File.ReadAllText(path);
                if (!Guid.TryParseExact(value, "D", out _))
                    throw new InvalidDataException("VERSION_INSTALLATION_ID_CORRUPT");
                return value;
            }
            string id = Guid.NewGuid().ToString("D");
            AtomicWrite(path, id);
            return id;
        }

        private static void AtomicWrite(string path, string value)
        {
            string stage = path + ".stage";
            using (var file = new FileStream(stage, FileMode.Create, FileAccess.Write, FileShare.None))
            {
                byte[] bytes = Encoding.UTF8.GetBytes(value);
                file.Write(bytes, 0, bytes.Length);
                file.Flush(true);
            }
            if (!File.Exists(path)) { File.Move(stage, path); return; }
            try { File.Replace(stage, path, path + ".backup"); }
            catch (PlatformNotSupportedException)
            {
                string backup = path + ".backup";
                if (File.Exists(backup)) File.Delete(backup);
                File.Move(path, backup);
                File.Move(stage, path);
            }
        }

        private static void RequireHttps(string value)
        {
            if (!Uri.TryCreate(value, UriKind.Absolute, out Uri uri) ||
                uri.Scheme != Uri.UriSchemeHttps || !string.IsNullOrEmpty(uri.UserInfo) ||
                !string.IsNullOrEmpty(uri.Fragment))
                throw new InvalidDataException("Version endpoints require HTTPS without credentials or fragments.");
        }
    }
}
