using System;
using System.IO;
using System.Text.RegularExpressions;
using MiniGamePlatform.HotUpdate.Security;

namespace MiniGamePlatform.HotUpdate
{
    public static class ModuleContentProtection
    {
        public const string Capability = ModuleProtectionDeclaration.Capability;
        public const int MaxPlainBytes = ModuleProtectionDeclaration.MaxPlainBytes;
        public static bool ValidId(string id) => ModuleProtectionDeclaration.ValidId(id);
        public static bool ValidateDeclaration(ModuleManifest manifest) => ModuleProtectionDeclaration.ValidateDeclaration(manifest);

        private static string Context(ModuleManifest manifest, string path)
        {
            if (!ValidateDeclaration(manifest) || !ValidId(manifest.gameId) || !ValidId(manifest.version) ||
                !ModuleManifest.IsAllowedModuleFile(manifest.gameId, path))
                throw new InvalidDataException("Invalid protected module context.");
            return "module/v1/" + manifest.gameId + "/" + manifest.version + "/" + manifest.contentKeyId + "/" + path;
        }

        public static byte[] Seal(ModuleManifest manifest, string path, byte[] plain, byte[] key) =>
            ModuleProtectedEnvelope.Seal(plain, key, Context(manifest, path), false);

        public static byte[] Open(ModuleManifest manifest, string path, byte[] encrypted, byte[] key) =>
            ModuleProtectedEnvelope.Open(encrypted, key, Context(manifest, path), MaxPlainBytes);

        internal static byte[] OpenBounded(ModuleManifest manifest, string path, byte[] encrypted, byte[] key, int maximumPlainLength) =>
            ModuleProtectedEnvelope.Open(encrypted, key, Context(manifest, path), maximumPlainLength);
    }
}
