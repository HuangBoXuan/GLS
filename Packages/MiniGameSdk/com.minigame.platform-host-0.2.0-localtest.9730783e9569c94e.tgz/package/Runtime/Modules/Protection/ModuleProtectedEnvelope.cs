using System;
using System.IO;
using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Engines;
using Org.BouncyCastle.Crypto.Modes;
using Org.BouncyCastle.Crypto.Parameters;

namespace MiniGamePlatform.HotUpdate.Security
{
    /// <summary>Versioned AES-256-GCM envelope. No unauthenticated bytes reach a parser or Unity.</summary>
    public static class ModuleProtectedEnvelope
    {
        private const int HeaderSize = 28;
        private const int TagSize = 16;
        private const int Magic = 0x31435057; // WPC1, little endian
        private const int AbsoluteLimit = 64 * 1024 * 1024;

        public static byte[] Seal(byte[] plain, byte[] key, string contentId, bool compress)
        {
            if (plain == null || plain.Length > AbsoluteLimit) throw new ArgumentException("Content size exceeds the package budget.");
            ValidateKey(key, contentId);
            byte[] payload = plain;
            if (compress)
            {
                using var buffer = new MemoryStream();
                using (var zip = new DeflateStream(buffer, CompressionLevel.Optimal, true)) zip.Write(plain, 0, plain.Length);
                payload = buffer.ToArray();
            }
            try
            {
                var header = new byte[HeaderSize];
                using (var writer = new BinaryWriter(new MemoryStream(header)))
                {
                    writer.Write(Magic); writer.Write(plain.Length); writer.Write(payload.Length);
                    writer.Write(compress ? 1 : 0);
                    var nonce = new byte[12];
                    using (var random = RandomNumberGenerator.Create()) random.GetBytes(nonce);
                    writer.Write(nonce);
                }
                var cipher = CreateCipher(true, key, contentId, header);
                var output = new byte[HeaderSize + payload.Length + TagSize];
                Buffer.BlockCopy(header, 0, output, 0, HeaderSize);
                var written = cipher.ProcessBytes(payload, 0, payload.Length, output, HeaderSize);
                cipher.DoFinal(output, HeaderSize + written);
                return output;
            }
            finally { if (compress) Array.Clear(payload, 0, payload.Length); }
        }

        public static byte[] Open(byte[] envelope, byte[] key, string contentId, int maximumPlainLength)
        {
            ValidateKey(key, contentId);
            if (maximumPlainLength < 0 || maximumPlainLength > AbsoluteLimit || envelope == null ||
                envelope.Length < HeaderSize + TagSize || envelope.Length > AbsoluteLimit + 65536)
                throw InvalidContent();
            var header = new byte[HeaderSize];
            Buffer.BlockCopy(envelope, 0, header, 0, HeaderSize);
            int length, payloadLength, flags;
            using (var reader = new BinaryReader(new MemoryStream(header)))
            {
                if (reader.ReadInt32() != Magic) throw InvalidContent();
                length = reader.ReadInt32(); payloadLength = reader.ReadInt32(); flags = reader.ReadInt32();
            }
            if (length < 0 || length > maximumPlainLength || payloadLength < 0 ||
                payloadLength != envelope.Length - HeaderSize - TagSize || (flags != 0 && flags != 1) ||
                (flags == 0 && payloadLength != length)) throw InvalidContent();
            // GCM implementations may write plaintext before DoFinal verifies the tag.
            // Keep it private and wipe on every failure, including decompression errors.
            var payload = new byte[payloadLength];
            byte[] result = null;
            try
            {
                var cipher = CreateCipher(false, key, contentId, header);
                int written = cipher.ProcessBytes(envelope, HeaderSize, payloadLength + TagSize, payload, 0);
                written += cipher.DoFinal(payload, written);
                if (written != payloadLength) throw InvalidContent();
                if (flags == 0) { result = payload; return result; }
                result = new byte[length];
                using var source = new MemoryStream(payload, false);
                using var zip = new DeflateStream(source, CompressionMode.Decompress);
                int position = 0;
                while (position < length)
                {
                    var read = zip.Read(result, position, length - position);
                    if (read == 0) throw InvalidContent();
                    position += read;
                }
                if (zip.ReadByte() != -1) throw InvalidContent();
                return result;
            }
            catch (Exception exception) when (exception is InvalidCipherTextException ||
                exception is IOException || exception is CryptographicException || exception is ArgumentException)
            {
                if (result != null) Array.Clear(result, 0, result.Length);
                throw InvalidContent();
            }
            finally { if (!ReferenceEquals(result, payload)) Array.Clear(payload, 0, payload.Length); }
        }

        private static GcmBlockCipher CreateCipher(bool encrypt, byte[] key, string contentId, byte[] header)
        {
            var nonce = new byte[12]; Buffer.BlockCopy(header, 16, nonce, 0, 12);
            var id = Encoding.UTF8.GetBytes("WoolCrush/content/v1\0" + contentId);
            var aad = new byte[id.Length + header.Length];
            Buffer.BlockCopy(id, 0, aad, 0, id.Length); Buffer.BlockCopy(header, 0, aad, id.Length, header.Length);
            var cipher = new GcmBlockCipher(new AesEngine());
            cipher.Init(encrypt, new AeadParameters(new KeyParameter(key), 128, nonce, aad));
            return cipher;
        }
        private static void ValidateKey(byte[] key, string id)
        {
            if (key == null || key.Length != 32 || string.IsNullOrEmpty(id) || id.Length > 1024)
                throw new ArgumentException("Invalid content encryption parameters.");
        }
        private static CryptographicException InvalidContent() => new CryptographicException("Protected content verification failed (PC01).");
    }
}
