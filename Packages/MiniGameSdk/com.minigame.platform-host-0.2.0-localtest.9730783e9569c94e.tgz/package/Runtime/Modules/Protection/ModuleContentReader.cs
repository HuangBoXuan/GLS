using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;

namespace MiniGamePlatform.HotUpdate
{
    // Host-only interface. Never expose providers or raw keys through the Lua bridge.
    public interface IModuleContentKeyProvider
    {
        bool CopyKey(string gameId, string keyId, byte[] destination);
    }

    public sealed class NativeModuleContentKeyProvider : IModuleContentKeyProvider
    {
        public bool CopyKey(string gameId, string keyId, byte[] destination)
        {
            if (!ModuleContentProtection.ValidId(gameId) || !ModuleContentProtection.ValidId(keyId) ||
                destination == null || destination.Length != 32) return false;
#if UNITY_ANDROID && !UNITY_EDITOR
            try { return mgp_module_key(gameId, keyId, destination, destination.Length) == 1; }
            catch (DllNotFoundException) { return false; }
            catch (EntryPointNotFoundException) { return false; }
#else
            return false;
#endif
        }
#if UNITY_ANDROID && !UNITY_EDITOR
        [DllImport("__Internal", CallingConvention = CallingConvention.Cdecl)]
        private static extern int mgp_module_key(string gameId, string keyId, [Out] byte[] bytes, int count);
#endif
    }

    public sealed class ModuleContentReader
    {
        private readonly ModuleManifest manifest;
        private readonly string directory;
        private readonly IModuleContentKeyProvider keys;
        private readonly bool encrypted;

        // Call after trusted catalog -> manifest hash validation; hashes alone are not publisher trust.
        public ModuleContentReader(ModuleManifest manifest, string directory, IModuleContentKeyProvider keys = null)
        {
            this.manifest = manifest ?? throw new ArgumentNullException(nameof(manifest));
            this.directory = Path.GetFullPath(directory);
            this.keys = keys ?? new NativeModuleContentKeyProvider();
            encrypted = ModuleContentProtection.ValidateDeclaration(manifest);
            if (encrypted)
            {
                var probe = new byte[32];
                try { if (!this.keys.CopyKey(manifest.gameId, manifest.contentKeyId, probe)) throw MissingKey(); }
                finally { Array.Clear(probe, 0, probe.Length); }
            }
        }

        public byte[] Read(string relativePath)
        {
            return ReadCore(relativePath, ModuleManifest.MaxFileBytes, ModuleContentProtection.MaxPlainBytes);
        }

        internal byte[] ReadDataBytes(string relativePath, int maximumPlainLength)
        {
            return ReadCore(relativePath, maximumPlainLength + (encrypted ? 65536L : 0L), maximumPlainLength);
        }

        // Keep a read lease until LoadFromFile returns; callers cannot substitute an
        // unchecked pathname or digest. Encrypted content retains authenticated decode.
        internal sealed class VerifiedPlainFile : IDisposable
        {
            private readonly FileStream stream;
            public string Path { get; }
            public string Hash { get; }
            internal VerifiedPlainFile(FileStream stream, string path, string hash)
            { this.stream = stream; Path = path; Hash = hash; }
            public void Dispose() => stream.Dispose();
        }

        internal VerifiedPlainFile OpenVerifiedPlainFile(string relativePath)
        {
            if (encrypted) throw new InvalidOperationException("Encrypted content requires authenticated decoding.");
            var file = Resolve(relativePath, ModuleManifest.MaxFileBytes, out string path);
            var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
            try
            {
                if (stream.Length != file.size) throw new InvalidDataException("Module content length mismatch.");
                string hash;
                using (var sha = SHA256.Create())
                {
                    var buffer = new byte[32768];
                    long remaining = file.size;
                    while (remaining > 0)
                    {
                        int count = stream.Read(buffer, 0, (int)Math.Min(buffer.Length, remaining));
                        if (count == 0) throw new InvalidDataException("Module content was truncated.");
                        sha.TransformBlock(buffer, 0, count, buffer, 0);
                        remaining -= count;
                    }
                    if (stream.ReadByte() != -1) throw new InvalidDataException("Module content grew during reading.");
                    sha.TransformFinalBlock(Array.Empty<byte>(), 0, 0);
                    hash = BitConverter.ToString(sha.Hash).Replace("-", "");
                }
                if (!hash.Equals(file.sha256, StringComparison.OrdinalIgnoreCase))
                    throw new CryptographicException("Module content hash mismatch.");
                return new VerifiedPlainFile(stream, path, hash);
            }
            catch { stream.Dispose(); throw; }
        }

        private ModuleFile Resolve(string relativePath, long maximumStoredLength, out string path)
        {
            if (!ModuleManifest.IsAllowedModuleFile(manifest.gameId, relativePath))
                throw new InvalidDataException("Invalid module content path.");
            var file = Array.Find(manifest.files, entry => entry.path == relativePath);
            if (file == null) throw new InvalidDataException("Undeclared module content.");
            path = Path.Combine(directory, relativePath.Replace('/', Path.DirectorySeparatorChar));
            for (var cursor = path; !string.IsNullOrEmpty(cursor); cursor = Path.GetDirectoryName(cursor))
                if ((File.Exists(cursor) || Directory.Exists(cursor)) && (File.GetAttributes(cursor) & FileAttributes.ReparsePoint) != 0)
                    throw new InvalidDataException("Module content cannot traverse links.");
            if (file.size < 0 || file.size > maximumStoredLength || file.size > ModuleManifest.MaxFileBytes ||
                (encrypted && file.size > ModuleContentProtection.MaxPlainBytes + 65536L))
                throw new InvalidDataException("Module content length mismatch.");
            return file;
        }

        private byte[] ReadCore(string relativePath, long maximumStoredLength, int maximumPlainLength)
        {
            var file = Resolve(relativePath, maximumStoredLength, out string path);
            byte[] bytes;
            using (var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                if (stream.Length != file.size) throw new InvalidDataException("Module content length mismatch.");
                bytes = new byte[(int)file.size];
                int offset = 0;
                while (offset < bytes.Length)
                {
                    int count = stream.Read(bytes, offset, bytes.Length - offset);
                    if (count == 0) throw new InvalidDataException("Module content was truncated.");
                    offset += count;
                }
                if (stream.ReadByte() != -1) throw new InvalidDataException("Module content grew during reading.");
            }
            using (var sha = SHA256.Create())
                if (!BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").Equals(file.sha256, StringComparison.OrdinalIgnoreCase))
                    throw new CryptographicException("Module content hash mismatch.");
            if (!encrypted) return bytes;
            var key = new byte[32];
            try
            {
                if (!keys.CopyKey(manifest.gameId, manifest.contentKeyId, key)) throw MissingKey();
                return ModuleContentProtection.OpenBounded(manifest, relativePath, bytes, key, maximumPlainLength);
            }
            finally { Array.Clear(key, 0, key.Length); }
        }
        private static CryptographicException MissingKey() => new CryptographicException("Host does not provision the required module key.");
    }
}
