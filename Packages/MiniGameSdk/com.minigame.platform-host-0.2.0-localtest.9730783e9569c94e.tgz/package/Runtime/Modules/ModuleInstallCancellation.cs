using System;
using UnityEngine.Networking;

namespace MiniGamePlatform.HotUpdate
{
    // Host-owned request lifetime. Cancellation never touches an installed module.
    public sealed class ModuleInstallCancellation
    {
        private UnityWebRequest _request;
        public bool IsCancellationRequested { get; private set; }
        public bool IsPaused { get; private set; }
        internal int PauseVersion { get; private set; }
        public string Phase { get; internal set; } = "正在读取游戏版本…";
        public void SetPaused(bool paused)
        {
            if (IsPaused == paused) return;
            IsPaused = paused;
            if (paused) { PauseVersion++; try { _request?.Abort(); } catch (ObjectDisposedException) { } }
        }
        public void Cancel()
        {
            IsCancellationRequested = true;
            try { _request?.Abort(); } catch (ObjectDisposedException) { }
        }
        internal IDisposable Track(UnityWebRequest request)
        {
            _request = request;
            return new RequestLease(this, request);
        }
        private sealed class RequestLease : IDisposable
        {
            private readonly ModuleInstallCancellation _owner;
            private readonly UnityWebRequest _request;
            public RequestLease(ModuleInstallCancellation owner, UnityWebRequest request)
            { _owner = owner; _request = request; }
            public void Dispose() { if (ReferenceEquals(_owner._request, _request)) _owner._request = null; }
        }
    }
}
