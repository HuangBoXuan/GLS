using System;
using System.Collections.Generic;
using UnityEngine;

namespace MiniGamePlatform.HotUpdate
{
    public sealed class HostProfile
    {
        public const int ApiVersion = 7;
        private readonly HashSet<string> _capabilities;

        public int Version { get; }
        public string Platform { get; }
        public string UnityVersion { get; }

        public bool SupportsCapability(string capability)
        {
            return capability != null && _capabilities.Contains(capability) && HostCapabilityRegistry.Contains(capability, Version);
        }

        public string[] GetSupportedCapabilities()
        {
            var supported = new List<string>();
            foreach (string capability in _capabilities)
                if (SupportsCapability(capability)) supported.Add(capability);
            supported.Sort(StringComparer.Ordinal);
            return supported.ToArray();
        }

        public HostProfile(int version, string platform, string unityVersion, IEnumerable<string> capabilities)
        {
            Version = version;
            Platform = platform;
            UnityVersion = unityVersion;
            _capabilities = new HashSet<string>(capabilities ?? Array.Empty<string>(), StringComparer.Ordinal);
        }

        public static HostProfile Current => ForPlatform(Application.platform == RuntimePlatform.Android ? "android" : "editor");

        public static HostProfile ForPlatform(string platform) =>
            new HostProfile(ApiVersion, platform, Application.unityVersion, CurrentCapabilities());

        internal bool SupportsBundleOwnership(int minApiVersion, string[] capabilities)
        {
            return Version < 6 || (minApiVersion >= 6 &&
                Array.IndexOf(capabilities ?? Array.Empty<string>(), "module_owned_resources_v1") >= 0);
        }

        private static IEnumerable<string> CurrentCapabilities()
        {
            yield return "module_owned_resources_v1";
            yield return "host_native_contract_v1";
            yield return "unity_render_batch_v1";
            yield return "unity_render_batch_packed_v1";
            yield return "unity_async_asset_v1";
            yield return "lua_late_update_v1";
            yield return "unity_camera_callback_v1";
            foreach (string capability in new[] { "lua", "ugui", "sprite2d", "mesh3d", "assetbundle", "protected_content", "data_text", "presentation", "tmp_text", "presentation_surface", "world_view", NativeLuaBaseline.Capability, "unity_ugui_mesh_v1", "unity_ugui_raycast_v1" })
                yield return capability;
            if (LocalizationBaseline.IsAvailable) yield return LocalizationBaseline.Capability;
        }

        public bool Supports(ModuleManifest manifest, out string reason)
        {
            if (Version >= 6 && Array.Exists(manifest.files ?? Array.Empty<ModuleFile>(),
                file => file != null && file.path != null && file.path.EndsWith(".bundle", StringComparison.Ordinal)) &&
                !SupportsBundleOwnership(manifest.minHostApiVersion, manifest.requiredCapabilities))
            {
                reason = "AssetBundle module must be rebuilt for host API 6 and module_owned_resources_v1 ownership.";
                return false;
            }
            if (manifest.minHostApiVersion > Version)
            {
                reason = "Module needs host API " + manifest.minHostApiVersion + ".";
                return false;
            }
            if (manifest.platform != "any" && manifest.platform != Platform)
            {
                reason = "Module target platform is " + manifest.platform + ".";
                return false;
            }
            if (!string.IsNullOrEmpty(manifest.unityVersion) && manifest.unityVersion != UnityVersion)
            {
                reason = "Module Unity version is " + manifest.unityVersion + ".";
                return false;
            }
            foreach (string capability in manifest.requiredCapabilities)
            {
                if (HostCapabilityRegistry.Contains(capability, manifest.minHostApiVersion) && SupportsCapability(capability)) continue;
                reason = "Missing host capability: " + capability;
                return false;
            }
            reason = null;
            return true;
        }
    }
}
