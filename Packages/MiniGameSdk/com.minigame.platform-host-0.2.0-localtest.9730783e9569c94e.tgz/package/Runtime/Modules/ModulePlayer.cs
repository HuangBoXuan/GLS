using System;
using System.IO;
using System.Security.Cryptography;
using MiniGamePlatform.SDK;
using MiniGamePlatform.SDK.Auth;
using MiniGamePlatform.SDK.Contracts;
using UnityEngine;
using MiniGamePlatform.SDK.Host;

namespace MiniGamePlatform.HotUpdate
{
    // Both shells execute this exact path. Catalog authorization remains the caller's responsibility.
    public sealed partial class ModulePlayer : IModuleRuntime
    {
        private readonly LuaGameRunner _runner;
        private readonly string _source, _singleGameId;
        public string ManifestSha256 { get; private set; }
        public GameRunState State => _runner.State;
        public bool HasPendingExit => _runner.HasPendingExit;
        public ModuleRunException LastError => _runner.LastError;
        public int SuccessfulTicks => _runner.SuccessfulTicks;
        public string CurrentGameId => _runner.CurrentGameId;
        public void MarkHealthy(ModuleActivationStore store, ModuleReleaseSelection selection, ModuleManifest manifest, string directory)
        {
            if (store == null) throw new ArgumentNullException(nameof(store));
            store.MarkHealthy(selection, manifest, directory, _runner);
        }

        public ModulePlayer(string source = "hub", string singleGameId = null, IModuleContentKeyProvider keys = null)
            : this(source, singleGameId, keys, CommonModuleServiceFactory.CreateDefault()) { }

        public ModulePlayer(string source, string singleGameId, IModuleContentKeyProvider keys, IModuleHostServiceFactory serviceFactory)
        {
            if (source != "hub" && source != "independent") throw new ArgumentException("Player source must be hub or independent.");
            if (source == "independent" && string.IsNullOrWhiteSpace(singleGameId)) throw new ArgumentException("Independent shell needs its game ID.");
            _source = source; _singleGameId = singleGameId; _runner = new LuaGameRunner(keys, serviceFactory);
        }

        public void OpenInstalled(string directory, string expectedManifestSha256, ProductContext product,
            PlatformSession session, string levelId, Action<string> status)
        {
            if (product == null) throw new ArgumentNullException(nameof(product));
            if (expectedManifestSha256 == null || expectedManifestSha256.Length != 64) throw new InvalidDataException("Pinned manifest SHA-256 is required.");
            byte[] bytes = File.ReadAllBytes(Path.Combine(directory, "manifest.json"));
            string hash = Hash(bytes);
            if (!string.Equals(hash, expectedManifestSha256, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("Installed manifest hash differs from selected release.");
            var manifest = ModuleManifest.Parse(System.Text.Encoding.UTF8.GetString(bytes));
            EnterVerified(manifest, directory, product, session, levelId, status, hash);
        }

        // Compatibility entry for shells that already resolved the trusted release and installed manifest.
        public void Enter(ModuleManifest manifest, string directory, Action<string> status, ProductContext product, PlatformSession session)
        {
            if (manifest == null) throw new ArgumentNullException(nameof(manifest));
            byte[] bytes = File.ReadAllBytes(Path.Combine(directory, "manifest.json"));
            var stored = ModuleManifest.Parse(System.Text.Encoding.UTF8.GetString(bytes));
            if (JsonUtility.ToJson(stored) != JsonUtility.ToJson(manifest)) throw new InvalidDataException("Installed manifest differs from selected module.");
            EnterVerified(stored, directory, product, session, null, status, Hash(bytes));
        }

        private void EnterVerified(ModuleManifest manifest, string directory, ProductContext product, PlatformSession session,
            string levelId, Action<string> status, string hash)
        {
            if (product == null || !product.AllowsGame(manifest.gameId) || (_singleGameId != null && manifest.gameId != _singleGameId))
                throw new InvalidDataException("Module is not allowed by this shell.");
            ManifestSha256 = null;
            _runner.Enter(manifest, directory, status, product, session, new ModuleLaunchContext(_source, levelId, manifest.version));
            ManifestSha256 = hash;
        }
        private static string Hash(byte[] bytes)
        { using var sha = SHA256.Create(); return BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant(); }
        public void Tick() => _runner.Tick();
        public void LateTick() => _runner.LateTick();
        public void Pause() => _runner.Pause();
        public void Resume() => _runner.Resume();
        public void Exit() { _runner.Exit(); ManifestSha256 = null; }
        public void Dispose() => Exit();
    }
}
