using System;
using UnityEngine;

namespace MiniGamePlatform.SDK.Auth
{
    public sealed class AndroidKeystoreCredentialStore : ICredentialStore
    {
        public void Save(CredentialState state)
        {
            if (state == null) throw new ArgumentNullException(nameof(state));
#if UNITY_ANDROID && !UNITY_EDITOR
            using (AndroidJavaObject context = ApplicationContext())
            using (var plugin = new AndroidJavaClass("com.minigame.sdk.PlatformCredentialStore"))
                plugin.CallStatic("save", context, JsonUtility.ToJson(state));
#else
            throw new PlatformNotSupportedException("Android Keystore is available only on Android players.");
#endif
        }

        public bool TryLoad(out CredentialState state)
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            string json;
            using (AndroidJavaObject context = ApplicationContext())
            using (var plugin = new AndroidJavaClass("com.minigame.sdk.PlatformCredentialStore"))
                json = plugin.CallStatic<string>("load", context);
            state = string.IsNullOrEmpty(json) ? null : JsonUtility.FromJson<CredentialState>(json);
            if (state != null && string.IsNullOrEmpty(state.DeviceId))
                throw new InvalidOperationException("Stored credentials are incomplete.");
            return state != null;
#else
            state = null;
            throw new PlatformNotSupportedException("Android Keystore is available only on Android players.");
#endif
        }

        public void Clear()
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            using (AndroidJavaObject context = ApplicationContext())
            using (var plugin = new AndroidJavaClass("com.minigame.sdk.PlatformCredentialStore"))
                plugin.CallStatic("clear", context);
#else
            throw new PlatformNotSupportedException("Android Keystore is available only on Android players.");
#endif
        }

#if UNITY_ANDROID && !UNITY_EDITOR
        private static AndroidJavaObject ApplicationContext()
        {
            using (var unityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
            using (AndroidJavaObject activity = unityPlayer.GetStatic<AndroidJavaObject>("currentActivity"))
                return activity.Call<AndroidJavaObject>("getApplicationContext");
        }
#endif
    }
}
