using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.UI;

namespace MiniGamePlatform.HotUpdate
{
    public sealed partial class ModulePresentation
    {
        private void Surface() { Alive(); _assets.RequireCapability("presentation_surface", 5); }
        private static bool Finite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);

        public void SetImageMode(int node, string mode, bool preserveAspect)
        {
            Surface();
            if (!(Get(node).Graphic is Image image) || (mode != "simple" && mode != "sliced"))
                throw new ArgumentException("Image mode must be simple or sliced on an Image node.");
            image.type = mode == "simple" ? Image.Type.Simple : Image.Type.Sliced;
            image.preserveAspect = preserveAspect;
        }

        public void SetUvRect(int node, float x, float y, float width, float height)
        {
            Surface();
            if (!(Get(node).Graphic is RawImage image) || !Range(x, -1024, 1024) || !Range(y, -1024, 1024) ||
                !Range(Mathf.Abs(width), .0001f, 1024) || !Range(Mathf.Abs(height), .0001f, 1024))
                throw new ArgumentException("Invalid RawImage UV rectangle.");
            image.uvRect = new Rect(x, y, width, height);
        }

        public void SetGraphicMaterial(int node, string bundle, string materialAsset)
        {
            Surface(); Node n = Get(node);
            if (!(n.Graphic is Image) && !(n.Graphic is RawImage)) throw new ArgumentException("Material binding requires Image or RawImage.");
            n.Graphic.material = _assets.LoadPresentationAsset<Material>(bundle, materialAsset);
        }

        [Serializable] private sealed class MaterialBatch { public MaterialUpdate[] properties; }
        [Serializable] private sealed class MaterialUpdate
        {
            public int node, slot;
            public string property, kind, bundle, asset;
            public float value, r, g, b, a, x, y, z, w;
        }

        public void ApplyMaterialProperties(string json)
        {
            Surface();
            if (string.IsNullOrEmpty(json) || json.Length > 262144) throw new ArgumentException("Invalid material batch JSON size.");
            MaterialBatch batch;
            try { batch = JsonUtility.FromJson<MaterialBatch>(json); }
            catch (Exception e) { throw new ArgumentException("Invalid material batch JSON.", e); }
            if (batch?.properties == null || batch.properties.Length == 0 || batch.properties.Length > MaxBatch)
                throw new ArgumentException("Invalid material batch count.");
            var seen = new HashSet<string>(StringComparer.Ordinal);
            var renderers = new Renderer[batch.properties.Length];
            var textures = new Texture2D[batch.properties.Length];
            for (int i = 0; i < batch.properties.Length; i++)
            {
                MaterialUpdate u = batch.properties[i];
                if (u == null || string.IsNullOrEmpty(u.property) || u.property.Length > 128 || u.slot < 0 || u.slot > 15 ||
                    !seen.Add(u.node + "|" + u.slot + "|" + u.property)) throw new ArgumentException("Invalid or duplicate material property target.");
                Renderer renderer = renderers[i] = Get(u.node).Renderer;
                if (renderer == null) throw new ArgumentException("Material target is not a Renderer node.");
                Material[] materials = renderer.sharedMaterials;
                if (u.slot >= materials.Length || materials[u.slot] == null || materials[u.slot].shader == null)
                    throw new ArgumentException("Material slot is missing.");
                Shader shader = materials[u.slot].shader;
                int propertyIndex = shader.FindPropertyIndex(u.property);
                if (propertyIndex < 0) throw new ArgumentException("Property is not declared by the game shader: " + u.property);
                ShaderPropertyType type = shader.GetPropertyType(propertyIndex);
                bool valid;
                switch (u.kind)
                {
                    case "float": valid = (type == ShaderPropertyType.Float || type == ShaderPropertyType.Range) && Finite(u.value); break;
                    case "color": valid = type == ShaderPropertyType.Color && Finite(u.r) && Finite(u.g) && Finite(u.b) && Finite(u.a); break;
                    case "vector": valid = type == ShaderPropertyType.Vector && Finite(u.x) && Finite(u.y) && Finite(u.z) && Finite(u.w); break;
                    case "texture": valid = type == ShaderPropertyType.Texture && shader.GetPropertyTextureDimension(propertyIndex) == TextureDimension.Tex2D; break;
                    default: valid = false; break;
                }
                if (!valid) throw new ArgumentException("Shader property type or finite value mismatch: " + u.property);
            }
            // Resolve every declared texture before mutating any renderer; path/type failure is atomic too.
            for (int i = 0; i < batch.properties.Length; i++)
                if (batch.properties[i].kind == "texture")
                    textures[i] = _assets.LoadPresentationAsset<Texture2D>(batch.properties[i].bundle, batch.properties[i].asset);
            var block = new MaterialPropertyBlock();
            for (int i = 0; i < batch.properties.Length; i++)
            {
                MaterialUpdate u = batch.properties[i];
                block.Clear(); renderers[i].GetPropertyBlock(block, u.slot);
                switch (u.kind)
                {
                    case "float": block.SetFloat(u.property, u.value); break;
                    case "color": block.SetColor(u.property, new Color(u.r, u.g, u.b, u.a)); break;
                    case "vector": block.SetVector(u.property, new Vector4(u.x, u.y, u.z, u.w)); break;
                    case "texture": block.SetTexture(u.property, textures[i]); break;
                }
                renderers[i].SetPropertyBlock(block, u.slot);
            }
        }

        [Serializable] private sealed class ViewConfig
        {
            public bool orthographic;
            public float size, fov, near, far, x, y, z, rx, ry, rz, r, g, b, a;
        }
        private sealed class WorldView
        {
            public Node Ui, World;
            public Camera Camera;
            public RenderTexture Texture;
            public int Layer;
            public readonly List<Camera> MaskedCameras = new List<Camera>();
        }
        private static readonly HashSet<int> LeasedLayers = new HashSet<int>();
        private WorldView _worldView;

        public int CreateWorldView(int uiParent, int pixelWidth, int pixelHeight)
        {
            Alive(); _assets.RequireCapability("world_view", 5);
            if (_worldView != null) throw new InvalidOperationException("A module can own only one world view.");
            if (pixelWidth < 64 || pixelHeight < 64 || pixelWidth > 2048 || pixelHeight > 2048)
                throw new ArgumentException("World view dimensions must be 64..2048.");
            Budget(2); Parent(true, uiParent);
            var occupied = new HashSet<int>(LeasedLayers);
            foreach (Transform transform in UnityEngine.Object.FindObjectsOfType<Transform>(true)) occupied.Add(transform.gameObject.layer);
            int layer = -1;
            for (int candidate = 31; candidate >= 24; candidate--) if (!occupied.Contains(candidate)) { layer = candidate; break; }
            if (layer < 0) throw new InvalidOperationException("No free presentation render layer in 24..31.");
            LeasedLayers.Add(layer);
            var view = new WorldView { Layer = layer };
            try
            {
                view.Ui = Create(true, uiParent, typeof(RawImage));
                view.World = Create(false, 0); view.World.Transform.gameObject.layer = layer;
                view.Texture = new RenderTexture(pixelWidth, pixelHeight, 24, RenderTextureFormat.ARGB32) {
                    name = "Module World View", antiAliasing = 1, useMipMap = false, autoGenerateMips = false, filterMode = FilterMode.Bilinear };
                if (!view.Texture.Create()) throw new InvalidOperationException("World render target creation failed.");
                foreach (Camera camera in UnityEngine.Object.FindObjectsOfType<Camera>(true))
                    if ((camera.cullingMask & (1 << layer)) != 0)
                    { view.MaskedCameras.Add(camera); camera.cullingMask &= ~(1 << layer); }
                var go = new GameObject("Module World Camera", typeof(Camera));
                go.transform.SetParent(view.World.Transform, false);
                view.Camera = go.GetComponent<Camera>(); view.Camera.enabled = false;
                view.Camera.targetTexture = view.Texture; view.Camera.cullingMask = 1 << layer;
                view.Camera.clearFlags = CameraClearFlags.SolidColor; view.Camera.backgroundColor = Color.clear;
                view.Camera.orthographic = true; view.Camera.orthographicSize = 5;
                view.Camera.nearClipPlane = .1f; view.Camera.farClipPlane = 200;
                view.Camera.aspect = (float)pixelWidth / pixelHeight;
                view.Camera.transform.localPosition = new Vector3(0, 0, -10);
                view.Camera.allowHDR = false; view.Camera.allowMSAA = false;
                ((RawImage)view.Ui.Graphic).texture = view.Texture;
                _worldView = view;
                view.Ui.Transform.gameObject.AddComponent<PresentationWorldViewDriver>().Init(this);
                RefreshWorldView();
                return view.Ui.Id;
            }
            catch
            {
                _worldView = view; ReleaseWorldView();
                if (view.Ui != null) DestroyNode(view.Ui.Id);
                if (view.World != null) DestroyNode(view.World.Id);
                throw;
            }
        }

        private WorldView GetView(int id)
        {
            Alive(); _assets.RequireCapability("world_view", 5);
            if (_worldView == null || _worldView.Ui.Id != id) throw new ArgumentException("Invalid world view handle.");
            return _worldView;
        }

        public int GetWorldRoot(int view) => GetView(view).World.Id;

        public void ConfigureWorldView(int view, string json)
        {
            WorldView target = GetView(view);
            if (string.IsNullOrEmpty(json) || json.Length > 8192) throw new ArgumentException("Invalid camera JSON size.");
            ViewConfig c;
            try { c = JsonUtility.FromJson<ViewConfig>(json); }
            catch (Exception e) { throw new ArgumentException("Invalid camera JSON.", e); }
            if (c == null || !Range(c.size, .001f, 10000) || !Range(c.fov, 1, 179) || !Range(c.near, .001f, 100000) ||
                !Range(c.far, .001f, 100000) || c.far <= c.near || !Range(c.x, -1000000, 1000000) ||
                !Range(c.y, -1000000, 1000000) || !Range(c.z, -1000000, 1000000) ||
                !Range(c.rx, -360000, 360000) || !Range(c.ry, -360000, 360000) || !Range(c.rz, -360000, 360000) ||
                !Range(c.r, 0, 1) || !Range(c.g, 0, 1) || !Range(c.b, 0, 1) || !Range(c.a, 0, 1))
                throw new ArgumentException("Invalid camera projection, pose or background.");
            Camera camera = target.Camera;
            camera.orthographic = c.orthographic; camera.orthographicSize = c.size; camera.fieldOfView = c.fov;
            camera.nearClipPlane = c.near; camera.farClipPlane = c.far;
            camera.transform.localPosition = new Vector3(c.x, c.y, c.z);
            camera.transform.localRotation = Quaternion.Euler(c.rx, c.ry, c.rz);
            camera.backgroundColor = new Color(c.r, c.g, c.b, c.a);
        }

        internal void RefreshWorldView()
        {
            if (_worldView?.Camera == null) return;
            _worldView.Camera.enabled = !_disposed && !_paused && _worldView.Ui.Transform != null &&
                _worldView.Ui.Transform.gameObject.activeInHierarchy && _worldView.World.Transform != null && _worldView.World.Transform.gameObject.activeInHierarchy;
        }

        private void ReleaseWorldViewFor(Node root)
        {
            WorldView view = _worldView;
            if (view == null || (!view.Ui.Transform.IsChildOf(root.Transform) && !view.World.Transform.IsChildOf(root.Transform))) return;
            ReleaseWorldView();
            if (!view.Ui.Transform.IsChildOf(root.Transform)) DestroyNode(view.Ui.Id);
            if (!view.World.Transform.IsChildOf(root.Transform)) DestroyNode(view.World.Id);
        }

        private void ReleaseWorldView()
        {
            WorldView view = _worldView; _worldView = null;
            if (view == null) return;
            if (view.World?.Transform != null) view.World.Transform.gameObject.SetActive(false);
            if (view.Camera != null)
            {
                view.Camera.enabled = false; view.Camera.targetTexture = null; DestroyOwned(view.Camera.gameObject);
            }
            if (view.Ui?.Graphic is RawImage raw) raw.texture = null;
            if (view.Texture != null) { view.Texture.Release(); DestroyOwned(view.Texture); }
            foreach (Camera camera in view.MaskedCameras) if (camera != null) camera.cullingMask |= 1 << view.Layer;
            LeasedLayers.Remove(view.Layer);
        }
    }
}
