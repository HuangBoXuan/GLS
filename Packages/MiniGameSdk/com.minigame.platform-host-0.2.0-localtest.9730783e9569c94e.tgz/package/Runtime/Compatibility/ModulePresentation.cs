using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace MiniGamePlatform.HotUpdate
{
    // Scoped rendering API, not a general Unity reflection facade or a Lua sandbox.
    [UnityEngine.Scripting.Preserve]
    public sealed partial class ModulePresentation : IDisposable
    {
        public const int MaxNodes = 4096;
        public const int MaxBatch = 512;
        public const int MaxTapQueue = 128;
        private static int _nextHandle;
        private readonly GameObject _root;
        private readonly ModuleAssetScope _assets;
        private readonly Dictionary<int, Node> _nodes = new Dictionary<int, Node>();
        private readonly Dictionary<Transform, Node> _transforms = new Dictionary<Transform, Node>();
        private readonly Queue<Tap> _taps = new Queue<Tap>();
        private GameObject _canvas;
        private GameObject _ownedEventSystem;
        private bool _disposed;
        private bool _paused;
        internal int InputEpoch { get; private set; }
        public int DroppedTapCount { get; private set; }
        public int NodeCount => _nodes.Count;

        private sealed class Node
        {
            public int Id;
            public Transform Transform;
            public bool Ui;
            public int TapId;
            public int Revision;
            public Graphic Graphic;
            public Renderer Renderer;
        }
        private struct Tap { public int Node; public int LogicalId; public int Revision; }
        [Serializable] private sealed class Batch { public Update[] nodes; }
        [Serializable] private sealed class Update
        {
            public int id;
            public bool pose, rect, tint, visibility, active;
            public float x, y, z, rx, ry, rz, sx, sy, sz, width, height, r, g, b, a;
        }

        internal ModulePresentation(Transform parent, ModuleAssetScope assets)
        {
            _assets = assets;
            _root = new GameObject("Module Presentation");
            _root.transform.SetParent(parent, false);
        }

        private void Alive()
        { if (_disposed) throw new ObjectDisposedException(nameof(ModulePresentation)); }

        private Node Get(int id)
        {
            Alive();
            if (!_nodes.TryGetValue(id, out Node node) || node.Transform == null)
                throw new ArgumentException("Unknown or expired presentation node: " + id);
            return node;
        }

        private void Budget(int count)
        {
            Alive();
            if (count < 1 || count > MaxNodes - _nodes.Count) throw new InvalidOperationException("Presentation node budget exceeded.");
        }

        private Node Register(Transform value, bool ui)
        {
            int id = Interlocked.Increment(ref _nextHandle);
            if (id <= 0) throw new InvalidOperationException("Presentation handle space exhausted.");
            var node = new Node { Id = id, Transform = value, Ui = ui,
                Graphic = value.GetComponent<Graphic>(), Renderer = value.GetComponent<Renderer>() };
            if (!ui && _worldView != null && value.IsChildOf(_worldView.World.Transform)) value.gameObject.layer = _worldView.Layer;
            _nodes.Add(id, node); _transforms.Add(value, node);
            return node;
        }

        private Transform Parent(bool ui, int parent)
        {
            Alive();
            if (parent != 0)
            {
                Node node = Get(parent);
                if (node.Ui != ui) throw new ArgumentException("Cannot mix UI and world parents.");
                return node.Transform;
            }
            if (!ui) return _root.transform;
            if (_canvas == null)
            {
                _canvas = new GameObject("Presentation Canvas", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
                _canvas.transform.SetParent(_root.transform, false);
                Canvas canvas = _canvas.GetComponent<Canvas>();
                canvas.renderMode = RenderMode.ScreenSpaceOverlay; canvas.sortingOrder = 100;
                CanvasScaler scaler = _canvas.GetComponent<CanvasScaler>();
                scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
                scaler.referenceResolution = new Vector2(1080, 1920); scaler.matchWidthOrHeight = .5f;
            }
            return _canvas.transform;
        }

        private Node Create(bool ui, int parent, Type component = null)
        {
            Budget(1);
            Transform target = Parent(ui, parent);
            GameObject go = ui ? new GameObject("Presentation Node", typeof(RectTransform)) : new GameObject("Presentation Node");
            try
            {
                go.transform.SetParent(target, false);
                if (ui)
                {
                    var rect = (RectTransform)go.transform;
                    rect.anchorMin = rect.anchorMax = rect.pivot = new Vector2(.5f, .5f);
                }
                if (component != null) go.AddComponent(component);
                Node node = Register(go.transform, ui);
                go.name = "Presentation Node " + node.Id;
                if (node.Graphic != null) node.Graphic.raycastTarget = false;
                return node;
            }
            catch { DestroyOwned(go); throw; }
        }

        public int CreateGroup(bool ui, int parent) => Create(ui, parent).Id;
        public int CreateImage(int parent) => Create(true, parent, typeof(Image)).Id;
        public int CreateRawImage(int parent) => Create(true, parent, typeof(RawImage)).Id;

        private static void TextValue(string text, int fontSize = 1)
        {
            if (text == null || text.Length > 2048 || fontSize < 1 || fontSize > 256)
                throw new ArgumentException("Invalid text or font size.");
        }

        public int CreateText(int parent, string text, int fontSize)
        {
            Alive(); TextValue(text, fontSize);
            Node node = Create(true, parent, typeof(Text));
            var label = (Text)node.Graphic;
            label.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            label.fontSize = fontSize; label.supportRichText = false; label.text = text;
            label.alignment = TextAnchor.MiddleCenter;
            return node.Id;
        }

        public int CreateTmpText(int parent, string bundle, string fontAsset, string text, int fontSize)
        {
            Alive(); TextValue(text, fontSize); Budget(1); Parent(true, parent);
            _assets.RequireCapability("tmp_text", 4);
            if (TMP_Settings.LoadDefaultSettings() == null)
                throw new InvalidOperationException("Host must import TMP Essential Resources before using tmp_text.");
            TMP_FontAsset font = _assets.LoadPresentationAsset<TMP_FontAsset>(bundle, fontAsset);
            Node node = Create(true, parent, typeof(TextMeshProUGUI));
            var label = (TextMeshProUGUI)node.Graphic;
            label.font = font; label.fontSize = fontSize; label.richText = false; label.text = text;
            label.alignment = TextAlignmentOptions.Center;
            return node.Id;
        }

        public void SetText(int node, string text)
        {
            Node target = Get(node); TextValue(text);
            if (target.Graphic is Text label) label.text = text;
            else if (target.Graphic is TMP_Text tmp) tmp.text = text;
            else throw new ArgumentException("Node is not a text label.");
        }

        public void SetImage(int node, string bundle, string asset)
        {
            Node target = Get(node);
            if (_worldView != null && _worldView.Ui.Id == node) throw new ArgumentException("World view texture is owned by its camera.");
            if (target.Graphic is Image image) image.sprite = _assets.LoadPresentationAsset<Sprite>(bundle, asset);
            else if (target.Graphic is RawImage raw) raw.texture = _assets.LoadPresentationAsset<Texture2D>(bundle, asset);
            else throw new ArgumentException("Node is not an Image or RawImage.");
        }

        // Validate the source before Instantiate: a rejected MonoBehaviour must never get Awake/OnEnable.
        internal static Transform[] ValidatePrefab(GameObject prefab)
        {
            Transform[] transforms = prefab.GetComponentsInChildren<Transform>(true);
            if (transforms.Length > MaxNodes) throw new InvalidDataException("Prefab exceeds node budget.");
            foreach (Component component in prefab.GetComponentsInChildren<Component>(true))
            {
                if (component == null) throw new InvalidDataException("Prefab contains a missing script.");
                Type type = component.GetType();
                if (type != typeof(Transform) && type != typeof(MeshFilter) && type != typeof(MeshRenderer) &&
                    type != typeof(SkinnedMeshRenderer) && type != typeof(SpriteRenderer))
                    throw new InvalidDataException("Unsupported presentation prefab component: " + type.FullName);
                if (component is SkinnedMeshRenderer skin)
                {
                    if (skin.rootBone != null && !skin.rootBone.IsChildOf(prefab.transform))
                        throw new InvalidDataException("Skinned root bone is outside prefab.");
                    foreach (Transform bone in skin.bones)
                        if (bone != null && !bone.IsChildOf(prefab.transform)) throw new InvalidDataException("Skinned bone is outside prefab.");
                }
            }
            return transforms;
        }

        public int CreatePrefab(int parent, string bundle, string asset)
        {
            Alive(); Transform target = Parent(false, parent);
            GameObject prefab = _assets.LoadPresentationAsset<GameObject>(bundle, asset);
            Transform[] source = ValidatePrefab(prefab); Budget(source.Length);
            GameObject instance = UnityEngine.Object.Instantiate(prefab, target, false);
            foreach (Transform transform in instance.GetComponentsInChildren<Transform>(true)) Register(transform, false);
            return _transforms[instance.transform].Id;
        }

        public int FindNode(int parent, string relativePath)
        {
            Node node = Get(parent);
            if (node.Ui || string.IsNullOrEmpty(relativePath) || relativePath.Length > 512 || relativePath.Contains("\\"))
                throw new ArgumentException("Invalid world child path.");
            Transform current = node.Transform;
            foreach (string part in relativePath.Split('/'))
            {
                if (part.Length == 0 || part == "." || part == "..") throw new ArgumentException("Invalid child path segment.");
                Transform match = null;
                foreach (Transform child in current)
                    if (child.name == part)
                    {
                        if (match != null) throw new ArgumentException("Ambiguous child name: " + part);
                        match = child;
                    }
                if (match == null) throw new ArgumentException("Missing child: " + part);
                current = match;
            }
            if (!_transforms.TryGetValue(current, out Node result)) throw new ArgumentException("Child is not owned by this presentation.");
            return result.Id;
        }

        private static bool Range(float value, float min, float max) => !float.IsNaN(value) && !float.IsInfinity(value) && value >= min && value <= max;
        private static bool Scale(float value) => Range(Mathf.Abs(value), .0001f, 1000);

        public void ApplyNodes(string json)
        {
            Alive();
            if (string.IsNullOrEmpty(json) || json.Length > 262144) throw new ArgumentException("Invalid update JSON size.");
            Batch batch;
            try { batch = JsonUtility.FromJson<Batch>(json); }
            catch (Exception error) { throw new ArgumentException("Invalid update JSON.", error); }
            if (batch?.nodes == null || batch.nodes.Length == 0 || batch.nodes.Length > MaxBatch) throw new ArgumentException("Invalid update batch.");
            var seen = new HashSet<int>();
            var targets = new Node[batch.nodes.Length];
            for (int i = 0; i < batch.nodes.Length; i++)
            {
                Update u = batch.nodes[i];
                if (u == null || !seen.Add(u.id)) throw new ArgumentException("Null or duplicate node update.");
                Node n = targets[i] = Get(u.id);
                if (u.pose && !(Range(u.x, -1000000, 1000000) && Range(u.y, -1000000, 1000000) && Range(u.z, -1000000, 1000000) &&
                    Range(u.rx, -360000, 360000) && Range(u.ry, -360000, 360000) && Range(u.rz, -360000, 360000) && Scale(u.sx) && Scale(u.sy) && Scale(u.sz)))
                    throw new ArgumentException("Invalid node pose.");
                if (u.rect && (!n.Ui || !Range(u.width, 0, 16384) || !Range(u.height, 0, 16384))) throw new ArgumentException("Invalid UI rectangle.");
                if (u.tint && ((n.Graphic == null && n.Renderer == null) || !(Range(u.r, 0, 1) && Range(u.g, 0, 1) && Range(u.b, 0, 1) && Range(u.a, 0, 1))))
                    throw new ArgumentException("Invalid tint target or color.");
            }
            for (int i = 0; i < batch.nodes.Length; i++)
            {
                Update u = batch.nodes[i]; Node n = targets[i];
                if (u.pose)
                {
                    n.Transform.localPosition = new Vector3(u.x, u.y, u.z);
                    n.Transform.localRotation = Quaternion.Euler(u.rx, u.ry, u.rz);
                    n.Transform.localScale = new Vector3(u.sx, u.sy, u.sz);
                }
                if (u.rect) ((RectTransform)n.Transform).sizeDelta = new Vector2(u.width, u.height);
                if (u.tint)
                {
                    var color = new Color(u.r, u.g, u.b, u.a);
                    if (n.Graphic != null) n.Graphic.color = color;
                    else if (n.Renderer is SpriteRenderer sprite) sprite.color = color;
                    else
                    {
                        var properties = new MaterialPropertyBlock();
                        n.Renderer.GetPropertyBlock(properties);
                        properties.SetColor("_Color", color); properties.SetColor("_BaseColor", color);
                        n.Renderer.SetPropertyBlock(properties);
                    }
                }
                if (u.visibility)
                {
                    if (!u.active)
                        foreach (Node child in _nodes.Values)
                            if (child.TapId > 0 && child.Transform.IsChildOf(n.Transform)) child.Revision++;
                    n.Transform.gameObject.SetActive(u.active);
                    RefreshWorldView();
                }
            }
        }

        public void BindTap(int node, int logicalId)
        {
            Node n = Get(node);
            if (!(n.Graphic is Image) && !(n.Graphic is RawImage)) throw new ArgumentException("Only Image/RawImage support taps.");
            if (logicalId <= 0) throw new ArgumentException("Tap ID must be positive.");
            if (EventSystem.current == null)
            {
                if (_ownedEventSystem == null)
                {
                    _ownedEventSystem = new GameObject("Presentation EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
                    _ownedEventSystem.transform.SetParent(_root.transform, false);
                }
            }
            n.Revision++; n.TapId = logicalId; n.Graphic.raycastTarget = true;
            var receiver = n.Transform.GetComponent<PresentationTapReceiver>() ?? n.Transform.gameObject.AddComponent<PresentationTapReceiver>();
            receiver.Init(this, node);
        }

        public void UnbindTap(int node)
        {
            Node n = Get(node); n.Revision++; n.TapId = 0;
            if (n.Graphic != null) n.Graphic.raycastTarget = false;
        }

        internal int InputRevision(int id)
        {
            if (_disposed || _paused || !_nodes.TryGetValue(id, out Node n) || n.Transform == null || !n.Transform.gameObject.activeInHierarchy || n.TapId <= 0) return -1;
            return n.Revision;
        }

        internal void InvalidateInput(int id)
        { if (_nodes.TryGetValue(id, out Node n)) n.Revision++; }

        internal void ReceiveTap(int id, int epoch, int revision)
        {
            if (epoch != InputEpoch || revision < 0 || InputRevision(id) != revision) return;
            PruneTaps();
            if (_taps.Count >= MaxTapQueue) { if (DroppedTapCount < int.MaxValue) DroppedTapCount++; return; }
            Node n = _nodes[id];
            _taps.Enqueue(new Tap { Node = id, LogicalId = n.TapId, Revision = n.Revision });
        }

        private void PruneTaps()
        {
            int count = _taps.Count;
            for (int i = 0; i < count; i++)
            {
                Tap tap = _taps.Dequeue();
                if (InputRevision(tap.Node) == tap.Revision) _taps.Enqueue(tap);
            }
        }

        public int PollTap()
        {
            Alive();
            while (_taps.Count > 0)
            {
                Tap tap = _taps.Dequeue();
                if (InputRevision(tap.Node) == tap.Revision) return tap.LogicalId;
            }
            return 0;
        }

        internal void SetPaused(bool paused)
        {
            if (_disposed || _paused == paused) return;
            _paused = paused; InputEpoch++; _taps.Clear();
            RefreshWorldView();
        }

        public void DestroyNode(int node)
        {
            Node root = Get(node);
            ReleaseWorldViewFor(root);
            var remove = new List<Node>();
            foreach (Node candidate in _nodes.Values)
                if (candidate.Transform == root.Transform || candidate.Transform.IsChildOf(root.Transform)) remove.Add(candidate);
            root.Transform.gameObject.SetActive(false);
            foreach (Node n in remove) { _nodes.Remove(n.Id); _transforms.Remove(n.Transform); }
            DestroyOwned(root.Transform.gameObject); PruneTaps();
        }

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true; InputEpoch++; _taps.Clear();
            ReleaseWorldView();
            if (_root != null) _root.SetActive(false);
            _nodes.Clear(); _transforms.Clear();
            DestroyOwned(_root);
        }

        private static void DestroyOwned(UnityEngine.Object value)
        {
            if (value == null) return;
#if UNITY_EDITOR
            if (!Application.isPlaying) { UnityEngine.Object.DestroyImmediate(value); return; }
#endif
            UnityEngine.Object.Destroy(value);
        }
    }
}
