using System;
using UnityEngine;
using MiniGamePlatform.Components;
namespace MiniGamePlatform.HotUpdate
{
    // Retained solely for existing first-party samples; new games use native Unity APIs.
    public sealed partial class GameHostBridge
    {
        private Camera _camera;
        private Vector3 _cameraPosition;
        private Quaternion _cameraRotation;
        private bool _wasOrthographic;
        private Texture2D[] _textures;
        private Sprite[] _sprites;
        private Material _cubeMaterial;
        private ModulePresentation _presentation;
        private bool _presentationPaused;
        [UnityEngine.Scripting.Preserve]
        public ModulePresentation Presentation
        {
            get
            {
                if (_disposed) throw new ObjectDisposedException(nameof(GameHostBridge));
                if (_assets == null || CurrentGameId != _assets.GameId) throw new InvalidOperationException("Presentation module scope is unavailable or mismatched.");
                _assets.RequireCapability("presentation", 4);
                if (_presentation == null)
                {
                    _presentation = new ModulePresentation(_root.transform, _assets);
                    _presentation.SetPaused(_presentationPaused);
                }
                return _presentation;
            }
        }

        internal void SetPresentationPaused(bool paused)
        { _presentationPaused = paused; _presentation?.SetPaused(paused); }
        private void InitializeCompatibility()
        {
            _camera = Camera.main;
            if (_camera != null)
            {
                _cameraPosition = _camera.transform.position;
                _cameraRotation = _camera.transform.rotation;
                _wasOrthographic = _camera.orthographic;
            }
        }

        public void Show2D()
        {
            if (_camera != null)
            {
                _camera.orthographic = true;
                _camera.transform.SetPositionAndRotation(new Vector3(0, 0, -10), Quaternion.identity);
            }
            _textures = new Texture2D[2];
            _sprites = new Sprite[2];
            for (int i = 0; i < 2; i++)
            {
                Texture2D texture = new Texture2D(2, 2);
                Color color = i == 0 ? Color.cyan : Color.magenta;
                texture.SetPixels(new[] { color, color, color, color });
                texture.Apply();
                _textures[i] = texture;
                _sprites[i] = Sprite.Create(texture, new Rect(0, 0, 2, 2), new Vector2(.5f, .5f), 1);
            }
            GameObject marker = new GameObject("2D Sprite");
            marker.transform.SetParent(_root.transform, false);
            marker.AddComponent<SpriteRenderer>().sprite = _sprites[0];
            marker.AddComponent<SpriteFramePlayer>().Init(_sprites, 2);
        }

        public void Show3D()
        {
            if (_camera != null)
            {
                _camera.orthographic = false;
                _camera.transform.SetPositionAndRotation(new Vector3(0, 0, -8), Quaternion.identity);
            }
            GameObject cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
            cube.name = "3D Cube";
            cube.transform.SetParent(_root.transform, false);
            Shader shader = Resources.Load<Shader>("MiniGamePlatform/FlatColor");
            if (shader == null) throw new InvalidOperationException("Built-in 3D demo shader is missing.");
            _cubeMaterial = new Material(shader) { color = Color.green };
            cube.GetComponent<MeshRenderer>().sharedMaterial = _cubeMaterial;
            cube.AddComponent<AutoRotate>();
        }

        private void DisposeCompatibility()
        {
            _presentation?.Dispose();
            if (_camera != null)
            {
                _camera.orthographic = _wasOrthographic;
                _camera.transform.SetPositionAndRotation(_cameraPosition, _cameraRotation);
            }
            DestroyOwned(_cubeMaterial);
            if (_sprites != null)
                foreach (Sprite sprite in _sprites) DestroyOwned(sprite);
            if (_textures != null)
                foreach (Texture2D texture in _textures) DestroyOwned(texture);
        }
    }
}
