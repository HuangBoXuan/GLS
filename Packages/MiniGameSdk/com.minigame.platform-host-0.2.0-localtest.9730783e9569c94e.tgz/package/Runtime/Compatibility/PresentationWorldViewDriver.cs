using UnityEngine;

namespace MiniGamePlatform.HotUpdate
{
    [AddComponentMenu("")]
    internal sealed class PresentationWorldViewDriver : MonoBehaviour
    {
        private ModulePresentation _owner;
        internal void Init(ModulePresentation owner) { _owner = owner; }
        private void OnEnable() { _owner?.RefreshWorldView(); }
        private void OnDisable() { _owner?.RefreshWorldView(); }
        private void LateUpdate() { _owner?.RefreshWorldView(); }
        private void OnDestroy() { _owner = null; }
    }
}
