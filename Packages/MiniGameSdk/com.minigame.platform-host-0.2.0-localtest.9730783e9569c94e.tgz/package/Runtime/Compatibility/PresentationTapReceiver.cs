using UnityEngine;
using UnityEngine.EventSystems;

namespace MiniGamePlatform.HotUpdate
{
    // No Lua delegates survive an event frame or a module exit.
    [AddComponentMenu("")]
    internal sealed class PresentationTapReceiver : MonoBehaviour, IPointerDownHandler, IPointerClickHandler
    {
        private ModulePresentation _owner;
        private int _node, _epoch, _revision, _pointer;
        private bool _armed;
        internal void Init(ModulePresentation owner, int node) { _owner = owner; _node = node; _armed = false; }
        public void OnPointerDown(PointerEventData data)
        {
            _armed = false;
            if (_owner == null || data == null || data.button != PointerEventData.InputButton.Left) return;
            _epoch = _owner.InputEpoch; _revision = _owner.InputRevision(_node); _pointer = data.pointerId;
            _armed = _revision >= 0;
        }
        public void OnPointerClick(PointerEventData data)
        {
            if (!_armed || data == null || data.pointerId != _pointer || data.button != PointerEventData.InputButton.Left) return;
            _armed = false; _owner?.ReceiveTap(_node, _epoch, _revision);
        }
        private void OnDisable() { _armed = false; _owner?.InvalidateInput(_node); }
        private void OnDestroy() { _owner = null; }
    }
}
