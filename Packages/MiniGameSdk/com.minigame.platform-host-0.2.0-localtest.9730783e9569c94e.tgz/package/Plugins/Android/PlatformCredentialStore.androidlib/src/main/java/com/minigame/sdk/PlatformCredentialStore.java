package com.minigame.sdk;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.AtomicFile;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public final class PlatformCredentialStore {
    private static final String KEY_ALIAS = "minigame.platform.credentials.v1";
    private static final String FILE_NAME = "minigame-platform-credentials.enc";

    private PlatformCredentialStore() {}

    public static synchronized void save(Context context, String plaintext) throws Exception {
        if (plaintext == null) throw new IllegalArgumentException("Credential payload is required");
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey());
        byte[] iv = cipher.getIV();
        byte[] encrypted = cipher.doFinal(plaintext.getBytes("UTF-8"));
        AtomicFile file = new AtomicFile(new File(context.getNoBackupFilesDir(), FILE_NAME));
        FileOutputStream output = file.startWrite();
        try {
            DataOutputStream data = new DataOutputStream(output);
            data.writeInt(iv.length);
            data.write(iv);
            data.writeInt(encrypted.length);
            data.write(encrypted);
            data.flush();
            file.finishWrite(output);
        } catch (Exception error) {
            file.failWrite(output);
            throw error;
        }
    }

    public static synchronized String load(Context context) throws Exception {
        AtomicFile file = new AtomicFile(new File(context.getNoBackupFilesDir(), FILE_NAME));
        if (!file.getBaseFile().exists()) return null;
        try (FileInputStream input = file.openRead(); DataInputStream data = new DataInputStream(input)) {
            int ivLength = data.readInt();
            if (ivLength < 12 || ivLength > 16) throw new IllegalStateException("Invalid credential IV");
            byte[] iv = new byte[ivLength];
            data.readFully(iv);
            int encryptedLength = data.readInt();
            if (encryptedLength < 16 || encryptedLength > 65536) throw new IllegalStateException("Invalid credential payload length");
            byte[] encrypted = new byte[encryptedLength];
            data.readFully(encrypted);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, getExistingKey(), new GCMParameterSpec(128, iv));
            return new String(cipher.doFinal(encrypted), "UTF-8");
        }
    }

    public static synchronized void clear(Context context) {
        new AtomicFile(new File(context.getNoBackupFilesDir(), FILE_NAME)).delete();
    }

    private static SecretKey getExistingKey() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        SecretKey key = (SecretKey) store.getKey(KEY_ALIAS, null);
        if (key == null) throw new IllegalStateException("Credential key is missing");
        return key;
    }

    private static SecretKey getOrCreateKey() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        SecretKey existing = (SecretKey) store.getKey(KEY_ALIAS, null);
        if (existing != null) return existing;
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build());
        return generator.generateKey();
    }
}
