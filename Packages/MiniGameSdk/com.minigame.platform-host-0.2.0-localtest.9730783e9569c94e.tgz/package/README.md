# MiniGame 共用 Unity 宿主 0.2.0

综合包与独立包共用的 Unity/xLua 运行实现：播放器、原生组件与 AOT、产品服务装配、签名目录、下载和安装、资源解密、Bundle 共享租约和退出回收。只依赖核心 SDK，不依赖开发工具。

宿主 API 6。含 Bundle 的模块须用新版工具重建，并声明 minHostApiVersion=6 和 module_owned_resources_v1。资源文件不能给旧 APK 增添未编入的 C# 类型或原生插件。

SpawnPrefab 自动登记实例；自行创建的节点放在 host.Root 下，或调用 TrackInstance。LoadAsset 返回作用域借用资产，不能跨模块缓存或自行销毁；游戏自建材质等非节点资源由游戏清理。最后 Bundle 租约仅在 VM 退出与实例销毁完成后 Unload(true)。

Exit 发起退场，必须等待 HasPendingExit=false 再进入下一款。持久回收驱动负责延迟销毁和 VM 失败退避重试；不能用全局 UnloadAllAssetBundles 或每帧主动 Exit 掩盖遗漏回调。

Compatibility 内保留旧表现桥供历史演示迁移，新游戏优先使用原生 Unity 与 UGUI。核心 SDK 不规定材质、颜色和美术风格。

共用账号页面 `MiniGamePlatform.Host.UI.PlatformAccountPanel` 位于 Runtime/UI，产品壳可用 `Create(canvas.transform, font)` 创建 UGUI 面板，订阅 LoginRequested、BindRequested、ContinueGuestRequested、RetryRequested 与 CloseRequested，再连接同一个 PlatformSession。组件处理输入与页面状态；认证与令牌仍由核心 SDK 负责。完整接入说明见工程 `docs/architecture/ugui-account-flow-2026-10-01.md`。
